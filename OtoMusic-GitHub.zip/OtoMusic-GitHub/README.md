# OtoMusic — Decompiled Project

This repository contains the decompiled output of the supplied Oto Music APK.

## Important

This is **not the original Android Studio source project**. It contains decompiled Java sources, Smali, and extracted APK resources.

Current layout:

- `sources/` — JADX/decompiler-readable Java sources
- `smali/` — Smali bytecode representation
- `resources/` — extracted APK resources and manifest

Because the original Gradle project files and some build-time metadata are not present in the APK, this tree is not guaranteed to build directly in Android Studio.

For inspection/editing, open the repository as a folder in Android Studio or use Android Studio's APK/decompiled-code tooling. A fully buildable project requires reconstructing the Gradle configuration and resolving dependencies from the original build.
