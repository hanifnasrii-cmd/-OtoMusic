package defpackage;

import androidx.appcompat.widget.AppCompatTextView;

/* JADX INFO: renamed from: а͑, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1405 extends C1339 {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ AppCompatTextView f15871a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1405(AppCompatTextView appCompatTextView) {
        super(appCompatTextView);
        this.f15871a = appCompatTextView;
    }

    @Override // defpackage.C1339, defpackage.InterfaceC1404
    /* JADX INFO: renamed from: ȧ */
    public final void mo7488a(int i, float f) {
        super/*android.widget.TextView*/.setLineHeight(i, f);
    }
}
