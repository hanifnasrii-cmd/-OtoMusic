package defpackage;

import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: pܻ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C6243p extends AbstractC2015 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final ArrayList f11048a = new ArrayList();

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final LinkedHashMap f11049a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final LinkedHashMap f11050a;

    public C6243p(List list) {
        List list2 = list;
        int iM5979a = AbstractC0214.m5979a(AbstractC2853.m9682a(list2, 10));
        LinkedHashMap linkedHashMap = new LinkedHashMap(iM5979a < 16 ? 16 : iM5979a);
        for (Object obj : list2) {
            linkedHashMap.put(((AbstractC6242p) obj).f11047a, obj);
        }
        this.f11049a = linkedHashMap;
        LinkedHashMap linkedHashMap2 = new LinkedHashMap(AbstractC0214.m5979a(linkedHashMap.size()));
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            linkedHashMap2.put(Integer.valueOf(((AbstractC6242p) entry.getValue()).mo4348a()), entry.getValue());
        }
        this.f11050a = linkedHashMap2;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ā */
    public final int mo1074a() {
        return this.f11048a.size();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ă */
    public final int mo3940a(int i) {
        return ((AbstractC6242p) AbstractC0214.m5978a(this.f11048a.get(i).getClass(), this.f11049a)).mo4348a();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̋ */
    public final void mo1037a(AbstractC2042 abstractC2042, int i) {
        int iMo3940a = mo3940a(i);
        ((AbstractC6242p) AbstractC0214.m5978a(Integer.valueOf(iMo3940a), this.f11050a)).mo4346a(abstractC2042, this.f11048a.get(i));
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̍ */
    public final AbstractC2042 mo1039a(ViewGroup viewGroup, int i) {
        return ((AbstractC6242p) AbstractC0214.m5978a(Integer.valueOf(i), this.f11050a)).mo4347a(viewGroup);
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̐ */
    public final void mo3942a(AbstractC2042 abstractC2042) {
        int i = abstractC2042.f18151a;
        ((AbstractC6242p) AbstractC0214.m5978a(Integer.valueOf(i), this.f11050a)).getClass();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ȃ */
    public final void mo1059a(AbstractC2042 abstractC2042) {
        int i = abstractC2042.f18151a;
        ((AbstractC6242p) AbstractC0214.m5978a(Integer.valueOf(i), this.f11050a)).getClass();
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final void m5395a(List list) {
        ArrayList arrayList = this.f11048a;
        arrayList.clear();
        arrayList.addAll(list);
        m8394a();
    }
}
