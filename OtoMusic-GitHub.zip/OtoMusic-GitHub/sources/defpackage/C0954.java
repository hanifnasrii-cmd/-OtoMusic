package defpackage;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.RemoteException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: renamed from: ρ⃮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0954 {

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static final HashMap f14325a = new HashMap();

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f14326a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C5948o f14327a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f14332a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final Intent f14333a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public ServiceConnectionC0917 f14337a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public InterfaceC0723 f14338a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final ArrayList f14329a = new ArrayList();

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final HashSet f14330a = new HashSet();

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Object f14331a = new Object();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final C0835 f14335a = new IBinder.DeathRecipient() { // from class: ρؕ
        @Override // android.os.IBinder.DeathRecipient
        public final void binderDied() {
            C0954 c0954 = this.f14098a;
            int i = 0;
            c0954.f14327a.m4909a("reportBinderDeath", new Object[0]);
            AbstractC4164a.m1000a(c0954.f14334a.get());
            c0954.f14327a.m4909a("%s : Binder has died.", c0954.f14328a);
            ArrayList arrayList = c0954.f14329a;
            int size = arrayList.size();
            while (i < size) {
                Object obj = arrayList.get(i);
                i++;
                RemoteException remoteException = new RemoteException(String.valueOf(c0954.f14328a).concat(" : Binder has died."));
                C3943 c3943 = ((AbstractRunnableC0814) obj).f14065a;
                if (c3943 != null) {
                    c3943.m11096a(remoteException);
                }
            }
            c0954.f14329a.clear();
            synchronized (c0954.f14331a) {
                c0954.m7028a();
            }
        }
    };

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final AtomicInteger f14336a = new AtomicInteger(0);

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f14328a = "com.google.android.finsky.inappreviewservice.InAppReviewService";

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final WeakReference f14334a = new WeakReference(null);

    /* JADX WARN: Type inference failed for: r0v3, types: [ρؕ] */
    public C0954(Context context, C5948o c5948o, Intent intent) {
        this.f14326a = context;
        this.f14327a = c5948o;
        this.f14333a = intent;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static void m7026a(C0954 c0954, C0726 c0726) {
        InterfaceC0723 interfaceC0723 = c0954.f14338a;
        C5948o c5948o = c0954.f14327a;
        ArrayList arrayList = c0954.f14329a;
        int i = 0;
        if (interfaceC0723 != null || c0954.f14332a) {
            if (!c0954.f14332a) {
                c0726.run();
                return;
            } else {
                c5948o.m4909a("Waiting to bind to the service.", new Object[0]);
                arrayList.add(c0726);
                return;
            }
        }
        c5948o.m4909a("Initiate binding to the service.", new Object[0]);
        arrayList.add(c0726);
        ServiceConnectionC0917 serviceConnectionC0917 = new ServiceConnectionC0917(c0954);
        c0954.f14337a = serviceConnectionC0917;
        c0954.f14332a = true;
        if (c0954.f14326a.bindService(c0954.f14333a, serviceConnectionC0917, 1)) {
            return;
        }
        c5948o.m4909a("Failed to bind to the service.", new Object[0]);
        c0954.f14332a = false;
        int size = arrayList.size();
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            C2895 c2895 = new C2895(13);
            C3943 c3943 = ((AbstractRunnableC0814) obj).f14065a;
            if (c3943 != null) {
                c3943.m11096a(c2895);
            }
        }
        arrayList.clear();
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Handler m7027a() {
        Handler handler;
        HashMap map = f14325a;
        synchronized (map) {
            try {
                if (!map.containsKey(this.f14328a)) {
                    HandlerThread handlerThread = new HandlerThread(this.f14328a, 10);
                    handlerThread.start();
                    map.put(this.f14328a, new Handler(handlerThread.getLooper()));
                }
                handler = (Handler) map.get(this.f14328a);
            } catch (Throwable th) {
                throw th;
            }
        }
        return handler;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m7028a() {
        HashSet hashSet = this.f14330a;
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            ((C3943) it.next()).m11096a(new RemoteException(String.valueOf(this.f14328a).concat(" : Binder has died.")));
        }
        hashSet.clear();
    }
}
