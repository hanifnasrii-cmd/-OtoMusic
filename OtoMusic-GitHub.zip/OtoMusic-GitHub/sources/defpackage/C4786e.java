package defpackage;

/* JADX INFO: renamed from: e͟, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4786e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f6024a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f6025a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f6026a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final boolean f6027a;

    public C4786e(int i, int i2, int i3, boolean z) {
        this.f6024a = i;
        this.f6025a = i2;
        this.f6026a = i3;
        this.f6027a = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C4786e)) {
            return false;
        }
        C4786e c4786e = (C4786e) obj;
        return this.f6024a == c4786e.f6024a && this.f6025a == c4786e.f6025a && this.f6026a == c4786e.f6026a && this.f6027a == c4786e.f6027a;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f6027a) + AbstractC4164a.m975a(this.f6026a, AbstractC4164a.m975a(this.f6025a, Integer.hashCode(this.f6024a) * 31, 31), 31);
    }

    public final String toString() {
        StringBuilder sbM751a = AbstractC4072a.m751a("RowSpec(id=", this.f6024a, ", label=", this.f6025a, ", icon=");
        sbM751a.append(this.f6026a);
        sbM751a.append(", hasCount=");
        sbM751a.append(this.f6027a);
        sbM751a.append(")");
        return sbM751a.toString();
    }
}
