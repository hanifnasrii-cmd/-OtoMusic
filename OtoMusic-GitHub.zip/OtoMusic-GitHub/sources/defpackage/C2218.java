package defpackage;

import java.security.MessageDigest;

/* JADX INFO: renamed from: оܻ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2218 implements InterfaceC1696 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final MessageDigest f18723a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C3742 f18724a = new C3742();

    public C2218(MessageDigest messageDigest) {
        this.f18723a = messageDigest;
    }

    @Override // defpackage.InterfaceC1696
    /* JADX INFO: renamed from: á */
    public final C3742 mo3116a() {
        return this.f18724a;
    }
}
