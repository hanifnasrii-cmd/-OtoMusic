package defpackage;

import com.piyush.music.R;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: renamed from: e֨, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4831e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final int[] f6156a = {R.attr.mo};

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final Map f6157a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final Map f6158a;

    static {
        C4828e c4828e = new C4828e();
        C4829e c4829e = new C4829e();
        HashMap map = new HashMap();
        map.put("fcnt", c4828e);
        map.put("google", c4828e);
        map.put("hmd global", c4828e);
        map.put("infinix", c4828e);
        map.put("infinix mobility limited", c4828e);
        map.put("itel", c4828e);
        map.put("kyocera", c4828e);
        map.put("lenovo", c4828e);
        map.put("lge", c4828e);
        map.put("meizu", c4828e);
        map.put("motorola", c4828e);
        map.put("nothing", c4828e);
        map.put("oneplus", c4828e);
        map.put("oppo", c4828e);
        map.put("realme", c4828e);
        map.put("robolectric", c4828e);
        map.put("samsung", c4829e);
        map.put("sharp", c4828e);
        map.put("shift", c4828e);
        map.put("sony", c4828e);
        map.put("tcl", c4828e);
        map.put("tecno", c4828e);
        map.put("tecno mobile limited", c4828e);
        map.put("vivo", c4828e);
        map.put("wingtech", c4828e);
        map.put("xiaomi", c4828e);
        f6157a = Collections.unmodifiableMap(map);
        HashMap map2 = new HashMap();
        map2.put("asus", c4828e);
        map2.put("jio", c4828e);
        f6158a = Collections.unmodifiableMap(map2);
    }

    /* JADX WARN: Removed duplicated region for block: B:118:0x01e5 A[Catch: Exception -> 0x019c, TRY_ENTER, TryCatch #2 {Exception -> 0x019c, blocks: (B:79:0x0186, B:85:0x0198, B:98:0x01c4, B:118:0x01e5, B:119:0x01e8), top: B:130:0x0186 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0080  */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void m2993a(defpackage.AbstractActivityC4023a r17, defpackage.C4832e r18) {
        /*
            Method dump skipped, instruction units count: 520
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.AbstractC4831e.m2993a(a̎, e֩):void");
    }
}
