package defpackage;

/* JADX INFO: renamed from: оⷱ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C2302 extends AbstractC5067i implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C2302 f18988a = new C2302(1, AbstractC2290.class, "normalizeForSearch", "normalizeForSearch(Ljava/lang/String;)Ljava/lang/String;", 1);

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        return AbstractC2290.m8729a((String) obj);
    }
}
