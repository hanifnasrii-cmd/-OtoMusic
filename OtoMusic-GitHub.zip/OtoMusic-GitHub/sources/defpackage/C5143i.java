package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: renamed from: i֖, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5143i {

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public static final /* synthetic */ int f7197a = 0;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C2064 f7200a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C5433j f7201a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public AbstractC5424j f7202a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public C5431j f7203a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final Context f7204a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final C0091 f7211a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final C5138i f7212a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final boolean f7213a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final boolean f7214a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public C5389j f7215a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final C5695o f7216a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final C5436j f7217a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public C5438j f7218a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public C5433j f7219a;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public C5433j f7220a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public C5433j f7221a;

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public AbstractC5423j f7222a;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public C5407j f7223a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public C5407j f7224a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public int f7225a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public C5924o f7226a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public C5454j f7227a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public final C5138i f7228a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final HandlerC5139i f7198a = new HandlerC5139i(this);

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final HashMap f7199a = new HashMap();

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final ArrayList f7205a = new ArrayList();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final ArrayList f7206a = new ArrayList();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final HashMap f7207a = new HashMap();

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final HashMap f7208a = new HashMap();

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final ArrayList f7209a = new ArrayList();

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final ArrayList f7210a = new ArrayList();

    static {
        Log.isLoggable("AxMediaRouter", 3);
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x00e4  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x008d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public C5143i(android.content.Context r8) {
        /*
            Method dump skipped, instruction units count: 325
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5143i.<init>(android.content.Context):void");
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m3704a(AbstractC5426j abstractC5426j, boolean z) {
        if (m3707a(abstractC5426j) == null) {
            C5432j c5432j = new C5432j(abstractC5426j, z);
            this.f7209a.add(c5432j);
            this.f7198a.m3673a(513, c5432j);
            m3718a(c5432j, abstractC5426j.f8352a);
            C5435j.m4235a();
            abstractC5426j.f8349a = this.f7212a;
            abstractC5426j.m4203a(this.f7223a);
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String m3705a(C5432j c5432j, String str) {
        String strFlattenToShortString = ((ComponentName) c5432j.f8377a.f21718a).flattenToShortString();
        boolean z = c5432j.f8376a;
        String strM747a = z ? str : AbstractC4072a.m747a(strFlattenToShortString, ":", str);
        HashMap map = this.f7208a;
        if (!z) {
            ArrayList arrayList = this.f7206a;
            int size = arrayList.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                }
                if (((C5433j) arrayList.get(i)).f8381a.equals(strM747a)) {
                    break;
                }
                i++;
            }
            if (i >= 0) {
                int i2 = 2;
                while (true) {
                    Locale locale = Locale.US;
                    String str2 = strM747a + "_" + i2;
                    int size2 = arrayList.size();
                    int i3 = 0;
                    while (true) {
                        if (i3 >= size2) {
                            i3 = -1;
                            break;
                        }
                        if (((C5433j) arrayList.get(i3)).f8381a.equals(str2)) {
                            break;
                        }
                        i3++;
                    }
                    if (i3 < 0) {
                        map.put(new C3550(strFlattenToShortString, str), str2);
                        return str2;
                    }
                    i2++;
                }
            }
        }
        map.put(new C3550(strFlattenToShortString, str), strM747a);
        return strM747a;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C5433j m3706a() {
        ArrayList arrayList = this.f7206a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            C5433j c5433j = (C5433j) obj;
            if (c5433j != this.f7219a && c5433j.m4223a() == this.f7216a && c5433j.m4233a("android.media.intent.category.LIVE_AUDIO") && !c5433j.m4233a("android.media.intent.category.LIVE_VIDEO") && c5433j.m4226a()) {
                return c5433j;
            }
        }
        return this.f7219a;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C5432j m3707a(AbstractC5426j abstractC5426j) {
        ArrayList arrayList = this.f7209a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            C5432j c5432j = (C5432j) obj;
            if (c5432j.f8374a == abstractC5426j) {
                return c5432j;
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final ArrayList m3708a() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.f7207a.values().iterator();
        if (!it.hasNext()) {
            return arrayList;
        }
        AbstractC4164a.m1000a(it.next());
        AbstractC0284.m6081a();
        throw null;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void m3709a() {
        Iterator it = this.f7207a.values().iterator();
        if (it.hasNext()) {
            AbstractC4164a.m1000a(it.next());
            AbstractC0284.m6081a();
            throw null;
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final AbstractC5424j m3710a(C5433j c5433j) {
        AbstractC5424j abstractC5424j;
        if (c5433j == this.f7201a && (abstractC5424j = this.f7202a) != null) {
            return abstractC5424j;
        }
        if ((c5433j instanceof C5430j) && ((C5430j) c5433j).m4213a()) {
            m3709a();
            return null;
        }
        AbstractC5424j abstractC5424j2 = (AbstractC5424j) this.f7199a.get(c5433j.f8381a);
        if (abstractC5424j2 != null) {
            return abstractC5424j2;
        }
        Iterator it = this.f7207a.values().iterator();
        if (!it.hasNext()) {
            return abstractC5424j2;
        }
        AbstractC4164a.m1000a(it.next());
        AbstractC0284.m6079a();
        throw null;
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C5433j m3711a() {
        C5433j c5433j = this.f7201a;
        if (c5433j != null) {
            return c5433j;
        }
        throw new IllegalStateException("There is no currently selected route.  The media router has not yet been fully initialized.");
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final boolean m3712a() {
        if (!this.f7214a) {
            return false;
        }
        C5438j c5438j = this.f7218a;
        return c5438j == null || c5438j.f8413a;
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void m3713a() {
        AbstractC5424j abstractC5424jMo4130a;
        if (this.f7201a.m4225a()) {
            List<C5433j> listUnmodifiableList = Collections.unmodifiableList(this.f7201a.f8400a);
            HashSet hashSet = new HashSet();
            Iterator it = listUnmodifiableList.iterator();
            while (it.hasNext()) {
                hashSet.add(((C5433j) it.next()).f8381a);
            }
            HashMap map = this.f7199a;
            Iterator it2 = map.entrySet().iterator();
            while (it2.hasNext()) {
                Map.Entry entry = (Map.Entry) it2.next();
                if (!hashSet.contains(entry.getKey())) {
                    AbstractC5424j abstractC5424j = (AbstractC5424j) entry.getValue();
                    abstractC5424j.mo4200a(0);
                    abstractC5424j.mo4121a();
                    it2.remove();
                }
            }
            for (C5433j c5433j : listUnmodifiableList) {
                if (!map.containsKey(c5433j.f8381a) && (abstractC5424jMo4130a = c5433j.m4223a().mo4130a(c5433j.f8380a, this.f7201a.f8380a)) != null) {
                    abstractC5424jMo4130a.mo4198a();
                    map.put(c5433j.f8381a, abstractC5424jMo4130a);
                }
            }
        }
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final void m3714a(C5433j c5433j, int i, boolean z) {
        int iM4212a;
        if (!this.f7206a.contains(c5433j)) {
            Objects.toString(c5433j);
            return;
        }
        if (!c5433j.f8385a) {
            c5433j.toString();
            return;
        }
        C5433j c5433j2 = this.f7201a;
        if (c5433j2 != c5433j) {
            C5430j c5430jM4222a = c5433j2 != null ? c5433j2.m4222a() : null;
            if (c5430jM4222a == null || Collections.unmodifiableList(c5430jM4222a.f8400a).size() != 1 || ((iM4212a = c5430jM4222a.m4212a(c5433j)) != 3 && iM4212a != 2)) {
                if (Build.VERSION.SDK_INT >= 30) {
                    AbstractC5426j abstractC5426jM4223a = c5433j.m4223a();
                    C5389j c5389j = this.f7215a;
                    if (abstractC5426jM4223a == c5389j && this.f7201a != c5433j) {
                        c5389j.m4137a(c5433j.f8380a);
                        return;
                    }
                }
                m3715a(c5433j, i, z);
                return;
            }
        }
        c5433j.toString();
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m3715a(C5433j c5433j, int i, boolean z) {
        C4585c c4585c;
        if (this.f7201a == c5433j) {
            return;
        }
        boolean z2 = c5433j == this.f7219a;
        C5433j c5433j2 = this.f7220a;
        Context context = this.f7204a;
        if (c5433j2 != null && z2) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            for (int i2 = 3; i2 < stackTrace.length; i2++) {
                StackTraceElement stackTraceElement = stackTrace[i2];
                stackTraceElement.getClassName();
                stackTraceElement.getMethodName();
                stackTraceElement.getLineNumber();
            }
            if (this.f7201a != null) {
                Locale locale = Locale.US;
                C5435j.m4235a();
                C5433j c5433j3 = C5435j.m4236a().f7220a;
            }
            context.getPackageName();
        }
        if (this.f7221a != null) {
            this.f7221a = null;
            AbstractC5423j abstractC5423j = this.f7222a;
            if (abstractC5423j != null) {
                abstractC5423j.mo4200a(3);
                this.f7222a.mo4121a();
                this.f7222a = null;
            }
        }
        if (m3712a() && (c4585c = c5433j.f8379a.f8378a) != null && c4585c.f5326a) {
            AbstractC5426j abstractC5426jM4223a = c5433j.m4223a();
            String str = c5433j.f8380a;
            Bundle bundle = new Bundle();
            bundle.putString("clientPackageName", context.getPackageName());
            AbstractC5423j abstractC5423jMo4128a = abstractC5426jM4223a.mo4128a(str, new C5425j(bundle));
            if (abstractC5423jMo4128a != null) {
                abstractC5423jMo4128a.m4197a(AbstractC4611c.m2530a(context), this.f7228a);
                this.f7221a = c5433j;
                this.f7222a = abstractC5423jMo4128a;
                abstractC5423jMo4128a.mo4198a();
                return;
            }
            c5433j.toString();
        }
        AbstractC5426j abstractC5426jM4223a2 = c5433j.m4223a();
        String str2 = c5433j.f8380a;
        Bundle bundle2 = new Bundle();
        bundle2.putString("clientPackageName", context.getPackageName());
        AbstractC5424j abstractC5424jMo4201a = abstractC5426jM4223a2.mo4201a(str2, new C5425j(bundle2));
        if (abstractC5424jMo4201a != null) {
            abstractC5424jMo4201a.mo4198a();
        }
        if (this.f7201a == null) {
            this.f7201a = c5433j;
            this.f7202a = abstractC5424jMo4201a;
            HandlerC5139i handlerC5139i = this.f7198a;
            handlerC5139i.getClass();
            Message messageObtainMessage = handlerC5139i.obtainMessage(262, new C5142i(null, c5433j, z));
            messageObtainMessage.arg1 = i;
            messageObtainMessage.sendToTarget();
            return;
        }
        C5431j c5431j = this.f7203a;
        if (c5431j != null) {
            c5431j.m4218a();
            this.f7203a = null;
        }
        C5431j c5431j2 = new C5431j(this, c5433j, abstractC5424jMo4201a, i, z, null, null);
        this.f7203a = c5431j2;
        c5431j2.m4219a();
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00aa  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x00ab A[SYNTHETIC] */
    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m3716a() {
        /*
            Method dump skipped, instruction units count: 376
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5143i.m3716a():void");
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void m3717a() {
        C5433j c5433j = this.f7201a;
        if (c5433j == null) {
            C5924o c5924o = this.f7226a;
            if (c5924o != null) {
                c5924o.m4878a();
                return;
            }
            return;
        }
        int i = c5433j.f8394a;
        C0091 c0091 = this.f7211a;
        c0091.f11895a = i;
        c0091.f11896a = c5433j.f8395a;
        c0091.f11897a = (!c5433j.m4225a() || C5435j.m4241a()) ? c5433j.f8393a : 0;
        c0091.f11898a = this.f7201a.f8391a;
        if (m3712a() && this.f7201a.m4223a() == this.f7215a) {
            c0091.f11899a = C5389j.m4127a(this.f7202a);
        } else {
            c0091.f11899a = null;
        }
        Iterator it = this.f7210a.iterator();
        if (it.hasNext()) {
            AbstractC4164a.m1000a(it.next());
            throw null;
        }
        C5924o c5924o2 = this.f7226a;
        if (c5924o2 != null) {
            C5433j c5433j2 = this.f7201a;
            C5433j c5433j3 = this.f7219a;
            if (c5433j3 == null) {
                throw new IllegalStateException("There is no default route.  The media router has not yet been fully initialized.");
            }
            if (c5433j2 == c5433j3 || c5433j2 == this.f7220a) {
                c5924o2.m4878a();
            } else {
                c5924o2.m4879a(c0091.f11897a == 1 ? 2 : 0, (String) c0091.f11899a, c0091.f11896a, c0091.f11895a);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0109 A[LOOP:3: B:54:0x0107->B:55:0x0109, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x012a  */
    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m3718a(defpackage.C5432j r19, defpackage.C4585c r20) {
        /*
            Method dump skipped, instruction units count: 401
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5143i.m3718a(j͑, cܳ):void");
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final int m3719a(C5433j c5433j, C5405j c5405j) {
        int iM4229a = c5433j.m4229a(c5405j);
        if (iM4229a != 0) {
            int i = iM4229a & 1;
            HandlerC5139i handlerC5139i = this.f7198a;
            if (i != 0) {
                handlerC5139i.m3673a(259, c5433j);
            }
            if ((iM4229a & 2) != 0) {
                handlerC5139i.m3673a(260, c5433j);
            }
            if ((iM4229a & 4) != 0) {
                handlerC5139i.m3673a(261, c5433j);
            }
        }
        return iM4229a;
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final void m3720a(boolean z) {
        C5433j c5433j = this.f7219a;
        if (c5433j != null && !c5433j.m4226a()) {
            Objects.toString(this.f7219a);
            this.f7219a = null;
        }
        C5433j c5433j2 = this.f7219a;
        C5695o c5695o = this.f7216a;
        ArrayList arrayList = this.f7206a;
        if (c5433j2 == null) {
            int size = arrayList.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    break;
                }
                Object obj = arrayList.get(i);
                i++;
                C5433j c5433j3 = (C5433j) obj;
                if (c5433j3.m4223a() == c5695o && c5433j3.f8380a.equals("DEFAULT_ROUTE") && c5433j3.m4226a()) {
                    this.f7219a = c5433j3;
                    Objects.toString(c5433j3);
                    break;
                }
            }
        }
        C5433j c5433j4 = this.f7220a;
        if (c5433j4 != null && !c5433j4.m4226a()) {
            Objects.toString(this.f7220a);
            this.f7220a = null;
        }
        if (this.f7220a == null) {
            int size2 = arrayList.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size2) {
                    break;
                }
                Object obj2 = arrayList.get(i2);
                i2++;
                C5433j c5433j5 = (C5433j) obj2;
                if (c5433j5.m4223a() == c5695o && c5433j5.m4233a("android.media.intent.category.LIVE_AUDIO") && !c5433j5.m4233a("android.media.intent.category.LIVE_VIDEO") && c5433j5.m4226a()) {
                    this.f7220a = c5433j5;
                    Objects.toString(c5433j5);
                    break;
                }
            }
        }
        C5433j c5433j6 = this.f7201a;
        if (c5433j6 == null || !c5433j6.f8385a) {
            Objects.toString(c5433j6);
            m3715a(m3706a(), 0, true);
        } else if (z) {
            m3713a();
            m3717a();
        }
    }
}
