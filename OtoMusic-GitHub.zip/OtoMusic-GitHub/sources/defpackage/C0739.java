package defpackage;

import java.nio.charset.Charset;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

/* JADX INFO: renamed from: ρ͍, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0739 extends AbstractC0713 implements RandomAccess, InterfaceC0744 {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final int[] f13932a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final C0739 f13933a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int[] f13934a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f13935a;

    static {
        int[] iArr = new int[0];
        f13932a = iArr;
        f13933a = new C0739(iArr, 0, false);
    }

    public C0739(int[] iArr, int i, boolean z) {
        super(z);
        this.f13934a = iArr;
        this.f13935a = i;
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static C0739 m6667a() {
        return f13933a;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i, Object obj) {
        int i2;
        int iIntValue = ((Integer) obj).intValue();
        m6614a();
        if (i < 0 || i > (i2 = this.f13935a)) {
            throw new IndexOutOfBoundsException(AbstractC4072a.m743a("Index:", i, ", Size:", this.f13935a));
        }
        int i3 = i + 1;
        int[] iArr = this.f13934a;
        int length = iArr.length;
        if (i2 < length) {
            System.arraycopy(iArr, i, iArr, i3, i2 - i);
        } else {
            int[] iArr2 = new int[AbstractC4164a.m976a(length, 3, 2, 1, 10)];
            System.arraycopy(this.f13934a, 0, iArr2, 0, i);
            System.arraycopy(this.f13934a, i, iArr2, i3, this.f13935a - i);
            this.f13934a = iArr2;
        }
        this.f13934a[i] = iIntValue;
        this.f13935a++;
        ((AbstractList) this).modCount++;
    }

    @Override // defpackage.AbstractC0713, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        m6614a();
        Charset charset = AbstractC0752.f13947a;
        collection.getClass();
        if (!(collection instanceof C0739)) {
            return super.addAll(collection);
        }
        C0739 c0739 = (C0739) collection;
        int i = c0739.f13935a;
        if (i == 0) {
            return false;
        }
        int i2 = this.f13935a;
        if (Integer.MAX_VALUE - i2 < i) {
            throw new OutOfMemoryError();
        }
        int i3 = i2 + i;
        int[] iArr = this.f13934a;
        if (i3 > iArr.length) {
            this.f13934a = Arrays.copyOf(iArr, i3);
        }
        System.arraycopy(c0739.f13934a, 0, this.f13934a, this.f13935a, c0739.f13935a);
        this.f13935a = i3;
        ((AbstractList) this).modCount++;
        return true;
    }

    @Override // defpackage.InterfaceC0745
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* bridge */ /* synthetic */ InterfaceC0745 mo6668a(int i) {
        if (i >= this.f13935a) {
            return new C0739(i == 0 ? f13932a : Arrays.copyOf(this.f13934a, i), this.f13935a, true);
        }
        throw new IllegalArgumentException();
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int m6669a(int i) {
        m6672a(i);
        return this.f13934a[i];
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void m6670a(int i) {
        m6614a();
        int i2 = this.f13935a;
        int length = this.f13934a.length;
        if (i2 == length) {
            int[] iArr = new int[AbstractC4164a.m976a(length, 3, 2, 1, 10)];
            System.arraycopy(this.f13934a, 0, iArr, 0, this.f13935a);
            this.f13934a = iArr;
        }
        int[] iArr2 = this.f13934a;
        int i3 = this.f13935a;
        this.f13935a = i3 + 1;
        iArr2[i3] = i;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final void m6671a(int i) {
        int length = this.f13934a.length;
        if (i <= length) {
            return;
        }
        if (length == 0) {
            this.f13934a = new int[Math.max(i, 10)];
            return;
        }
        while (length < i) {
            length = AbstractC4164a.m976a(length, 3, 2, 1, 10);
        }
        this.f13934a = Arrays.copyOf(this.f13934a, length);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m6672a(int i) {
        if (i < 0 || i >= this.f13935a) {
            throw new IndexOutOfBoundsException(AbstractC4072a.m743a("Index:", i, ", Size:", this.f13935a));
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    @Override // defpackage.AbstractC0713, java.util.AbstractList, java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0739)) {
            return super.equals(obj);
        }
        C0739 c0739 = (C0739) obj;
        if (this.f13935a != c0739.f13935a) {
            return false;
        }
        int[] iArr = c0739.f13934a;
        for (int i = 0; i < this.f13935a; i++) {
            if (this.f13934a[i] != iArr[i]) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* synthetic */ Object get(int i) {
        m6672a(i);
        return Integer.valueOf(this.f13934a[i]);
    }

    @Override // defpackage.AbstractC0713, java.util.AbstractList, java.util.Collection, java.util.List
    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.f13935a; i2++) {
            i = (i * 31) + this.f13934a[i2];
        }
        return i;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Integer)) {
            return -1;
        }
        int iIntValue = ((Integer) obj).intValue();
        int i = this.f13935a;
        for (int i2 = 0; i2 < i; i2++) {
            if (this.f13934a[i2] == iIntValue) {
                return i2;
            }
        }
        return -1;
    }

    @Override // defpackage.AbstractC0713, java.util.AbstractList, java.util.List
    public final /* bridge */ /* synthetic */ Object remove(int i) {
        m6614a();
        m6672a(i);
        int[] iArr = this.f13934a;
        int i2 = iArr[i];
        if (i < this.f13935a - 1) {
            System.arraycopy(iArr, i + 1, iArr, i, (r2 - i) - 1);
        }
        this.f13935a--;
        ((AbstractList) this).modCount++;
        return Integer.valueOf(i2);
    }

    @Override // java.util.AbstractList
    public final void removeRange(int i, int i2) {
        m6614a();
        if (i2 < i) {
            throw new IndexOutOfBoundsException("toIndex < fromIndex");
        }
        int[] iArr = this.f13934a;
        System.arraycopy(iArr, i2, iArr, i, this.f13935a - i2);
        this.f13935a -= i2 - i;
        ((AbstractList) this).modCount++;
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* bridge */ /* synthetic */ Object set(int i, Object obj) {
        int iIntValue = ((Integer) obj).intValue();
        m6614a();
        m6672a(i);
        int[] iArr = this.f13934a;
        int i2 = iArr[i];
        iArr[i] = iIntValue;
        return Integer.valueOf(i2);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f13935a;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* bridge */ /* synthetic */ boolean add(Object obj) {
        m6670a(((Integer) obj).intValue());
        return true;
    }
}
