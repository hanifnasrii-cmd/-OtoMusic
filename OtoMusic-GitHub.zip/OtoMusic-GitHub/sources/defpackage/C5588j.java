package defpackage;

import android.content.res.Configuration;

/* JADX INFO: renamed from: j݀, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5588j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean f8867a;

    public C5588j(boolean z) {
        this.f8867a = z;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean m4419a() {
        return this.f8867a;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C5588j(boolean z, Configuration configuration) {
        this(z);
        AbstractC3098.m10103a(configuration, "newConfig");
    }
}
