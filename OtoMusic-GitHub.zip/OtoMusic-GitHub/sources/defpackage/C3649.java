package defpackage;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.piyush.music.R;
import com.piyush.music.dialogs.bottomsheet.sort.SortDialog;
import com.piyush.music.sort.Sort;
import java.util.List;

/* JADX INFO: renamed from: օ̈, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3649 extends AbstractC6242p {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final SortDialog f23233a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Sort f23234a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final boolean f23235a;

    public C3649(SortDialog sortDialog, Sort sort, boolean z) {
        super(C3650.class);
        this.f23233a = sortDialog;
        this.f23234a = sort;
        this.f23235a = z;
    }

    @Override // defpackage.AbstractC6242p
    /* JADX INFO: renamed from: à */
    public final void mo4346a(AbstractC2042 abstractC2042, Object obj) {
        int iMo1074a;
        C3650 c3650 = (C3650) obj;
        C3648 c3648 = (C3648) abstractC2042;
        LinearLayout linearLayout = c3648.f23231a;
        Context context = linearLayout.getContext();
        TextView textView = c3648.f23232a;
        textView.setText(c3650.f23236a.getTextId());
        linearLayout.setOnClickListener(new ViewOnClickListenerC0364(this, 6, c3650));
        int id = c3650.f23236a.getId();
        Sort sort = this.f23234a;
        boolean z = id == sort.getId();
        int iM8440a = c3648.m8440a();
        AbstractC2015 abstractC2015 = c3648.f18164a;
        C6243p c6243p = abstractC2015 instanceof C6243p ? (C6243p) abstractC2015 : null;
        List list = c6243p != null ? c6243p.f11048a : null;
        if (list == null) {
            list = C4891e.f6320a;
        }
        int size = list.size();
        Integer numValueOf = size > 0 ? Integer.valueOf(size) : null;
        if (numValueOf != null) {
            iMo1074a = numValueOf.intValue();
        } else {
            AbstractC2015 abstractC20152 = c3648.f18164a;
            iMo1074a = abstractC20152 != null ? abstractC20152.mo1074a() : 1;
        }
        float fM3432a = AbstractC5120i.m3432a(20.0f, context);
        float fM3432a2 = AbstractC5120i.m3432a(4.0f, context);
        float fM3432a3 = AbstractC5120i.m3432a(16.0f, context);
        List list2 = list;
        int i = iM8440a + 1;
        boolean z2 = i >= 0 && i < list2.size() && ((C3650) list.get(i)).f23236a.getId() == sort.getId();
        int size2 = list2.size();
        int i2 = iM8440a - 1;
        boolean z3 = i2 >= 0 && i2 < size2 && ((C3650) list.get(i2)).f23236a.getId() == sort.getId();
        if (z) {
            int iM10120a = AbstractC3098.m10120a(linearLayout, R.attr.hr);
            int iM10120a2 = AbstractC3098.m10120a(linearLayout, R.attr.ha);
            C4842e c4842e = new C4842e(0);
            C4842e c4842e2 = new C4842e(0);
            C4842e c4842e3 = new C4842e(0);
            C4842e c4842e4 = new C4842e(0);
            AbstractC4647c abstractC4647cM8624a = AbstractC2179.m8624a(0);
            C4031a c4031a = new C4031a(fM3432a);
            C4031a c4031a2 = new C4031a(fM3432a);
            C4031a c4031a3 = new C4031a(fM3432a);
            C4031a c4031a4 = new C4031a(fM3432a);
            C0456 c0456 = new C0456();
            c0456.f13058a = abstractC4647cM8624a;
            c0456.f13059a = abstractC4647cM8624a;
            c0456.f13060a = abstractC4647cM8624a;
            c0456.f13061a = abstractC4647cM8624a;
            c0456.f13062a = c4031a;
            c0456.f13063a = c4031a2;
            c0456.f13064a = c4031a3;
            c0456.f13065a = c4031a4;
            c0456.f13066a = c4842e;
            c0456.f13067a = c4842e2;
            c0456.f13068a = c4842e3;
            c0456.f13069a = c4842e4;
            C0262 c0262 = new C0262(c0456);
            c0262.m6049a(ColorStateList.valueOf(iM10120a));
            linearLayout.setBackground(c0262);
            textView.setTextColor(iM10120a2);
            textView.setTypeface(AbstractC3573.m10773a(context, 800));
            textView.setTextSize(17.0f);
            return;
        }
        int iM10120a3 = AbstractC3098.m10120a(linearLayout, R.attr.xz);
        boolean z4 = iM8440a == 0;
        boolean z5 = iM8440a == iMo1074a + (-1);
        float f = z4 ? fM3432a : z3 ? fM3432a3 : fM3432a2;
        if (!z5) {
            fM3432a = z2 ? fM3432a3 : fM3432a2;
        }
        C4842e c4842e5 = new C4842e(0);
        C4842e c4842e6 = new C4842e(0);
        C4842e c4842e7 = new C4842e(0);
        C4842e c4842e8 = new C4842e(0);
        AbstractC4647c abstractC4647cM8624a2 = AbstractC2179.m8624a(0);
        C4031a c4031a5 = new C4031a(f);
        AbstractC4647c abstractC4647cM8624a3 = AbstractC2179.m8624a(0);
        C4031a c4031a6 = new C4031a(f);
        AbstractC4647c abstractC4647cM8624a4 = AbstractC2179.m8624a(0);
        C4031a c4031a7 = new C4031a(fM3432a);
        AbstractC4647c abstractC4647cM8624a5 = AbstractC2179.m8624a(0);
        C4031a c4031a8 = new C4031a(fM3432a);
        C0456 c04562 = new C0456();
        c04562.f13058a = abstractC4647cM8624a2;
        c04562.f13059a = abstractC4647cM8624a3;
        c04562.f13060a = abstractC4647cM8624a5;
        c04562.f13061a = abstractC4647cM8624a4;
        c04562.f13062a = c4031a5;
        c04562.f13063a = c4031a6;
        c04562.f13064a = c4031a8;
        c04562.f13065a = c4031a7;
        c04562.f13066a = c4842e5;
        c04562.f13067a = c4842e6;
        c04562.f13068a = c4842e7;
        c04562.f13069a = c4842e8;
        C0262 c02622 = new C0262(c04562);
        c02622.m6049a(ColorStateList.valueOf(iM10120a3));
        linearLayout.setBackground(c02622);
        textView.setTextColor(AbstractC3098.m10120a(linearLayout, R.attr.hi));
        textView.setTypeface(AbstractC3573.m10773a(context, 500));
        textView.setTextSize(16.0f);
    }

    @Override // defpackage.AbstractC6242p
    /* JADX INFO: renamed from: á */
    public final AbstractC2042 mo4347a(ViewGroup viewGroup) {
        View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dm, viewGroup, false);
        AbstractC3098.m10101a(viewInflate, "null cannot be cast to non-null type android.widget.LinearLayout");
        LinearLayout linearLayout = (LinearLayout) viewInflate;
        linearLayout.findViewById(R.id.option_supporting).setVisibility(8);
        int iM3433a = AbstractC5120i.m3433a(1.0f, linearLayout.getContext());
        ViewGroup.LayoutParams layoutParams = linearLayout.getLayoutParams();
        if (layoutParams == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        marginLayoutParams.topMargin = iM3433a;
        marginLayoutParams.bottomMargin = iM3433a;
        linearLayout.setLayoutParams(marginLayoutParams);
        linearLayout.setClipToOutline(true);
        linearLayout.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        return new C3648(linearLayout);
    }
}
