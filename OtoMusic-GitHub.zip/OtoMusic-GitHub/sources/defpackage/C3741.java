package defpackage;

/* JADX INFO: renamed from: օͤ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3741 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public int f23575a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public C5141i f23576a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int[][] f23577a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C5141i[] f23578a;

    /* JADX WARN: Removed duplicated region for block: B:28:0x006d  */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m10942a(android.content.Context r12, android.content.res.XmlResourceParser r13, android.util.AttributeSet r14, android.content.res.Resources.Theme r15) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C3741.m10942a(android.content.Context, android.content.res.XmlResourceParser, android.util.AttributeSet, android.content.res.Resources$Theme):void");
    }
}
