package defpackage;

import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import com.piyush.music.fragments.player.PlayerSheet;

/* JADX INFO: renamed from: c݉, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4607c implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float f5392a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float f5393a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final float f5394a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final float f5395a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final float f5396a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C4609c f5397a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ float f5398a;

    public C4607c(C4609c c4609c, float f) {
        this.f5397a = c4609c;
        this.f5398a = f;
        View view = c4609c.f5402a;
        float alpha = view.getAlpha();
        this.f5392a = alpha;
        this.f5393a = view.getTranslationY();
        this.f5394a = c4609c.f5401a.getTranslationY();
        boolean z = f > alpha;
        this.f5395a = z ? 0.15f : 0.0f;
        this.f5396a = z ? 0.2f : 0.18f;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        PathInterpolator pathInterpolator = AbstractC0257.f12458a;
        Object animatedValue = valueAnimator.getAnimatedValue();
        AbstractC3098.m10101a(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        float interpolation = pathInterpolator.getInterpolation(((Float) animatedValue).floatValue());
        C4609c c4609c = this.f5397a;
        View view = c4609c.f5402a;
        view.setTranslationY(AbstractC4647c.m2687a(this.f5393a, c4609c.f5408a, interpolation));
        LinearInterpolator linearInterpolator = AbstractC0257.f12456a;
        Object animatedValue2 = valueAnimator.getAnimatedValue();
        AbstractC3098.m10101a(animatedValue2, "null cannot be cast to non-null type kotlin.Float");
        view.setAlpha(AbstractC4647c.m2688a(this.f5392a, this.f5398a, this.f5395a, this.f5396a, linearInterpolator.getInterpolation(((Float) animatedValue2).floatValue())));
        PlayerSheet playerSheet = c4609c.f5401a;
        if (playerSheet.getBehavior().f2925a != 2) {
            float translationY = playerSheet.getTranslationY();
            float f = c4609c.f5409a;
            if (translationY == f) {
                return;
            }
            playerSheet.setTranslationY(AbstractC4647c.m2687a(this.f5394a, f, interpolation));
        }
    }
}
