package defpackage;

import android.content.Context;
import com.piyush.taglib.TagLib;
import java.util.Locale;
import java.util.Set;

/* JADX INFO: renamed from: і҅, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3093 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C3093 f21710a = new C3093();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C3865 f21711a = new C3865(new C4225a(15));

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static volatile C3092 f21712a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static boolean m10078a(InterfaceC5880o interfaceC5880o) {
        C3092 c3092 = f21712a;
        String str = c3092 != null ? c3092.f21708a : null;
        Boolean boolValueOf = c3092 != null ? Boolean.valueOf(c3092.f21709a) : null;
        if (str != null && AbstractC3098.m10094a(boolValueOf, Boolean.FALSE)) {
            C0492 c0492 = (C0492) interfaceC5880o;
            int iM6346a = c0492.m6346a();
            C0487 c0487 = c0492.f13264a;
            InterfaceC3192[] interfaceC3192Arr = C0492.f13161a;
            InterfaceC3192 interfaceC3192 = interfaceC3192Arr[56];
            int iIntValue = ((Number) c0487.m6329a()).intValue();
            z = iM6346a - (iIntValue < 0 ? iM6346a : iIntValue) < 2;
            Integer numValueOf = iIntValue < 0 ? Integer.valueOf(iM6346a) : null;
            if (numValueOf != null) {
                int iIntValue2 = numValueOf.intValue();
                C0487 c04872 = c0492.f13264a;
                InterfaceC3192 interfaceC31922 = interfaceC3192Arr[56];
                c04872.mo6324a(Integer.valueOf(iIntValue2));
            }
        }
        return z;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m10079a(Context context) {
        Object objM7168a;
        if (f21712a != null) {
            return;
        }
        synchronized (this) {
            try {
                if (f21712a != null) {
                    return;
                }
                try {
                    objM7168a = TagLib.containerTag(context.getApplicationInfo().sourceDir);
                } catch (Throwable th) {
                    objM7168a = AbstractC1149.m7168a(th);
                }
                String upperCase = null;
                if (objM7168a instanceof C2151) {
                    objM7168a = null;
                }
                String str = (String) objM7168a;
                if (str != null) {
                    upperCase = str.toUpperCase(Locale.ROOT);
                    AbstractC3098.m10102a(upperCase, "toUpperCase(...)");
                }
                f21712a = new C3092(upperCase, upperCase != null && ((Set) f21711a.getValue()).contains(upperCase));
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
