package defpackage;

/* JADX INFO: renamed from: о݉, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC2232 extends InterfaceC3292 {
    C2230 getSavedStateRegistry();
}
