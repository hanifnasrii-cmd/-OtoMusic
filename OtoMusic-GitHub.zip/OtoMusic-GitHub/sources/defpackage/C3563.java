package defpackage;

import java.lang.reflect.Array;
import java.util.Iterator;

/* JADX INFO: renamed from: јޫ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3563 extends AbstractC3478 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f22999a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ AbstractC3478 f23000a;

    public /* synthetic */ C3563(AbstractC3478 abstractC3478, int i) {
        this.f22999a = i;
        this.f23000a = abstractC3478;
    }

    @Override // defpackage.AbstractC3478
    /* JADX INFO: renamed from: á */
    public final void mo10647a(C2103 c2103, Object obj) {
        switch (this.f22999a) {
            case 0:
                Iterable iterable = (Iterable) obj;
                if (iterable != null) {
                    Iterator it = iterable.iterator();
                    while (it.hasNext()) {
                        this.f23000a.mo10647a(c2103, it.next());
                    }
                    break;
                }
                break;
            default:
                if (obj != null) {
                    int length = Array.getLength(obj);
                    for (int i = 0; i < length; i++) {
                        this.f23000a.mo10647a(c2103, Array.get(obj, i));
                    }
                    break;
                }
                break;
        }
    }
}
