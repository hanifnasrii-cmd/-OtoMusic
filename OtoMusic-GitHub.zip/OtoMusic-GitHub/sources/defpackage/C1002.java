package defpackage;

/* JADX INFO: renamed from: ϲ̉, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1002 implements InterfaceC0402 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C0404 f14384a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final InterfaceC3183 f14385a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f14386a;

    public C1002(C0404 c0404, C2807 c2807) {
        AbstractC3098.m10103a(c2807, "kClass");
        this.f14384a = c0404;
        this.f14385a = c2807;
        this.f14386a = c0404.f12908a + '<' + c2807.m9579a() + '>';
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: à */
    public final String mo4747a() {
        return this.f14386a;
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: á */
    public final AbstractC5124i mo4748a() {
        return this.f14384a.f12909a;
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: â */
    public final int mo4749a() {
        return this.f14384a.f12910a;
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: ã */
    public final String mo4750a(int i) {
        return this.f14384a.f12912a[i];
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: a̅ */
    public final boolean mo4751a() {
        return false;
    }

    @Override // defpackage.InterfaceC0402
    /* JADX INFO: renamed from: ă */
    public final InterfaceC0402 mo4752a(int i) {
        return this.f14384a.f12913a[i];
    }

    public final boolean equals(Object obj) {
        C1002 c1002 = obj instanceof C1002 ? (C1002) obj : null;
        return c1002 != null && this.f14384a.equals(c1002.f14384a) && AbstractC3098.m10094a(c1002.f14385a, this.f14385a);
    }

    public final int hashCode() {
        return this.f14386a.hashCode() + (((C2807) this.f14385a).hashCode() * 31);
    }

    public final String toString() {
        return "ContextDescriptor(kClass: " + this.f14385a + ", original: " + this.f14384a + ')';
    }
}
