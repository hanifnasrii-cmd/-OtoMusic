package defpackage;

import android.view.View;
import androidx.fragment.app.AbstractComponentCallbacksC3990a;
import java.util.ArrayList;

/* JADX INFO: renamed from: еⷲ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC1972 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C1977 f17953a = new C1977();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final AbstractC1978 f17954a;

    static {
        AbstractC1978 abstractC1978 = null;
        try {
            abstractC1978 = (AbstractC1978) C1983.class.getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f17954a = abstractC1978;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final void m8325a(AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a, AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a2, boolean z, C1454 c1454) {
        AbstractC3098.m10103a(abstractComponentCallbacksC3990a, "inFragment");
        AbstractC3098.m10103a(abstractComponentCallbacksC3990a2, "outFragment");
        if (z) {
            abstractComponentCallbacksC3990a2.getEnterTransitionCallback();
        } else {
            abstractComponentCallbacksC3990a.getEnterTransitionCallback();
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final void m8326a(C1454 c1454, C1454 c14542) {
        int i = c1454.f13353a;
        while (true) {
            i--;
            if (-1 >= i) {
                return;
            }
            if (!c14542.containsKey((String) c1454.m6381a(i))) {
                c1454.mo2792a(i);
            }
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final void m8327a(ArrayList arrayList, int i) {
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ((View) obj).setVisibility(i);
        }
    }
}
