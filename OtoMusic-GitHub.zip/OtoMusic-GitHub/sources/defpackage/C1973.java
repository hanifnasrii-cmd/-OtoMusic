package defpackage;

import android.graphics.Rect;
import android.transition.Transition;

/* JADX INFO: renamed from: еⷳ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1973 extends Transition.EpicenterCallback {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f17955a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ Rect f17956a;

    public /* synthetic */ C1973(int i, Rect rect) {
        this.f17955a = i;
        this.f17956a = rect;
    }

    @Override // android.transition.Transition.EpicenterCallback
    public final Rect onGetEpicenter(Transition transition) {
        switch (this.f17955a) {
            case 0:
                return this.f17956a;
            default:
                Rect rect = this.f17956a;
                if (rect == null || rect.isEmpty()) {
                    return null;
                }
                return rect;
        }
    }
}
