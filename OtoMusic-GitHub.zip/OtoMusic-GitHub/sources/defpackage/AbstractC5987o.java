package defpackage;

import android.R;

/* JADX INFO: renamed from: oⷧ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC5987o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final int[] f10202a = {R.attr.maxWidth};

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final int[] f10203a = {R.attr.src, R.attr.text, com.piyush.music.R.attr.adm};

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final int[] f10204a = {com.piyush.music.R.attr.by, com.piyush.music.R.attr.lw, com.piyush.music.R.attr.me, com.piyush.music.R.attr.sl};

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final int[] f10205a = {R.attr.id, R.attr.layout, R.attr.inflatedId, R.attr.backgroundTint};

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final int[] f10206a = {R.attr.positiveButtonText, R.attr.negativeButtonText};

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final int[] f10207a = {com.piyush.music.R.attr.a5i, com.piyush.music.R.attr.a5j, com.piyush.music.R.attr.a5k, com.piyush.music.R.attr.a5l, com.piyush.music.R.attr.a5m, com.piyush.music.R.attr.a5n, com.piyush.music.R.attr.a5o, com.piyush.music.R.attr.a5p};

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final int[] f10208a = {R.attr.textAppearance, R.attr.text, R.attr.hint, com.piyush.music.R.attr.b0, com.piyush.music.R.attr.b1, com.piyush.music.R.attr.bf, com.piyush.music.R.attr.rw, com.piyush.music.R.attr.a69, com.piyush.music.R.attr.af2};

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final int[] f10209a = {com.piyush.music.R.attr.aw, com.piyush.music.R.attr.ax, com.piyush.music.R.attr.gf, com.piyush.music.R.attr.ns, com.piyush.music.R.attr.nt, com.piyush.music.R.attr.nu, com.piyush.music.R.attr.nv, com.piyush.music.R.attr.ny, com.piyush.music.R.attr.zs};

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final int[] f10210a = {R.attr.src, com.piyush.music.R.attr.p2, com.piyush.music.R.attr.p7, com.piyush.music.R.attr.p8, com.piyush.music.R.attr.p9, com.piyush.music.R.attr.p_, com.piyush.music.R.attr.a8m};

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final int[] f10211a = {R.attr.fadeDuration};

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final int[] f10212a = {com.piyush.music.R.attr.ba};

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static final int[] f10213a = {com.piyush.music.R.attr.tk, com.piyush.music.R.attr.tl, com.piyush.music.R.attr.tm, com.piyush.music.R.attr.tn, com.piyush.music.R.attr.to};

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public static final int[] f10214a = {R.attr.maxHeight};

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static final int[] f10215a = {R.attr.maxWidth, R.attr.maxHeight};

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static final int[] f10216a = {com.piyush.music.R.attr.zy, com.piyush.music.R.attr.a0b};

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static final int[] f10217a = {com.piyush.music.R.attr.e5, com.piyush.music.R.attr.a0k, com.piyush.music.R.attr.acr};

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public static final int[] f10218a = {com.piyush.music.R.attr.a23, com.piyush.music.R.attr.a24};

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public static final int[] f10219a = {R.attr.textAppearance, R.attr.text, R.attr.hint, com.piyush.music.R.attr.cg, com.piyush.music.R.attr.kv, com.piyush.music.R.attr.ky, com.piyush.music.R.attr.rw, com.piyush.music.R.attr.a9e, com.piyush.music.R.attr.a9f};

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public static final int[] f10220a = {com.piyush.music.R.attr.mn};

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public static final int[] f10221a = {R.attr.elevation, com.piyush.music.R.attr.az, com.piyush.music.R.attr.bo, com.piyush.music.R.attr.cm, com.piyush.music.R.attr.ta, com.piyush.music.R.attr.a5u, com.piyush.music.R.attr.a7k};

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public static final int[] f10222a = {R.attr.gravity, com.piyush.music.R.attr.n1, com.piyush.music.R.attr.pb, com.piyush.music.R.attr.a2f, com.piyush.music.R.attr.a8p, com.piyush.music.R.attr.a8q};

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public static final int[] f10223a = {R.attr.tint, com.piyush.music.R.attr.a81};

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public static final int[] f10224a = {R.attr.background, com.piyush.music.R.attr.g1};

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public static final int[] f10225a = {R.attr.enabled, com.piyush.music.R.attr.a5x, com.piyush.music.R.attr.a5y, com.piyush.music.R.attr.a5z, com.piyush.music.R.attr.a60, com.piyush.music.R.attr.a61, com.piyush.music.R.attr.a62, com.piyush.music.R.attr.a63, com.piyush.music.R.attr.a64, com.piyush.music.R.attr.a65, com.piyush.music.R.attr.a66};

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public static final int[] f10226a = {com.piyush.music.R.attr.a4u, com.piyush.music.R.attr.a4v, com.piyush.music.R.attr.a4w};

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public static final int[] f10227a = {com.piyush.music.R.attr.ci, com.piyush.music.R.attr.t5, com.piyush.music.R.attr.t7, com.piyush.music.R.attr.t9, com.piyush.music.R.attr.a7b};
}
