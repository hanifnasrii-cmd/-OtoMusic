package defpackage;

import android.graphics.BlurMaskFilter;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: іⷽ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3307 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final ArrayList f22241a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final boolean f22242a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final double f22243a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final double f22244a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final double f22245a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Object f22246a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f22247a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final BlurMaskFilter f22248a;

    public C3307(ArrayList arrayList, boolean z, double d, double d2, double d3, List list, int i, BlurMaskFilter blurMaskFilter) {
        this.f22241a = arrayList;
        this.f22242a = z;
        this.f22243a = d;
        this.f22244a = d2;
        this.f22245a = d3;
        this.f22246a = list;
        this.f22247a = i;
        this.f22248a = blurMaskFilter;
    }
}
