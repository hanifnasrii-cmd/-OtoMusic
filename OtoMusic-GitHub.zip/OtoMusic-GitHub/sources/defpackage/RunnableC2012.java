package defpackage;

import androidx.recyclerview.widget.RecyclerView;

/* JADX INFO: renamed from: о̚, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC2012 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f18078a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ RecyclerView f18079a;

    public /* synthetic */ RunnableC2012(RecyclerView recyclerView, int i) {
        this.f18078a = i;
        this.f18079a = recyclerView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f18078a) {
            case 0:
                RecyclerView recyclerView = this.f18079a;
                if (recyclerView.f759a && !recyclerView.isLayoutRequested()) {
                    if (!recyclerView.f757a) {
                        recyclerView.requestLayout();
                    } else if (!recyclerView.f762a) {
                        recyclerView.m500a();
                    } else {
                        recyclerView.f761a = true;
                    }
                    break;
                }
                break;
            default:
                RecyclerView recyclerView2 = this.f18079a;
                AbstractC2021 abstractC2021 = recyclerView2.f777a;
                if (abstractC2021 != null) {
                    abstractC2021.mo6434a();
                }
                recyclerView2.f801a = false;
                break;
        }
    }
}
