package defpackage;

import com.google.android.flexbox.FlexboxLayoutManager;

/* JADX INFO: renamed from: е֦, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1793 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public int f17112a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f17113a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int f17114a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f17115a = 0;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f17116a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public boolean f17117a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f17118a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ FlexboxLayoutManager f17119a;

    public C1793(FlexboxLayoutManager flexboxLayoutManager) {
        this.f17119a = flexboxLayoutManager;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static void m8198a(C1793 c1793) {
        FlexboxLayoutManager flexboxLayoutManager = c1793.f17119a;
        if (flexboxLayoutManager.mo1301a() || !flexboxLayoutManager.f1884a) {
            c1793.f17114a = c1793.f17116a ? flexboxLayoutManager.f1892a.mo10671a() : flexboxLayoutManager.f1892a.mo10675a();
        } else {
            c1793.f17114a = c1793.f17116a ? flexboxLayoutManager.f1892a.mo10671a() : flexboxLayoutManager.f851a - flexboxLayoutManager.f1892a.mo10675a();
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static void m8199a(C1793 c1793) {
        c1793.f17112a = -1;
        c1793.f17113a = -1;
        c1793.f17114a = Integer.MIN_VALUE;
        c1793.f17117a = false;
        c1793.f17118a = false;
        FlexboxLayoutManager flexboxLayoutManager = c1793.f17119a;
        if (flexboxLayoutManager.mo1301a()) {
            int i = flexboxLayoutManager.f1881a;
            if (i == 0) {
                c1793.f17116a = flexboxLayoutManager.f1880a == 1;
                return;
            } else {
                c1793.f17116a = i == 2;
                return;
            }
        }
        int i2 = flexboxLayoutManager.f1881a;
        if (i2 == 0) {
            c1793.f17116a = flexboxLayoutManager.f1880a == 3;
        } else {
            c1793.f17116a = i2 == 2;
        }
    }

    public final String toString() {
        return "AnchorInfo{mPosition=" + this.f17112a + ", mFlexLinePosition=" + this.f17113a + ", mCoordinate=" + this.f17114a + ", mPerpendicularCoordinate=" + this.f17115a + ", mLayoutFromEnd=" + this.f17116a + ", mValid=" + this.f17117a + ", mAssignedFromSavedState=" + this.f17118a + '}';
    }
}
