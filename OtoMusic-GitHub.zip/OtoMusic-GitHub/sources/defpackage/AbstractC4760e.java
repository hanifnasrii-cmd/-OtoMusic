package defpackage;

import com.piyush.music.R;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: eͅ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4760e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final List f5948a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C4759e f5949a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final ArrayList f5950a;

    static {
        List<C4759e> listM9677a = AbstractC2852.m9677a(new C4759e("coffee", R.string.fn, R.string.fp, R.drawable.n3, true), new C4759e("love", R.string.a0i, R.string.fq, R.drawable.nq, false), new C4759e("movie", R.string.fy, R.string.fs, R.drawable.p7, false), new C4759e("pizza", R.string.g1, R.string.ft, R.drawable.tb, false), new C4759e("meal", R.string.fw, R.string.fr, R.drawable.np, false));
        f5948a = listM9677a;
        for (C4759e c4759e : listM9677a) {
            if (c4759e.f5947a) {
                f5949a = c4759e;
                List list = f5948a;
                ArrayList arrayList = new ArrayList();
                for (Object obj : list) {
                    if (!((C4759e) obj).f5947a) {
                        arrayList.add(obj);
                    }
                }
                f5950a = arrayList;
                return;
            }
        }
        throw new NoSuchElementException("Collection contains no element matching the predicate.");
    }
}
