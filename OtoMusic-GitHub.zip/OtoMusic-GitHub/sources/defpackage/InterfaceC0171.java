package defpackage;

/* JADX INFO: renamed from: ιؓ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0171 {
}
