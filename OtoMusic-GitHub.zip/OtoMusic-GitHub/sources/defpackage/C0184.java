package defpackage;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

/* JADX INFO: renamed from: ιِ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0184 extends ViewOutlineProvider {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ float f12195a;

    public C0184(float f) {
        this.f12195a = f;
    }

    @Override // android.view.ViewOutlineProvider
    public final void getOutline(View view, Outline outline) {
        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), this.f12195a);
    }
}
