package defpackage;

import android.os.Bundle;

/* JADX INFO: renamed from: е⃕, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1929 implements InterfaceC1962 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final AbstractC3284 f17778a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final InterfaceC1962 f17779a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C4150a f17780a;

    public C1929(AbstractC3284 abstractC3284, InterfaceC1962 interfaceC1962, C4150a c4150a) {
        this.f17778a = abstractC3284;
        this.f17779a = interfaceC1962;
        this.f17780a = c4150a;
    }

    @Override // defpackage.InterfaceC1962
    /* JADX INFO: renamed from: á */
    public final void mo3035a(String str, Bundle bundle) {
        this.f17779a.mo3035a(str, bundle);
    }
}
