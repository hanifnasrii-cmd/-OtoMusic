package defpackage;

import java.io.IOException;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: јެ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3564 extends AbstractC3478 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Method f23001a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f23002a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final InterfaceC1014 f23003a;

    public C3564(Method method, int i, InterfaceC1014 interfaceC1014) {
        this.f23001a = method;
        this.f23002a = i;
        this.f23003a = interfaceC1014;
    }

    @Override // defpackage.AbstractC3478
    /* JADX INFO: renamed from: á */
    public final void mo10647a(C2103 c2103, Object obj) {
        int i = this.f23002a;
        Method method = this.f23001a;
        if (obj == null) {
            throw AbstractC3573.m10767a(method, i, "Body parameter value must not be null.", new Object[0]);
        }
        try {
            c2103.f18363a = (AbstractC2101) this.f23003a.mo2731a(obj);
        } catch (IOException e) {
            throw AbstractC3573.m10768a(method, e, i, "Unable to convert " + obj + " to RequestBody", new Object[0]);
        }
    }
}
