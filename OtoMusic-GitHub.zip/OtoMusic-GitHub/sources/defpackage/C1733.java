package defpackage;

/* JADX INFO: renamed from: е͎, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1733 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f16927a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C3556 f16928a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f16929a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1733(C3556 c3556, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f16928a = c3556;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f16927a = obj;
        this.f16929a |= Integer.MIN_VALUE;
        return C3556.m10707a(this.f16928a, null, null, this);
    }
}
