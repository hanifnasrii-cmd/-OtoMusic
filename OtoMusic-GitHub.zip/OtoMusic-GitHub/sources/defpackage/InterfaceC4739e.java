package defpackage;

/* JADX INFO: renamed from: ḛ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC4739e {
    /* JADX INFO: renamed from: á */
    void mo2889a();
}
