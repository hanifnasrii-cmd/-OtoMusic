package defpackage;

import com.piyush.music.fragments.theme.ThemeFragment;
import com.piyush.music.models.CutOff;
import com.piyush.music.models.MetadataDownloadOptions;
import com.piyush.music.models.NowPlayingTheme;
import com.piyush.music.models.tag.TagFields;
import com.piyush.music.models.tag.TagFieldsParser;
import com.piyush.taglib.AudioProperties;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: renamed from: օؒ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C3811 implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f23763a;

    public /* synthetic */ C3811(int i) {
        this.f23763a = i;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        int i = this.f23763a;
        C6174p c6174p = C6174p.f10843a;
        Object obj2 = null;
        switch (i) {
            case 0:
                String str = (String) obj;
                int i2 = C3813.f23766a;
                Iterator<E> it = MetadataDownloadOptions.getEntries().iterator();
                while (true) {
                    if (it.hasNext()) {
                        Object next = it.next();
                        if (AbstractC3098.m10094a(((MetadataDownloadOptions) next).getStorageKey(), str)) {
                            obj2 = next;
                        }
                    }
                }
                MetadataDownloadOptions metadataDownloadOptions = (MetadataDownloadOptions) obj2;
                if (metadataDownloadOptions != null) {
                    C0484 c0484 = AbstractC3810.m11021a().f13194a;
                    InterfaceC3192 interfaceC3192 = C0492.f13161a[15];
                    c0484.mo6324a(metadataDownloadOptions);
                }
                return c6174p;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                boolean zBooleanValue = ((Boolean) obj).booleanValue();
                int i3 = C3817.f23771a;
                return Boolean.valueOf(!zBooleanValue);
            case 2:
                Integer num = (Integer) obj;
                int i4 = C3817.f23771a;
                return num.intValue() <= 0 ? Integer.valueOf(AbstractC1458.m7713a(AbstractC3386.f22516a)) : num;
            case 3:
                int i5 = C3819.f23773a;
                return Boolean.valueOf(!((NowPlayingTheme) obj).isEditorial());
            case 4:
                String str2 = (String) obj;
                int i6 = C3822.f23776a;
                Iterator<E> it2 = CutOff.getEntries().iterator();
                while (true) {
                    if (it2.hasNext()) {
                        Object next2 = it2.next();
                        if (AbstractC3098.m10094a(((CutOff) next2).getStorageKey(), str2)) {
                            obj2 = next2;
                        }
                    }
                }
                CutOff cutOff = (CutOff) obj2;
                if (cutOff != null) {
                    C0484 c04842 = AbstractC3810.m11021a().f13190a;
                    InterfaceC3192 interfaceC31922 = C0492.f13161a[13];
                    c04842.mo6324a(cutOff);
                }
                return c6174p;
            case 5:
                String str3 = (String) obj;
                int i7 = C3822.f23776a;
                Iterator<E> it3 = CutOff.getEntries().iterator();
                while (true) {
                    if (it3.hasNext()) {
                        Object next3 = it3.next();
                        if (AbstractC3098.m10094a(((CutOff) next3).getStorageKey(), str3)) {
                            obj2 = next3;
                        }
                    }
                }
                CutOff cutOff2 = (CutOff) obj2;
                if (cutOff2 != null) {
                    C0484 c04843 = AbstractC3810.m11021a().f13185a;
                    InterfaceC3192 interfaceC31923 = C0492.f13161a[9];
                    c04843.mo6324a(cutOff2);
                }
                return c6174p;
            case 6:
                return ((TagFields) obj).getTitle();
            case 7:
                return ((TagFields) obj).getArtist();
            case 8:
                return ((TagFields) obj).getAlbum();
            case 9:
                return ((TagFields) obj).getAlbumArtist();
            case 10:
                return ((TagFields) obj).getGenre();
            case 11:
                return TagFieldsParser.INSTANCE.yearOnly(((TagFields) obj).getYear());
            case 12:
                return ((TagFields) obj).getComposer();
            default:
                EnumC0274 enumC0274 = (EnumC0274) obj;
                List list = ThemeFragment.f3413a;
                return Boolean.valueOf(enumC0274 == EnumC0274.DEFAULT);
        }
    }
}
