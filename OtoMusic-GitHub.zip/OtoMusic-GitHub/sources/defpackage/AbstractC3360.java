package defpackage;

import android.net.ConnectivityManager;
import android.net.Network;

/* JADX INFO: renamed from: ј̲, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC3360 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final Network m10449a(ConnectivityManager connectivityManager) {
        AbstractC3098.m10103a(connectivityManager, "<this>");
        return connectivityManager.getActiveNetwork();
    }
}
