package defpackage;

import android.view.View;
import androidx.fragment.app.AbstractActivityC3991a;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: е֘, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1779 implements i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Set f17070a = Collections.newSetFromMap(new WeakHashMap());

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public volatile boolean f17071a;

    @Override // defpackage.i
    /* JADX INFO: renamed from: â */
    public final void mo3345a(AbstractActivityC3991a abstractActivityC3991a) {
        if (!this.f17071a && this.f17070a.add(abstractActivityC3991a)) {
            View decorView = abstractActivityC3991a.getWindow().getDecorView();
            decorView.getViewTreeObserver().addOnDrawListener(new ViewTreeObserverOnDrawListenerC1778(this, decorView));
        }
    }
}
