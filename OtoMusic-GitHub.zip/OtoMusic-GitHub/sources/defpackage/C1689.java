package defpackage;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: е̢, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1689 extends AbstractC1804 {

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public volatile C1688 f16786a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public C1688 f16787a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public C4538c f16788a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C5035i f16789a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f16790a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f16791a;

    @Override // defpackage.AbstractC1804
    /* JADX INFO: renamed from: a̍ */
    public final void mo2449a() {
        C4538c c4538c = this.f16788a;
        if (c4538c != null) {
            AbstractC1458.m7704a((float[]) c4538c.f5219a);
            AbstractC1458.m7704a((float[]) c4538c.f5220a);
        }
        C5035i c5035i = this.f16789a;
        if (c5035i != null) {
            ArrayList arrayList = c5035i.f6905a;
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj = arrayList.get(i);
                i++;
                C5034i c5034i = (C5034i) obj;
                AbstractC1458.m7704a(c5034i.f6900a);
                c5034i.f6901a = 0;
                c5034i.f6902a = 0.0f;
            }
            ArrayList arrayList2 = c5035i.f6906a;
            int size2 = arrayList2.size();
            int i2 = 0;
            while (i2 < size2) {
                Object obj2 = arrayList2.get(i2);
                i2++;
                C5034i c5034i2 = (C5034i) obj2;
                AbstractC1458.m7704a(c5034i2.f6900a);
                c5034i2.f6901a = 0;
                c5034i2.f6902a = 0.0f;
            }
            ArrayList arrayList3 = c5035i.f6907a;
            int size3 = arrayList3.size();
            int i3 = 0;
            while (i3 < size3) {
                Object obj3 = arrayList3.get(i3);
                i3++;
                C5033i c5033i = (C5033i) obj3;
                AbstractC1458.m7704a(c5033i.f6898a);
                c5033i.f6899a = 0;
            }
            ArrayList arrayList4 = c5035i.f6908a;
            int size4 = arrayList4.size();
            int i4 = 0;
            while (i4 < size4) {
                Object obj4 = arrayList4.get(i4);
                i4++;
                C5033i c5033i2 = (C5033i) obj4;
                AbstractC1458.m7704a(c5033i2.f6898a);
                c5033i2.f6899a = 0;
            }
        }
    }

    @Override // defpackage.AbstractC1804
    /* JADX INFO: renamed from: a̎ */
    public final void mo2450a(int i, int i2) {
        this.f16790a = i;
        this.f16791a = i2;
        this.f16787a = null;
        this.f16789a = null;
    }

    @Override // defpackage.AbstractC1804
    /* JADX INFO: renamed from: ȁ */
    public final void mo2451a(float[] fArr, int i) {
        C1688 c1688 = this.f16786a;
        float f = 0.0f;
        if (c1688 != this.f16787a) {
            List listM7706a = c1688.f16783a == 0.0f ? C4891e.f6320a : AbstractC1458.m7706a(new C4539c[]{AbstractC0284.m6086a(new C1769(0.5412f), this.f16790a), AbstractC0284.m6086a(new C1769(1.3066f), this.f16790a), AbstractC0284.m6086a(new C1772(70.0f, c1688.f16783a, 1.0f, true), this.f16790a)});
            C4538c c4538c = this.f16788a;
            if (listM7706a.isEmpty()) {
                this.f16788a = null;
            } else if (c4538c == null || listM7706a.size() != ((C4539c[]) c4538c.f5218a).length) {
                this.f16788a = new C4538c(this.f16791a, listM7706a);
            } else {
                c4538c.f5218a = (C4539c[]) listM7706a.toArray(new C4539c[0]);
            }
            if (c1688.f16784a <= 0.0f || this.f16791a != 2) {
                this.f16789a = null;
            } else if (this.f16789a == null) {
                this.f16789a = new C5035i(this.f16790a);
            }
            this.f16787a = c1688;
        }
        float f2 = c1688.f16785a;
        if (f2 != 1.0f) {
            for (int i2 = 0; i2 < i; i2++) {
                fArr[i2] = fArr[i2] * f2;
            }
        }
        C4538c c4538c2 = this.f16788a;
        if (c4538c2 != null) {
            c4538c2.m2408a(fArr, i);
        }
        C5035i c5035i = this.f16789a;
        if (c5035i == null) {
            return;
        }
        float f3 = c1688.f16784a;
        ArrayList arrayList = c5035i.f6907a;
        float f4 = c5035i.f6910a;
        float f5 = c5035i.f6909a;
        ArrayList arrayList2 = c5035i.f6905a;
        int i3 = 0;
        while (true) {
            int i4 = i3 + 1;
            if (i4 >= i) {
                return;
            }
            float f6 = fArr[i3];
            float f7 = fArr[i4];
            float f8 = (f6 + f7) * 0.015f;
            int size = arrayList2.size();
            float fM3375a = f;
            float fM3375a2 = fM3375a;
            for (int i5 = 0; i5 < size; i5++) {
                fM3375a = ((C5034i) arrayList2.get(i5)).m3375a(f8, f5, f4) + fM3375a;
                fM3375a2 = ((C5034i) c5035i.f6906a.get(i5)).m3375a(f8, f5, f4) + fM3375a2;
            }
            float fM3374a = fM3375a;
            float fM3374a2 = fM3375a2;
            int i6 = 0;
            for (int size2 = arrayList.size(); i6 < size2; size2 = size2) {
                fM3374a = ((C5033i) arrayList.get(i6)).m3374a(fM3374a);
                fM3374a2 = ((C5033i) c5035i.f6908a.get(i6)).m3374a(fM3374a2);
                i6++;
            }
            fArr[i3] = (fM3374a * f3) + f6;
            fArr[i4] = (fM3374a2 * f3) + f7;
            i3 += 2;
            f = 0.0f;
        }
    }
}
