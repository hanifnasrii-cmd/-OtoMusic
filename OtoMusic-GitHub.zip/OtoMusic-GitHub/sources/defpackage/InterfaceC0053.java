package defpackage;

/* JADX INFO: renamed from: ι̵, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC0053 {
    void invoke(Object obj);
}
