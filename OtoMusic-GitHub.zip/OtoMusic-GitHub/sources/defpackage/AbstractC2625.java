package defpackage;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.android.billingclient.api.Purchase;
import java.util.ArrayList;
import org.json.JSONException;

/* JADX INFO: renamed from: рⷩ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2625 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final int f19874a = Runtime.getRuntime().availableProcessors();

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static int m9315a(String str, Bundle bundle) {
        if (bundle == null) {
            Log.isLoggable(str, 5);
            return 6;
        }
        Object obj = bundle.get("RESPONSE_CODE");
        if (obj == null) {
            m9321a(str, "getResponseCodeFromBundle() got null response code, assuming OK");
            return 0;
        }
        if (obj instanceof Integer) {
            return ((Integer) obj).intValue();
        }
        "Unexpected type for bundle response code: ".concat(obj.getClass().getName());
        Log.isLoggable(str, 5);
        return 6;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static void m9316a(Bundle bundle, String str, String str2, long j) {
        bundle.putString("playBillingLibraryVersion", str);
        if (str2 != null) {
            bundle.putString("playBillingLibraryWrapperVersion", str2);
        }
        bundle.putLong("billingClientSessionId", j);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static Bundle m9317a(C4535c c4535c, EnumC0825 enumC0825) {
        Bundle bundle = new Bundle();
        bundle.putInt("RESPONSE_CODE", c4535c.f5209a);
        bundle.putString("DEBUG_MESSAGE", c4535c.f5211a);
        bundle.putInt("LOG_REASON", enumC0825.m6827a());
        return bundle;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static Bundle m9318a(String str, String str2, ArrayList arrayList, C5220i c5220i, long j) {
        Bundle bundle = new Bundle();
        m9316a(bundle, str, str2, j);
        bundle.putBoolean("enablePendingPurchases", true);
        bundle.putString("SKU_DETAILS_RESPONSE_FORMAT", "PRODUCT_DETAILS");
        C2608 c2608 = AbstractC2611.f19843a;
        Object[] objArr = {"subs", "inapp"};
        AbstractC2179.m8663a(2, objArr);
        bundle.putStringArrayList("PRODUCT_TYPES_TO_RETURN_MULTIPLE_OFFERS", new ArrayList<>(AbstractC2611.m9294a(2, objArr)));
        Object[] objArr2 = {"inapp"};
        AbstractC2179.m8663a(1, objArr2);
        bundle.putStringArrayList("PRODUCT_TYPES_TO_RETURN_PREORDER_OFFERS", new ArrayList<>(AbstractC2611.m9294a(1, objArr2)));
        Object[] objArr3 = {"inapp"};
        AbstractC2179.m8663a(1, objArr3);
        bundle.putStringArrayList("PRODUCT_TYPES_TO_RETURN_RENT_OFFERS", new ArrayList<>(AbstractC2611.m9294a(1, objArr3)));
        bundle.putBoolean("SHOULD_RETURN_UNFETCHED_PRODUCTS", true);
        ArrayList<String> arrayList2 = new ArrayList<>();
        ArrayList<String> arrayList3 = new ArrayList<>();
        ArrayList<String> arrayList4 = new ArrayList<>();
        int size = arrayList.size();
        boolean z = false;
        boolean z2 = false;
        for (int i = 0; i < size; i++) {
            C5947o c5947o = (C5947o) arrayList.get(i);
            arrayList2.add(null);
            z |= !TextUtils.isEmpty(null);
            arrayList4.add(null);
            z2 |= !TextUtils.isEmpty(null);
            if (c5947o.f10034a.equals("first_party")) {
                throw new NullPointerException("Serialized DocId is required for constructing ExtraParams to query ProductDetails for all first party products.");
            }
        }
        if (z) {
            bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2);
        }
        if (!arrayList3.isEmpty()) {
            bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList3);
        }
        if (!TextUtils.isEmpty(null)) {
            bundle.putString("accountName", null);
        }
        if (z2) {
            bundle.putStringArrayList("SKU_DYNAMIC_PRODUCT_TOKEN_LIST", arrayList4);
        }
        return bundle;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static C4535c m9319a(String str, Intent intent) {
        if (intent != null) {
            C4534c c4534cM2406a = C4535c.m2406a();
            c4534cM2406a.f5206a = m9315a(str, intent.getExtras());
            c4534cM2406a.f5208a = m9320a(str, intent.getExtras());
            return c4534cM2406a.m2405a();
        }
        Log.isLoggable("BillingHelper", 5);
        C4534c c4534cM2406a2 = C4535c.m2406a();
        c4534cM2406a2.f5206a = 6;
        c4534cM2406a2.f5208a = "An internal error occurred.";
        return c4534cM2406a2.m2405a();
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static String m9320a(String str, Bundle bundle) {
        if (bundle == null) {
            Log.isLoggable(str, 5);
            return "";
        }
        Object obj = bundle.get("DEBUG_MESSAGE");
        if (obj == null) {
            m9321a(str, "getDebugMessageFromBundle() got null response code, assuming OK");
            return "";
        }
        if (obj instanceof String) {
            return (String) obj;
        }
        "Unexpected type for debug message: ".concat(obj.getClass().getName());
        Log.isLoggable(str, 5);
        return "";
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static void m9321a(String str, String str2) {
        if (!Log.isLoggable(str, 2) || str2.isEmpty()) {
            return;
        }
        int i = 40000;
        while (!str2.isEmpty() && i > 0) {
            int iMin = Math.min(str2.length(), Math.min(4000, i));
            str2.substring(0, iMin);
            str2 = str2.substring(iMin);
            i -= iMin;
        }
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static void m9322a(String str) {
        try {
            Log.isLoggable(str, 5);
        } catch (Throwable unused) {
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static Purchase m9323a(String str, String str2) {
        if (str == null || str2 == null) {
            m9321a("BillingHelper", "Received a null purchase data.");
            return null;
        }
        try {
            return new Purchase(str, str2);
        } catch (JSONException e) {
            "Got JSONException while parsing purchase data: ".concat(e.toString());
            Log.isLoggable("BillingHelper", 5);
            return null;
        }
    }
}
