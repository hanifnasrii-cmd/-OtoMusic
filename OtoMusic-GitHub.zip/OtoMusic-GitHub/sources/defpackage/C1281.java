package defpackage;

/* JADX INFO: renamed from: ϲ⃪, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1281 extends AbstractC3732 {

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final AbstractC5559j f15433a;

    public C1281(AbstractC5559j abstractC5559j) {
        super(abstractC5559j.f11082a);
        this.f15433a = abstractC5559j;
    }
}
