package defpackage;

import com.piyush.music.models.BackgroundVocal;
import java.util.ArrayList;

/* JADX INFO: renamed from: ι֠, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0132 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final ArrayList f12049a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final boolean f12050a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f12051a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f12052a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final BackgroundVocal f12053a;

    public C0132(ArrayList arrayList, boolean z, String str, int i, BackgroundVocal backgroundVocal) {
        this.f12049a = arrayList;
        this.f12050a = z;
        this.f12051a = str;
        this.f12052a = i;
        this.f12053a = backgroundVocal;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0132)) {
            return false;
        }
        C0132 c0132 = (C0132) obj;
        return this.f12049a.equals(c0132.f12049a) && this.f12050a == c0132.f12050a && AbstractC3098.m10094a(this.f12051a, c0132.f12051a) && this.f12052a == c0132.f12052a && AbstractC3098.m10094a(this.f12053a, c0132.f12053a);
    }

    public final int hashCode() {
        int iM975a = AbstractC4164a.m975a(this.f12052a, AbstractC4072a.m735a(this.f12051a, AbstractC4164a.m978a(this.f12049a.hashCode() * 31, this.f12050a, 31), 31), 31);
        BackgroundVocal backgroundVocal = this.f12053a;
        return iM975a + (backgroundVocal == null ? 0 : backgroundVocal.hashCode());
    }

    public final String toString() {
        return "ParsedLrcLine(timeMsList=" + this.f12049a + ", isTranslation=" + this.f12050a + ", content=" + this.f12051a + ", voice=" + this.f12052a + ", background=" + this.f12053a + ")";
    }
}
