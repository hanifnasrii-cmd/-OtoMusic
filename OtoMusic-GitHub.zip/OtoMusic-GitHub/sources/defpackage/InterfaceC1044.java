package defpackage;

/* JADX INFO: renamed from: ϲ̳, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1044 {
    /* JADX INFO: renamed from: a̖ */
    InterfaceC1031 mo686a();
}
