package defpackage;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* JADX INFO: renamed from: ј֨, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3450 implements OnBackAnimationCallback {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5040i f22760a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5040i f22761a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5038i f22762a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5038i f22763a;

    public C3450(InterfaceC5040i interfaceC5040i, InterfaceC5040i interfaceC5040i2, InterfaceC5038i interfaceC5038i, InterfaceC5038i interfaceC5038i2) {
        this.f22760a = interfaceC5040i;
        this.f22761a = interfaceC5040i2;
        this.f22762a = interfaceC5038i;
        this.f22763a = interfaceC5038i2;
    }

    public final void onBackCancelled() {
        this.f22763a.invoke();
    }

    public final void onBackInvoked() {
        this.f22762a.invoke();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        AbstractC3098.m10103a(backEvent, "backEvent");
        this.f22761a.invoke(new C4369c(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        AbstractC3098.m10103a(backEvent, "backEvent");
        this.f22760a.invoke(new C4369c(backEvent));
    }
}
