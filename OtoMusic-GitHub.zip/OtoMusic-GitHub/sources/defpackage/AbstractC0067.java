package defpackage;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.imageview.ShapeableImageView;
import com.piyush.music.widget.stats.CountUpTextView;
import com.piyush.music.widget.stats.HeatmapView;
import com.piyush.music.widget.stats.SegmentedControlView;

/* JADX INFO: renamed from: ἰ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0067 extends AbstractC6265p {

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final RecyclerView f11796a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final ShapeableImageView f11797a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final TextView f11798a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public final TextView f11799a;

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public final AppCompatImageView f11800a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public final TextView f11801a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public final TextView f11802a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final ConstraintLayout f11803a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final LinearLayout f11804a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final LinearLayout f11805a;

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public final HeatmapView f11806a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public final TextView f11807a;

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final CountUpTextView f11808a;

    /* JADX INFO: renamed from: ą, reason: contains not printable characters */
    public final TextView f11809a;

    /* JADX INFO: renamed from: a̩, reason: contains not printable characters */
    public final NestedScrollView f11810a;

    /* JADX INFO: renamed from: a̪, reason: contains not printable characters */
    public final CoordinatorLayout f11811a;

    /* JADX INFO: renamed from: a̫, reason: contains not printable characters */
    public final TextView f11812a;

    /* JADX INFO: renamed from: a̬, reason: contains not printable characters */
    public final CountUpTextView f11813a;

    /* JADX INFO: renamed from: a̭, reason: contains not printable characters */
    public final TextView f11814a;

    /* JADX INFO: renamed from: a̮, reason: contains not printable characters */
    public final LinearLayout f11815a;

    /* JADX INFO: renamed from: a̯, reason: contains not printable characters */
    public final ProgressBar f11816a;

    /* JADX INFO: renamed from: a̰, reason: contains not printable characters */
    public final TextView f11817a;

    /* JADX INFO: renamed from: a̱, reason: contains not printable characters */
    public final CountUpTextView f11818a;

    /* JADX INFO: renamed from: a̲, reason: contains not printable characters */
    public final TextView f11819a;

    /* JADX INFO: renamed from: a̳, reason: contains not printable characters */
    public final SegmentedControlView f11820a;

    /* JADX INFO: renamed from: a̴, reason: contains not printable characters */
    public final MaterialToolbar f11821a;

    /* JADX INFO: renamed from: a̵, reason: contains not printable characters */
    public final TextView f11822a;

    public AbstractC0067(InterfaceC1126 interfaceC1126, View view, RecyclerView recyclerView, ShapeableImageView shapeableImageView, TextView textView, TextView textView2, AppCompatImageView appCompatImageView, TextView textView3, TextView textView4, ConstraintLayout constraintLayout, LinearLayout linearLayout, LinearLayout linearLayout2, HeatmapView heatmapView, TextView textView5, CountUpTextView countUpTextView, TextView textView6, NestedScrollView nestedScrollView, CoordinatorLayout coordinatorLayout, TextView textView7, CountUpTextView countUpTextView2, TextView textView8, LinearLayout linearLayout3, ProgressBar progressBar, TextView textView9, CountUpTextView countUpTextView3, TextView textView10, SegmentedControlView segmentedControlView, MaterialToolbar materialToolbar, TextView textView11) {
        super(interfaceC1126, view, 0);
        this.f11796a = recyclerView;
        this.f11797a = shapeableImageView;
        this.f11798a = textView;
        this.f11799a = textView2;
        this.f11800a = appCompatImageView;
        this.f11801a = textView3;
        this.f11802a = textView4;
        this.f11803a = constraintLayout;
        this.f11804a = linearLayout;
        this.f11805a = linearLayout2;
        this.f11806a = heatmapView;
        this.f11807a = textView5;
        this.f11808a = countUpTextView;
        this.f11809a = textView6;
        this.f11810a = nestedScrollView;
        this.f11811a = coordinatorLayout;
        this.f11812a = textView7;
        this.f11813a = countUpTextView2;
        this.f11814a = textView8;
        this.f11815a = linearLayout3;
        this.f11816a = progressBar;
        this.f11817a = textView9;
        this.f11818a = countUpTextView3;
        this.f11819a = textView10;
        this.f11820a = segmentedControlView;
        this.f11821a = materialToolbar;
        this.f11822a = textView11;
    }
}
