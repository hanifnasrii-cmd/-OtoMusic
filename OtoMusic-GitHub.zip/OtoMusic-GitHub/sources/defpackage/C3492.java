package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.piyush.music.fragments.list.OpenMode;

/* JADX INFO: renamed from: јَ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3492 extends OpenMode {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C3492 f22807a = new C3492(null);
    public static final Parcelable.Creator<C3492> CREATOR = new C5663j(15);

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(1);
    }
}
