package defpackage;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* JADX INFO: renamed from: ιۙ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0204 implements Map.Entry, InterfaceC3189 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C0207 f12261a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f12262a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f12263a;

    public C0204(C0207 c0207, int i) {
        AbstractC3098.m10103a(c0207, "map");
        this.f12261a = c0207;
        this.f12262a = i;
        this.f12263a = c0207.f12276a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m5962a() {
        if (this.f12261a.f12276a != this.f12263a) {
            throw new ConcurrentModificationException("The backing map has been modified after this entry was obtained.");
        }
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        return AbstractC3098.m10094a(entry.getKey(), getKey()) && AbstractC3098.m10094a(entry.getValue(), getValue());
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        m5962a();
        return this.f12261a.f12269a[this.f12262a];
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        m5962a();
        Object[] objArr = this.f12261a.f12270a;
        AbstractC3098.m10100a(objArr);
        return objArr[this.f12262a];
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Object key = getKey();
        int iHashCode = key != null ? key.hashCode() : 0;
        Object value = getValue();
        return iHashCode ^ (value != null ? value.hashCode() : 0);
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        m5962a();
        C0207 c0207 = this.f12261a;
        c0207.m5968a();
        Object[] objArr = c0207.f12270a;
        if (objArr == null) {
            int length = c0207.f12269a.length;
            if (length < 0) {
                throw new IllegalArgumentException("capacity must be non-negative.");
            }
            objArr = new Object[length];
            c0207.f12270a = objArr;
        }
        int i = this.f12262a;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        return obj2;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getKey());
        sb.append('=');
        sb.append(getValue());
        return sb.toString();
    }
}
