package defpackage;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;

/* JADX INFO: renamed from: jܰ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5572j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public long f8831a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public TimeInterpolator f8833a = null;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f8834a = 0;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f8835a = 1;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public long f8832a = 150;

    public C5572j(long j) {
        this.f8831a = j;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m4406a(ObjectAnimator objectAnimator) {
        objectAnimator.setStartDelay(this.f8831a);
        objectAnimator.setDuration(this.f8832a);
        objectAnimator.setInterpolator(m4407a());
        objectAnimator.setRepeatCount(this.f8834a);
        objectAnimator.setRepeatMode(this.f8835a);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final TimeInterpolator m4407a() {
        TimeInterpolator timeInterpolator = this.f8833a;
        return timeInterpolator != null ? timeInterpolator : AbstractC4336a.f1798a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C5572j)) {
            return false;
        }
        C5572j c5572j = (C5572j) obj;
        if (this.f8831a == c5572j.f8831a && this.f8832a == c5572j.f8832a && this.f8834a == c5572j.f8834a && this.f8835a == c5572j.f8835a) {
            return m4407a().getClass().equals(c5572j.m4407a().getClass());
        }
        return false;
    }

    public final int hashCode() {
        long j = this.f8831a;
        long j2 = this.f8832a;
        return ((((m4407a().getClass().hashCode() + (((((int) (j ^ (j >>> 32))) * 31) + ((int) ((j2 >>> 32) ^ j2))) * 31)) * 31) + this.f8834a) * 31) + this.f8835a;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("\n");
        sb.append(C5572j.class.getName());
        sb.append('{');
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" delay: ");
        sb.append(this.f8831a);
        sb.append(" duration: ");
        sb.append(this.f8832a);
        sb.append(" interpolator: ");
        sb.append(m4407a().getClass());
        sb.append(" repeatCount: ");
        sb.append(this.f8834a);
        sb.append(" repeatMode: ");
        return AbstractC4072a.m748a(sb, this.f8835a, "}\n");
    }
}
