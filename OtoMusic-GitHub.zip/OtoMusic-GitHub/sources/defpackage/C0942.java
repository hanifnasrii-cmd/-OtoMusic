package defpackage;

/* JADX INFO: renamed from: ρ⃛, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0942 extends AbstractC6386s {
    private static final C0942 zzg;
    private int zzb;
    private int zzd;
    private int zze;
    private C0939 zzf;

    static {
        C0942 c0942 = new C0942();
        zzg = c0942;
        AbstractC6386s.m5619a(C0942.class, c0942);
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzg, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001င\u0000\u0002င\u0001\u0003ဉ\u0002", new Object[]{"zzb", "zzd", "zze", "zzf"});
        }
        if (i2 == 3) {
            return new C0942();
        }
        if (i2 == 4) {
            return new C0940(zzg);
        }
        if (i2 == 5) {
            return zzg;
        }
        throw null;
    }
}
