package defpackage;

import android.graphics.RenderNode;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.media.MediaCodecInfo;

/* JADX INFO: renamed from: а߫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC1583 {
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static /* bridge */ /* synthetic */ RenderNode m7984a(Object obj) {
        return (RenderNode) obj;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static /* synthetic */ Typeface.CustomFallbackBuilder m7985a(FontFamily fontFamily) {
        return new Typeface.CustomFallbackBuilder(fontFamily);
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static /* synthetic */ FontFamily.Builder m7988a(Font font) {
        return new FontFamily.Builder(font);
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static /* synthetic */ MediaCodecInfo.VideoCapabilities.PerformancePoint m7989a() {
        return new MediaCodecInfo.VideoCapabilities.PerformancePoint(1280, 720, 60);
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static /* synthetic */ MediaCodecInfo.VideoCapabilities.PerformancePoint m7990a(int i, int i2, int i3) {
        return new MediaCodecInfo.VideoCapabilities.PerformancePoint(i, i2, i3);
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static /* bridge */ /* synthetic */ MediaCodecInfo.VideoCapabilities.PerformancePoint m7991a(Object obj) {
        return (MediaCodecInfo.VideoCapabilities.PerformancePoint) obj;
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static /* synthetic */ void m7996a() {
    }

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public static /* synthetic */ void m8006a() {
    }

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public static /* synthetic */ void m8008a() {
    }
}
