package defpackage;

import android.R;

/* JADX INFO: renamed from: oⷢ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC5982o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final int[] f10144a = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, com.piyush.music.R.attr.pc, com.piyush.music.R.attr.pd, com.piyush.music.R.attr.pe, com.piyush.music.R.attr.pf, com.piyush.music.R.attr.pg, com.piyush.music.R.attr.v3, com.piyush.music.R.attr.a5b, com.piyush.music.R.attr.a86, com.piyush.music.R.attr.a8n};
}
