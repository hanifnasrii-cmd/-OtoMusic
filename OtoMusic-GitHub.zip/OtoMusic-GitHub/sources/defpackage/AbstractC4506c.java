package defpackage;

/* JADX INFO: renamed from: c֭, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4506c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final String f5094a;

    static {
        String strM5884a = C0110.m5884a("BatteryNotLowTracker");
        AbstractC3098.m10102a(strM5884a, "tagWithPrefix(\"BatteryNotLowTracker\")");
        f5094a = strM5884a;
    }
}
