package defpackage;

import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import com.piyush.music.R;
import java.util.List;

/* JADX INFO: renamed from: р̯, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2364 extends AbstractC2368 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final PathInterpolator f19195a = new PathInterpolator(0.0f, 1.1f, 0.0f, 1.0f);

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final C1708 f19196a = new C1708(0);

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final DecelerateInterpolator f19197a = new DecelerateInterpolator(1.5f);

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final AccelerateInterpolator f19198a = new AccelerateInterpolator(1.5f);

    public C2364(int i, Interpolator interpolator, long j) {
        super(i, interpolator, j);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static void m8784a(View view) {
        C3083 c3083M8789a = m8789a(view);
        if (c3083M8789a != null) {
            c3083M8789a.f21687a.setTranslationY(0.0f);
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                m8784a(viewGroup.getChildAt(i));
            }
        }
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static void m8785a(View view, C2390 c2390, boolean z) {
        C3083 c3083M8789a = m8789a(view);
        if (c3083M8789a != null) {
            c3083M8789a.f21686a = c2390;
            if (!z) {
                View view2 = c3083M8789a.f21687a;
                int[] iArr = c3083M8789a.f21690a;
                view2.getLocationOnScreen(iArr);
                z = true;
                c3083M8789a.f21688a = iArr[1];
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                m8785a(viewGroup.getChildAt(i), c2390, z);
            }
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static void m8786a(View view, C2390 c2390, List list) {
        C3083 c3083M8789a = m8789a(view);
        if (c3083M8789a != null) {
            c3083M8789a.m10036a(c2390, list);
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                m8786a(viewGroup.getChildAt(i), c2390, list);
            }
        }
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static void m8787a(View view, C5166i c5166i) {
        C3083 c3083M8789a = m8789a(view);
        if (c3083M8789a != null) {
            View view2 = c3083M8789a.f21687a;
            int[] iArr = c3083M8789a.f21690a;
            view2.getLocationOnScreen(iArr);
            int i = c3083M8789a.f21688a - iArr[1];
            c3083M8789a.f21689a = i;
            view2.setTranslationY(i);
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                m8787a(viewGroup.getChildAt(i2), c5166i);
            }
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static WindowInsets m8788a(View view, WindowInsets windowInsets) {
        return view.getTag(R.id.tag_on_apply_window_listener) != null ? windowInsets : view.onApplyWindowInsets(windowInsets);
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static C3083 m8789a(View view) {
        Object tag = view.getTag(R.id.tag_window_insets_animation_callback);
        if (tag instanceof ViewOnApplyWindowInsetsListenerC2363) {
            return ((ViewOnApplyWindowInsetsListenerC2363) tag).f19193a;
        }
        return null;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static void m8790a(View view, C3083 c3083) {
        View.OnApplyWindowInsetsListener viewOnApplyWindowInsetsListenerC2363 = new ViewOnApplyWindowInsetsListenerC2363(view, c3083);
        view.setTag(R.id.tag_window_insets_animation_callback, viewOnApplyWindowInsetsListenerC2363);
        if (view.getTag(R.id.tag_compat_insets_dispatch) == null && view.getTag(R.id.tag_on_apply_window_listener) == null) {
            view.setOnApplyWindowInsetsListener(viewOnApplyWindowInsetsListenerC2363);
        }
    }
}
