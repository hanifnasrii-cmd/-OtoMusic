package defpackage;

/* JADX INFO: renamed from: оۭ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC2205 extends AutoCloseable {
    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    boolean mo8686a();

    /* JADX INFO: renamed from: a̽, reason: contains not printable characters */
    InterfaceC2207 mo8687a(String str);
}
