package defpackage;

import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewOutlineProvider;
import com.google.android.material.chip.Chip;
import com.piyush.music.widget.AnimatedCollageView;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: aⷧ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4315a extends ViewOutlineProvider {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f1728a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ Object f1729a;

    public /* synthetic */ C4315a(int i, Object obj) {
        this.f1728a = i;
        this.f1729a = obj;
    }

    @Override // android.view.ViewOutlineProvider
    public final void getOutline(View view, Outline outline) {
        switch (this.f1728a) {
            case 0:
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), ((AnimatedCollageView) this.f1729a).f3843a);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C2776 c2776 = ((Chip) this.f1729a).f2319a;
                if (c2776 == null) {
                    outline.setAlpha(0.0f);
                } else {
                    c2776.getOutline(outline);
                }
                break;
            case 2:
                int width = view.getWidth();
                if (width > 0 && view.getHeight() > 0) {
                    int iM5206a = AbstractC6161p.m5206a(AbstractC2411.m8929a(AbstractC6161p.m5205a(((C1694) this.f1729a).f16806a, 0.0f, 1.0f) * width), 1, width);
                    float height = view.getHeight() / 2.0f;
                    if (view.getLayoutDirection() != 1) {
                        outline.setRoundRect(width - iM5206a, 0, width, view.getHeight(), height);
                    } else {
                        outline.setRoundRect(0, 0, iM5206a, view.getHeight(), height);
                    }
                } else {
                    outline.setEmpty();
                }
                break;
            case 3:
                C0469 c0469 = (C0469) this.f1729a;
                if (c0469.f13110a != null && !c0469.f13111a.isEmpty()) {
                    RectF rectF = c0469.f13111a;
                    outline.setRoundRect((int) rectF.left, (int) rectF.top, (int) rectF.right, (int) rectF.bottom, c0469.f13114a);
                    break;
                }
                break;
            default:
                Path path = ((C0470) this.f1729a).f13112a;
                if (!path.isEmpty()) {
                    outline.setPath(path);
                }
                break;
        }
    }
}
