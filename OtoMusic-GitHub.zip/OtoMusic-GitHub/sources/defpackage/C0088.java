package defpackage;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;

/* JADX INFO: renamed from: ι͘, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0088 extends Drawable implements Drawable.Callback {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Context f11880a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C0091 f11881a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C0090 f11882a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C0087 f11883a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public int f11885a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public C6224p f11886a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C4339a f11879a = new C4339a();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final Paint f11884a = new Paint();

    public C0088(Context context, C0091 c0091, C0090 c0090, C0087 c0087) {
        this.f11880a = context;
        this.f11881a = c0091;
        this.f11882a = c0090;
        this.f11883a = c0087;
        c0087.f11877a = this;
        setAlpha(255);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean m5857a(boolean z, boolean z2, boolean z3) {
        boolean visible = super.setVisible(z, z2);
        C0087 c0087 = this.f11883a;
        ObjectAnimator objectAnimator = c0087.f11874a;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        C3697 c3697 = c0087.f11875a;
        if (c3697 != null) {
            c3697.m10900a();
        }
        if (!z || !z3 || (this.f11879a != null && C4339a.m1225a(this.f11880a.getContentResolver()) == 0.0f)) {
            return visible;
        }
        if (c0087.f11875a == null) {
            C3697 c36972 = new C3697(c0087, C0087.f11870a);
            C3698 c3698 = new C3698();
            c3698.m10902a(200.0f);
            c3698.m10901a(0.6f);
            c36972.f23381a = c3698;
            c36972.m10898a(0.01f);
            c0087.f11875a = c36972;
        }
        if (c0087.f11874a == null) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(c0087, C0087.f11869a, 0.0f, 1.0f);
            c0087.f11874a = objectAnimatorOfFloat;
            objectAnimatorOfFloat.setDuration(650L);
            c0087.f11874a.setInterpolator(null);
            c0087.f11874a.setRepeatCount(-1);
            c0087.f11874a.addListener(new C4780e(2, c0087));
        }
        c0087.f11871a = 1;
        c0087.m5856a(0.0f);
        c0087.f11878a.f11887a = ((int[]) c0087.f11876a.f11899a)[0];
        c0087.f11875a.m10895a(c0087.f11871a);
        c0087.f11874a.start();
        return visible;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) {
        int i;
        C6224p c6224p;
        Rect rect = new Rect();
        Rect bounds = getBounds();
        if (!bounds.isEmpty() && isVisible() && canvas.getClipBounds(rect)) {
            C4339a c4339a = this.f11879a;
            int i2 = 0;
            C0091 c0091 = this.f11881a;
            if (c4339a != null && C4339a.m1225a(this.f11880a.getContentResolver()) == 0.0f && (c6224p = this.f11886a) != null) {
                c6224p.setBounds(bounds);
                this.f11886a.setTint(((int[]) c0091.f11899a)[0]);
                this.f11886a.draw(canvas);
                return;
            }
            canvas.save();
            C0090 c0090 = this.f11882a;
            c0090.getClass();
            C0091 c00912 = c0090.f11892a;
            canvas.translate(bounds.centerX(), bounds.centerY());
            c00912.getClass();
            float f = 2.0f;
            canvas.clipRect((-Math.max(c00912.f11897a, c00912.f11895a)) / 2.0f, (-Math.max(c00912.f11896a, c00912.f11895a)) / 2.0f, Math.max(c00912.f11897a, c00912.f11895a) / 2.0f, Math.max(c00912.f11896a, c00912.f11895a) / 2.0f);
            canvas.rotate(-90.0f);
            float fMin = Math.min(c00912.f11896a, c00912.f11897a) / 2.0f;
            int iM10113a = AbstractC3098.m10113a(c0091.f11898a, this.f11885a);
            Paint paint = this.f11884a;
            paint.setColor(iM10113a);
            Paint.Style style = Paint.Style.FILL;
            paint.setStyle(style);
            canvas.drawRoundRect(new RectF((-r10) / 2.0f, (-r12) / 2.0f, c00912.f11896a / 2.0f, c00912.f11897a / 2.0f), fMin, fMin, paint);
            C0089 c0089 = this.f11883a.f11878a;
            int i3 = this.f11885a;
            Matrix matrix = c0090.f11894a;
            paint.setColor(AbstractC3098.m10113a(c0089.f11887a, i3));
            paint.setStyle(style);
            canvas.save();
            canvas.rotate(c0089.f11889a);
            Path path = c0090.f11893a;
            path.rewind();
            int iFloor = (int) Math.floor(c0089.f11888a);
            C4906e[] c4906eArr = C0090.f11891a;
            int length = c4906eArr.length;
            int i4 = iFloor / length;
            if ((iFloor ^ length) < 0 && i4 * length != iFloor) {
                i4--;
            }
            float f2 = c0089.f11888a - iFloor;
            C4906e c4906e = c4906eArr[iFloor - (i4 * length)];
            AbstractC3098.m10103a(c4906e, "<this>");
            C0029 c0029M3430a = AbstractC5120i.m3430a();
            ArrayList arrayList = c4906e.f6340a;
            int size = arrayList.size();
            C1080 c1080 = null;
            int i5 = 0;
            C1080 c10802 = null;
            while (i5 < size) {
                int i6 = i2;
                float[] fArr = new float[8];
                float f3 = f;
                int i7 = i6;
                for (int i8 = 8; i7 < i8; i8 = 8) {
                    fArr[i7] = AbstractC6209p.m5364a(((C1080) ((C3549) arrayList.get(i5)).f22954a).f14565a[i7], ((C1080) ((C3549) arrayList.get(i5)).f22955a).f14565a[i7], f2);
                    i7++;
                }
                C1080 c10803 = new C1080(fArr);
                if (c10802 == null) {
                    c10802 = c10803;
                }
                if (c1080 != null) {
                    c0029M3430a.add(c1080);
                }
                i5++;
                c1080 = c10803;
                i2 = i6;
                f = f3;
            }
            int i9 = i2;
            float f4 = f;
            if (c1080 != null && c10802 != null) {
                float[] fArr2 = c1080.f14565a;
                float f5 = fArr2[i9];
                float f6 = fArr2[1];
                float f7 = fArr2[2];
                float f8 = fArr2[3];
                float f9 = fArr2[4];
                float f10 = fArr2[5];
                float[] fArr3 = c10802.f14565a;
                c0029M3430a.add(AbstractC3098.m10091a(f5, f6, f7, f8, f9, f10, fArr3[i9], fArr3[1]));
            }
            C0029 c0029M3423a = AbstractC5120i.m3423a(c0029M3430a);
            path.rewind();
            int iMo720a = c0029M3423a.mo720a();
            int i10 = 1;
            int i11 = i9;
            while (i11 < iMo720a) {
                C1080 c10804 = (C1080) c0029M3423a.get(i11);
                if (i10 != 0) {
                    float[] fArr4 = c10804.f14565a;
                    path.moveTo(fArr4[i9], fArr4[1]);
                    i = i9;
                } else {
                    i = i10;
                }
                float[] fArr5 = c10804.f14565a;
                path.cubicTo(fArr5[2], fArr5[3], fArr5[4], fArr5[5], c10804.m7104a(), c10804.m7105a());
                i11++;
                i10 = i;
            }
            path.close();
            float f11 = c00912.f11895a / f4;
            matrix.setScale(f11, f11);
            path.transform(matrix);
            canvas.drawPath(path, paint);
            canvas.restore();
            canvas.restore();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final int getAlpha() {
        return this.f11885a;
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicHeight() {
        C0091 c0091 = this.f11882a.f11892a;
        return Math.max(c0091.f11896a, c0091.f11895a);
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicWidth() {
        C0091 c0091 = this.f11882a.f11892a;
        return Math.max(c0091.f11897a, c0091.f11895a);
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public final void invalidateDrawable(Drawable drawable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, runnable, j);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        if (this.f11885a != i) {
            this.f11885a = i;
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.f11884a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final boolean setVisible(boolean z, boolean z2) {
        return m5857a(z, z2, z);
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, runnable);
        }
    }
}
