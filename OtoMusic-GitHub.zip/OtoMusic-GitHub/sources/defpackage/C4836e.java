package defpackage;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.ProviderInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.IInterface;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: renamed from: e֭, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4836e {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static Boolean f6164a = null;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static String f6165a = null;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static boolean f6166a = false;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static int f6167a = -1;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static Boolean f6168a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static C0877 f6172a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static C0890 f6173a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f6174a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final ThreadLocal f6169a = new ThreadLocal();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final C0708 f6170a = new C0708();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final C5220i f6171a = new C5220i(25);

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C5220i f6163a = new C5220i(26);

    public C4836e(Context context) {
        this.f6174a = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0092 A[Catch: all -> 0x0087, TRY_LEAVE, TryCatch #2 {all -> 0x0087, blocks: (B:9:0x0074, B:13:0x0080, B:20:0x008c, B:23:0x0092, B:35:0x00b7, B:112:0x01eb, B:113:0x01f5, B:116:0x01f8, B:117:0x01f9, B:118:0x0200, B:135:0x0255, B:136:0x0273, B:119:0x0201, B:121:0x0218, B:123:0x0225, B:133:0x024d, B:134:0x0254, B:137:0x0274, B:138:0x02b3), top: B:157:0x0074, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00b4  */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static defpackage.C4836e m2998a(android.content.Context r22, defpackage.C5220i r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 737
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C4836e.m2998a(android.content.Context, iٟ):e֭");
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static boolean m2999a(Context context) {
        ApplicationInfo applicationInfo;
        Boolean bool = Boolean.TRUE;
        if (bool.equals(null) || bool.equals(f6168a)) {
            return true;
        }
        boolean z = false;
        if (f6168a == null) {
            ProviderInfo providerInfoResolveContentProvider = context.getPackageManager().resolveContentProvider("com.google.android.gms.chimera", Build.VERSION.SDK_INT >= 29 ? 268435456 : 0);
            if (C5159i.f7278a.m3730a(context, 10000000) == 0 && providerInfoResolveContentProvider != null && "com.google.android.gms".equals(providerInfoResolveContentProvider.packageName)) {
                z = true;
            }
            f6168a = Boolean.valueOf(z);
            if (z && (applicationInfo = providerInfoResolveContentProvider.applicationInfo) != null && (applicationInfo.flags & 129) == 0) {
                f6166a = true;
            }
        }
        if (!z) {
            Log.e("DynamiteModule", "Invalid GmsCore APK, remote loading disabled.");
        }
        return z;
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Removed duplicated region for block: B:124:0x00e7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x013a A[PHI: r3
      0x013a: PHI (r3v7 boolean) = (r3v6 boolean), (r3v9 boolean) binds: [B:58:0x00f1, B:83:0x0137] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int m3000a(android.content.Context r14, boolean r15, boolean r16) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 406
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C4836e.m3000a(android.content.Context, boolean, boolean):int");
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static void m3001a(ClassLoader classLoader) throws C4833e {
        try {
            C0890 c0890 = null;
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(null).newInstance(null);
            if (iBinder != null) {
                IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                c0890 = iInterfaceQueryLocalInterface instanceof C0890 ? (C0890) iInterfaceQueryLocalInterface : new C0890(iBinder, "com.google.android.gms.dynamite.IDynamiteLoaderV2", 1);
            }
            f6173a = c0890;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
            throw new C4833e("Failed to instantiate dynamite loader", e);
        }
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static C0877 m3002a(Context context) {
        C0877 c0877;
        synchronized (C4836e.class) {
            C0877 c08772 = f6172a;
            if (c08772 != null) {
                return c08772;
            }
            try {
                IBinder iBinder = (IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance();
                if (iBinder == null) {
                    c0877 = null;
                } else {
                    IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
                    c0877 = iInterfaceQueryLocalInterface instanceof C0877 ? (C0877) iInterfaceQueryLocalInterface : new C0877(iBinder);
                }
                if (c0877 != null) {
                    f6172a = c0877;
                    return c0877;
                }
            } catch (Exception e) {
                String message = e.getMessage();
                StringBuilder sb = new StringBuilder(String.valueOf(message).length() + 45);
                sb.append("Failed to load IDynamiteLoader from GmsCore: ");
                sb.append(message);
                Log.e("DynamiteModule", sb.toString());
            }
            return null;
        }
    }
}
