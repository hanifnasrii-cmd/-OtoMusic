package defpackage;

import com.google.android.datatransport.runtime.TransportContext;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.Uploader;
import com.google.android.datatransport.runtime.synchronization.SynchronizationGuard;

/* JADX INFO: renamed from: eⷥ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C4995e implements InterfaceC0053, SynchronizationGuard.CriticalSection {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f6692a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f6693a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ Object f6694a;

    public /* synthetic */ C4995e(int i, C5729o c5729o, C5729o c5729o2) {
        this.f6692a = i;
        this.f6693a = c5729o;
        this.f6694a = c5729o2;
    }

    @Override // com.google.android.datatransport.runtime.synchronization.SynchronizationGuard.CriticalSection
    public Object execute() {
        return ((Uploader) this.f6693a).lambda$upload$0((TransportContext) this.f6694a, this.f6692a);
    }

    @Override // defpackage.InterfaceC0053
    public void invoke(Object obj) {
        C5729o c5729o = (C5729o) this.f6693a;
        C5729o c5729o2 = (C5729o) this.f6694a;
        InterfaceC5728o interfaceC5728o = (InterfaceC5728o) obj;
        interfaceC5728o.getClass();
        interfaceC5728o.mo4683a(this.f6692a, c5729o, c5729o2);
    }

    public /* synthetic */ C4995e(Uploader uploader, TransportContext transportContext, int i) {
        this.f6693a = uploader;
        this.f6694a = transportContext;
        this.f6692a = i;
    }
}
