package defpackage;

import android.view.View;
import com.piyush.taglib.AudioProperties;
import java.util.List;

/* JADX INFO: renamed from: οؕ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0504 extends AbstractC2042 {
    public C0504(AbstractC0501 abstractC0501, final C5281i c5281i) {
        super(abstractC0501.f11082a);
        final int i = 0;
        abstractC0501.f13314a.setOnClickListener(new View.OnClickListener() { // from class: οؔ
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                InterfaceC5272i interfaceC5272i = c5281i;
                switch (i2) {
                    case 0:
                        C5281i c5281i2 = (C5281i) interfaceC5272i;
                        c5281i2.getClass();
                        C5763o c5763o = C5601j.f8884a;
                        C5611j c5611j = c5281i2.f7754a;
                        if (c5611j != null) {
                            C5601j.m4443a(-1, null, (List) c5611j.f8935a.m5849a());
                            return;
                        } else {
                            AbstractC3098.m10141a("musicRepository");
                            throw null;
                        }
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        C5281i c5281i3 = (C5281i) interfaceC5272i;
                        c5281i3.getClass();
                        AbstractC6161p.m5213a(c5281i3).m10430a(C3488.f22803a, AbstractC5120i.m3444a());
                        return;
                    case 2:
                        C5281i c5281i4 = (C5281i) interfaceC5272i;
                        c5281i4.getClass();
                        AbstractC6161p.m5213a(c5281i4).m10427a(-1, true);
                        return;
                    default:
                        C5281i c5281i5 = (C5281i) interfaceC5272i;
                        c5281i5.getClass();
                        AbstractC6161p.m5213a(c5281i5).m10430a(C3490.f22805a, AbstractC5120i.m3444a());
                        return;
                }
            }
        });
        final int i2 = 1;
        abstractC0501.f13312a.setOnClickListener(new View.OnClickListener() { // from class: οؔ
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i22 = i2;
                InterfaceC5272i interfaceC5272i = c5281i;
                switch (i22) {
                    case 0:
                        C5281i c5281i2 = (C5281i) interfaceC5272i;
                        c5281i2.getClass();
                        C5763o c5763o = C5601j.f8884a;
                        C5611j c5611j = c5281i2.f7754a;
                        if (c5611j != null) {
                            C5601j.m4443a(-1, null, (List) c5611j.f8935a.m5849a());
                            return;
                        } else {
                            AbstractC3098.m10141a("musicRepository");
                            throw null;
                        }
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        C5281i c5281i3 = (C5281i) interfaceC5272i;
                        c5281i3.getClass();
                        AbstractC6161p.m5213a(c5281i3).m10430a(C3488.f22803a, AbstractC5120i.m3444a());
                        return;
                    case 2:
                        C5281i c5281i4 = (C5281i) interfaceC5272i;
                        c5281i4.getClass();
                        AbstractC6161p.m5213a(c5281i4).m10427a(-1, true);
                        return;
                    default:
                        C5281i c5281i5 = (C5281i) interfaceC5272i;
                        c5281i5.getClass();
                        AbstractC6161p.m5213a(c5281i5).m10430a(C3490.f22805a, AbstractC5120i.m3444a());
                        return;
                }
            }
        });
        final int i3 = 2;
        abstractC0501.f13311a.setOnClickListener(new View.OnClickListener() { // from class: οؔ
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i22 = i3;
                InterfaceC5272i interfaceC5272i = c5281i;
                switch (i22) {
                    case 0:
                        C5281i c5281i2 = (C5281i) interfaceC5272i;
                        c5281i2.getClass();
                        C5763o c5763o = C5601j.f8884a;
                        C5611j c5611j = c5281i2.f7754a;
                        if (c5611j != null) {
                            C5601j.m4443a(-1, null, (List) c5611j.f8935a.m5849a());
                            return;
                        } else {
                            AbstractC3098.m10141a("musicRepository");
                            throw null;
                        }
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        C5281i c5281i3 = (C5281i) interfaceC5272i;
                        c5281i3.getClass();
                        AbstractC6161p.m5213a(c5281i3).m10430a(C3488.f22803a, AbstractC5120i.m3444a());
                        return;
                    case 2:
                        C5281i c5281i4 = (C5281i) interfaceC5272i;
                        c5281i4.getClass();
                        AbstractC6161p.m5213a(c5281i4).m10427a(-1, true);
                        return;
                    default:
                        C5281i c5281i5 = (C5281i) interfaceC5272i;
                        c5281i5.getClass();
                        AbstractC6161p.m5213a(c5281i5).m10430a(C3490.f22805a, AbstractC5120i.m3444a());
                        return;
                }
            }
        });
        final int i4 = 3;
        abstractC0501.f13313a.setOnClickListener(new View.OnClickListener() { // from class: οؔ
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i22 = i4;
                InterfaceC5272i interfaceC5272i = c5281i;
                switch (i22) {
                    case 0:
                        C5281i c5281i2 = (C5281i) interfaceC5272i;
                        c5281i2.getClass();
                        C5763o c5763o = C5601j.f8884a;
                        C5611j c5611j = c5281i2.f7754a;
                        if (c5611j != null) {
                            C5601j.m4443a(-1, null, (List) c5611j.f8935a.m5849a());
                            return;
                        } else {
                            AbstractC3098.m10141a("musicRepository");
                            throw null;
                        }
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        C5281i c5281i3 = (C5281i) interfaceC5272i;
                        c5281i3.getClass();
                        AbstractC6161p.m5213a(c5281i3).m10430a(C3488.f22803a, AbstractC5120i.m3444a());
                        return;
                    case 2:
                        C5281i c5281i4 = (C5281i) interfaceC5272i;
                        c5281i4.getClass();
                        AbstractC6161p.m5213a(c5281i4).m10427a(-1, true);
                        return;
                    default:
                        C5281i c5281i5 = (C5281i) interfaceC5272i;
                        c5281i5.getClass();
                        AbstractC6161p.m5213a(c5281i5).m10430a(C3490.f22805a, AbstractC5120i.m3444a());
                        return;
                }
            }
        });
    }
}
