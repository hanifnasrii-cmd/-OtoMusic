package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: օܾ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3876 extends AbstractC0493 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f23920a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C3876(AbstractC2178 abstractC2178, int i) {
        super(abstractC2178);
        this.f23920a = i;
    }

    @Override // defpackage.AbstractC0493
    /* JADX INFO: renamed from: ā */
    public final String mo4784a() {
        switch (this.f23920a) {
            case 0:
                return "DELETE FROM SystemIdInfo where work_spec_id=? AND generation=?";
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return "DELETE FROM SystemIdInfo where work_spec_id=?";
            case 2:
                return "DELETE from WorkProgress where work_spec_id=?";
            case 3:
                return "DELETE FROM WorkProgress";
            case 4:
                return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
            case 5:
                return "UPDATE workspec SET next_schedule_time_override=? WHERE id=?";
            case 6:
                return "UPDATE workspec SET next_schedule_time_override=9223372036854775807 WHERE (id=? AND next_schedule_time_override_generation=?)";
            case 7:
                return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
            case 8:
                return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
            case 9:
                return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
            case 10:
                return "UPDATE workspec SET generation=generation+1 WHERE id=?";
            case 11:
                return "UPDATE workspec SET stop_reason=? WHERE id=?";
            case 12:
                return "UPDATE OR ABORT `WorkSpec` SET `id` = ?,`state` = ?,`worker_class_name` = ?,`input_merger_class_name` = ?,`input` = ?,`output` = ?,`initial_delay` = ?,`interval_duration` = ?,`flex_duration` = ?,`run_attempt_count` = ?,`backoff_policy` = ?,`backoff_delay_duration` = ?,`last_enqueue_time` = ?,`minimum_retention_duration` = ?,`schedule_requested_at` = ?,`run_in_foreground` = ?,`out_of_quota_policy` = ?,`period_count` = ?,`generation` = ?,`next_schedule_time_override` = ?,`next_schedule_time_override_generation` = ?,`stop_reason` = ?,`required_network_type` = ?,`requires_charging` = ?,`requires_device_idle` = ?,`requires_battery_not_low` = ?,`requires_storage_not_low` = ?,`trigger_content_update_delay` = ?,`trigger_max_content_delay` = ?,`content_uri_triggers` = ? WHERE `id` = ?";
            case 13:
                return "DELETE FROM workspec WHERE id=?";
            case 14:
                return "UPDATE workspec SET state=? WHERE id=?";
            case 15:
                return "UPDATE workspec SET stop_reason = CASE WHEN state=1 THEN 1 ELSE -256 END, state=5 WHERE id=?";
            case 16:
                return "UPDATE workspec SET period_count=period_count+1 WHERE id=?";
            case 17:
                return "UPDATE workspec SET output=? WHERE id=?";
            case 18:
                return "UPDATE workspec SET last_enqueue_time=? WHERE id=?";
            default:
                return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public void m11059a(C5032i c5032i, Object obj) throws Throwable {
        int i;
        C2422 c2422 = (C2422) obj;
        String str = c2422.f19347a;
        int i2 = 1;
        if (str == null) {
            c5032i.mo3368a(1);
        } else {
            c5032i.mo3371a(1, str);
        }
        c5032i.mo3369a(2, AbstractC1149.m7199a(c2422.f19348a));
        String str2 = c2422.f19349a;
        if (str2 == null) {
            c5032i.mo3368a(3);
        } else {
            c5032i.mo3371a(3, str2);
        }
        String str3 = c2422.f19350a;
        if (str3 == null) {
            c5032i.mo3368a(4);
        } else {
            c5032i.mo3371a(4, str3);
        }
        byte[] bArrM7135a = C1124.m7135a(c2422.f19351a);
        if (bArrM7135a == null) {
            c5032i.mo3368a(5);
        } else {
            c5032i.mo3372a(bArrM7135a, 5);
        }
        byte[] bArrM7135a2 = C1124.m7135a(c2422.f19352a);
        if (bArrM7135a2 == null) {
            c5032i.mo3368a(6);
        } else {
            c5032i.mo3372a(bArrM7135a2, 6);
        }
        c5032i.mo3369a(7, c2422.f19353a);
        c5032i.mo3369a(8, c2422.f19354a);
        c5032i.mo3369a(9, c2422.f19355a);
        c5032i.mo3369a(10, c2422.f19357a);
        EnumC4381c enumC4381c = c2422.f19358a;
        AbstractC3098.m10103a(enumC4381c, "backoffPolicy");
        int i3 = AbstractC2430.f19397a[enumC4381c.ordinal()];
        if (i3 == 1) {
            i = 0;
        } else {
            if (i3 != 2) {
                throw new C2895((char) 0);
            }
            i = 1;
        }
        c5032i.mo3369a(11, i);
        c5032i.mo3369a(12, c2422.f19359a);
        c5032i.mo3369a(13, c2422.f19360a);
        c5032i.mo3369a(14, c2422.f19361a);
        c5032i.mo3369a(15, c2422.f19362a);
        c5032i.mo3369a(16, c2422.f19363a ? 1L : 0L);
        EnumC3529 enumC3529 = c2422.f19364a;
        AbstractC3098.m10103a(enumC3529, "policy");
        int i4 = AbstractC2430.f19399a[enumC3529.ordinal()];
        if (i4 == 1) {
            i2 = 0;
        } else if (i4 != 2) {
            throw new C2895((char) 0);
        }
        c5032i.mo3369a(17, i2);
        c5032i.mo3369a(18, c2422.f19365a);
        c5032i.mo3369a(19, c2422.f19366a);
        c5032i.mo3369a(20, c2422.f19367a);
        c5032i.mo3369a(21, c2422.f19368a);
        c5032i.mo3369a(22, c2422.f19369a);
        C2973 c2973 = c2422.f19356a;
        if (c2973 != null) {
            c5032i.mo3369a(23, AbstractC1149.m7191a(c2973.f21362a));
            c5032i.mo3369a(24, c2973.f21363a ? 1L : 0L);
            c5032i.mo3369a(25, c2973.f21364a ? 1L : 0L);
            c5032i.mo3369a(26, c2973.f21365a ? 1L : 0L);
            c5032i.mo3369a(27, c2973.f21366a ? 1L : 0L);
            c5032i.mo3369a(28, c2973.f21367a);
            c5032i.mo3369a(29, c2973.f21368a);
            c5032i.mo3372a(AbstractC1149.m7197a(c2973.f21369a), 30);
        } else {
            c5032i.mo3368a(23);
            c5032i.mo3368a(24);
            c5032i.mo3368a(25);
            c5032i.mo3368a(26);
            c5032i.mo3368a(27);
            c5032i.mo3368a(28);
            c5032i.mo3368a(29);
            c5032i.mo3368a(30);
        }
        if (str == null) {
            c5032i.mo3368a(31);
        } else {
            c5032i.mo3371a(31, str);
        }
    }
}
