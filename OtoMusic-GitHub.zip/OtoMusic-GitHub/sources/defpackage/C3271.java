package defpackage;

/* JADX INFO: renamed from: і⃮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3271 {
    public final InterfaceC3193 serializer() {
        return C3270.f22174a;
    }
}
