package defpackage;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import defpackage.InterfaceC6244p;

/* JADX INFO: renamed from: i݀, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC5258i<VB extends InterfaceC6244p, AB extends InterfaceC6244p> extends AbstractC3762<VB, AB> implements InterfaceC5080i {

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public C6261p f7670a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public volatile C1918 f7672a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public boolean f7671a = false;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final Object f7673a = new Object();

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public boolean f7674a = false;

    /* JADX INFO: renamed from: a̵, reason: contains not printable characters */
    public final void m3931a() {
        if (this.f7670a == null) {
            this.f7670a = new C6261p(super.getContext(), this);
            this.f7671a = AbstractC2411.m8922a(super.getContext());
        }
    }

    @Override // defpackage.InterfaceC5080i
    public final Object generatedComponent() {
        if (this.f7672a == null) {
            synchronized (this.f7673a) {
                try {
                    if (this.f7672a == null) {
                        this.f7672a = new C1918(this);
                    }
                } finally {
                }
            }
        }
        return this.f7672a.generatedComponent();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final Context getContext() {
        if (super.getContext() == null && !this.f7671a) {
            return null;
        }
        m3931a();
        return this.f7670a;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a, defpackage.InterfaceC5200i
    public final InterfaceC6282p getDefaultViewModelProviderFactory() {
        return AbstractC2411.m8914a(this, super.getDefaultViewModelProviderFactory());
    }

    public final void inject() {
        if (this.f7674a) {
            return;
        }
        this.f7674a = true;
        ((C3683) this).f23323a = (InterfaceC5880o) ((C1114) ((InterfaceC3684) generatedComponent())).f14668a.f14684a.get();
    }

    @Override // androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onAttach(Context context) {
        super.onAttach(context);
        m3931a();
        inject();
    }

    @Override // androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final LayoutInflater onGetLayoutInflater(Bundle bundle) {
        LayoutInflater layoutInflaterOnGetLayoutInflater = super.onGetLayoutInflater(bundle);
        return layoutInflaterOnGetLayoutInflater.cloneInContext(new C6261p(layoutInflaterOnGetLayoutInflater, this));
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onAttach(Activity activity) {
        super.onAttach(activity);
        C6261p c6261p = this.f7670a;
        AbstractC4647c.m2662a(c6261p == null || C1918.m8300a(c6261p) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        m3931a();
        inject();
    }
}
