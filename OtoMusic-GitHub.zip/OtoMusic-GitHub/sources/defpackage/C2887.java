package defpackage;

/* JADX INFO: renamed from: с݂, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2887 extends C3156 implements InterfaceC2886 {
    @Override // defpackage.InterfaceC1245
    /* JADX INFO: renamed from: a̗ */
    public final Object mo7399a(AbstractC3855 abstractC3855) {
        Object objM10207a = m10207a(abstractC3855);
        EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
        return objM10207a;
    }
}
