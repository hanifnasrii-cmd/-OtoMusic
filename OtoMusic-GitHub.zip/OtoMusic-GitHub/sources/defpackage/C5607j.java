package defpackage;

import android.content.Context;
import android.content.pm.Signature;
import android.os.Process;
import android.util.Base64;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Locale;

/* JADX INFO: renamed from: jޮ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5607j extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f8908a = 1;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public /* synthetic */ Object f8909a;

    public /* synthetic */ C5607j(int i, InterfaceC1005 interfaceC1005) {
        super(i, interfaceC1005);
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        switch (this.f8908a) {
            case 0:
                return new C5607j((C5611j) this.f8909a, interfaceC1005);
            default:
                C5607j c5607j = new C5607j(2, interfaceC1005);
                c5607j.f8909a = obj;
                return c5607j;
        }
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f8908a) {
            case 0:
                C5607j c5607j = (C5607j) create((InterfaceC1044) obj, (InterfaceC1005) obj2);
                C6174p c6174p = C6174p.f10843a;
                c5607j.invokeSuspend(c6174p);
                return c6174p;
            default:
                return ((C5607j) create((EnumC0495) obj, (InterfaceC1005) obj2)).invokeSuspend(C6174p.f10843a);
        }
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        Boolean boolValueOf;
        switch (this.f8908a) {
            case 0:
                EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                AbstractC1149.m7200a(obj);
                C1436 c1436 = ((C5611j) this.f8909a).f8929a;
                int i = C1436.f15955a;
                Context context = c1436.f15956a;
                if (c1436.f15957a == null) {
                    try {
                        Signature[] signatureArr = context.getPackageManager().getPackageInfo(context.getPackageName(), 64).signatures;
                        AbstractC3098.m10100a(signatureArr);
                        byte[] byteArray = signatureArr[0].toByteArray();
                        byte[] bArrDecode = Base64.decode("U0hBMQ==", 0);
                        Charset charsetForName = Charset.forName("UTF-8");
                        AbstractC3098.m10102a(charsetForName, "forName(...)");
                        MessageDigest messageDigest = MessageDigest.getInstance(new String(bArrDecode, charsetForName));
                        messageDigest.update(byteArray);
                        byte[] bArrDigest = messageDigest.digest();
                        char[] cArr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
                        char[] cArr2 = new char[bArrDigest.length * 2];
                        for (int i2 = 0; i2 < bArrDigest.length; i2++) {
                            byte b = bArrDigest[i2];
                            int i3 = i2 * 2;
                            cArr2[i3] = cArr[(b & 255) >>> 4];
                            cArr2[i3 + 1] = cArr[b & 15];
                        }
                        String str = new String(cArr2);
                        ArrayList arrayList = c1436.f15958a;
                        ArrayList arrayList2 = new ArrayList(AbstractC2853.m9682a(arrayList, 10));
                        int size = arrayList.size();
                        int i4 = 0;
                        while (i4 < size) {
                            Object obj2 = arrayList.get(i4);
                            i4++;
                            byte[] bArrDecode2 = Base64.decode((String) obj2, 0);
                            Charset charsetForName2 = Charset.forName("UTF-8");
                            AbstractC3098.m10102a(charsetForName2, "forName(...)");
                            String lowerCase = new String(bArrDecode2, charsetForName2).toLowerCase(Locale.ROOT);
                            AbstractC3098.m10102a(lowerCase, "toLowerCase(...)");
                            arrayList2.add(lowerCase);
                        }
                        String lowerCase2 = str.toLowerCase(Locale.ROOT);
                        AbstractC3098.m10102a(lowerCase2, "toLowerCase(...)");
                        boolValueOf = Boolean.valueOf(arrayList2.contains(lowerCase2));
                    } catch (Exception e) {
                        e.printStackTrace();
                        boolValueOf = Boolean.FALSE;
                    }
                    c1436.f15957a = boolValueOf;
                    if (boolValueOf.equals(Boolean.FALSE)) {
                        Process.killProcess(Process.myPid());
                        System.exit(1);
                        throw new RuntimeException("System.exit returned normally, while it was supposed to halt JVM.");
                    }
                    break;
                }
                return C6174p.f10843a;
            default:
                EnumC1045 enumC10452 = EnumC1045.COROUTINE_SUSPENDED;
                AbstractC1149.m7200a(obj);
                return Boolean.valueOf(((EnumC0495) this.f8909a) != EnumC0495.START);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5607j(C5611j c5611j, InterfaceC1005 interfaceC1005) {
        super(2, interfaceC1005);
        this.f8909a = c5611j;
    }
}
