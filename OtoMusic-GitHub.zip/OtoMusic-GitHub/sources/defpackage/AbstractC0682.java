package defpackage;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/* JADX INFO: renamed from: ῥ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0682 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C0111 f13830a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f13831a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C5924o f13832a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final List f13833a;

    public AbstractC0682(String str) {
        AbstractC2711.m9451a(str);
        this.f13831a = str;
        this.f13830a = new C0111("MediaControlChannel", null);
        this.f13833a = Collections.synchronizedList(new ArrayList());
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m6588a(C2564 c2564) {
        this.f13833a.add(c2564);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m6589a(String str, long j) {
        Object[] objArr = {str, null};
        C0111 c0111 = this.f13830a;
        c0111.getClass();
        String str2 = c0111.f11965a;
        if (!Build.TYPE.equals("user") && c0111.f11966a && Log.isLoggable(str2, 2)) {
            c0111.m5889a("Sending text message: %s to: %s", objArr);
        }
        C5924o c5924o = this.f13832a;
        if (c5924o == null) {
            Log.e(str2, c0111.m5889a("Attempt to send text message without a sink", new Object[0]));
            return;
        }
        InterfaceC0892 interfaceC0892 = (InterfaceC0892) c5924o.f9989a;
        if (interfaceC0892 == null) {
            throw new IllegalStateException("Device is not connected");
        }
        C2601 c2601 = (C2601) interfaceC0892;
        String str3 = this.f13831a;
        AbstractC2711.m9451a(str3);
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        }
        if (str.length() > 524288) {
            C2601.f19797a.m5889a("Message send failed. Message exceeds maximum size", new Object[0]);
            throw new IllegalArgumentException("Message exceeds maximum size524288");
        }
        C4592c c4592cM2483a = C4592c.m2483a();
        c4592cM2483a.f5344a = new C2568(c2601, str3, str, 0);
        c4592cM2483a.f5343a = 8405;
        c2601.m3726a(1, c4592cM2483a.m2484a()).m5546a(new C5211i(c5924o, j));
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final long m6590a() {
        C5924o c5924o = this.f13832a;
        if (c5924o != null) {
            return ((AtomicLong) c5924o.f9990a).getAndIncrement();
        }
        C0111 c0111 = this.f13830a;
        Log.e(c0111.f11965a, c0111.m5889a("Attempt to generate requestId without a sink", new Object[0]));
        return 0L;
    }
}
