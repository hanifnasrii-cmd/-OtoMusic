package defpackage;

import java.text.Collator;
import java.util.Locale;

/* JADX INFO: renamed from: с݀, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2885 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final Collator f20871a = Collator.getInstance(Locale.getDefault());

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static int m9770a(String str, String str2) {
        if (str == null) {
            return -1;
        }
        if (str2 == null) {
            return 1;
        }
        if (str.equals(str2)) {
            return 0;
        }
        return f20871a.compare(str, str2);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static int m9771a(int i, int i2) {
        if (i < i2) {
            return -1;
        }
        return i == i2 ? 0 : 1;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static int m9772a(long j, long j2) {
        if (j < j2) {
            return -1;
        }
        return j == j2 ? 0 : 1;
    }
}
