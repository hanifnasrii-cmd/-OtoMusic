package defpackage;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: renamed from: oⷾ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class RunnableC6010o implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final InterfaceC4688c f10313a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public volatile AtomicInteger f10314a = new AtomicInteger(0);

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C1987 f10315a;

    public RunnableC6010o(C1987 c1987, InterfaceC4688c interfaceC4688c) {
        this.f10315a = c1987;
        this.f10313a = interfaceC4688c;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m5005a(ThreadPoolExecutor threadPoolExecutor) {
        AbstractC3098.m10103a(threadPoolExecutor, "executorService");
        C1987 c1987 = this.f10315a;
        C3438 c3438 = c1987.f17986a;
        byte[] bArr = AbstractC6204p.f10905a;
        try {
            try {
                threadPoolExecutor.execute(this);
            } catch (RejectedExecutionException e) {
                InterruptedIOException interruptedIOException = new InterruptedIOException("executor rejected");
                interruptedIOException.initCause(e);
                c1987.m8358a(interruptedIOException);
                this.f10313a.mo2806a(interruptedIOException);
                c3438.f22708a.m11064a(this);
            }
        } catch (Throwable th) {
            c3438.f22708a.m11064a(this);
            throw th;
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final AtomicInteger m5006a() {
        return this.f10314a;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String m5007a() {
        return ((C3005) this.f10315a.f17987a.f14958a).f21504a;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C3438 c3438;
        String strConcat = "OkHttp ".concat(((C3005) this.f10315a.f17987a.f14958a).m9999a());
        C1987 c1987 = this.f10315a;
        Thread threadCurrentThread = Thread.currentThread();
        String name = threadCurrentThread.getName();
        threadCurrentThread.setName(strConcat);
        try {
            c1987.f17989a.m7777a();
            boolean z = false;
            try {
                try {
                } catch (Throwable th) {
                    c1987.f17986a.f22708a.m11064a(this);
                    throw th;
                }
            } catch (IOException e) {
                e = e;
            } catch (Throwable th2) {
                th = th2;
            }
            try {
                this.f10313a.mo2807a(c1987.m8356a());
                c3438 = c1987.f17986a;
            } catch (IOException e2) {
                e = e2;
                z = true;
                if (z) {
                    C5693o c5693o = C5693o.f9228a;
                    C5693o c5693o2 = C5693o.f9228a;
                    String str = "Callback failure for " + C1987.m8351a(c1987);
                    c5693o2.getClass();
                    C5693o.m4573a(str, 4, e);
                } else {
                    this.f10313a.mo2806a(e);
                }
                c3438 = c1987.f17986a;
            } catch (Throwable th3) {
                th = th3;
                z = true;
                c1987.cancel();
                if (!z) {
                    IOException iOException = new IOException("canceled due to " + th);
                    AbstractC4611c.m2514a(iOException, th);
                    this.f10313a.mo2806a(iOException);
                }
                throw th;
            }
            c3438.f22708a.m11064a(this);
        } finally {
            threadCurrentThread.setName(name);
        }
    }
}
