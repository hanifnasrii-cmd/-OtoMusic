package defpackage;

import java.io.IOException;
import java.util.Objects;

/* JADX INFO: renamed from: cͬ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4469c implements InterfaceC2088, InterfaceC5755o {
    private InterfaceC2821 clock;
    private C2089 configuration;
    private int index;
    private long lastResetPositionUs;
    private C5466j mediaPeriodId;
    private C5753o playerId;
    private InterfaceC2087 rendererCapabilitiesListener;
    private int state;
    private InterfaceC2220 stream;
    private C1898[] streamFormats;
    private boolean streamIsFinal;
    private long streamOffsetUs;
    private boolean throwRendererExceptionIsExecuting;
    private final Object lock = new Object();
    private final int trackType = 1;
    private final C1899 formatHolder = new C1899();
    private long readingPositionUs = Long.MIN_VALUE;
    private AbstractC6037p timeline = AbstractC6037p.f10405a;

    @Override // defpackage.InterfaceC2088
    public final void clearListener() {
        synchronized (this.lock) {
            this.rendererCapabilitiesListener = null;
        }
    }

    public final C4986e createRendererException(Throwable th, C1898 c1898, int i) {
        return createRendererException(th, c1898, false, i);
    }

    public final void disable() {
        AbstractC1545.m7850a(this.state == 1);
        this.formatHolder.f17638a = null;
        this.state = 0;
        this.stream = null;
        this.streamFormats = null;
        this.streamIsFinal = false;
        onDisabled();
        this.mediaPeriodId = null;
    }

    public final void enable(C2089 c2089, C1898[] c1898Arr, InterfaceC2220 interfaceC2220, long j, boolean z, boolean z2, long j2, long j3, C5466j c5466j) throws C4986e {
        AbstractC1545.m7850a(this.state == 0);
        this.configuration = c2089;
        this.mediaPeriodId = c5466j;
        this.state = 1;
        onEnabled(z, z2);
        replaceStream(c1898Arr, interfaceC2220, j2, j3, c5466j);
        this.streamIsFinal = false;
        this.lastResetPositionUs = j2;
        this.readingPositionUs = j2;
        onPositionReset(j2, z, true);
    }

    public void enableMayRenderStartOfStream() {
    }

    public final InterfaceC2088 getCapabilities() {
        return this;
    }

    public final InterfaceC2821 getClock() {
        InterfaceC2821 interfaceC2821 = this.clock;
        interfaceC2821.getClass();
        return interfaceC2821;
    }

    public final C2089 getConfiguration() {
        C2089 c2089 = this.configuration;
        c2089.getClass();
        return c2089;
    }

    public abstract long getDurationToProgressUs(long j, long j2);

    public final C1899 getFormatHolder() {
        C1899 c1899 = this.formatHolder;
        c1899.f17638a = null;
        return c1899;
    }

    public final int getIndex() {
        return this.index;
    }

    public final long getLastResetPositionUs() {
        return this.lastResetPositionUs;
    }

    public abstract InterfaceC0301 getMediaClock();

    public final C5466j getMediaPeriodId() {
        return this.mediaPeriodId;
    }

    @Override // defpackage.InterfaceC2088
    public abstract String getName();

    public final C5753o getPlayerId() {
        C5753o c5753o = this.playerId;
        c5753o.getClass();
        return c5753o;
    }

    public final long getReadingPositionUs() {
        return this.readingPositionUs;
    }

    public final int getState() {
        return this.state;
    }

    public final InterfaceC2220 getStream() {
        return this.stream;
    }

    public final C1898[] getStreamFormats() {
        C1898[] c1898Arr = this.streamFormats;
        c1898Arr.getClass();
        return c1898Arr;
    }

    public final long getStreamOffsetUs() {
        return this.streamOffsetUs;
    }

    public final AbstractC6037p getTimeline() {
        return this.timeline;
    }

    @Override // defpackage.InterfaceC2088
    public final int getTrackType() {
        return this.trackType;
    }

    public final boolean hasReadStreamToEnd() {
        return this.readingPositionUs == Long.MIN_VALUE;
    }

    public final void init(int i, C5753o c5753o, InterfaceC2821 interfaceC2821) {
        this.index = i;
        this.playerId = c5753o;
        this.clock = interfaceC2821;
        onInit();
    }

    public final boolean isCurrentStreamFinal() {
        return this.streamIsFinal;
    }

    public abstract boolean isEnded();

    public abstract boolean isReady();

    public final boolean isSourceReady() {
        if (hasReadStreamToEnd()) {
            return this.streamIsFinal;
        }
        InterfaceC2220 interfaceC2220 = this.stream;
        interfaceC2220.getClass();
        return interfaceC2220.mo3684a();
    }

    public final void maybeThrowStreamError() throws IOException {
        InterfaceC2220 interfaceC2220 = this.stream;
        interfaceC2220.getClass();
        interfaceC2220.mo3686a();
    }

    public abstract void onDisabled();

    public abstract void onEnabled(boolean z, boolean z2);

    public void onInit() {
    }

    public abstract void onPositionReset(long j, boolean z, boolean z2);

    public void onRelease() {
    }

    public final void onRendererCapabilitiesChanged() {
        InterfaceC2087 interfaceC2087;
        synchronized (this.lock) {
            interfaceC2087 = this.rendererCapabilitiesListener;
        }
        if (interfaceC2087 != null) {
            C1242 c1242 = (C1242) interfaceC2087;
            synchronized (c1242.f15328a) {
                c1242.f15331a.getClass();
            }
        }
    }

    public void onReset() {
    }

    public abstract void onStarted();

    public abstract void onStopped();

    public abstract void onStreamChanged(C1898[] c1898Arr, long j, long j2, C5466j c5466j);

    public void onTimelineChanged(AbstractC6037p abstractC6037p) {
    }

    public final int readSource(C1899 c1899, C1164 c1164, int i) {
        InterfaceC2220 interfaceC2220 = this.stream;
        interfaceC2220.getClass();
        int iMo3678a = interfaceC2220.mo3678a(c1899, c1164, i);
        if (iMo3678a == -4) {
            if (c1164.isEndOfStream()) {
                this.readingPositionUs = Long.MIN_VALUE;
                return this.streamIsFinal ? -4 : -3;
            }
            long j = c1164.f14933a + this.streamOffsetUs;
            c1164.f14933a = j;
            this.readingPositionUs = Math.max(this.readingPositionUs, j);
            return iMo3678a;
        }
        if (iMo3678a == -5) {
            C1898 c1898 = c1899.f17638a;
            c1898.getClass();
            long j2 = c1898.f17617a;
            if (j2 != Long.MAX_VALUE) {
                C1897 c1897M8273a = c1898.m8273a();
                c1897M8273a.f17587a = j2 + this.streamOffsetUs;
                c1899.f17638a = new C1898(c1897M8273a);
            }
        }
        return iMo3678a;
    }

    public final void release() {
        AbstractC1545.m7850a(this.state == 0);
        onRelease();
    }

    public abstract void render(long j, long j2);

    public final void replaceStream(C1898[] c1898Arr, InterfaceC2220 interfaceC2220, long j, long j2, C5466j c5466j) throws C4986e {
        AbstractC1545.m7850a(!this.streamIsFinal);
        this.stream = interfaceC2220;
        this.mediaPeriodId = c5466j;
        if (this.readingPositionUs == Long.MIN_VALUE) {
            this.readingPositionUs = j;
        }
        this.streamFormats = c1898Arr;
        this.streamOffsetUs = j2;
        onStreamChanged(c1898Arr, j, j2, c5466j);
    }

    public final void reset() {
        AbstractC1545.m7850a(this.state == 0);
        this.formatHolder.f17638a = null;
        onReset();
    }

    public final void resetPosition(long j, boolean z) throws C4986e {
        this.streamIsFinal = false;
        this.lastResetPositionUs = j;
        this.readingPositionUs = j;
        if (!z) {
            z = skipSource(j) != 0;
        }
        onPositionReset(j, false, z);
    }

    public final void setCurrentStreamFinal() {
        this.streamIsFinal = true;
    }

    @Override // defpackage.InterfaceC2088
    public final void setListener(InterfaceC2087 interfaceC2087) {
        synchronized (this.lock) {
            this.rendererCapabilitiesListener = interfaceC2087;
        }
    }

    public abstract void setPlaybackSpeed(float f, float f2);

    public final void setTimeline(AbstractC6037p abstractC6037p) {
        if (Objects.equals(this.timeline, abstractC6037p)) {
            return;
        }
        this.timeline = abstractC6037p;
        onTimelineChanged(abstractC6037p);
    }

    public int skipSource(long j) {
        InterfaceC2220 interfaceC2220 = this.stream;
        interfaceC2220.getClass();
        return interfaceC2220.mo3688a(j - this.streamOffsetUs);
    }

    public final void start() throws C4986e {
        AbstractC1545.m7850a(this.state == 1);
        this.state = 2;
        onStarted();
    }

    public final void stop() {
        AbstractC1545.m7850a(this.state == 2);
        this.state = 1;
        onStopped();
    }

    public boolean supportsResetPositionWithoutKeyFrameReset(long j) {
        return false;
    }

    public final C4986e createRendererException(Throwable th, C1898 c1898, boolean z, int i) {
        int iSupportsFormat;
        if (c1898 == null || this.throwRendererExceptionIsExecuting) {
            iSupportsFormat = 4;
        } else {
            this.throwRendererExceptionIsExecuting = true;
            try {
                iSupportsFormat = supportsFormat(c1898) & 7;
            } catch (C4986e unused) {
                iSupportsFormat = 4;
            } finally {
                this.throwRendererExceptionIsExecuting = false;
            }
        }
        return new C4986e(1, th, i, getName(), getIndex(), c1898, c1898 == null ? 4 : iSupportsFormat, this.mediaPeriodId, z);
    }
}
