package defpackage;

import android.os.BadParcelableException;
import android.os.Parcel;

/* JADX INFO: renamed from: ρ̉, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class BinderC0671 extends AbstractBinderC2560 {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C0879 f13808a;

    public BinderC0671(C0879 c0879) {
        super(0);
        attachInterface(this, "com.google.android.apps.play.billingtestcompanion.aidl.IBillingOverrideServiceCallback");
        this.f13808a = c0879;
    }

    @Override // defpackage.AbstractBinderC2560
    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public final boolean mo6572a(Parcel parcel, int i) {
        if (i != 1) {
            return false;
        }
        int i2 = parcel.readInt();
        int i3 = AbstractC2563.f19724a;
        int iDataAvail = parcel.dataAvail();
        if (iDataAvail > 0) {
            throw new BadParcelableException(AbstractC4072a.m739a(iDataAvail, "Parcel data not fully consumed, unread size: "));
        }
        this.f13808a.m6928a(Integer.valueOf(i2));
        return true;
    }
}
