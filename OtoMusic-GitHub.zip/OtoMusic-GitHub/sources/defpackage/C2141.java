package defpackage;

import java.io.Closeable;

/* JADX INFO: renamed from: оַ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2141 implements Closeable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C1176 f18506a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final EnumC5928o f18507a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final String f18508a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f18509a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C5198i f18510a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C5208i f18511a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final AbstractC2143 f18512a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final C2141 f18513a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final C2141 f18514a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final C2141 f18515a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final long f18516a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final long f18517a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final C4670c f18518a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public C4673c f18519a;

    public C2141(C1176 c1176, EnumC5928o enumC5928o, String str, int i, C5198i c5198i, C5208i c5208i, AbstractC2143 abstractC2143, C2141 c2141, C2141 c21412, C2141 c21413, long j, long j2, C4670c c4670c) {
        AbstractC3098.m10103a(c1176, "request");
        AbstractC3098.m10103a(enumC5928o, "protocol");
        AbstractC3098.m10103a(str, "message");
        this.f18506a = c1176;
        this.f18507a = enumC5928o;
        this.f18508a = str;
        this.f18509a = i;
        this.f18510a = c5198i;
        this.f18511a = c5208i;
        this.f18512a = abstractC2143;
        this.f18513a = c2141;
        this.f18514a = c21412;
        this.f18515a = c21413;
        this.f18516a = j;
        this.f18517a = j2;
        this.f18518a = c4670c;
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static String m8589a(C2141 c2141, String str) {
        c2141.getClass();
        String strM3865a = c2141.f18511a.m3865a(str);
        if (strM3865a == null) {
            return null;
        }
        return strM3865a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C4673c m8590a() {
        C4673c c4673c = this.f18519a;
        if (c4673c != null) {
            return c4673c;
        }
        C4673c c4673c2 = C4673c.f5638a;
        C4673c c4673cM9199a = AbstractC2577.m9199a(this.f18511a);
        this.f18519a = c4673cM9199a;
        return c4673cM9199a;
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final C5208i m8591a() {
        return this.f18511a;
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final boolean m8592a() {
        int i = this.f18509a;
        return 200 <= i && i < 300;
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final C2139 m8593a() {
        C2139 c2139 = new C2139();
        c2139.f18491a = this.f18506a;
        c2139.f18492a = this.f18507a;
        c2139.f18493a = this.f18509a;
        c2139.f18494a = this.f18508a;
        c2139.f18495a = this.f18510a;
        c2139.f18496a = this.f18511a.m3867a();
        c2139.f18497a = this.f18512a;
        c2139.f18498a = this.f18513a;
        c2139.f18499a = this.f18514a;
        c2139.f18500a = this.f18515a;
        c2139.f18501a = this.f18516a;
        c2139.f18502a = this.f18517a;
        c2139.f18503a = this.f18518a;
        return c2139;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        AbstractC2143 abstractC2143 = this.f18512a;
        if (abstractC2143 == null) {
            throw new IllegalStateException("response is not eligible for a body and must not be closed");
        }
        abstractC2143.close();
    }

    public final String toString() {
        return "Response{protocol=" + this.f18507a + ", code=" + this.f18509a + ", message=" + this.f18508a + ", url=" + ((C3005) this.f18506a.f14958a) + '}';
    }
}
