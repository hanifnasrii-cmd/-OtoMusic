package defpackage;

/* JADX INFO: renamed from: c֨, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC4501c {
}
