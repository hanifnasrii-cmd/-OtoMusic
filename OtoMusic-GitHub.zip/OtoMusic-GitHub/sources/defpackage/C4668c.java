package defpackage;

import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* JADX INFO: renamed from: cⷨ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4668c {

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final String f5616a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static final String f5617a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C3005 f5618a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C5208i f5619a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f5620a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final EnumC5928o f5621a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f5622a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final String f5623a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C5208i f5624a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C5198i f5625a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final long f5626a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final long f5627a;

    static {
        C5693o c5693o = C5693o.f9228a;
        C5693o.f9228a.getClass();
        f5616a = "OkHttp-Sent-Millis";
        C5693o.f9228a.getClass();
        f5617a = "OkHttp-Received-Millis";
    }

    public C4668c(InterfaceC3655 interfaceC3655) throws IOException {
        C3005 c3005M9972a;
        EnumC6057p enumC6057pM5063a;
        AbstractC3098.m10103a(interfaceC3655, "rawSource");
        try {
            C6009o c6009oM3596a = AbstractC5124i.m3596a(interfaceC3655);
            String strMo2588a = c6009oM3596a.mo2588a(Long.MAX_VALUE);
            try {
                C3003 c3003 = new C3003();
                c3003.m9974a(null, strMo2588a);
                c3005M9972a = c3003.m9972a();
            } catch (IllegalArgumentException unused) {
                c3005M9972a = null;
            }
            if (c3005M9972a == null) {
                IOException iOException = new IOException("Cache corruption for ".concat(strMo2588a));
                C5693o c5693o = C5693o.f9228a;
                C5693o.f9228a.getClass();
                C5693o.m4573a("cache corruption", 5, iOException);
                throw iOException;
            }
            this.f5618a = c3005M9972a;
            this.f5620a = c6009oM3596a.mo2588a(Long.MAX_VALUE);
            C5207i c5207i = new C5207i(0);
            int iM3452a = AbstractC5120i.m3452a(c6009oM3596a);
            for (int i = 0; i < iM3452a; i++) {
                c5207i.m3857a(c6009oM3596a.mo2588a(Long.MAX_VALUE));
            }
            this.f5619a = c5207i.m3860a();
            C2896 c2896M10068a = AbstractC3085.m10068a(c6009oM3596a.mo2588a(Long.MAX_VALUE));
            this.f5621a = (EnumC5928o) c2896M10068a.f20889a;
            this.f5622a = c2896M10068a.f20888a;
            this.f5623a = (String) c2896M10068a.f20890a;
            C5207i c5207i2 = new C5207i(0);
            int iM3452a2 = AbstractC5120i.m3452a(c6009oM3596a);
            for (int i2 = 0; i2 < iM3452a2; i2++) {
                c5207i2.m3857a(c6009oM3596a.mo2588a(Long.MAX_VALUE));
            }
            String str = f5616a;
            String strM3862a = c5207i2.m3862a(str);
            String str2 = f5617a;
            String strM3862a2 = c5207i2.m3862a(str2);
            c5207i2.m3864a(str);
            c5207i2.m3864a(str2);
            this.f5626a = strM3862a != null ? Long.parseLong(strM3862a) : 0L;
            this.f5627a = strM3862a2 != null ? Long.parseLong(strM3862a2) : 0L;
            this.f5624a = c5207i2.m3860a();
            if (AbstractC3098.m10094a(this.f5618a.f21501a, "https")) {
                String strMo2588a2 = c6009oM3596a.mo2588a(Long.MAX_VALUE);
                if (strMo2588a2.length() > 0) {
                    throw new IOException("expected \"\" but was \"" + strMo2588a2 + '\"');
                }
                C2789 c2789M3753a = C2789.f20503a.m3753a(c6009oM3596a.mo2588a(Long.MAX_VALUE));
                List listM2774a = m2774a(c6009oM3596a);
                List listM2774a2 = m2774a(c6009oM3596a);
                if (c6009oM3596a.m5001a()) {
                    enumC6057pM5063a = EnumC6057p.SSL_3_0;
                } else {
                    C6056p c6056p = EnumC6057p.Companion;
                    String strMo2588a3 = c6009oM3596a.mo2588a(Long.MAX_VALUE);
                    c6056p.getClass();
                    enumC6057pM5063a = C6056p.m5063a(strMo2588a3);
                }
                AbstractC3098.m10103a(enumC6057pM5063a, "tlsVersion");
                this.f5625a = new C5198i(enumC6057pM5063a, c2789M3753a, AbstractC6204p.m5341a(listM2774a2), new C5197i(0, AbstractC6204p.m5341a(listM2774a)));
            } else {
                this.f5625a = null;
            }
            interfaceC3655.close();
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                AbstractC1149.m7166a(interfaceC3655, th);
                throw th2;
            }
        }
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static List m2774a(C6009o c6009o) throws IOException {
        int iM3452a = AbstractC5120i.m3452a(c6009o);
        if (iM3452a == -1) {
            return C4891e.f6320a;
        }
        try {
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            ArrayList arrayList = new ArrayList(iM3452a);
            for (int i = 0; i < iM3452a; i++) {
                String strMo2588a = c6009o.mo2588a(Long.MAX_VALUE);
                C4628c c4628c = new C4628c();
                C4663c c4663c = C4663c.f5598a;
                byte[] bArrM659a = a.m659a(strMo2588a);
                C4663c c4663c2 = bArrM659a != null ? new C4663c(bArrM659a) : null;
                if (c4663c2 == null) {
                    throw new IOException("Corrupt certificate in cache entry");
                }
                c4628c.m2607a(c4663c2);
                arrayList.add(certificateFactory.generateCertificate(new C4627c(c4628c, 0)));
            }
            return arrayList;
        } catch (CertificateException e) {
            throw new IOException(e.getMessage());
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static void m2775a(C6008o c6008o, List list) throws IOException {
        try {
            c6008o.mo2597a(list.size());
            c6008o.writeByte(10);
            Iterator it = list.iterator();
            while (it.hasNext()) {
                byte[] encoded = ((Certificate) it.next()).getEncoded();
                C4663c c4663c = C4663c.f5598a;
                AbstractC3098.m10102a(encoded, "bytes");
                c6008o.mo2596a(a.m660a(C5165i.m3745a(encoded).f5599a));
                c6008o.writeByte(10);
            }
        } catch (CertificateEncodingException e) {
            throw new IOException(e.getMessage());
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m2776a(C1530 c1530) {
        C3005 c3005 = this.f5618a;
        C5198i c5198i = this.f5625a;
        C5208i c5208i = this.f5624a;
        C5208i c5208i2 = this.f5619a;
        C6008o c6008oM3595a = AbstractC5124i.m3595a(c1530.m7810a(0));
        try {
            c6008oM3595a.mo2596a(c3005.f21509a);
            c6008oM3595a.writeByte(10);
            c6008oM3595a.mo2596a(this.f5620a);
            c6008oM3595a.writeByte(10);
            c6008oM3595a.mo2597a(c5208i2.size());
            c6008oM3595a.writeByte(10);
            int size = c5208i2.size();
            for (int i = 0; i < size; i++) {
                c6008oM3595a.mo2596a(c5208i2.m3866a(i));
                c6008oM3595a.mo2596a(": ");
                c6008oM3595a.mo2596a(c5208i2.m3868a(i));
                c6008oM3595a.writeByte(10);
            }
            EnumC5928o enumC5928o = this.f5621a;
            int i2 = this.f5622a;
            String str = this.f5623a;
            AbstractC3098.m10103a(enumC5928o, "protocol");
            AbstractC3098.m10103a(str, "message");
            StringBuilder sb = new StringBuilder();
            if (enumC5928o == EnumC5928o.HTTP_1_0) {
                sb.append("HTTP/1.0");
            } else {
                sb.append("HTTP/1.1");
            }
            sb.append(' ');
            sb.append(i2);
            sb.append(' ');
            sb.append(str);
            String string = sb.toString();
            AbstractC3098.m10102a(string, "StringBuilder().apply(builderAction).toString()");
            c6008oM3595a.mo2596a(string);
            c6008oM3595a.writeByte(10);
            c6008oM3595a.mo2597a(c5208i.size() + 2);
            c6008oM3595a.writeByte(10);
            int size2 = c5208i.size();
            for (int i3 = 0; i3 < size2; i3++) {
                c6008oM3595a.mo2596a(c5208i.m3866a(i3));
                c6008oM3595a.mo2596a(": ");
                c6008oM3595a.mo2596a(c5208i.m3868a(i3));
                c6008oM3595a.writeByte(10);
            }
            c6008oM3595a.mo2596a(f5616a);
            c6008oM3595a.mo2596a(": ");
            c6008oM3595a.mo2597a(this.f5626a);
            c6008oM3595a.writeByte(10);
            c6008oM3595a.mo2596a(f5617a);
            c6008oM3595a.mo2596a(": ");
            c6008oM3595a.mo2597a(this.f5627a);
            c6008oM3595a.writeByte(10);
            if (AbstractC3098.m10094a(c3005.f21501a, "https")) {
                c6008oM3595a.writeByte(10);
                AbstractC3098.m10100a(c5198i);
                c6008oM3595a.mo2596a(c5198i.f7431a.f20522a);
                c6008oM3595a.writeByte(10);
                m2775a(c6008oM3595a, c5198i.m3846a());
                m2775a(c6008oM3595a, c5198i.f7432a);
                c6008oM3595a.mo2596a(c5198i.f7430a.m5064a());
                c6008oM3595a.writeByte(10);
            }
            c6008oM3595a.close();
        } finally {
        }
    }

    public C4668c(C2141 c2141) {
        C5208i c5208i;
        C1176 c1176 = c2141.f18506a;
        this.f5618a = (C3005) c1176.f14958a;
        C2141 c21412 = c2141.f18513a;
        AbstractC3098.m10100a(c21412);
        C5208i c5208i2 = (C5208i) c21412.f18506a.f14960a;
        C5208i c5208i3 = c2141.f18511a;
        Set setM3469a = AbstractC5120i.m3469a(c5208i3);
        if (setM3469a.isEmpty()) {
            c5208i = AbstractC6204p.f10906a;
        } else {
            ArrayList arrayList = new ArrayList(20);
            int size = c5208i2.size();
            for (int i = 0; i < size; i++) {
                String strM3866a = c5208i2.m3866a(i);
                if (setM3469a.contains(strM3866a)) {
                    String strM3868a = c5208i2.m3868a(i);
                    AbstractC3098.m10103a(strM3866a, "name");
                    AbstractC3098.m10103a(strM3868a, "value");
                    AbstractC3098.m10099a(strM3866a);
                    AbstractC3098.m10106a(strM3868a, strM3866a);
                    arrayList.add(strM3866a);
                    arrayList.add(AbstractC3778.m10991a(strM3868a).toString());
                }
            }
            c5208i = new C5208i((String[]) arrayList.toArray(new String[0]));
        }
        this.f5619a = c5208i;
        this.f5620a = (String) c1176.f14959a;
        this.f5621a = c2141.f18507a;
        this.f5622a = c2141.f18509a;
        this.f5623a = c2141.f18508a;
        this.f5624a = c5208i3;
        this.f5625a = c2141.f18510a;
        this.f5626a = c2141.f18516a;
        this.f5627a = c2141.f18517a;
    }
}
