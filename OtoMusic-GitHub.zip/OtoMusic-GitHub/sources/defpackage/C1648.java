package defpackage;

/* JADX INFO: renamed from: аⷹ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1648 extends C6129p {
    public C1648() {
        m5147a(1);
        m5144a(new C1699(2));
        m5144a(new C2730());
        m5144a(new C1699(1));
    }
}
