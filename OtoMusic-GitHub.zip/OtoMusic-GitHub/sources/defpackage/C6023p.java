package defpackage;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

/* JADX INFO: renamed from: p̌, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6023p implements InterfaceC6024p {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final String[] f10341a = {"_data"};

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final String[] f10342a = {"_data"};

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f10343a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final ContentResolver f10344a;

    public /* synthetic */ C6023p(ContentResolver contentResolver, int i) {
        this.f10343a = i;
        this.f10344a = contentResolver;
    }

    @Override // defpackage.InterfaceC6024p
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Cursor mo5022a(Uri uri) {
        switch (this.f10343a) {
            case 0:
                String lastPathSegment = uri.getLastPathSegment();
                return this.f10344a.query(MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, f10341a, "kind = 1 AND image_id = ?", new String[]{lastPathSegment}, null);
            default:
                String lastPathSegment2 = uri.getLastPathSegment();
                return this.f10344a.query(MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, f10342a, "kind = 1 AND video_id = ?", new String[]{lastPathSegment2}, null);
        }
    }
}
