package defpackage;

/* JADX INFO: renamed from: еُ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1838 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f17393a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f17394a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public InterfaceC1816 f17395a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ C1839 f17396a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1838(C1839 c1839, InterfaceC1005 interfaceC1005) {
        super(interfaceC1005);
        this.f17396a = c1839;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f17393a = obj;
        this.f17394a |= Integer.MIN_VALUE;
        return this.f17396a.mo674a(null, this);
    }
}
