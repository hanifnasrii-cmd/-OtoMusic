package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;

/* JADX INFO: renamed from: e͙, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4780e extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f5991a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ Object f5992a;

    public /* synthetic */ C4780e(int i, Object obj) {
        this.f5991a = i;
        this.f5992a = obj;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        switch (this.f5991a) {
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                super.onAnimationEnd(animator);
                AbstractC4781e abstractC4781e = (AbstractC4781e) this.f5992a;
                super/*android.graphics.drawable.Drawable*/.setVisible(false, false);
                ArrayList arrayList = abstractC4781e.f6000a;
                if (arrayList != null && !abstractC4781e.f6001a) {
                    int size = arrayList.size();
                    int i = 0;
                    while (i < size) {
                        Object obj = arrayList.get(i);
                        i++;
                        ((AbstractC4307a) obj).mo1195a(abstractC4781e);
                    }
                    break;
                }
                break;
            default:
                super.onAnimationEnd(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationRepeat(Animator animator) {
        switch (this.f5991a) {
            case 2:
                super.onAnimationRepeat(animator);
                C0087 c0087 = (C0087) this.f5992a;
                C3697 c3697 = c0087.f11875a;
                int i = c0087.f11871a + 1;
                c0087.f11871a = i;
                c3697.m10895a(i);
                break;
            default:
                super.onAnimationRepeat(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        switch (this.f5991a) {
            case 0:
                super.onAnimationStart(animator);
                AbstractC4781e abstractC4781e = (AbstractC4781e) this.f5992a;
                ArrayList arrayList = abstractC4781e.f6000a;
                if (arrayList != null && !abstractC4781e.f6001a) {
                    int size = arrayList.size();
                    int i = 0;
                    while (i < size) {
                        Object obj = arrayList.get(i);
                        i++;
                        ((AbstractC4307a) obj).mo1196a(abstractC4781e);
                    }
                    break;
                }
                break;
            default:
                super.onAnimationStart(animator);
                break;
        }
    }
}
