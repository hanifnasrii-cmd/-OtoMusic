package defpackage;

import java.io.IOException;

/* JADX INFO: renamed from: iⷿ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5351i extends AbstractC3942 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C2985 f7980a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ int f7981a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ int f7982a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5351i(String str, C2985 c2985, int i, int i2) {
        super(str, true);
        this.f7980a = c2985;
        this.f7981a = i;
        this.f7982a = i2;
    }

    @Override // defpackage.AbstractC3942
    /* JADX INFO: renamed from: à */
    public final long mo2845a() {
        C2985 c2985 = this.f7980a;
        try {
            c2985.f21415a.m9948a(this.f7981a, true, this.f7982a);
            return -1L;
        } catch (IOException e) {
            c2985.m9918a(e);
            return -1L;
        }
    }
}
