package defpackage;

/* JADX INFO: renamed from: оܲ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C2209 extends AbstractC5067i implements InterfaceC5056i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C2209 f18708a = new C2209(3, InterfaceC1816.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);

    @Override // defpackage.InterfaceC5056i
    /* JADX INFO: renamed from: á */
    public final Object mo2172a(Object obj, Object obj2, Object obj3) {
        return ((InterfaceC1816) obj).mo674a(obj2, (InterfaceC1005) obj3);
    }
}
