package defpackage;

import android.content.Context;
import android.text.TextPaint;
import java.lang.ref.WeakReference;

/* JADX INFO: renamed from: օⷰ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3956 {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public float f24165a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public float f24166a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final WeakReference f24168a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public C3953 f24169a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final TextPaint f24163a = new TextPaint(1);

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C2773 f24164a = new C2773(1, this);

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f24167a = true;

    public C3956(InterfaceC3955 interfaceC3955) {
        this.f24168a = new WeakReference(null);
        this.f24168a = new WeakReference(interfaceC3955);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C3953 m11118a() {
        return this.f24169a;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float m11119a(String str) {
        if (!this.f24167a) {
            return this.f24166a;
        }
        m11122a(str);
        return this.f24166a;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final TextPaint m11120a() {
        return this.f24163a;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final float m11121a(String str) {
        if (!this.f24167a) {
            return this.f24165a;
        }
        m11122a(str);
        return this.f24165a;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final void m11122a(String str) {
        TextPaint textPaint = this.f24163a;
        this.f24165a = str == null ? 0.0f : textPaint.measureText((CharSequence) str, 0, str.length());
        this.f24166a = str != null ? Math.abs(textPaint.getFontMetrics().ascent) : 0.0f;
        this.f24167a = false;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void m11123a(C3953 c3953, Context context) {
        if (this.f24169a != c3953) {
            this.f24169a = c3953;
            if (c3953 != null) {
                TextPaint textPaint = this.f24163a;
                C2773 c2773 = this.f24164a;
                c3953.m11116a(context, textPaint, c2773);
                InterfaceC3955 interfaceC3955 = (InterfaceC3955) this.f24168a.get();
                if (interfaceC3955 != null) {
                    textPaint.drawableState = interfaceC3955.getState();
                }
                c3953.m11115a(context, textPaint, c2773);
                this.f24167a = true;
            }
            InterfaceC3955 interfaceC39552 = (InterfaceC3955) this.f24168a.get();
            if (interfaceC39552 != null) {
                interfaceC39552.mo2088a();
                interfaceC39552.onStateChange(interfaceC39552.getState());
            }
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void m11124a() {
        this.f24167a = true;
    }
}
