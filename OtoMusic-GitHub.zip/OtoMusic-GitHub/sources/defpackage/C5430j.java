package defpackage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: renamed from: j͏, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5430j extends C5433j {

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final ArrayList f8362a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final C1454 f8363a;

    public C5430j(C5432j c5432j, String str, String str2) {
        super(c5432j, str, str2, false);
        this.f8362a = new ArrayList();
        this.f8363a = new C1454(0);
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final int m4212a(C5433j c5433j) {
        C5421j c5421j = (C5421j) this.f8363a.get(c5433j.f8381a);
        if (c5421j != null) {
            return c5421j.f8335a;
        }
        return 4;
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final boolean m4213a() {
        C5435j.m4235a();
        return C5435j.m4236a().m3708a().contains(this);
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final boolean m4214a(C5433j c5433j) {
        C5421j c5421j = (C5421j) this.f8363a.get(c5433j.f8381a);
        return c5421j != null && c5421j.f8337a;
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final boolean m4215a(C5433j c5433j) {
        C5421j c5421j = (C5421j) this.f8363a.get(c5433j.f8381a);
        return c5421j != null && c5421j.f8338a;
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final boolean m4216a(C5433j c5433j) {
        C5421j c5421j = (C5421j) this.f8363a.get(c5433j.f8381a);
        return c5421j != null && c5421j.f8336a;
    }

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final void m4217a(Collection collection) {
        this.f8400a.clear();
        ArrayList arrayList = this.f8362a;
        arrayList.clear();
        C1454 c1454 = this.f8363a;
        c1454.clear();
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            C5421j c5421j = (C5421j) it.next();
            C5433j c5433jM4220a = this.f8379a.m4220a(c5421j.f8334a.m4172a());
            if (c5433jM4220a != null) {
                arrayList.add(c5433jM4220a);
                c1454.put(c5433jM4220a.f8381a, c5421j);
                int i = c5421j.f8335a;
                if (i == 2 || i == 3) {
                    this.f8400a.add(c5433jM4220a);
                }
            }
        }
        C5435j.m4236a().f7198a.m3673a(259, this);
    }
}
