package defpackage;

import com.piyush.music.fragments.equalizer.EqualizerFragment;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: renamed from: cٛ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C4556c implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f5254a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ String f5255a;

    public /* synthetic */ C4556c(EqualizerFragment equalizerFragment, String str, int i) {
        this.f5254a = i;
        this.f5255a = str;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) throws Exception {
        InterfaceC2207 interfaceC2207Mo8687a;
        int i = this.f5254a;
        String str = this.f5255a;
        switch (i) {
            case 0:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("SELECT * FROM BLACKLIST WHERE path=?");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    int iM9236a = AbstractC2582.m9236a(interfaceC2207Mo8687a, "id");
                    int iM9236a2 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "path");
                    if (interfaceC2207Mo8687a.mo4767a()) {
                        c4551c = new C4551c((int) interfaceC2207Mo8687a.getLong(iM9236a), interfaceC2207Mo8687a.mo4765a(iM9236a2));
                        break;
                    }
                    return c4551c;
                } finally {
                }
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return EqualizerFragment.m1744a(((Integer) obj).intValue(), str);
            case 2:
                return EqualizerFragment.m1744a(((Integer) obj).intValue(), str);
            case 3:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("SELECT * FROM Playlist WHERE title LIKE '%' || ? || '%'");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    int iM9236a3 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "id");
                    int iM9236a4 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "title");
                    int iM9236a5 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "is_favorite");
                    int iM9236a6 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "time_updated");
                    ArrayList arrayList = new ArrayList();
                    while (interfaceC2207Mo8687a.mo4767a()) {
                        arrayList.add(new C5767o((int) interfaceC2207Mo8687a.getLong(iM9236a3), interfaceC2207Mo8687a.mo4765a(iM9236a4), interfaceC2207Mo8687a.mo4765a(iM9236a6), ((int) interfaceC2207Mo8687a.getLong(iM9236a5)) != 0));
                        break;
                    }
                    return arrayList;
                } finally {
                }
            case 4:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("DELETE FROM search_history WHERE query = ?");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    interfaceC2207Mo8687a.mo4767a();
                    interfaceC2207Mo8687a.close();
                    return C6174p.f10843a;
                } finally {
                }
            case 5:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("SELECT * FROM song_affinity WHERE song_path = ?");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    return interfaceC2207Mo8687a.mo4767a() ? new C0602(interfaceC2207Mo8687a.mo4765a(AbstractC2582.m9236a(interfaceC2207Mo8687a, "song_path")), (int) interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "plays")), interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "total_played_ms")), (float) interfaceC2207Mo8687a.getDouble(AbstractC2582.m9236a(interfaceC2207Mo8687a, "completion_rate")), (float) interfaceC2207Mo8687a.getDouble(AbstractC2582.m9236a(interfaceC2207Mo8687a, "early_skip_rate")), interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "last_played_at")), interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "first_played_at")), (int) interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "explicit_likes")), (float) interfaceC2207Mo8687a.getDouble(AbstractC2582.m9236a(interfaceC2207Mo8687a, "score")), interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "updated_at")), (int) interfaceC2207Mo8687a.getLong(AbstractC2582.m9236a(interfaceC2207Mo8687a, "legacy_plays"))) : null;
                } finally {
                }
            case 6:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("SELECT lyrics FROM song_lyrics WHERE song_path = ? LIMIT 1");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    if (interfaceC2207Mo8687a.mo4767a() && !interfaceC2207Mo8687a.isNull(0)) {
                        c4551c = interfaceC2207Mo8687a.mo4765a(0);
                        break;
                    }
                    return c4551c;
                } finally {
                }
            case 7:
                interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a("SELECT lyrics FROM song_lyrics WHERE song_path = ? LIMIT 1");
                try {
                    interfaceC2207Mo8687a.mo4766a(1, str);
                    if (interfaceC2207Mo8687a.mo4767a() && !interfaceC2207Mo8687a.isNull(0)) {
                        c4551c = interfaceC2207Mo8687a.mo4765a(0);
                        break;
                    }
                    return c4551c;
                } finally {
                }
            case 8:
                String str2 = (String) obj;
                AbstractC3098.m10103a(str2, "it");
                return AbstractC3778.m10973a(str2) ? str2.length() < str.length() ? str : str2 : AbstractC4072a.m746a(str, str2);
            case 9:
                int iIntValue = ((Integer) obj).intValue();
                int i2 = C3798.f23737a;
                if (iIntValue <= 0) {
                    return str;
                }
                return iIntValue + "ms";
            default:
                int iIntValue2 = ((Integer) obj).intValue();
                int i3 = C3798.f23737a;
                if (iIntValue2 <= 0) {
                    return str;
                }
                if (iIntValue2 % 1000 != 0) {
                    return String.format("%.2fs", Arrays.copyOf(new Object[]{Float.valueOf(iIntValue2 / 1000.0f)}, 1));
                }
                return (iIntValue2 / 1000) + "s";
        }
    }

    public /* synthetic */ C4556c(String str, int i) {
        this.f5254a = i;
        this.f5255a = str;
    }
}
