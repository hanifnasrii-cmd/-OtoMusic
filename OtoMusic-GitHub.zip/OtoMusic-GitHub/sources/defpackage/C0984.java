package defpackage;

/* JADX INFO: renamed from: ρⷷ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0984 extends AbstractC6386s {
    private static final C0984 zzi;
    private int zzb;
    private int zzd;
    private long zze;
    private InterfaceC6391s zzf;
    private InterfaceC6391s zzg;
    private InterfaceC6391s zzh;

    static {
        C0984 c0984 = new C0984();
        zzi = c0984;
        AbstractC6386s.m5619a(C0984.class, c0984);
    }

    public C0984() {
        C6406s c6406s = C6406s.f11436a;
        this.zzf = c6406s;
        this.zzg = c6406s;
        this.zzh = c6406s;
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzi, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0003\u0000\u0001᠌\u0000\u0002ဂ\u0001\u0003\u001b\u0004\u001b\u0005\u001b", new Object[]{"zzb", "zzd", C0869.f14191a, "zze", "zzf", C0977.class, "zzg", C0906.class, "zzh", C0980.class});
        }
        if (i2 == 3) {
            return new C0984();
        }
        if (i2 == 4) {
            return new C0981(zzi);
        }
        if (i2 == 5) {
            return zzi;
        }
        throw null;
    }
}
