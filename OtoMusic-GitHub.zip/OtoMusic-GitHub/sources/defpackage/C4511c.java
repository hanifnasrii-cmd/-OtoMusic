package defpackage;

import android.app.Application;

/* JADX INFO: renamed from: cֲ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4511c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public volatile C5220i f5109a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Application f5110a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public volatile C4531c f5111a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean m2349a() {
        try {
            Application application = this.f5110a;
            return application.getPackageManager().getApplicationInfo(application.getPackageName(), 128).metaData.getBoolean("com.google.android.play.billingclient.enableBillingOverridesTesting", false);
        } catch (Exception unused) {
            AbstractC2625.m9322a("BillingClient");
            return false;
        }
    }
}
