package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: ο҅, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class EnumC0445 {
    private static final /* synthetic */ InterfaceC4935e $ENTRIES;
    private static final /* synthetic */ EnumC0445[] $VALUES;
    public static final EnumC0445 NAV;
    public static final EnumC0445 SLIDER;
    public static final EnumC0445 TOGGLE;
    public static final EnumC0445 VALUE;

    static {
        EnumC0445 enumC0445 = new EnumC0445("TOGGLE", 0);
        TOGGLE = enumC0445;
        EnumC0445 enumC04452 = new EnumC0445("VALUE", 1);
        VALUE = enumC04452;
        EnumC0445 enumC04453 = new EnumC0445("NAV", 2);
        NAV = enumC04453;
        EnumC0445 enumC04454 = new EnumC0445("SLIDER", 3);
        SLIDER = enumC04454;
        EnumC0445[] enumC0445Arr = {enumC0445, enumC04452, enumC04453, enumC04454};
        $VALUES = enumC0445Arr;
        $ENTRIES = AbstractC5120i.m3435a(enumC0445Arr);
    }

    public static EnumC0445 valueOf(String str) {
        return (EnumC0445) Enum.valueOf(EnumC0445.class, str);
    }

    public static EnumC0445[] values() {
        return (EnumC0445[]) $VALUES.clone();
    }
}
