package defpackage;

import android.net.Uri;

/* JADX INFO: renamed from: аؘ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1500 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f16113a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Uri f16114a;

    public C1500(String str, Uri uri) {
        this.f16113a = str;
        this.f16114a = uri;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Uri m7770a() {
        return this.f16114a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1500)) {
            return false;
        }
        C1500 c1500 = (C1500) obj;
        return AbstractC3098.m10094a(this.f16113a, c1500.f16113a) && AbstractC3098.m10094a(this.f16114a, c1500.f16114a);
    }

    public final int hashCode() {
        return this.f16114a.hashCode() + (this.f16113a.hashCode() * 31);
    }

    public final String toString() {
        return "Parameters(name=" + this.f16113a + ", uri=" + this.f16114a + ")";
    }
}
