package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: ȃ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4026a extends AbstractC3210 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f959a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C4027a f960a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C4026a(C4027a c4027a, int i) {
        super(0);
        this.f959a = i;
        this.f960a = c4027a;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        switch (this.f959a) {
            case 0:
                C6284p viewModelStore = this.f960a.requireActivity().getViewModelStore();
                AbstractC3098.m10102a(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return this.f960a.requireActivity().getDefaultViewModelCreationExtras();
            default:
                InterfaceC6282p defaultViewModelProviderFactory = this.f960a.requireActivity().getDefaultViewModelProviderFactory();
                AbstractC3098.m10102a(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
        }
    }
}
