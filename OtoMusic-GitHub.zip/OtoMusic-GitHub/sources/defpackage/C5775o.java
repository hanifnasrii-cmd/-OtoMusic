package defpackage;

import java.util.List;

/* JADX INFO: renamed from: o͞, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5775o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC2178 f9543a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C4557c f9544a = new C4557c(6);

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C4558c f9545a = new C4558c(1);

    public C5775o(AbstractC2178 abstractC2178) {
        this.f9543a = abstractC2178;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public long m4714a(String str, boolean z) {
        return ((Number) AbstractC6161p.m5222a(this.f9543a, false, true, new C5193i(this, 1, new C5767o(0, str, String.valueOf(System.currentTimeMillis()), z)))).longValue();
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C2181 m4715a() {
        C3106 c3106M8608a = this.f9543a.m8608a();
        String[] strArr = {"PLAYLIST"};
        C0063 c0063 = new C0063(19);
        c3106M8608a.f21743a.m5180a(strArr);
        C2415 c2415 = c3106M8608a.f21748a;
        c2415.getClass();
        return new C2181((AbstractC2178) c2415.f19331a, c2415, strArr, c0063);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final List m4716a() {
        return (List) AbstractC6161p.m5222a(this.f9543a, true, false, new C0063(18));
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C5767o m4717a() {
        C4555c c4555c = new C4555c(15);
        AbstractC2178 abstractC2178 = this.f9543a;
        C5767o c5767o = (C5767o) AbstractC6161p.m5222a(abstractC2178, true, false, c4555c);
        if (c5767o != null) {
            return c5767o;
        }
        m4714a("Favorites", true);
        C5767o c5767o2 = (C5767o) AbstractC6161p.m5222a(abstractC2178, true, false, new C4555c(15));
        AbstractC3098.m10100a(c5767o2);
        return c5767o2;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C5767o m4718a(int i) {
        return (C5767o) AbstractC6161p.m5222a(this.f9543a, true, false, new C0059(i, 1));
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public void m4719a(int i) {
        AbstractC6161p.m5222a(this.f9543a, false, true, new C5773o(String.valueOf(System.currentTimeMillis()), i, 0));
    }
}
