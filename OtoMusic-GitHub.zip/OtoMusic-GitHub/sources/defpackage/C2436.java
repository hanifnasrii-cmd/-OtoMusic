package defpackage;

import android.content.Context;

/* JADX INFO: renamed from: р֓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2436 {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C2436 f19430a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public C1434 f19431a;

    static {
        C2436 c2436 = new C2436();
        c2436.f19431a = null;
        f19430a = c2436;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static C1434 m9009a(Context context) {
        C1434 c1434;
        C2436 c2436 = f19430a;
        synchronized (c2436) {
            try {
                if (c2436.f19431a == null) {
                    if (context.getApplicationContext() != null) {
                        context = context.getApplicationContext();
                    }
                    c2436.f19431a = new C1434(context);
                }
                c1434 = c2436.f19431a;
            } catch (Throwable th) {
                throw th;
            }
        }
        return c1434;
    }
}
