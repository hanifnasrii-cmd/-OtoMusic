package defpackage;

import android.graphics.Matrix;
import android.graphics.Path;

/* JADX INFO: renamed from: ο֡, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0464 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Matrix f13098a = new Matrix();

    /* JADX INFO: renamed from: à */
    public abstract void mo6300a(Matrix matrix, Path path);
}
