package defpackage;

import java.util.Comparator;
import java.util.SortedMap;
import java.util.SortedSet;

/* JADX INFO: renamed from: a̴, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public class C4061a extends C4056a implements SortedMap {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public SortedSet f1030a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ C5590j f1031a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C4061a(C5590j c5590j, SortedMap sortedMap) {
        super(c5590j, sortedMap);
        this.f1031a = c5590j;
    }

    /* JADX INFO: renamed from: á */
    public SortedSet mo708a() {
        return new C4062a(this.f1031a, mo710a());
    }

    @Override // defpackage.C4056a, java.util.AbstractMap, java.util.Map
    /* JADX INFO: renamed from: â, reason: merged with bridge method [inline-methods] */
    public SortedSet keySet() {
        SortedSet sortedSet = this.f1030a;
        if (sortedSet != null) {
            return sortedSet;
        }
        SortedSet sortedSetMo708a = mo708a();
        this.f1030a = sortedSetMo708a;
        return sortedSetMo708a;
    }

    /* JADX INFO: renamed from: ã */
    public SortedMap mo710a() {
        return (SortedMap) this.f1024a;
    }

    @Override // java.util.SortedMap
    public final Comparator comparator() {
        return mo710a().comparator();
    }

    @Override // java.util.SortedMap
    public final Object firstKey() {
        return mo710a().firstKey();
    }

    public SortedMap headMap(Object obj) {
        return new C4061a(this.f1031a, mo710a().headMap(obj));
    }

    @Override // java.util.SortedMap
    public final Object lastKey() {
        return mo710a().lastKey();
    }

    public SortedMap subMap(Object obj, Object obj2) {
        return new C4061a(this.f1031a, mo710a().subMap(obj, obj2));
    }

    public SortedMap tailMap(Object obj) {
        return new C4061a(this.f1031a, mo710a().tailMap(obj));
    }
}
