package defpackage;

import android.os.Parcel;
import android.service.media.MediaBrowserService;
import android.support.v4.media.MediaBrowserCompat$MediaItem;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: ι⃪, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0288 extends AbstractC0293 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f12593a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C5141i f12594a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0288(String str, C5141i c5141i, int i) {
        super(str);
        this.f12593a = i;
        this.f12594a = c5141i;
    }

    @Override // defpackage.AbstractC0293
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void mo6119a() {
        switch (this.f12593a) {
            case 0:
                ((MediaBrowserService.Result) this.f12594a.f7193a).detach();
                break;
            default:
                ((MediaBrowserService.Result) this.f12594a.f7193a).detach();
                break;
        }
    }

    @Override // defpackage.AbstractC0293
    /* JADX INFO: renamed from: â */
    public final void mo6118a(Object obj) {
        ArrayList arrayList;
        switch (this.f12593a) {
            case 0:
                List<MediaBrowserCompat$MediaItem> list = (List) obj;
                if (list == null) {
                    arrayList = null;
                } else {
                    ArrayList arrayList2 = new ArrayList(list.size());
                    for (MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem : list) {
                        Parcel parcelObtain = Parcel.obtain();
                        mediaBrowserCompat$MediaItem.writeToParcel(parcelObtain, 0);
                        arrayList2.add(parcelObtain);
                    }
                    arrayList = arrayList2;
                }
                this.f12594a.m3702a(arrayList);
                break;
            default:
                MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem2 = (MediaBrowserCompat$MediaItem) obj;
                C5141i c5141i = this.f12594a;
                if (mediaBrowserCompat$MediaItem2 == null) {
                    c5141i.m3702a(null);
                } else {
                    Parcel parcelObtain2 = Parcel.obtain();
                    mediaBrowserCompat$MediaItem2.writeToParcel(parcelObtain2, 0);
                    c5141i.m3702a(parcelObtain2);
                }
                break;
        }
    }
}
