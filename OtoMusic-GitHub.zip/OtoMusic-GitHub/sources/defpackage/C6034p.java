package defpackage;

/* JADX INFO: renamed from: p̗, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6034p extends AbstractC6037p {
    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: á */
    public final int mo4736a(Object obj) {
        return -1;
    }

    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: a̅ */
    public final C6035p mo4734a(int i, C6035p c6035p, boolean z) {
        throw new IndexOutOfBoundsException();
    }

    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: ȧ */
    public final int mo4740a() {
        return 0;
    }

    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: a̋ */
    public final Object mo4742a(int i) {
        throw new IndexOutOfBoundsException();
    }

    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: ǎ */
    public final C6036p mo4743a(int i, C6036p c6036p, long j) {
        throw new IndexOutOfBoundsException();
    }

    @Override // defpackage.AbstractC6037p
    /* JADX INFO: renamed from: a̎ */
    public final int mo4744a() {
        return 0;
    }
}
