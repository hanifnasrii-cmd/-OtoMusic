package defpackage;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: renamed from: iⷳ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC5339i {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C5203i[] f7947a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final Map f7948a;

    static {
        C5203i c5203i = new C5203i(C5203i.f7451a, "");
        C4663c c4663c = C5203i.f7448a;
        C5203i c5203i2 = new C5203i(c4663c, "GET");
        C5203i c5203i3 = new C5203i(c4663c, "POST");
        C4663c c4663c2 = C5203i.f7449a;
        C5203i c5203i4 = new C5203i(c4663c2, "/");
        C5203i c5203i5 = new C5203i(c4663c2, "/index.html");
        C4663c c4663c3 = C5203i.f7450a;
        C5203i c5203i6 = new C5203i(c4663c3, "http");
        C5203i c5203i7 = new C5203i(c4663c3, "https");
        C4663c c4663c4 = C5203i.f7447a;
        C5203i[] c5203iArr = {c5203i, c5203i2, c5203i3, c5203i4, c5203i5, c5203i6, c5203i7, new C5203i(c4663c4, "200"), new C5203i(c4663c4, "204"), new C5203i(c4663c4, "206"), new C5203i(c4663c4, "304"), new C5203i(c4663c4, "400"), new C5203i(c4663c4, "404"), new C5203i(c4663c4, "500"), new C5203i("accept-charset", ""), new C5203i("accept-encoding", "gzip, deflate"), new C5203i("accept-language", ""), new C5203i("accept-ranges", ""), new C5203i("accept", ""), new C5203i("access-control-allow-origin", ""), new C5203i("age", ""), new C5203i("allow", ""), new C5203i("authorization", ""), new C5203i("cache-control", ""), new C5203i("content-disposition", ""), new C5203i("content-encoding", ""), new C5203i("content-language", ""), new C5203i("content-length", ""), new C5203i("content-location", ""), new C5203i("content-range", ""), new C5203i("content-type", ""), new C5203i("cookie", ""), new C5203i("date", ""), new C5203i("etag", ""), new C5203i("expect", ""), new C5203i("expires", ""), new C5203i("from", ""), new C5203i("host", ""), new C5203i("if-match", ""), new C5203i("if-modified-since", ""), new C5203i("if-none-match", ""), new C5203i("if-range", ""), new C5203i("if-unmodified-since", ""), new C5203i("last-modified", ""), new C5203i("link", ""), new C5203i("location", ""), new C5203i("max-forwards", ""), new C5203i("proxy-authenticate", ""), new C5203i("proxy-authorization", ""), new C5203i("range", ""), new C5203i("referer", ""), new C5203i("refresh", ""), new C5203i("retry-after", ""), new C5203i("server", ""), new C5203i("set-cookie", ""), new C5203i("strict-transport-security", ""), new C5203i("transfer-encoding", ""), new C5203i("user-agent", ""), new C5203i("vary", ""), new C5203i("via", ""), new C5203i("www-authenticate", "")};
        f7947a = c5203iArr;
        LinkedHashMap linkedHashMap = new LinkedHashMap(61);
        for (int i = 0; i < 61; i++) {
            if (!linkedHashMap.containsKey(c5203iArr[i].f7452a)) {
                linkedHashMap.put(c5203iArr[i].f7452a, Integer.valueOf(i));
            }
        }
        Map mapUnmodifiableMap = Collections.unmodifiableMap(linkedHashMap);
        AbstractC3098.m10102a(mapUnmodifiableMap, "unmodifiableMap(result)");
        f7948a = mapUnmodifiableMap;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static void m3969a(C4663c c4663c) {
        AbstractC3098.m10103a(c4663c, "name");
        int iMo2761a = c4663c.mo2761a();
        for (int i = 0; i < iMo2761a; i++) {
            byte bMo2764a = c4663c.mo2764a(i);
            if (65 <= bMo2764a && bMo2764a < 91) {
                throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: ".concat(c4663c.m2768a()));
            }
        }
    }
}
