package defpackage;

import com.piyush.music.models.Song;
import com.piyush.music.sort.Sort;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

/* JADX INFO: renamed from: a⃛, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4289a implements InterfaceC3422 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C4290a f1665a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ String f1666a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ String f1667a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ String f1668a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ C4032a f1669a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ String f1670a;

    public C4289a(C4290a c4290a, String str, String str2, String str3, C4032a c4032a, String str4) {
        this.f1665a = c4290a;
        this.f1666a = str;
        this.f1667a = str2;
        this.f1668a = str3;
        this.f1669a = c4032a;
        this.f1670a = str4;
    }

    @Override // defpackage.InterfaceC3422
    /* JADX INFO: renamed from: á */
    public final void mo676a(Object obj) {
        final List list = (List) obj;
        this.f1665a.f1673a.f8935a.m5851a(this);
        C1222 c1222 = C1222.f15216a;
        final String str = this.f1666a;
        final C4290a c4290a = this.f1665a;
        final String str2 = this.f1667a;
        final String str3 = this.f1668a;
        final C4032a c4032a = this.f1669a;
        final String str4 = this.f1670a;
        c1222.m7365a(new InterfaceC5038i() { // from class: a⃚
            @Override // defpackage.InterfaceC5038i
            public final Object invoke() throws JSONException {
                ArrayList arrayList;
                int i = 0;
                String str5 = str;
                C4290a c4290a2 = c4290a;
                List list2 = list;
                String str6 = str4;
                if (str5 != null) {
                    ArrayList arrayListM10851a = AbstractC3646.m10851a(c4290a2.m1185a(), c4290a2.f1674a.m7736a(str5, list2), Sort.NAME, 4);
                    arrayList = new ArrayList(AbstractC2853.m9682a(arrayListM10851a, 10));
                    int size = arrayListM10851a.size();
                    while (i < size) {
                        Object obj2 = arrayListM10851a.get(i);
                        i++;
                        int i2 = C4290a.f1671a;
                        arrayList.add(AbstractC2582.m9251a(str6, (Song) obj2));
                    }
                } else {
                    String str7 = str2;
                    if (str7 != null) {
                        C0630 c0630M1185a = c4290a2.m1185a();
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj3 : list2) {
                            Song song = (Song) obj3;
                            if (str7.equals(song.getAlbumName() + "_" + song.getAlbumArtist())) {
                                arrayList2.add(obj3);
                            }
                        }
                        ArrayList arrayListM10851a2 = AbstractC3646.m10851a(c0630M1185a, arrayList2, Sort.TRACK_NUMBER, 4);
                        arrayList = new ArrayList(AbstractC2853.m9682a(arrayListM10851a2, 10));
                        int size2 = arrayListM10851a2.size();
                        while (i < size2) {
                            Object obj4 = arrayListM10851a2.get(i);
                            i++;
                            int i3 = C4290a.f1671a;
                            arrayList.add(AbstractC2582.m9251a(str6, (Song) obj4));
                        }
                    } else {
                        String str8 = str3;
                        if (str8 != null) {
                            ArrayList arrayListM10851a3 = AbstractC3646.m10851a(c4290a2.m1185a(), C2791.f20530a.m7347a(c4290a2.f1672a).m9557a(str8, list2), Sort.NAME, 4);
                            arrayList = new ArrayList(AbstractC2853.m9682a(arrayListM10851a3, 10));
                            int size3 = arrayListM10851a3.size();
                            while (i < size3) {
                                Object obj5 = arrayListM10851a3.get(i);
                                i++;
                                int i4 = C4290a.f1671a;
                                arrayList.add(AbstractC2582.m9251a(str6, (Song) obj5));
                            }
                        } else {
                            List<Song> listM9661a = AbstractC2851.m9661a(list2, new C5393j(8));
                            arrayList = new ArrayList(AbstractC2853.m9682a(listM9661a, 10));
                            for (Song song2 : listM9661a) {
                                int i5 = C4290a.f1671a;
                                arrayList.add(AbstractC2582.m9251a(str6, song2));
                            }
                        }
                    }
                }
                c4032a.invoke(arrayList);
                return C6174p.f10843a;
            }
        });
    }
}
