package defpackage;

import android.content.SharedPreferences;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: οֶ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0485 extends AbstractSharedPreferencesOnSharedPreferenceChangeListenerC0488 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f13149a = 2;

    public /* synthetic */ C0485(String str, Object obj, InterfaceC3238 interfaceC3238) {
        super(str, obj, interfaceC3238);
    }

    @Override // defpackage.AbstractSharedPreferencesOnSharedPreferenceChangeListenerC0488
    /* JADX INFO: renamed from: â */
    public final Object mo6323a() {
        switch (this.f13149a) {
            case 0:
                return Float.valueOf(m6328a().getFloat(this.f13152a, ((Number) this.f13153a).floatValue()));
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return Long.valueOf(m6328a().getLong(this.f13152a, ((Number) this.f13153a).longValue()));
            default:
                String string = m6328a().getString(this.f13152a, (String) this.f13153a);
                AbstractC3098.m10100a(string);
                return string;
        }
    }

    @Override // defpackage.AbstractSharedPreferencesOnSharedPreferenceChangeListenerC0488
    /* JADX INFO: renamed from: ã */
    public final void mo6324a(Object obj) {
        switch (this.f13149a) {
            case 0:
                float fFloatValue = ((Number) obj).floatValue();
                SharedPreferences.Editor editorEdit = m6328a().edit();
                editorEdit.putFloat(this.f13152a, fFloatValue);
                editorEdit.apply();
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                long jLongValue = ((Number) obj).longValue();
                SharedPreferences.Editor editorEdit2 = m6328a().edit();
                editorEdit2.putLong(this.f13152a, jLongValue);
                editorEdit2.apply();
                break;
            default:
                SharedPreferences.Editor editorEdit3 = m6328a().edit();
                editorEdit3.putString(this.f13152a, (String) obj);
                editorEdit3.apply();
                break;
        }
    }

    public C0485(C0492 c0492, String str, float f) {
        super(str, Float.valueOf(f), c0492.f13165a);
    }

    public C0485(C0492 c0492, String str, String str2) {
        super(str, str2, c0492.f13165a);
    }

    public C0485(String str, C3865 c3865) {
        super(str, 0L, c3865);
    }
}
