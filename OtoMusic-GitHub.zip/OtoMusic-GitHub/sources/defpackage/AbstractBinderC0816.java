package defpackage;

import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/* JADX INFO: renamed from: ρֶ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractBinderC0816 extends AbstractBinderC2560 implements InterfaceC6370s {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f14067a;

    public AbstractBinderC0816(byte[] bArr) {
        super("com.google.android.gms.common.internal.ICertData", 2);
        if (bArr.length != 25) {
            throw new IllegalArgumentException();
        }
        this.f14067a = Arrays.hashCode(bArr);
    }

    /* JADX INFO: renamed from: a͎, reason: contains not printable characters */
    public static byte[] m6812a(String str) {
        try {
            return str.getBytes("ISO-8859-1");
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError(e);
        }
    }

    @Override // defpackage.AbstractBinderC2560
    /* JADX INFO: renamed from: a̝ */
    public final boolean mo6592a(int i, Parcel parcel, Parcel parcel2) {
        if (i == 1) {
            BinderC3417 binderC3417 = new BinderC3417(mo6591a());
            parcel2.writeNoException();
            AbstractC2623.m9313a(parcel2, binderC3417);
            return true;
        }
        if (i != 2) {
            return false;
        }
        parcel2.writeNoException();
        parcel2.writeInt(this.f14067a);
        return true;
    }

    /* JADX INFO: renamed from: ḁ */
    public abstract byte[] mo6591a();

    public final boolean equals(Object obj) {
        if (obj instanceof InterfaceC6370s) {
            try {
                InterfaceC6370s interfaceC6370s = (InterfaceC6370s) obj;
                if (((AbstractBinderC0816) interfaceC6370s).f14067a == this.f14067a) {
                    return Arrays.equals(mo6591a(), (byte[]) BinderC3417.m10558a(new BinderC3417(((AbstractBinderC0816) interfaceC6370s).mo6591a())));
                }
            } catch (RemoteException e) {
                Log.e("GoogleCertificates", "Failed to get Google certificates from remote", e);
                return false;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f14067a;
    }
}
