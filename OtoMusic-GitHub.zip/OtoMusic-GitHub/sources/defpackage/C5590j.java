package defpackage;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeMap;

/* JADX INFO: renamed from: j݂, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5590j extends AbstractC4067a implements Serializable {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public transient TreeMap f8869a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public transient int f8870a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public transient C5589j f8871a;

    @Override // defpackage.AbstractC4067a
    /* JADX INFO: renamed from: à */
    public final C4056a mo719a() {
        C4056a c4056a = this.f1044a;
        if (c4056a != null) {
            return c4056a;
        }
        TreeMap treeMap = this.f8869a;
        C4056a c4058a = treeMap != null ? new C4058a(this, treeMap) : treeMap != null ? new C4061a(this, treeMap) : new C4056a(this, treeMap);
        this.f1044a = c4058a;
        return c4058a;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m4420a() {
        TreeMap treeMap = this.f8869a;
        Iterator it = treeMap.values().iterator();
        while (it.hasNext()) {
            ((Collection) it.next()).clear();
        }
        treeMap.clear();
        this.f8870a = 0;
    }
}
