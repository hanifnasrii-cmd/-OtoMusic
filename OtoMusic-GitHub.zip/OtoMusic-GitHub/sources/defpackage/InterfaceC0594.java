package defpackage;

import java.util.List;
import javax.net.ssl.SSLSocket;

/* JADX INFO: renamed from: ο߯, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0594 {
    /* JADX INFO: renamed from: à */
    boolean mo1176a(SSLSocket sSLSocket);

    /* JADX INFO: renamed from: á */
    boolean mo1177a();

    /* JADX INFO: renamed from: â */
    String mo1178a(SSLSocket sSLSocket);

    /* JADX INFO: renamed from: ã */
    void mo1179a(SSLSocket sSLSocket, String str, List list);
}
