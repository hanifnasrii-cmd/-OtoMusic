package defpackage;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;

/* JADX INFO: renamed from: i݅, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC5263i extends AbstractC3810 implements InterfaceC5080i {

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public C6261p f7695a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public volatile C1918 f7697a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public boolean f7696a = false;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final Object f7698a = new Object();

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public boolean f7699a = false;

    /* JADX INFO: renamed from: a̪, reason: contains not printable characters */
    public final void m3936a() {
        if (this.f7695a == null) {
            this.f7695a = new C6261p(super.getContext(), this);
            this.f7696a = AbstractC2411.m8922a(super.getContext());
        }
    }

    @Override // defpackage.InterfaceC5080i
    public final Object generatedComponent() {
        if (this.f7697a == null) {
            synchronized (this.f7698a) {
                try {
                    if (this.f7697a == null) {
                        this.f7697a = new C1918(this);
                    }
                } finally {
                }
            }
        }
        return this.f7697a.generatedComponent();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final Context getContext() {
        if (super.getContext() == null && !this.f7696a) {
            return null;
        }
        m3936a();
        return this.f7695a;
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a, defpackage.InterfaceC5200i
    public final InterfaceC6282p getDefaultViewModelProviderFactory() {
        return AbstractC2411.m8914a(this, super.getDefaultViewModelProviderFactory());
    }

    public final void inject() {
        if (this.f7699a) {
            return;
        }
        this.f7699a = true;
        ((C3817) this).f23772a = (C5144i) ((C1114) ((InterfaceC3818) generatedComponent())).f14668a.f14690a.get();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onAttach(Context context) {
        super.onAttach(context);
        m3936a();
        inject();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final LayoutInflater onGetLayoutInflater(Bundle bundle) {
        LayoutInflater layoutInflater = getLayoutInflater(bundle);
        return layoutInflater.cloneInContext(new C6261p(layoutInflater, this));
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onAttach(Activity activity) {
        super.onAttach(activity);
        C6261p c6261p = this.f7695a;
        AbstractC4647c.m2662a(c6261p == null || C1918.m8300a(c6261p) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        m3936a();
        inject();
    }
}
