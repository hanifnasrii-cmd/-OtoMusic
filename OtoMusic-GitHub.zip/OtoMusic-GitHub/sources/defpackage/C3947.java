package defpackage;

import java.util.ArrayList;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Logger;

/* JADX INFO: renamed from: օⷧ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3947 {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final C3947 f24119a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final Logger f24120a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C3097 f24121a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public boolean f24123a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public long f24124a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f24122a = 10000;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final ArrayList f24125a = new ArrayList();

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final ArrayList f24126a = new ArrayList();

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final RunnableC4134a f24127a = new RunnableC4134a(13, this);

    static {
        String str = AbstractC6204p.f10910a + " TaskRunner";
        AbstractC3098.m10103a(str, "name");
        f24119a = new C3947(new C3097(new ThreadFactoryC6195p(str, true)));
        Logger logger = Logger.getLogger(C3947.class.getName());
        AbstractC3098.m10102a(logger, "getLogger(TaskRunner::class.java.name)");
        f24120a = logger;
    }

    public C3947(C3097 c3097) {
        this.f24121a = c3097;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final void m11104a(C3947 c3947, AbstractC3942 abstractC3942) {
        byte[] bArr = AbstractC6204p.f10905a;
        Thread threadCurrentThread = Thread.currentThread();
        String name = threadCurrentThread.getName();
        threadCurrentThread.setName(abstractC3942.f24106a);
        try {
            long jMo2845a = abstractC3942.mo2845a();
            synchronized (c3947) {
                c3947.m11105a(abstractC3942, jMo2845a);
            }
            threadCurrentThread.setName(name);
        } catch (Throwable th) {
            synchronized (c3947) {
                c3947.m11105a(abstractC3942, -1L);
                threadCurrentThread.setName(name);
                throw th;
            }
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m11105a(AbstractC3942 abstractC3942, long j) {
        byte[] bArr = AbstractC6204p.f10905a;
        C3946 c3946 = abstractC3942.f24108a;
        AbstractC3098.m10100a(c3946);
        if (c3946.f24116a != abstractC3942) {
            throw new IllegalStateException("Check failed.");
        }
        boolean z = c3946.f24118a;
        c3946.f24118a = false;
        c3946.f24116a = null;
        this.f24125a.remove(c3946);
        if (j != -1 && !z && !c3946.f24115a) {
            c3946.m11102a(abstractC3942, j, true);
        }
        if (c3946.f24117a.isEmpty()) {
            return;
        }
        this.f24126a.add(c3946);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final AbstractC3942 m11106a() {
        long j;
        AbstractC3942 abstractC3942;
        boolean z;
        byte[] bArr = AbstractC6204p.f10905a;
        while (true) {
            ArrayList arrayList = this.f24126a;
            if (arrayList.isEmpty()) {
                return null;
            }
            long jNanoTime = System.nanoTime();
            int size = arrayList.size();
            long jMin = Long.MAX_VALUE;
            int i = 0;
            AbstractC3942 abstractC39422 = null;
            while (true) {
                if (i >= size) {
                    j = jNanoTime;
                    abstractC3942 = null;
                    z = false;
                    break;
                }
                Object obj = arrayList.get(i);
                i++;
                AbstractC3942 abstractC39423 = (AbstractC3942) ((C3946) obj).f24117a.get(0);
                j = jNanoTime;
                abstractC3942 = null;
                long jMax = Math.max(0L, abstractC39423.f24109a - j);
                if (jMax > 0) {
                    jMin = Math.min(jMax, jMin);
                } else {
                    if (abstractC39422 != null) {
                        z = true;
                        break;
                    }
                    abstractC39422 = abstractC39423;
                }
                jNanoTime = j;
            }
            ArrayList arrayList2 = this.f24125a;
            if (abstractC39422 != null) {
                byte[] bArr2 = AbstractC6204p.f10905a;
                abstractC39422.f24109a = -1L;
                C3946 c3946 = abstractC39422.f24108a;
                AbstractC3098.m10100a(c3946);
                c3946.f24117a.remove(abstractC39422);
                arrayList.remove(c3946);
                c3946.f24116a = abstractC39422;
                arrayList2.add(c3946);
                if (z || (!this.f24123a && !arrayList.isEmpty())) {
                    RunnableC4134a runnableC4134a = this.f24127a;
                    AbstractC3098.m10103a(runnableC4134a, "runnable");
                    ((ThreadPoolExecutor) this.f24121a.f21718a).execute(runnableC4134a);
                }
                return abstractC39422;
            }
            if (this.f24123a) {
                if (jMin >= this.f24124a - j) {
                    return abstractC3942;
                }
                notify();
                return abstractC3942;
            }
            this.f24123a = true;
            this.f24124a = j + jMin;
            try {
                try {
                    long j2 = jMin / 1000000;
                    long j3 = jMin - (1000000 * j2);
                    if (j2 > 0 || jMin > 0) {
                        wait(j2, (int) j3);
                    }
                } catch (InterruptedException unused) {
                    for (int size2 = arrayList2.size() - 1; -1 < size2; size2--) {
                        ((C3946) arrayList2.get(size2)).m11100a();
                    }
                    for (int size3 = arrayList.size() - 1; -1 < size3; size3--) {
                        C3946 c39462 = (C3946) arrayList.get(size3);
                        c39462.m11100a();
                        if (c39462.f24117a.isEmpty()) {
                            arrayList.remove(size3);
                        }
                    }
                }
            } finally {
                this.f24123a = false;
            }
        }
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m11107a(C3946 c3946) {
        AbstractC3098.m10103a(c3946, "taskQueue");
        byte[] bArr = AbstractC6204p.f10905a;
        if (c3946.f24116a == null) {
            boolean zIsEmpty = c3946.f24117a.isEmpty();
            ArrayList arrayList = this.f24126a;
            if (zIsEmpty) {
                arrayList.remove(c3946);
            } else {
                AbstractC3098.m10103a(arrayList, "<this>");
                if (!arrayList.contains(c3946)) {
                    arrayList.add(c3946);
                }
            }
        }
        if (this.f24123a) {
            notify();
            return;
        }
        RunnableC4134a runnableC4134a = this.f24127a;
        AbstractC3098.m10103a(runnableC4134a, "runnable");
        ((ThreadPoolExecutor) this.f24121a.f21718a).execute(runnableC4134a);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C3946 m11108a() {
        int i;
        synchronized (this) {
            i = this.f24122a;
            this.f24122a = i + 1;
        }
        return new C3946(this, AbstractC4072a.m739a(i, "Q"));
    }
}
