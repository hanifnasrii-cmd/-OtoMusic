package defpackage;

import android.view.View;
import com.piyush.music.R;
import com.piyush.music.activities.main.MainActivityViewModel;
import com.piyush.music.widget.PlayButtonParent;

/* JADX INFO: renamed from: c͡, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ViewOnLongClickListenerC4458c implements View.OnLongClickListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f4849a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ Object f4850a;

    public /* synthetic */ ViewOnLongClickListenerC4458c(int i, Object obj) {
        this.f4849a = i;
        this.f4850a = obj;
    }

    @Override // android.view.View.OnLongClickListener
    public final boolean onLongClick(View view) {
        int i = this.f4849a;
        Object obj = this.f4850a;
        switch (i) {
            case 0:
                MainActivityViewModel mainActivityViewModel = (MainActivityViewModel) ((AbstractC4463c) obj).f4861a.getValue();
                C5763o c5763o = C5601j.f8884a;
                mainActivityViewModel.m1621a(C5601j.m4435a(), R.id.edit_lyrics);
                return true;
            default:
                int i2 = PlayButtonParent.f4045a;
                return ((PlayButtonParent) obj).performLongClick();
        }
    }
}
