package defpackage;

/* JADX INFO: renamed from: о߽, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2254 {
    public static final C2253 Companion = new C2253();

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f18796a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f18797a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f18798a;

    public C2254(String str, String str2, String str3) {
        this.f18796a = str;
        this.f18797a = str2;
        this.f18798a = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C2254)) {
            return false;
        }
        C2254 c2254 = (C2254) obj;
        return AbstractC3098.m10094a(this.f18796a, c2254.f18796a) && AbstractC3098.m10094a(this.f18797a, c2254.f18797a) && AbstractC3098.m10094a(this.f18798a, c2254.f18798a);
    }

    public final int hashCode() {
        String str = this.f18796a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f18797a;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f18798a;
        return iHashCode2 + (str3 != null ? str3.hashCode() : 0);
    }

    public final String toString() {
        return AbstractC4072a.m749a(AbstractC4072a.m753a("Scm(connection=", this.f18796a, ", developerConnection=", this.f18797a, ", url="), this.f18798a, ")");
    }
}
