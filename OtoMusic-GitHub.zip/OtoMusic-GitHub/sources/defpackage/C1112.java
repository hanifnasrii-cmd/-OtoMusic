package defpackage;

/* JADX INFO: renamed from: ϲ֓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1112 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ C1113 f14663a;

    public C1112(C1113 c1113) {
        this.f14663a = c1113;
    }
}
