package defpackage;

import android.content.Context;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

/* JADX INFO: renamed from: p⳯, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6306p extends RecyclerView {

    /* JADX INFO: renamed from: a͙, reason: contains not printable characters */
    public final /* synthetic */ ViewPager2 f11201a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C6306p(ViewPager2 viewPager2, Context context) {
        super(context, null);
        this.f11201a = viewPager2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.ViewGroup, android.view.View
    public final CharSequence getAccessibilityClassName() {
        this.f11201a.f877a.getClass();
        return super.getAccessibilityClassName();
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        ViewPager2 viewPager2 = this.f11201a;
        accessibilityEvent.setFromIndex(viewPager2.f861a);
        accessibilityEvent.setToIndex(viewPager2.f861a);
        accessibilityEvent.setSource((ViewPager2) viewPager2.f877a.f22983a);
        accessibilityEvent.setClassName("androidx.viewpager.widget.ViewPager");
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f11201a.f875a && super.onInterceptTouchEvent(motionEvent);
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        return this.f11201a.f875a && super.onTouchEvent(motionEvent);
    }
}
