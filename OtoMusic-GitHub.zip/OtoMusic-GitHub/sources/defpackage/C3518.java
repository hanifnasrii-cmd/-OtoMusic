package defpackage;

/* JADX INFO: renamed from: ј۟, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3518 {
    public final InterfaceC3193 serializer() {
        return C3517.f22873a;
    }
}
