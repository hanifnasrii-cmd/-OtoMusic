package defpackage;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* JADX INFO: renamed from: ϲⷮ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1306 implements InterfaceC6244p {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final NestedScrollView f15557a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C2683 f15558a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C2684 f15559a;

    public C1306(NestedScrollView nestedScrollView, C2683 c2683, C2684 c2684) {
        this.f15557a = nestedScrollView;
        this.f15558a = c2683;
        this.f15559a = c2684;
    }

    @Override // defpackage.InterfaceC6244p
    public final View getRoot() {
        return this.f15557a;
    }
}
