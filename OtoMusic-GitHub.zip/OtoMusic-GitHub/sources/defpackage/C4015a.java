package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import com.google.android.material.appbar.MaterialToolbar;
import com.piyush.music.R;
import com.piyush.music.widget.OtoAppBarLayout;

/* JADX INFO: renamed from: ă, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4015a extends AbstractC4014a {

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public static final C2416 f928a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public static final SparseIntArray f929a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final OtoAppBarLayout f930a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public boolean f931a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public long f932a;

    static {
        C2416 c2416 = new C2416(18);
        f928a = c2416;
        c2416.m8958a(3, new int[]{6}, new int[]{R.layout.ed}, new String[]{"item_support"});
        c2416.m8958a(4, new int[]{5}, new int[]{R.layout.ex}, new String[]{"layout_links"});
        SparseIntArray sparseIntArray = new SparseIntArray();
        f929a = sparseIntArray;
        sparseIntArray.put(R.id.toolbar, 7);
        sparseIntArray.put(R.id.icon, 8);
        sparseIntArray.put(R.id.app_name, 9);
        sparseIntArray.put(R.id.version, 10);
        sparseIntArray.put(R.id.icon_parent, 11);
        sparseIntArray.put(R.id.app_instagram, 12);
        sparseIntArray.put(R.id.app_discord, 13);
        sparseIntArray.put(R.id.card, 14);
        sparseIntArray.put(R.id.filePath, 15);
        sparseIntArray.put(R.id.i_made_it_old, 16);
        sparseIntArray.put(R.id.i_made_it_now, 17);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C4015a(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 18, f928a, f929a);
        FrameLayout frameLayout = (FrameLayout) objArrM5440a[13];
        FrameLayout frameLayout2 = (FrameLayout) objArrM5440a[12];
        AbstractC1588 abstractC1588 = (AbstractC1588) objArrM5440a[5];
        TextView textView = (TextView) objArrM5440a[16];
        NestedScrollView nestedScrollView = (NestedScrollView) objArrM5440a[2];
        AbstractC3834 abstractC3834 = (AbstractC3834) objArrM5440a[6];
        MaterialToolbar materialToolbar = (MaterialToolbar) objArrM5440a[7];
        super(null, view, frameLayout, frameLayout2, abstractC1588, textView, nestedScrollView, abstractC3834, materialToolbar);
        this.f932a = -1L;
        AbstractC1588 abstractC15882 = this.f923a;
        if (abstractC15882 != null) {
            abstractC15882.f11087a = this;
        }
        this.f925a.setTag(null);
        ((CoordinatorLayout) objArrM5440a[0]).setTag(null);
        OtoAppBarLayout otoAppBarLayout = (OtoAppBarLayout) objArrM5440a[1];
        this.f930a = otoAppBarLayout;
        otoAppBarLayout.setTag(null);
        ((LinearLayout) objArrM5440a[3]).setTag(null);
        ((LinearLayout) objArrM5440a[4]).setTag(null);
        AbstractC3834 abstractC38342 = this.f926a;
        if (abstractC38342 != null) {
            abstractC38342.f11087a = this;
        }
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱, reason: contains not printable characters */
    public final void mo665a() {
        long j;
        synchronized (this) {
            j = this.f932a;
            this.f932a = 0L;
        }
        long j2 = j & 4;
        if (j2 != 0) {
            AbstractC2179.m8620a(this.f925a, false, false, false, this.f931a, false, false, false, true);
            AbstractC2179.m8620a(this.f930a, false, this.f931a, false, false, false, true, false, false);
        }
        if (j2 != 0) {
            this.f931a = true;
        }
        this.f923a.m5442a();
        this.f926a.m5442a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴, reason: contains not printable characters */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                if (this.f932a != 0) {
                    return true;
                }
                return this.f923a.mo666a() || this.f926a.mo666a();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶, reason: contains not printable characters */
    public final void mo667a() {
        synchronized (this) {
            this.f932a = 4L;
        }
        this.f923a.mo667a();
        this.f926a.mo667a();
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺, reason: contains not printable characters */
    public final boolean mo668a(int i, Object obj) {
        if (i != 0) {
            return false;
        }
        synchronized (this) {
            this.f932a |= 1;
        }
        return true;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
