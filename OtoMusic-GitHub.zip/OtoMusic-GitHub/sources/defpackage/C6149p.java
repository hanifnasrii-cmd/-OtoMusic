package defpackage;

/* JADX INFO: renamed from: p֦, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C6149p extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public EnumC3419[] f10747a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C6150p f10748a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public InterfaceC6107p f10749a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int f10750a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f10751a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public int f10752a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public int f10753a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final /* synthetic */ EnumC3419[] f10754a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final /* synthetic */ C6150p f10755a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC6107p f10756a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C6149p(EnumC3419[] enumC3419Arr, C6150p c6150p, InterfaceC6107p interfaceC6107p, InterfaceC1005 interfaceC1005) {
        super(2, interfaceC1005);
        this.f10754a = enumC3419Arr;
        this.f10755a = c6150p;
        this.f10756a = interfaceC6107p;
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        return new C6149p(this.f10754a, this.f10755a, this.f10756a, interfaceC1005);
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        return ((C6149p) create((InterfaceC6105p) obj, (InterfaceC1005) obj2)).invokeSuspend(C6174p.f10843a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x0078, code lost:
    
        if (defpackage.C6150p.m5176a(r7, r6, r12, r11) == r0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x005d, code lost:
    
        r5 = r9;
     */
    /* JADX WARN: Removed duplicated region for block: B:11:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x007e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x007b -> B:27:0x007c). Please report as a decompilation issue!!! */
    @Override // defpackage.AbstractC4415c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r12) {
        /*
            r11 = this;
            ϲ̴ r0 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r1 = r11.f10753a
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L24
            if (r1 == r3) goto Lc
            if (r1 != r2) goto L1c
        Lc:
            int r1 = r11.f10752a
            int r4 = r11.f10751a
            int r5 = r11.f10750a
            p͠ r6 = r11.f10749a
            p֧ r7 = r11.f10748a
            јͭ[] r8 = r11.f10747a
            defpackage.AbstractC1149.m7200a(r12)
            goto L5d
        L1c:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r0)
            throw r12
        L24:
            defpackage.AbstractC1149.m7200a(r12)
            јͭ[] r12 = r11.f10754a
            int r1 = r12.length
            r4 = 0
            p֧ r5 = r11.f10755a
            p͠ r6 = r11.f10756a
            r8 = r12
            r12 = r4
            r7 = r5
        L32:
            if (r4 >= r1) goto L7e
            r5 = r8[r4]
            int r9 = r12 + 1
            int[] r10 = defpackage.AbstractC6148p.f10746a
            int r5 = r5.ordinal()
            r5 = r10[r5]
            if (r5 == r3) goto L7b
            if (r5 == r2) goto L66
            r10 = 3
            if (r5 != r10) goto L5f
            r11.f10747a = r8
            r11.f10748a = r7
            r11.f10749a = r6
            r11.f10750a = r9
            r11.f10751a = r4
            r11.f10752a = r1
            r11.f10753a = r2
            java.lang.Object r12 = defpackage.C6150p.m5177a(r7, r6, r12, r11)
            if (r12 != r0) goto L5c
            goto L7a
        L5c:
            r5 = r9
        L5d:
            r12 = r5
            goto L7c
        L5f:
            с݊ r12 = new с݊
            r0 = 0
            r12.<init>(r0)
            throw r12
        L66:
            r11.f10747a = r8
            r11.f10748a = r7
            r11.f10749a = r6
            r11.f10750a = r9
            r11.f10751a = r4
            r11.f10752a = r1
            r11.f10753a = r3
            java.lang.Object r12 = defpackage.C6150p.m5176a(r7, r6, r12, r11)
            if (r12 != r0) goto L5c
        L7a:
            return r0
        L7b:
            r12 = r9
        L7c:
            int r4 = r4 + r3
            goto L32
        L7e:
            pׁ r12 = defpackage.C6174p.f10843a
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C6149p.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
