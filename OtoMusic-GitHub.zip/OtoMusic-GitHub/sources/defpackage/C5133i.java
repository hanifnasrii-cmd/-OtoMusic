package defpackage;

import android.content.Context;
import com.piyush.music.R;
import com.piyush.music.glide.artist.ArtistImage;
import com.piyush.music.glide.artist.ArtistImageFetcher;
import com.piyush.music.glide.artist.ArtistSignatureUtil;
import com.piyush.music.models.Song;

/* JADX INFO: renamed from: i҃, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5133i {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C5084i f7171a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C5084i f7172a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static C4716e f7173a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final int f7174a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final int f7175a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final int f7176a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static boolean f7177a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static boolean f7178a;

    static {
        C5084i c5084i = new C5084i();
        c5084i.f10684a = C3377.f22507a;
        f7171a = c5084i;
        C5084i c5084i2 = new C5084i();
        c5084i2.f10684a = new C5853o(14);
        f7172a = c5084i2;
        f7173a = C4716e.f5804a;
        f7174a = R.drawable.uz;
        f7175a = R.drawable.m_;
        f7176a = R.drawable.m0;
        f7177a = true;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static C2104 m3648a(ComponentCallbacks2C2114 componentCallbacks2C2114, Song song, Integer num) {
        return m3651a(componentCallbacks2C2114.mo3663a(), song, song.getDateModified(), num, f7178a).mo3658a(new C4247a(song));
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static C2104 m3649a(ComponentCallbacks2C2114 componentCallbacks2C2114, String str, Context context, Song song, Integer num) {
        C2104 c2104 = (C2104) ((C2104) ((C2104) ((C2104) ((C2104) componentCallbacks2C2114.mo3663a().mo3661a(f7172a).mo2244a(C4766e.f5960a)).mo2260a(ArtistSignatureUtil.INSTANCE.getInstance(context).getArtistSignature(str))).mo2256a(EnumC5893o.LOW)).mo2264a(AbstractC2943.f21027a)).mo2243a(C4716e.f5805a);
        if (num != null) {
            c2104 = (C2104) c2104.mo2254a(num.intValue());
        }
        if (song == null) {
            song = C0623.f13664a;
        }
        return c2104.mo3658a(new ArtistImage(str, song)).mo2237a(C2118.m8568a(ArtistImageFetcher.INSTANCE.getIS_ALLOWED_TO_DOWNLOAD(), Boolean.valueOf(f7177a)));
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static C2104 m3650a(ComponentCallbacks2C2114 componentCallbacks2C2114, C5767o c5767o) {
        C2104 c2104Mo3661a = componentCallbacks2C2114.mo3663a().mo3661a(f7171a);
        C3511 c3511 = C5795o.f9600a;
        return (C2104) ((C2104) ((C2104) c2104Mo3661a.mo2237a(C2118.m8568a(AbstractC3085.m10052a(), Boolean.TRUE)).mo3658a(new C2839(c5767o.f9523a, c5767o.f9527a)).mo2260a(new C5477j(Long.parseLong(c5767o.f9526a)))).mo2254a(f7174a)).mo2243a(f7173a);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static C2104 m3651a(C2104 c2104, Song song, long j, Integer num, boolean z) {
        C2104 c2104Mo3658a = ((C2104) ((C2104) ((C2104) c2104.mo2243a(f7173a)).mo2244a(C4766e.f5960a)).mo2237a(C2118.m8568a(C1539.f16272a, Boolean.valueOf(z))).mo2260a(new C5477j(j))).mo3658a(song);
        return num == null ? c2104Mo3658a : (C2104) c2104Mo3658a.mo2254a(num.intValue());
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static C2104 m3652a(C2104 c2104, Song song) {
        return m3651a(c2104, song, song.getDateModified(), Integer.valueOf(f7174a), f7178a);
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static C2104 m3653a(ComponentCallbacks2C2114 componentCallbacks2C2114, Song song, Integer num, int i) {
        if ((i & 4) != 0) {
            num = Integer.valueOf(f7174a);
        }
        return m3651a(componentCallbacks2C2114.mo3663a(), song, song.getDateModified(), num, (i & 8) != 0 ? f7178a : true);
    }
}
