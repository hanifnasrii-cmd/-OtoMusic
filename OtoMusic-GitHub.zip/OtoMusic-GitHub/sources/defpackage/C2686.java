package defpackage;

import androidx.constraintlayout.widget.ConstraintLayout;

/* JADX INFO: renamed from: с̦, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2686 extends AbstractC2042 {

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final C1176 f20095a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final /* synthetic */ C5327i f20096a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2686(C5327i c5327i, C1176 c1176) {
        super((ConstraintLayout) c1176.f14958a);
        this.f20096a = c5327i;
        this.f20095a = c1176;
    }
}
