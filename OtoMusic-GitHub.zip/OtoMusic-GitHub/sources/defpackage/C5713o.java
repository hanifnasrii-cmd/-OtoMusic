package defpackage;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import com.piyush.music.R;

/* JADX INFO: renamed from: o̠, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5713o extends Drawable {

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public static final C2726 f9309a = new C2726(10, Float.TYPE, "progress");

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Path f9310a = new Path();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Path f9311a = new Path();

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Paint f9312a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final float f9313a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final float f9314a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final float f9315a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public float f9316a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public float f9317a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public float f9318a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public boolean f9319a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f9320a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public ObjectAnimator f9321a;

    public C5713o(Context context, boolean z) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(z ? Color.parseColor("#202124") : -1);
        this.f9312a = paint;
        Resources resources = context.getResources();
        this.f9313a = resources.getDimensionPixelSize(R.dimen.ami);
        this.f9314a = resources.getDimensionPixelSize(R.dimen.amh);
        this.f9315a = resources.getDimensionPixelSize(R.dimen.amg);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m4612a(boolean z, boolean z2) {
        if (z) {
            if (z2) {
                if (this.f9320a) {
                    m4613a();
                    return;
                }
                return;
            } else {
                this.f9320a = false;
                this.f9319a = false;
                this.f9318a = 0.0f;
                invalidateSelf();
                return;
            }
        }
        if (z2) {
            if (this.f9320a) {
                return;
            }
            m4613a();
        } else {
            this.f9320a = true;
            this.f9319a = true;
            this.f9318a = 1.0f;
            invalidateSelf();
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m4613a() {
        ObjectAnimator objectAnimator = this.f9321a;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        this.f9320a = !this.f9320a;
        boolean z = this.f9319a;
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, f9309a, z ? 1.0f : 0.0f, z ? 0.0f : 1.0f);
        objectAnimatorOfFloat.addListener(new C4112a(15, this));
        objectAnimatorOfFloat.setInterpolator(AbstractC0257.f12454a);
        objectAnimatorOfFloat.setDuration(350L);
        objectAnimatorOfFloat.start();
        this.f9321a = objectAnimatorOfFloat;
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) {
        Path path = this.f9310a;
        path.rewind();
        Path path2 = this.f9311a;
        path2.rewind();
        float f = this.f9318a;
        float f2 = this.f9315a;
        float fM734a = AbstractC4072a.m734a(0.0f, f2, f, f2);
        float f3 = this.f9314a;
        float f4 = this.f9313a;
        float fM8929a = (((f3 / 1.75f) - f4) * f) + f4;
        if (f == 1.0f) {
            fM8929a = AbstractC2411.m8929a(fM8929a);
        }
        float f5 = this.f9318a;
        float fM734a2 = AbstractC4072a.m734a(fM8929a, 0.0f, f5, 0.0f);
        float f6 = (fM8929a * 2.0f) + fM734a;
        float f7 = fM8929a + fM734a;
        float fM734a3 = AbstractC4072a.m734a(f7, f6, f5, f6);
        path.moveTo(0.0f, 0.0f);
        path.lineTo(fM734a2, -f3);
        path.lineTo(fM8929a, -f3);
        path.lineTo(fM8929a, 0.0f);
        path.close();
        path2.moveTo(f7, 0.0f);
        path2.lineTo(f7, -f3);
        path2.lineTo(fM734a3, -f3);
        path2.lineTo((2 * fM8929a) + fM734a, 0.0f);
        path2.close();
        int iSave = canvas.save();
        canvas.translate(AbstractC4072a.m734a(f3 / 8.0f, 0.0f, this.f9318a, 0.0f), 0.0f);
        boolean z = this.f9319a;
        float f8 = z ? 1.0f - this.f9318a : this.f9318a;
        float f9 = z ? 90.0f : 0.0f;
        canvas.rotate((((90.0f + f9) - f9) * f8) + f9, this.f9316a / 2.0f, this.f9317a / 2.0f);
        canvas.translate(AbstractC2411.m8929a((this.f9316a / 2.0f) - (f6 / 2.0f)), AbstractC2411.m8929a((f3 / 2.0f) + (this.f9317a / 2.0f)));
        Paint paint = this.f9312a;
        canvas.drawPath(path, paint);
        canvas.drawPath(path2, paint);
        canvas.restoreToCount(iSave);
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public final void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        if (rect.width() <= 0 || rect.height() <= 0) {
            return;
        }
        this.f9316a = rect.width();
        this.f9317a = rect.height();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        this.f9312a.setAlpha(i);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.f9312a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setTint(int i) {
        this.f9312a.setColor(i);
        invalidateSelf();
    }
}
