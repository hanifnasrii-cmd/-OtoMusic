package defpackage;

import java.util.List;

/* JADX INFO: renamed from: ι҇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0116 extends AbstractC3855 implements InterfaceC5056i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f11993a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f11994a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public /* synthetic */ InterfaceC1816 f11995a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public /* synthetic */ Object f11996a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ C5924o f11997a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ C3935 f11998a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0116(InterfaceC1005 interfaceC1005, C5924o c5924o, C3935 c3935, int i) {
        super(3, interfaceC1005);
        this.f11993a = i;
        this.f11997a = c5924o;
        this.f11998a = c3935;
    }

    @Override // defpackage.InterfaceC5056i
    /* JADX INFO: renamed from: á */
    public final Object mo2172a(Object obj, Object obj2, Object obj3) {
        InterfaceC1816 interfaceC1816 = (InterfaceC1816) obj;
        InterfaceC1005 interfaceC1005 = (InterfaceC1005) obj3;
        switch (this.f11993a) {
            case 0:
                C0116 c0116 = new C0116(interfaceC1005, this.f11997a, this.f11998a, 0);
                c0116.f11995a = interfaceC1816;
                c0116.f11996a = obj2;
                return c0116.invokeSuspend(C6174p.f10843a);
            default:
                C0116 c01162 = new C0116(interfaceC1005, this.f11997a, this.f11998a, 1);
                c01162.f11995a = interfaceC1816;
                c01162.f11996a = obj2;
                return c01162.invokeSuspend(C6174p.f10843a);
        }
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        InterfaceC1814 interfaceC1814M7202a;
        InterfaceC1814 interfaceC1814M7175a;
        int i = this.f11993a;
        C6174p c6174p = C6174p.f10843a;
        InterfaceC1005 interfaceC1005 = null;
        C3935 c3935 = this.f11998a;
        C5924o c5924o = this.f11997a;
        int i2 = 2;
        int i3 = 1;
        switch (i) {
            case 0:
                EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                int i4 = this.f11994a;
                if (i4 != 0) {
                    if (i4 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC1149.m7200a(obj);
                    return c6174p;
                }
                AbstractC1149.m7200a(obj);
                InterfaceC1816 interfaceC1816 = this.f11995a;
                List list = (List) this.f11996a;
                if (list.isEmpty()) {
                    C4521c c4521c = new C4521c(new C4567c(26, interfaceC1005, (C5141i) c5924o.f9990a, c3935));
                    C1221 c1221 = AbstractC4734e.f5894a;
                    interfaceC1814M7202a = AbstractC1149.m7202a(AbstractC1149.m7175a(c4521c, ExecutorC1197.f15088a), new C0116(interfaceC1005, c5924o, c3935, i3));
                } else {
                    interfaceC1814M7202a = new C1616(i2, list);
                }
                this.f11994a = 1;
                return AbstractC1149.m7171a(interfaceC1816, interfaceC1814M7202a, this) == enumC1045 ? enumC1045 : c6174p;
            default:
                EnumC1045 enumC10452 = EnumC1045.COROUTINE_SUSPENDED;
                int i5 = this.f11994a;
                if (i5 != 0) {
                    if (i5 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC1149.m7200a(obj);
                    return c6174p;
                }
                AbstractC1149.m7200a(obj);
                InterfaceC1816 interfaceC18162 = this.f11995a;
                List list2 = (List) this.f11996a;
                if (list2.isEmpty()) {
                    C4521c c4521c2 = new C4521c(new C2289((C4929e) c5924o.f9991a, c3935, null));
                    C1221 c12212 = AbstractC4734e.f5894a;
                    interfaceC1814M7175a = AbstractC1149.m7175a(c4521c2, ExecutorC1197.f15088a);
                } else {
                    interfaceC1814M7175a = new C1616(i2, list2);
                }
                this.f11994a = 1;
                return AbstractC1149.m7171a(interfaceC18162, interfaceC1814M7175a, this) == enumC10452 ? enumC10452 : c6174p;
        }
    }
}
