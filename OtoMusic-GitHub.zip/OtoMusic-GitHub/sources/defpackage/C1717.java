package defpackage;

import android.R;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

/* JADX INFO: renamed from: е̾, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1717 extends AbstractC2022 implements InterfaceC2028 {

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public static final int[] f16851a = {R.attr.state_pressed};

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public static final int[] f16852a = new int[0];

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f16853a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f16854a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final StateListDrawable f16855a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Drawable f16856a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f16857a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f16858a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final StateListDrawable f16859a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final Drawable f16860a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final int f16861a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final int f16862a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public int f16863a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public int f16864a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public float f16865a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f16866a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f16867a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public float f16868a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final RecyclerView f16871a;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final ValueAnimator f16878a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public int f16879a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final RunnableC1358 f16880a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public int f16869a = 0;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public int f16870a = 0;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public boolean f16872a = false;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public boolean f16873a = false;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public int f16874a = 0;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public int f16875a = 0;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final int[] f16876a = new int[2];

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public final int[] f16877a = new int[2];

    public C1717(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i, int i2, int i3) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f16878a = valueAnimatorOfFloat;
        this.f16879a = 0;
        RunnableC1358 runnableC1358 = new RunnableC1358(7, this);
        this.f16880a = runnableC1358;
        C4443c c4443c = new C4443c(1, this);
        this.f16855a = stateListDrawable;
        this.f16856a = drawable;
        this.f16859a = stateListDrawable2;
        this.f16860a = drawable2;
        this.f16857a = Math.max(i, stateListDrawable.getIntrinsicWidth());
        this.f16858a = Math.max(i, drawable.getIntrinsicWidth());
        this.f16861a = Math.max(i, stateListDrawable2.getIntrinsicWidth());
        this.f16862a = Math.max(i, drawable2.getIntrinsicWidth());
        this.f16853a = i2;
        this.f16854a = i3;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        valueAnimatorOfFloat.addListener(new C1691(this));
        valueAnimatorOfFloat.addUpdateListener(new C2844(1, this));
        RecyclerView recyclerView2 = this.f16871a;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            recyclerView2.m542a(this);
            RecyclerView recyclerView3 = this.f16871a;
            recyclerView3.f755a.remove(this);
            if (recyclerView3.f756a == this) {
                recyclerView3.f756a = null;
            }
            ArrayList arrayList = this.f16871a.f797a;
            if (arrayList != null) {
                arrayList.remove(c4443c);
            }
            this.f16871a.removeCallbacks(runnableC1358);
        }
        this.f16871a = recyclerView;
        recyclerView.m494a(this);
        this.f16871a.f755a.add(this);
        this.f16871a.m496a(c4443c);
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static int m8110a(float f, float f2, int[] iArr, int i, int i2, int i3) {
        int i4 = iArr[1] - iArr[0];
        if (i4 != 0) {
            int i5 = i - i3;
            int i6 = (int) (((f2 - f) / i4) * i5);
            int i7 = i2 + i6;
            if (i7 < i5 && i7 >= 0) {
                return i6;
            }
        }
        return 0;
    }

    @Override // defpackage.InterfaceC2028
    /* JADX INFO: renamed from: á */
    public final void mo8107a(MotionEvent motionEvent) {
        if (this.f16874a == 0) {
            return;
        }
        if (motionEvent.getAction() == 0) {
            boolean zM8113a = m8113a(motionEvent.getX(), motionEvent.getY());
            boolean zM8112a = m8112a(motionEvent.getX(), motionEvent.getY());
            if (zM8113a || zM8112a) {
                if (zM8112a) {
                    this.f16875a = 1;
                    this.f16868a = (int) motionEvent.getX();
                } else if (zM8113a) {
                    this.f16875a = 2;
                    this.f16865a = (int) motionEvent.getY();
                }
                m8114a(2);
                return;
            }
            return;
        }
        if (motionEvent.getAction() == 1 && this.f16874a == 2) {
            this.f16865a = 0.0f;
            this.f16868a = 0.0f;
            m8114a(1);
            this.f16875a = 0;
            return;
        }
        if (motionEvent.getAction() == 2 && this.f16874a == 2) {
            m8115a();
            int i = this.f16875a;
            int i2 = this.f16854a;
            if (i == 1) {
                float x = motionEvent.getX();
                int[] iArr = this.f16877a;
                iArr[0] = i2;
                int i3 = this.f16869a - i2;
                iArr[1] = i3;
                float fMax = Math.max(i2, Math.min(i3, x));
                if (Math.abs(this.f16867a - fMax) >= 2.0f) {
                    int iM8110a = m8110a(this.f16868a, fMax, iArr, this.f16871a.computeHorizontalScrollRange(), this.f16871a.computeHorizontalScrollOffset(), this.f16869a);
                    if (iM8110a != 0) {
                        this.f16871a.scrollBy(iM8110a, 0);
                    }
                    this.f16868a = fMax;
                }
            }
            if (this.f16875a == 2) {
                float y = motionEvent.getY();
                int[] iArr2 = this.f16876a;
                iArr2[0] = i2;
                int i4 = this.f16870a - i2;
                iArr2[1] = i4;
                float fMax2 = Math.max(i2, Math.min(i4, y));
                if (Math.abs(this.f16864a - fMax2) < 2.0f) {
                    return;
                }
                int iM8110a2 = m8110a(this.f16865a, fMax2, iArr2, this.f16871a.computeVerticalScrollRange(), this.f16871a.computeVerticalScrollOffset(), this.f16870a);
                if (iM8110a2 != 0) {
                    this.f16871a.scrollBy(0, iM8110a2);
                }
                this.f16865a = fMax2;
            }
        }
    }

    @Override // defpackage.InterfaceC2028
    /* JADX INFO: renamed from: â */
    public final boolean mo8108a(MotionEvent motionEvent) {
        int i = this.f16874a;
        if (i != 1) {
            return i == 2;
        }
        boolean zM8113a = m8113a(motionEvent.getX(), motionEvent.getY());
        boolean zM8112a = m8112a(motionEvent.getX(), motionEvent.getY());
        if (motionEvent.getAction() != 0) {
            return false;
        }
        if (!zM8113a && !zM8112a) {
            return false;
        }
        if (zM8112a) {
            this.f16875a = 1;
            this.f16868a = (int) motionEvent.getX();
        } else if (zM8113a) {
            this.f16875a = 2;
            this.f16865a = (int) motionEvent.getY();
        }
        m8114a(2);
        return true;
    }

    @Override // defpackage.InterfaceC2028
    /* JADX INFO: renamed from: ā */
    public final void mo8109a(boolean z) {
    }

    @Override // defpackage.AbstractC2022
    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void mo8111a(Canvas canvas, RecyclerView recyclerView) {
        if (this.f16869a != this.f16871a.getWidth() || this.f16870a != this.f16871a.getHeight()) {
            this.f16869a = this.f16871a.getWidth();
            this.f16870a = this.f16871a.getHeight();
            m8114a(0);
            return;
        }
        if (this.f16879a != 0) {
            if (this.f16872a) {
                int i = this.f16869a;
                int i2 = this.f16857a;
                int i3 = i - i2;
                int i4 = this.f16864a;
                int i5 = this.f16863a;
                int i6 = i4 - (i5 / 2);
                StateListDrawable stateListDrawable = this.f16855a;
                stateListDrawable.setBounds(0, 0, i2, i5);
                int i7 = this.f16858a;
                int i8 = this.f16870a;
                Drawable drawable = this.f16856a;
                drawable.setBounds(0, 0, i7, i8);
                if (this.f16871a.getLayoutDirection() == 1) {
                    drawable.draw(canvas);
                    canvas.translate(i2, i6);
                    canvas.scale(-1.0f, 1.0f);
                    stateListDrawable.draw(canvas);
                    canvas.scale(-1.0f, 1.0f);
                    canvas.translate(-i2, -i6);
                } else {
                    canvas.translate(i3, 0.0f);
                    drawable.draw(canvas);
                    canvas.translate(0.0f, i6);
                    stateListDrawable.draw(canvas);
                    canvas.translate(-i3, -i6);
                }
            }
            if (this.f16873a) {
                int i9 = this.f16870a;
                int i10 = this.f16861a;
                int i11 = i9 - i10;
                int i12 = this.f16867a;
                int i13 = this.f16866a;
                int i14 = i12 - (i13 / 2);
                StateListDrawable stateListDrawable2 = this.f16859a;
                stateListDrawable2.setBounds(0, 0, i13, i10);
                int i15 = this.f16869a;
                int i16 = this.f16862a;
                Drawable drawable2 = this.f16860a;
                drawable2.setBounds(0, 0, i15, i16);
                canvas.translate(0.0f, i11);
                drawable2.draw(canvas);
                canvas.translate(i14, 0.0f);
                stateListDrawable2.draw(canvas);
                canvas.translate(-i14, -i11);
            }
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final boolean m8112a(float f, float f2) {
        if (f2 < this.f16870a - this.f16861a) {
            return false;
        }
        int i = this.f16867a;
        int i2 = this.f16866a;
        return f >= ((float) (i - (i2 / 2))) && f <= ((float) ((i2 / 2) + i));
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final boolean m8113a(float f, float f2) {
        int layoutDirection = this.f16871a.getLayoutDirection();
        int i = this.f16857a;
        if (layoutDirection == 1) {
            if (f > i) {
                return false;
            }
        } else if (f < this.f16869a - i) {
            return false;
        }
        int i2 = this.f16864a;
        int i3 = this.f16863a / 2;
        return f2 >= ((float) (i2 - i3)) && f2 <= ((float) (i3 + i2));
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m8114a(int i) {
        RunnableC1358 runnableC1358 = this.f16880a;
        StateListDrawable stateListDrawable = this.f16855a;
        if (i == 2 && this.f16874a != 2) {
            stateListDrawable.setState(f16851a);
            this.f16871a.removeCallbacks(runnableC1358);
        }
        if (i == 0) {
            this.f16871a.invalidate();
        } else {
            m8115a();
        }
        if (this.f16874a == 2 && i != 2) {
            stateListDrawable.setState(f16852a);
            this.f16871a.removeCallbacks(runnableC1358);
            this.f16871a.postDelayed(runnableC1358, 1200);
        } else if (i == 1) {
            this.f16871a.removeCallbacks(runnableC1358);
            this.f16871a.postDelayed(runnableC1358, 1500);
        }
        this.f16874a = i;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final void m8115a() {
        int i = this.f16879a;
        ValueAnimator valueAnimator = this.f16878a;
        if (i != 0) {
            if (i != 3) {
                return;
            } else {
                valueAnimator.cancel();
            }
        }
        this.f16879a = 1;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        valueAnimator.setDuration(500L);
        valueAnimator.setStartDelay(0L);
        valueAnimator.start();
    }
}
