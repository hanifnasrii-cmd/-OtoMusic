package defpackage;

import java.lang.reflect.Method;
import java.util.Objects;

/* JADX INFO: renamed from: ј߫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3569 extends AbstractC3478 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Method f23020a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f23021a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final String f23022a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C4648c f23023a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final boolean f23024a;

    public C3569(Method method, int i, String str, boolean z) {
        C4648c c4648c = C4648c.f5546a;
        this.f23020a = method;
        this.f23021a = i;
        Objects.requireNonNull(str, "name == null");
        this.f23022a = str;
        this.f23023a = c4648c;
        this.f23024a = z;
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x00fb  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00fe  */
    @Override // defpackage.AbstractC3478
    /* JADX INFO: renamed from: á */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void mo10647a(defpackage.C2103 r23, java.lang.Object r24) {
        /*
            Method dump skipped, instruction units count: 291
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C3569.mo10647a(о֑, java.lang.Object):void");
    }
}
