package defpackage;

import android.widget.ImageButton;

/* JADX INFO: renamed from: р́, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2318 extends ImageButton {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f19015a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m8738a(int i, boolean z) {
        super.setVisibility(i);
        if (z) {
            this.f19015a = i;
        }
    }

    public final int getUserSetVisibility() {
        return this.f19015a;
    }

    @Override // android.widget.ImageView, android.view.View
    public void setVisibility(int i) {
        m8738a(i, true);
    }
}
