package defpackage;

import com.piyush.music.database.Database;

/* JADX INFO: renamed from: o͛, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5772o extends AbstractC1502 {

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final /* synthetic */ int f9536a = 0;

    @Override // defpackage.AbstractC1502
    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final String mo4711a(String str) {
        return AbstractC4072a.m746a(str, ".artwork");
    }

    @Override // defpackage.AbstractC1502
    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final String mo4712a() {
        return "/custom_playlist_images/";
    }

    @Override // defpackage.AbstractC1502
    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final void mo4713a(String str, String str2) {
        AbstractC1502.f16117a.m3032a(str);
        Database.f2961a.m3031a(this.f16121a).mo1659a().m4719a(Integer.parseInt(str2));
    }
}
