package defpackage;

/* JADX INFO: renamed from: с߳, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2915 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public boolean f20954a;

    public final boolean equals(Object obj) {
        if (this != obj) {
            return (obj instanceof C2915) && this.f20954a == ((C2915) obj).f20954a;
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    public final int hashCode() {
        boolean z = this.f20954a;
        ?? r0 = z;
        if (z) {
            r0 = 1;
        }
        return (((((((r0 * 31) + ((int) 2000)) * 31) + 1) * 31) + 1) * 31) + ((int) 0);
    }

    public final String toString() {
        return "ConfettiConfig(fadeOut=" + this.f20954a + ", timeToLive=2000, rotate=true, accelerate=true, delay=0)";
    }
}
