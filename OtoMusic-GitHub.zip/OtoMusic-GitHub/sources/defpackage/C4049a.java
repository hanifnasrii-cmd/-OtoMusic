package defpackage;

import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: renamed from: ą, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4049a extends AbstractC4050a implements RandomAccess {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final AbstractC4050a f1007a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f1008a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f1009a;

    public C4049a(AbstractC4050a abstractC4050a, int i, int i2) {
        this.f1007a = abstractC4050a;
        this.f1008a = i;
        AbstractC3098.m10105a(i, i2, abstractC4050a.mo684a());
        this.f1009a = i2 - i;
    }

    @Override // defpackage.AbstractC4033a
    /* JADX INFO: renamed from: ã */
    public final int mo684a() {
        return this.f1009a;
    }

    @Override // java.util.List
    public final Object get(int i) {
        int i2 = this.f1009a;
        if (i < 0 || i >= i2) {
            throw new IndexOutOfBoundsException(AbstractC4072a.m743a("index: ", i, ", size: ", i2));
        }
        return this.f1007a.get(this.f1008a + i);
    }

    @Override // defpackage.AbstractC4050a, java.util.List
    public final List subList(int i, int i2) {
        AbstractC3098.m10105a(i, i2, this.f1009a);
        int i3 = this.f1008a;
        return new C4049a(this.f1007a, i + i3, i3 + i2);
    }
}
