package defpackage;

/* JADX INFO: renamed from: р͇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC2388 {
}
