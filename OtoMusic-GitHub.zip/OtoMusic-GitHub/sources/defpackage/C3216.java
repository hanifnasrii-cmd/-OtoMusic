package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Pattern;

/* JADX INFO: renamed from: і݀, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3216 extends AbstractC4080a {
    public static final Parcelable.Creator<C3216> CREATOR = new C2492(8);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final boolean f22047a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final String f22048a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final boolean f22049a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C1071 f22050a;

    public C3216(boolean z, String str, boolean z2, C1071 c1071) {
        this.f22047a = z;
        this.f22048a = str;
        this.f22049a = z2;
        this.f22050a = c1071;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C3216)) {
            return false;
        }
        C3216 c3216 = (C3216) obj;
        return this.f22047a == c3216.f22047a && AbstractC2711.m9452a(this.f22048a, c3216.f22048a) && this.f22049a == c3216.f22049a && AbstractC2711.m9452a(this.f22050a, c3216.f22050a);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Boolean.valueOf(this.f22047a), this.f22048a, Boolean.valueOf(this.f22049a), this.f22050a});
    }

    public final String toString() {
        return "LaunchOptions(relaunchIfRunning=" + this.f22047a + ", language=" + this.f22048a + ", androidReceiverCompatible: " + this.f22049a + ")";
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int iM7217a = AbstractC1149.m7217a(parcel, 20293);
        AbstractC1149.m7216a(parcel, 2, 4);
        parcel.writeInt(this.f22047a ? 1 : 0);
        AbstractC1149.m7212a(parcel, 3, this.f22048a);
        AbstractC1149.m7216a(parcel, 4, 4);
        parcel.writeInt(this.f22049a ? 1 : 0);
        AbstractC1149.m7211a(parcel, 5, this.f22050a, i);
        AbstractC1149.m7219a(parcel, iM7217a);
    }

    public C3216() {
        Locale locale = Locale.getDefault();
        Pattern pattern = AbstractC2711.f20225a;
        StringBuilder sb = new StringBuilder(20);
        sb.append(locale.getLanguage());
        String country = locale.getCountry();
        if (!TextUtils.isEmpty(country)) {
            sb.append('-');
            sb.append(country);
        }
        String variant = locale.getVariant();
        if (!TextUtils.isEmpty(variant)) {
            sb.append('-');
            sb.append(variant);
        }
        this(false, sb.toString(), false, null);
    }
}
