package defpackage;

/* JADX INFO: renamed from: pܰ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC6232p {
}
