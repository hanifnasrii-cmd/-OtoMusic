package defpackage;

/* JADX INFO: renamed from: оⷤ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2289 extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f18929a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public /* synthetic */ Object f18930a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C4929e f18931a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ C3935 f18932a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2289(C4929e c4929e, C3935 c3935, InterfaceC1005 interfaceC1005) {
        super(2, interfaceC1005);
        this.f18931a = c4929e;
        this.f18932a = c3935;
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        C2289 c2289 = new C2289(this.f18931a, this.f18932a, interfaceC1005);
        c2289.f18930a = obj;
        return c2289;
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        return ((C2289) create((InterfaceC1816) obj, (InterfaceC1005) obj2)).invokeSuspend(C6174p.f10843a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:38:0x00b9, code lost:
    
        if (r2.mo674a(r6, r23) == r1) goto L39;
     */
    @Override // defpackage.AbstractC4415c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r24) {
        /*
            r23 = this;
            r0 = r23
            ϲ̴ r1 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r2 = r0.f18929a
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L25
            if (r2 == r4) goto L1b
            if (r2 != r3) goto L13
            defpackage.AbstractC1149.m7200a(r24)
            goto Lbc
        L13:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r1.<init>(r2)
            throw r1
        L1b:
            java.lang.Object r2 = r0.f18930a
            еֽ r2 = (defpackage.InterfaceC1816) r2
            defpackage.AbstractC1149.m7200a(r24)
            r4 = r24
            goto L42
        L25:
            defpackage.AbstractC1149.m7200a(r24)
            java.lang.Object r2 = r0.f18930a
            еֽ r2 = (defpackage.InterfaceC1816) r2
            e݁ r5 = r0.f18931a
            іܾ r5 = r5.f6449a
            օ⃰ r6 = r0.f18932a
            java.lang.String r7 = r6.f24083a
            java.lang.String r6 = r6.f24082a
            r0.f18930a = r2
            r0.f18929a = r4
            java.lang.Object r4 = r5.m10314a(r7, r6, r0)
            if (r4 != r1) goto L42
            goto Lbb
        L42:
            com.piyush.music.rest.lastfm.models.LastFmTrackSearch r4 = (com.piyush.music.rest.lastfm.models.LastFmTrackSearch) r4
            com.piyush.music.rest.lastfm.models.LastFmTrackSearch$Results r4 = r4.getResults()
            r5 = 0
            if (r4 == 0) goto L56
            com.piyush.music.rest.lastfm.models.LastFmTrackSearch$TrackMatches r4 = r4.getTrackmatches()
            if (r4 == 0) goto L56
            java.util.List r4 = r4.getTrack()
            goto L57
        L56:
            r4 = r5
        L57:
            if (r4 != 0) goto L5b
            eٰ r4 = defpackage.C4891e.f6320a
        L5b:
            java.lang.Iterable r4 = (java.lang.Iterable) r4
            java.util.ArrayList r6 = new java.util.ArrayList
            r7 = 10
            int r7 = defpackage.AbstractC2853.m9682a(r4, r7)
            r6.<init>(r7)
            java.util.Iterator r4 = r4.iterator()
        L6c:
            boolean r7 = r4.hasNext()
            if (r7 == 0) goto Lb1
            java.lang.Object r7 = r4.next()
            com.piyush.music.rest.lastfm.models.LastFmTrackSearch$Track r7 = (com.piyush.music.rest.lastfm.models.LastFmTrackSearch.Track) r7
            java.lang.String r8 = r7.getName()
            java.lang.String r9 = ""
            if (r8 != 0) goto L82
            r11 = r9
            goto L83
        L82:
            r11 = r8
        L83:
            java.lang.String r8 = r7.getArtist()
            if (r8 != 0) goto L8b
            r12 = r9
            goto L8c
        L8b:
            r12 = r8
        L8c:
            օ⃯ r10 = new օ⃯
            java.lang.String r7 = r7.getMbid()
            if (r7 != 0) goto L97
            r18 = r9
            goto L99
        L97:
            r18 = r7
        L99:
            օ⳯ r21 = defpackage.EnumC3936.LASTFM
            r22 = 1792(0x700, float:2.511E-42)
            java.lang.String r14 = ""
            java.lang.String r15 = ""
            java.lang.String r16 = ""
            java.lang.String r17 = ""
            r19 = 0
            r20 = 0
            r13 = r12
            r10.<init>(r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            r6.add(r10)
            goto L6c
        Lb1:
            r0.f18930a = r5
            r0.f18929a = r3
            java.lang.Object r2 = r2.mo674a(r6, r0)
            if (r2 != r1) goto Lbc
        Lbb:
            return r1
        Lbc:
            pׁ r1 = defpackage.C6174p.f10843a
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2289.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
