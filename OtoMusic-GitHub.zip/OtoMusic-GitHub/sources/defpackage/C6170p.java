package defpackage;

/* JADX INFO: renamed from: pֻ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C6170p extends AbstractC1033 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final /* synthetic */ int f10836a = 0;

    static {
        new C6170p();
    }

    @Override // defpackage.AbstractC1033
    /* JADX INFO: renamed from: a̿ */
    public final void mo3151a(InterfaceC1031 interfaceC1031, Runnable runnable) {
        C2445 c2445 = (C2445) interfaceC1031.get(C2445.f19456a);
        if (c2445 == null) {
            throw new UnsupportedOperationException("Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.");
        }
        c2445.f19457a = true;
    }

    @Override // defpackage.AbstractC1033
    public final String toString() {
        return "Dispatchers.Unconfined";
    }
}
