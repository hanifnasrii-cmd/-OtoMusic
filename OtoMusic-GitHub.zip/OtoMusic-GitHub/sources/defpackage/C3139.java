package defpackage;

import java.util.NoSuchElementException;

/* JADX INFO: renamed from: іּ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3139 extends AbstractC6179p {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Object f21900a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f21901a;

    public C3139(Object obj) {
        this.f21900a = obj;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return !this.f21901a;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f21901a) {
            throw new NoSuchElementException();
        }
        this.f21901a = true;
        return this.f21900a;
    }
}
