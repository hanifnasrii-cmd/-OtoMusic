package defpackage;

import android.R;

/* JADX INFO: renamed from: oⷱ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC5997o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final int[] f10255a = {R.attr.id, com.piyush.music.R.attr.l5, com.piyush.music.R.attr.nd, com.piyush.music.R.attr.nq, com.piyush.music.R.attr.uz, com.piyush.music.R.attr.a3v, com.piyush.music.R.attr.a3w, com.piyush.music.R.attr.a3x, com.piyush.music.R.attr.a3y, com.piyush.music.R.attr.a3z, com.piyush.music.R.attr.a5a};

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final int[] f10256a = {R.attr.name, R.attr.defaultValue, com.piyush.music.R.attr.b8, com.piyush.music.R.attr.a2e};

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final int[] f10257a = {R.attr.autoVerify, com.piyush.music.R.attr.c, com.piyush.music.R.attr.a07, com.piyush.music.R.attr.af0};

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final int[] f10258a = {com.piyush.music.R.attr.a8r};

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final int[] f10259a = {R.attr.label, R.attr.id, com.piyush.music.R.attr.a5g};
}
