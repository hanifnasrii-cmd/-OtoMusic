package defpackage;

/* JADX INFO: renamed from: ρ⳱, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0959 extends AbstractC6386s {
    private static final C0959 zzg;
    private int zzb;
    private int zzd;
    private int zze;
    private int zzf;

    static {
        C0959 c0959 = new C0959();
        zzg = c0959;
        AbstractC6386s.m5619a(C0959.class, c0959);
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzg, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001င\u0000\u0002င\u0001\u0003င\u0002", new Object[]{"zzb", "zzd", "zze", "zzf"});
        }
        if (i2 == 3) {
            return new C0959();
        }
        if (i2 == 4) {
            return new C0940(zzg);
        }
        if (i2 == 5) {
            return zzg;
        }
        throw null;
    }
}
