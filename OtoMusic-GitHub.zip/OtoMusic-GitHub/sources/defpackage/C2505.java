package defpackage;

/* JADX INFO: renamed from: рٔ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2505 extends Exception {
}
