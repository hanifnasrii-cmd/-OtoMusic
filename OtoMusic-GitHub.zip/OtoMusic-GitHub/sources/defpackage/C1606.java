package defpackage;

/* JADX INFO: renamed from: а⃡, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1606 extends AbstractC4372c {

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final C1606 f16531a = new C1606();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1606);
    }

    public final int hashCode() {
        return -1437676026;
    }

    public final String toString() {
        return "Empty";
    }
}
