package defpackage;

/* JADX INFO: renamed from: ρⷴ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0981 extends AbstractC6385s {
}
