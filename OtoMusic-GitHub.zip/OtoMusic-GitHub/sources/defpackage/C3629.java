package defpackage;

/* JADX INFO: renamed from: јⷴ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3629 implements InterfaceC3633 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f23179a;

    public C3629(String str) {
        this.f23179a = str;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String m10834a() {
        return this.f23179a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C3629) && AbstractC3098.m10094a(this.f23179a, ((C3629) obj).f23179a);
    }

    public final int hashCode() {
        return this.f23179a.hashCode();
    }

    public final String toString() {
        return AbstractC4072a.m760a("Folder(path=", this.f23179a, ")");
    }
}
