package defpackage;

import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.security.auth.x500.X500Principal;

/* JADX INFO: renamed from: c֤, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4497c implements InterfaceC6153p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final LinkedHashMap f5072a;

    public C4497c(X509Certificate... x509CertificateArr) {
        AbstractC3098.m10103a(x509CertificateArr, "caCerts");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (X509Certificate x509Certificate : x509CertificateArr) {
            X500Principal subjectX500Principal = x509Certificate.getSubjectX500Principal();
            AbstractC3098.m10102a(subjectX500Principal, "caCert.subjectX500Principal");
            Object linkedHashSet = linkedHashMap.get(subjectX500Principal);
            if (linkedHashSet == null) {
                linkedHashSet = new LinkedHashSet();
                linkedHashMap.put(subjectX500Principal, linkedHashSet);
            }
            ((Set) linkedHashSet).add(x509Certificate);
        }
        this.f5072a = linkedHashMap;
    }

    @Override // defpackage.InterfaceC6153p
    /* JADX INFO: renamed from: à */
    public final X509Certificate mo1187a(X509Certificate x509Certificate) {
        Set set = (Set) this.f5072a.get(x509Certificate.getIssuerX500Principal());
        Object obj = null;
        if (set == null) {
            return null;
        }
        Iterator it = set.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            try {
                x509Certificate.verify(((X509Certificate) next).getPublicKey());
                obj = next;
                break;
            } catch (Exception unused) {
            }
        }
        return (X509Certificate) obj;
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            return (obj instanceof C4497c) && AbstractC3098.m10094a(((C4497c) obj).f5072a, this.f5072a);
        }
        return true;
    }

    public final int hashCode() {
        return this.f5072a.hashCode();
    }
}
