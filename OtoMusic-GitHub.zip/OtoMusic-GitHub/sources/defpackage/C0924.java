package defpackage;

/* JADX INFO: renamed from: ρ߮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0924 extends AbstractC6386s {
    private static final C0924 zzg;
    private int zzb;
    private int zzd = 0;
    private Object zze;
    private long zzf;

    static {
        C0924 c0924 = new C0924();
        zzg = c0924;
        AbstractC6386s.m5619a(C0924.class, c0924);
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzg, "\u0001\u0004\u0001\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001စ\u0000\u0002:\u0000\u00035\u0000\u00048\u0000", new Object[]{"zze", "zzd", "zzb", "zzf"});
        }
        if (i2 == 3) {
            return new C0924();
        }
        if (i2 == 4) {
            return new C2507(zzg);
        }
        if (i2 == 5) {
            return zzg;
        }
        throw null;
    }
}
