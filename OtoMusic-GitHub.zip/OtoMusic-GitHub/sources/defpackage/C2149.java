package defpackage;

/* JADX INFO: renamed from: оׁ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2149 extends AbstractC2154 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C2149 f18530a = new C2149();
}
