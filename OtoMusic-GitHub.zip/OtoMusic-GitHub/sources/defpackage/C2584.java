package defpackage;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: renamed from: р߳, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2584 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f19764a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f19765a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final BinderC2595 f19766a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C2693 f19767a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final BinderC2613 f19768a;

    public C2584(Context context, C2693 c2693, BinderC2613 binderC2613) {
        String strM8953a;
        ArrayList arrayList = c2693.f20119a;
        String str = c2693.f20118a;
        if (Collections.unmodifiableList(arrayList).isEmpty()) {
            strM8953a = AbstractC3098.m10098a(str);
        } else {
            List listUnmodifiableList = Collections.unmodifiableList(c2693.f20119a);
            if (str == null) {
                throw new IllegalArgumentException("applicationId cannot be null");
            }
            if (listUnmodifiableList == null) {
                throw new IllegalArgumentException("namespaces cannot be null");
            }
            strM8953a = new C2415(str, 19, listUnmodifiableList).m8953a();
        }
        this.f19766a = new BinderC2595(this);
        this.f19764a = context.getApplicationContext();
        AbstractC2582.m9221a(strM8953a);
        this.f19765a = strM8953a;
        this.f19767a = c2693;
        this.f19768a = binderC2613;
    }
}
