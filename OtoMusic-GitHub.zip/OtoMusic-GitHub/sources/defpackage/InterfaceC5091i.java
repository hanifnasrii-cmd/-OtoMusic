package defpackage;

/* JADX INFO: renamed from: i͆, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC5091i {
}
