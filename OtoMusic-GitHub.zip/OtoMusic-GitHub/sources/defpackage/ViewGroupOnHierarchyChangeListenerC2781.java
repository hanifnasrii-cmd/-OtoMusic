package defpackage;

import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import java.util.HashMap;
import java.util.HashSet;

/* JADX INFO: renamed from: с֡, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class ViewGroupOnHierarchyChangeListenerC2781 implements ViewGroup.OnHierarchyChangeListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public ViewGroup.OnHierarchyChangeListener f20479a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ ChipGroup f20480a;

    public ViewGroupOnHierarchyChangeListenerC2781(ChipGroup chipGroup) {
        this.f20480a = chipGroup;
    }

    @Override // android.view.ViewGroup.OnHierarchyChangeListener
    public final void onChildViewAdded(View view, View view2) {
        ChipGroup chipGroup = this.f20480a;
        if (view == chipGroup && (view2 instanceof Chip)) {
            if (view2.getId() == -1) {
                view2.setId(View.generateViewId());
            }
            C2762 c2762 = chipGroup.f2341a;
            Chip chip = (Chip) view2;
            ((HashMap) c2762.f20393a).put(Integer.valueOf(chip.getId()), chip);
            if (chip.isChecked()) {
                c2762.m9485a(chip);
            }
            chip.setInternalOnCheckedChangeListener(new C2791(16, c2762));
        }
        ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f20479a;
        if (onHierarchyChangeListener != null) {
            onHierarchyChangeListener.onChildViewAdded(view, view2);
        }
    }

    @Override // android.view.ViewGroup.OnHierarchyChangeListener
    public final void onChildViewRemoved(View view, View view2) {
        ChipGroup chipGroup = this.f20480a;
        if (view == chipGroup && (view2 instanceof Chip)) {
            C2762 c2762 = chipGroup.f2341a;
            Chip chip = (Chip) view2;
            c2762.getClass();
            chip.setInternalOnCheckedChangeListener(null);
            ((HashMap) c2762.f20393a).remove(Integer.valueOf(chip.getId()));
            ((HashSet) c2762.f20394a).remove(Integer.valueOf(chip.getId()));
        }
        ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f20479a;
        if (onHierarchyChangeListener != null) {
            onHierarchyChangeListener.onChildViewRemoved(view, view2);
        }
    }
}
