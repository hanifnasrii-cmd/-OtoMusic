package defpackage;

/* JADX INFO: renamed from: s̺, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC6399s {
    /* JADX INFO: renamed from: á */
    boolean mo5501a(Class cls);

    /* JADX INFO: renamed from: â */
    C6407s mo5502a(Class cls);
}
