package defpackage;

import java.util.List;

/* JADX INFO: renamed from: c̯, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4408c extends AbstractC1082 {

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public final ComponentCallbacks2C2114 f4684a;

    public AbstractC4408c(ComponentCallbacks2C2114 componentCallbacks2C2114, C0386 c0386, int i) {
        super(c0386, i, 8);
        this.f4684a = componentCallbacks2C2114;
        this.f14575a = true;
    }

    @Override // defpackage.AbstractC1082
    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public void mo2144a(AbstractC2042 abstractC2042, Object obj, int i, List list) {
        super.mo2144a(abstractC2042, obj, i, list);
        ((AbstractC4493c) abstractC2042).mo1129a(obj, this.f4684a);
    }

    @Override // defpackage.AbstractC1082
    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final void mo2145a(List list, Runnable runnable) {
        m7112a();
        this.f14576a = this.f14575a;
        super.mo2145a(list, null);
    }
}
