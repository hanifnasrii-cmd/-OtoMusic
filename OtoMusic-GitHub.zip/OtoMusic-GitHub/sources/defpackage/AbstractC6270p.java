package defpackage;

import android.view.ViewGroup;

/* JADX INFO: renamed from: p߫, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC6270p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int f11152a = 0;

    static {
        C2390.f19243a.m8868a();
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static boolean m5470a(ViewGroup viewGroup) {
        return viewGroup.isTransitionGroup();
    }
}
