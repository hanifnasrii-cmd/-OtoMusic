package defpackage;

import android.os.Process;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import java.util.IllegalFormatException;
import java.util.Locale;

/* JADX INFO: renamed from: aͤ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4109a implements InterfaceC4880e {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f1099a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public String f1100a;

    public /* synthetic */ C4109a(int i) {
        this.f1099a = i;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static C4109a m872a() {
        return new C4109a(0);
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static C4109a m873a() {
        return new C4109a(3);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static String m874a(String str, String str2, Object... objArr) {
        if (objArr.length > 0) {
            try {
                str2 = String.format(Locale.US, str2, objArr);
            } catch (IllegalFormatException e) {
                Log.e("PlayCore", "Unable to format ".concat(str2), e);
                str2 = str2 + " [" + TextUtils.join(", ", objArr) + "]";
            }
        }
        return AbstractC4072a.m747a(str, " : ", str2);
    }

    @Override // defpackage.InterfaceC4880e
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public Object mo875a() {
        return this;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public C4109a m876a() {
        String str = this.f1100a;
        if (str == null) {
            throw new IllegalArgumentException("Purchase token must be set");
        }
        C4109a c4109a = new C4109a(1);
        c4109a.f1100a = str;
        return c4109a;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C4109a m877a() {
        String str = this.f1100a;
        if (str == null) {
            throw new IllegalArgumentException("Purchase token must be set");
        }
        C4109a c4109a = new C4109a(4);
        c4109a.f1100a = str;
        return c4109a;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public String m878a() {
        return this.f1100a;
    }

    @Override // defpackage.InterfaceC4880e
    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean mo879a(CharSequence charSequence, int i, int i2, C6167p c6167p) {
        if (!TextUtils.equals(charSequence.subSequence(i, i2), this.f1100a)) {
            return true;
        }
        c6167p.f10825a = (c6167p.f10825a & 3) | 4;
        return false;
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public void m880a(String str) {
        switch (this.f1099a) {
            case 0:
                this.f1100a = str;
                break;
            default:
                this.f1100a = str;
                break;
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public void m881a(String str, Object... objArr) {
        if (Log.isLoggable("PlayCore", 3)) {
            m874a(this.f1100a, str, objArr);
        }
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public void m882a(RemoteException remoteException, String str, Object... objArr) {
        if (Log.isLoggable("PlayCore", 6)) {
            Log.e("PlayCore", m874a(this.f1100a, str, objArr), remoteException);
        }
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public void m883a(String str, Object... objArr) {
        if (Log.isLoggable("PlayCore", 4)) {
            m874a(this.f1100a, str, objArr);
        }
    }

    public C4109a(String str, int i) {
        this.f1099a = i;
        switch (i) {
            case 6:
                str.getClass();
                this.f1100a = str;
                break;
            case 7:
                this.f1100a = AbstractC4072a.m744a("UID: [", Process.myUid(), "]  PID: [", Process.myPid(), "] ").concat(str);
                break;
            default:
                this.f1100a = str;
                break;
        }
    }
}
