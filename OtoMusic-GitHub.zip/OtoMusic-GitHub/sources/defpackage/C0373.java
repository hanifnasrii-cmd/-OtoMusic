package defpackage;

import android.os.Bundle;
import android.os.Parcelable;
import com.piyush.music.preference.GridCountType;
import java.io.Serializable;
import java.util.HashMap;

/* JADX INFO: renamed from: ο̪, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0373 implements InterfaceC5659j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final HashMap f12841a = new HashMap();

    public static C0373 fromBundle(Bundle bundle) {
        C0373 c0373 = new C0373();
        bundle.setClassLoader(C0373.class.getClassLoader());
        if (!bundle.containsKey("type")) {
            throw new IllegalArgumentException("Required argument \"type\" is missing and does not have an android:defaultValue");
        }
        if (!Parcelable.class.isAssignableFrom(GridCountType.class) && !Serializable.class.isAssignableFrom(GridCountType.class)) {
            throw new UnsupportedOperationException(GridCountType.class.getName().concat(" must implement Parcelable or Serializable or must be an Enum."));
        }
        GridCountType gridCountType = (GridCountType) bundle.get("type");
        if (gridCountType == null) {
            throw new IllegalArgumentException("Argument \"type\" is marked as non-null but was passed a null value.");
        }
        c0373.f12841a.put("type", gridCountType);
        return c0373;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final GridCountType m6232a() {
        return (GridCountType) this.f12841a.get("type");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0373.class != obj.getClass()) {
            return false;
        }
        C0373 c0373 = (C0373) obj;
        if (this.f12841a.containsKey("type") != c0373.f12841a.containsKey("type")) {
            return false;
        }
        return m6232a() == null ? c0373.m6232a() == null : m6232a().equals(c0373.m6232a());
    }

    public final int hashCode() {
        return 31 + (m6232a() != null ? m6232a().hashCode() : 0);
    }

    public final String toString() {
        return "SelectGridCountDialogArgs{type=" + m6232a() + "}";
    }
}
