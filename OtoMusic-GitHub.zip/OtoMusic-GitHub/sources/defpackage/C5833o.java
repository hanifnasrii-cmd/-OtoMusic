package defpackage;

/* JADX INFO: renamed from: oִ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5833o extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public EnumC6106p f9715a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C2934 f9716a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public /* synthetic */ Object f9717a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ C5837o f9718a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f9719a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5833o(C5837o c5837o, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f9718a = c5837o;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f9717a = obj;
        this.f9719a |= Integer.MIN_VALUE;
        return this.f9718a.m4771a(null, this);
    }
}
