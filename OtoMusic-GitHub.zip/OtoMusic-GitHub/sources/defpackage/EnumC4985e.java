package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: e⃰, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC4985e {
    private static final /* synthetic */ EnumC4985e[] $VALUES;
    public static final EnumC4985e APPEND;
    public static final EnumC4985e APPEND_OR_REPLACE;
    public static final EnumC4985e KEEP;
    public static final EnumC4985e REPLACE;

    static {
        EnumC4985e enumC4985e = new EnumC4985e("REPLACE", 0);
        REPLACE = enumC4985e;
        EnumC4985e enumC4985e2 = new EnumC4985e("KEEP", 1);
        KEEP = enumC4985e2;
        EnumC4985e enumC4985e3 = new EnumC4985e("APPEND", 2);
        APPEND = enumC4985e3;
        EnumC4985e enumC4985e4 = new EnumC4985e("APPEND_OR_REPLACE", 3);
        APPEND_OR_REPLACE = enumC4985e4;
        $VALUES = new EnumC4985e[]{enumC4985e, enumC4985e2, enumC4985e3, enumC4985e4};
    }

    public static EnumC4985e valueOf(String str) {
        return (EnumC4985e) Enum.valueOf(EnumC4985e.class, str);
    }

    public static EnumC4985e[] values() {
        return (EnumC4985e[]) $VALUES.clone();
    }
}
