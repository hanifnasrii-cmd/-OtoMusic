package defpackage;

/* JADX INFO: renamed from: οͨ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC0435 {
    /* JADX INFO: renamed from: à */
    String mo6283a();
}
