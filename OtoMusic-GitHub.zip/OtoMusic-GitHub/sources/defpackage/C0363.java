package defpackage;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/* JADX INFO: renamed from: ο̠, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0363 extends C4663c {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final transient byte[][] f12820a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final transient int[] f12821a;

    public C0363(byte[][] bArr, int[] iArr) {
        super(C4663c.f5598a.f5599a);
        this.f12820a = bArr;
        this.f12821a = iArr;
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: à */
    public final C4663c mo2760a(String str) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance(str);
        byte[][] bArr = this.f12820a;
        int length = bArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int[] iArr = this.f12821a;
            int i3 = iArr[length + i];
            int i4 = iArr[i];
            messageDigest.update(bArr[i], i3, i4 - i2);
            i++;
            i2 = i4;
        }
        byte[] bArrDigest = messageDigest.digest();
        AbstractC3098.m10100a(bArrDigest);
        return new C4663c(bArrDigest);
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: á */
    public final int mo2761a() {
        return this.f12821a[this.f12820a.length - 1];
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: â */
    public final String mo2762a() {
        return new C4663c(m6227a()).mo2762a();
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: ã */
    public final byte[] mo2763a() {
        return m6227a();
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: ā */
    public final byte mo2764a(int i) {
        byte[][] bArr = this.f12820a;
        int length = bArr.length - 1;
        int[] iArr = this.f12821a;
        AbstractC5120i.m3428a(iArr[length], i, 1L);
        int iM2059a = AbstractC4372c.m2059a(this, i);
        return bArr[iM2059a][(i - (iM2059a == 0 ? 0 : iArr[iM2059a - 1])) + iArr[bArr.length + iM2059a]];
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: a̅ */
    public final boolean mo2765a(int i, byte[] bArr, int i2, int i3) {
        AbstractC3098.m10103a(bArr, "other");
        if (i < 0 || i > mo2761a() - i3 || i2 < 0 || i2 > bArr.length - i3) {
            return false;
        }
        int i4 = i3 + i;
        int iM2059a = AbstractC4372c.m2059a(this, i);
        while (i < i4) {
            int[] iArr = this.f12821a;
            int i5 = iM2059a == 0 ? 0 : iArr[iM2059a - 1];
            int i6 = iArr[iM2059a] - i5;
            byte[][] bArr2 = this.f12820a;
            int i7 = iArr[bArr2.length + iM2059a];
            int iMin = Math.min(i4, i6 + i5) - i;
            if (!AbstractC5120i.m3421a((i - i5) + i7, i2, iMin, bArr2[iM2059a], bArr)) {
                return false;
            }
            i2 += iMin;
            i += iMin;
            iM2059a++;
        }
        return true;
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: ă */
    public final boolean mo2766a(C4663c c4663c, int i) {
        AbstractC3098.m10103a(c4663c, "other");
        if (mo2761a() - i >= 0) {
            int iM2059a = AbstractC4372c.m2059a(this, 0);
            int i2 = 0;
            int i3 = 0;
            while (i2 < i) {
                int[] iArr = this.f12821a;
                int i4 = iM2059a == 0 ? 0 : iArr[iM2059a - 1];
                int i5 = iArr[iM2059a] - i4;
                byte[][] bArr = this.f12820a;
                int i6 = iArr[bArr.length + iM2059a];
                int iMin = Math.min(i, i5 + i4) - i2;
                if (c4663c.mo2765a(i3, bArr[iM2059a], (i2 - i4) + i6, iMin)) {
                    i3 += iMin;
                    i2 += iMin;
                    iM2059a++;
                }
            }
            return true;
        }
        return false;
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: ȧ */
    public final C4663c mo2767a() {
        return new C4663c(m6227a()).mo2767a();
    }

    @Override // defpackage.C4663c
    /* JADX INFO: renamed from: ả */
    public final void mo2769a(C4628c c4628c, int i) {
        int iM2059a = AbstractC4372c.m2059a(this, 0);
        int i2 = 0;
        while (i2 < i) {
            int[] iArr = this.f12821a;
            int i3 = iM2059a == 0 ? 0 : iArr[iM2059a - 1];
            int i4 = iArr[iM2059a] - i3;
            byte[][] bArr = this.f12820a;
            int i5 = iArr[bArr.length + iM2059a];
            int iMin = Math.min(i, i4 + i3) - i2;
            int i6 = (i2 - i3) + i5;
            C0360 c0360 = new C0360(bArr[iM2059a], i6, i6 + iMin, true);
            C0360 c03602 = c4628c.f5467a;
            if (c03602 == null) {
                c0360.f12814a = c0360;
                c0360.f12813a = c0360;
                c4628c.f5467a = c0360;
            } else {
                C0360 c03603 = c03602.f12814a;
                AbstractC3098.m10100a(c03603);
                c03603.m6216a(c0360);
            }
            i2 += iMin;
            iM2059a++;
        }
        c4628c.f5468a += (long) i;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final byte[] m6227a() {
        byte[] bArr = new byte[mo2761a()];
        byte[][] bArr2 = this.f12820a;
        int length = bArr2.length;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (i < length) {
            int[] iArr = this.f12821a;
            int i4 = iArr[length + i];
            int i5 = iArr[i];
            int i6 = i5 - i2;
            AbstractC1458.m7697a(i3, i4, i4 + i6, bArr2[i], bArr);
            i3 += i6;
            i++;
            i2 = i5;
        }
        return bArr;
    }

    @Override // defpackage.C4663c
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C4663c)) {
            return false;
        }
        C4663c c4663c = (C4663c) obj;
        return c4663c.mo2761a() == mo2761a() && mo2766a(c4663c, mo2761a());
    }

    @Override // defpackage.C4663c
    public final int hashCode() {
        int i = this.f5600a;
        if (i != 0) {
            return i;
        }
        byte[][] bArr = this.f12820a;
        int length = bArr.length;
        int i2 = 0;
        int i3 = 1;
        int i4 = 0;
        while (i2 < length) {
            int[] iArr = this.f12821a;
            int i5 = iArr[length + i2];
            int i6 = iArr[i2];
            byte[] bArr2 = bArr[i2];
            int i7 = (i6 - i4) + i5;
            while (i5 < i7) {
                i3 = (i3 * 31) + bArr2[i5];
                i5++;
            }
            i2++;
            i4 = i6;
        }
        this.f5600a = i3;
        return i3;
    }

    @Override // defpackage.C4663c
    public final String toString() {
        return new C4663c(m6227a()).toString();
    }
}
