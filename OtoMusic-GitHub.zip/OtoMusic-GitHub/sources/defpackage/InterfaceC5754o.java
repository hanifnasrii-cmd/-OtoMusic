package defpackage;

/* JADX INFO: renamed from: o͉, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC5754o {
}
