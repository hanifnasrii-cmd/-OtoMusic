package defpackage;

import java.util.LinkedHashSet;

/* JADX INFO: renamed from: ο̹, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0388 extends AbstractC6278p {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C5631j f12882a = new C5631j(new LinkedHashSet());
}
