package defpackage;

import android.app.PendingIntent;

/* JADX INFO: renamed from: аͦ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1426 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f15922a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f15923a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f15924a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final PendingIntent f15925a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f15926a = false;

    public C1426(int i, int i2, int i3, long j, long j2, PendingIntent pendingIntent, PendingIntent pendingIntent2, PendingIntent pendingIntent3, PendingIntent pendingIntent4) {
        this.f15922a = i;
        this.f15923a = i2;
        this.f15924a = i3;
        this.f15925a = pendingIntent2;
    }
}
