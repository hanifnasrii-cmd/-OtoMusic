package defpackage;

/* JADX INFO: renamed from: i͔, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5105i extends AbstractC2162 {
}
