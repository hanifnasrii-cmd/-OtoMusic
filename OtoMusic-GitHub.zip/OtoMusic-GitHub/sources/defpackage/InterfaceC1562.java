package defpackage;

/* JADX INFO: renamed from: а݁, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC1562 {
    /* JADX INFO: renamed from: à */
    C5724o mo7272a(C5724o c5724o);

    /* JADX INFO: renamed from: á */
    long mo7273a();

    /* JADX INFO: renamed from: â */
    boolean mo7274a(boolean z);

    /* JADX INFO: renamed from: ã */
    long mo7275a(long j);

    /* JADX INFO: renamed from: ā */
    InterfaceC1561[] mo7276a();
}
