package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: οܱ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0553 extends AbstractC3210 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f13458a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C0554 f13459a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0553(C0554 c0554, int i) {
        super(0);
        this.f13458a = i;
        this.f13459a = c0554;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        switch (this.f13458a) {
            case 0:
                C6284p viewModelStore = this.f13459a.requireActivity().getViewModelStore();
                AbstractC3098.m10102a(viewModelStore, "requireActivity().viewModelStore");
                return viewModelStore;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return this.f13459a.requireActivity().getDefaultViewModelCreationExtras();
            default:
                InterfaceC6282p defaultViewModelProviderFactory = this.f13459a.requireActivity().getDefaultViewModelProviderFactory();
                AbstractC3098.m10102a(defaultViewModelProviderFactory, "requireActivity().defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory;
        }
    }
}
