package defpackage;

/* JADX INFO: renamed from: оؕ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2159 extends AbstractC3855 implements InterfaceC5056i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f18539a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public /* synthetic */ InterfaceC1816 f18540a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public /* synthetic */ Throwable f18541a;

    @Override // defpackage.InterfaceC5056i
    /* JADX INFO: renamed from: á */
    public final Object mo2172a(Object obj, Object obj2, Object obj3) {
        C2159 c2159 = new C2159(3, (InterfaceC1005) obj3);
        c2159.f18540a = (InterfaceC1816) obj;
        c2159.f18541a = (Throwable) obj2;
        return c2159.invokeSuspend(C6174p.f10843a);
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
        int i = this.f18539a;
        if (i == 0) {
            AbstractC1149.m7200a(obj);
            InterfaceC1816 interfaceC1816 = this.f18540a;
            C2150 c2150 = new C2150(this.f18541a);
            this.f18540a = null;
            this.f18539a = 1;
            if (interfaceC1816.mo674a(c2150, this) == enumC1045) {
                return enumC1045;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC1149.m7200a(obj);
        }
        return C6174p.f10843a;
    }
}
