package defpackage;

/* JADX INFO: renamed from: eؙ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4868e {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void mo3049a() {
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public abstract void mo3050a();
}
