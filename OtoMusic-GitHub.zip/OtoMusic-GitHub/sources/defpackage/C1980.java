package defpackage;

import android.view.View;
import java.util.ArrayList;

/* JADX INFO: renamed from: еⷺ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1980 implements InterfaceC6118p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ View f17965a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ ArrayList f17966a;

    public C1980(View view, ArrayList arrayList) {
        this.f17965a = view;
        this.f17966a = arrayList;
    }

    @Override // defpackage.InterfaceC6118p
    /* JADX INFO: renamed from: à */
    public final void mo5098a(AbstractC6120p abstractC6120p) {
        abstractC6120p.mo5129a(this);
        abstractC6120p.m5108a(this);
    }

    @Override // defpackage.InterfaceC6118p
    /* JADX INFO: renamed from: á */
    public final void mo5099a() {
    }

    @Override // defpackage.InterfaceC6118p
    /* JADX INFO: renamed from: â */
    public final void mo5100a() {
    }

    @Override // defpackage.InterfaceC6118p
    /* JADX INFO: renamed from: ã */
    public final void mo5101a(AbstractC6120p abstractC6120p) {
        abstractC6120p.mo5129a(this);
        this.f17965a.setVisibility(8);
        ArrayList arrayList = this.f17966a;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((View) arrayList.get(i)).setVisibility(0);
        }
    }

    @Override // defpackage.InterfaceC6118p
    /* JADX INFO: renamed from: a̅ */
    public final void mo5103a(AbstractC6120p abstractC6120p) {
    }
}
