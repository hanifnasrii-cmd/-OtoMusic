package defpackage;

/* JADX INFO: renamed from: ϲّ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C1178 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f14972a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC1574 f14973a;

    public /* synthetic */ C1178(InterfaceC1574 interfaceC1574, int i) {
        this.f14972a = i;
        this.f14973a = interfaceC1574;
    }
}
