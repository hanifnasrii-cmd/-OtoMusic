package defpackage;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: renamed from: oۨ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5896o extends AbstractC4888e {
    final /* synthetic */ C5897o this$0;

    /* JADX INFO: renamed from: oۨ$à, reason: invalid class name */
    public static final class a extends AbstractC4888e {
        final /* synthetic */ C5897o this$0;

        public a(C5897o c5897o) {
            this.this$0 = c5897o;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            AbstractC3098.m10103a(activity, "activity");
            this.this$0.m4831a();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            AbstractC3098.m10103a(activity, "activity");
            C5897o c5897o = this.this$0;
            int i = c5897o.f9910a + 1;
            c5897o.f9910a = i;
            if (i == 1 && c5897o.f9913a) {
                c5897o.f9915a.m10362a(EnumC3281.ON_START);
                c5897o.f9913a = false;
            }
        }
    }

    public C5896o(C5897o c5897o) {
        this.this$0 = c5897o;
    }

    @Override // defpackage.AbstractC4888e, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        AbstractC3098.m10103a(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i = FragmentC2097.f18342a;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            AbstractC3098.m10101a(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((FragmentC2097) fragmentFindFragmentByTag).f18343a = this.this$0.f9917a;
        }
    }

    @Override // defpackage.AbstractC4888e, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        AbstractC3098.m10103a(activity, "activity");
        C5897o c5897o = this.this$0;
        int i = c5897o.f9911a - 1;
        c5897o.f9911a = i;
        if (i == 0) {
            Handler handler = c5897o.f9914a;
            AbstractC3098.m10100a(handler);
            handler.postDelayed(c5897o.f9916a, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        AbstractC3098.m10103a(activity, "activity");
        AbstractC5895o.m4830a(activity, new a(this.this$0));
    }

    @Override // defpackage.AbstractC4888e, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        AbstractC3098.m10103a(activity, "activity");
        C5897o c5897o = this.this$0;
        int i = c5897o.f9910a - 1;
        c5897o.f9910a = i;
        if (i == 0 && c5897o.f9912a) {
            c5897o.f9915a.m10362a(EnumC3281.ON_STOP);
            c5897o.f9913a = true;
        }
    }
}
