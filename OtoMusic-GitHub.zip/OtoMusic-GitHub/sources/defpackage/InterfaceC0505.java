package defpackage;

/* JADX INFO: renamed from: οؖ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC0505 {
    /* JADX INFO: renamed from: á */
    boolean mo5810a();

    /* JADX INFO: renamed from: ã */
    void mo5812a();

    /* JADX INFO: renamed from: ȧ */
    C4807e mo5814a();

    void dismiss();
}
