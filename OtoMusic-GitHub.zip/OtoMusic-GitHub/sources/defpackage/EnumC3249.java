package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: і⃑, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class EnumC3249 {
    private static final /* synthetic */ EnumC3249[] $VALUES;
    public static final EnumC3249 ADAPTIVE_TOWARDS_MID;
    public static final EnumC3249 PRESERVE_LIGHTNESS;
    public static final EnumC3249 PROJECT_TO_MID;

    static {
        EnumC3249 enumC3249 = new EnumC3249("PRESERVE_LIGHTNESS", 0);
        PRESERVE_LIGHTNESS = enumC3249;
        EnumC3249 enumC32492 = new EnumC3249("PROJECT_TO_MID", 1);
        PROJECT_TO_MID = enumC32492;
        EnumC3249 enumC32493 = new EnumC3249("ADAPTIVE_TOWARDS_MID", 2);
        ADAPTIVE_TOWARDS_MID = enumC32493;
        $VALUES = new EnumC3249[]{enumC3249, enumC32492, enumC32493};
    }

    public static EnumC3249 valueOf(String str) {
        return (EnumC3249) Enum.valueOf(EnumC3249.class, str);
    }

    public static EnumC3249[] values() {
        return (EnumC3249[]) $VALUES.clone();
    }
}
