package defpackage;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat$Token;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.piyush.music.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/* JADX INFO: renamed from: jͅ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class DialogC5420j extends DialogC1373 {

    /* JADX INFO: renamed from: a̰, reason: contains not printable characters */
    public static final /* synthetic */ int f8293a = 0;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C5435j f8294a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final C2700 f8295a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public C5427j f8296a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public C5433j f8297a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final ArrayList f8298a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final ArrayList f8299a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final ArrayList f8300a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final ArrayList f8301a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final Context f8302a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public boolean f8303a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public boolean f8304a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public long f8305a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final HandlerC1522 f8306a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public RecyclerView f8307a;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public C5418j f8308a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public C5419j f8309a;

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public HashMap f8310a;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public C5433j f8311a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public HashMap f8312a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public boolean f8313a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public boolean f8314a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public boolean f8315a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public ImageButton f8316a;

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public Button f8317a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public ImageView f8318a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public View f8319a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public ImageView f8320a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public TextView f8321a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public TextView f8322a;

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public String f8323a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public C2415 f8324a;

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final C5401j f8325a;

    /* JADX INFO: renamed from: ą, reason: contains not printable characters */
    public MediaDescriptionCompat f8326a;

    /* JADX INFO: renamed from: a̩, reason: contains not printable characters */
    public AsyncTaskC5414j f8327a;

    /* JADX INFO: renamed from: a̪, reason: contains not printable characters */
    public Bitmap f8328a;

    /* JADX INFO: renamed from: a̫, reason: contains not printable characters */
    public Uri f8329a;

    /* JADX INFO: renamed from: a̬, reason: contains not printable characters */
    public boolean f8330a;

    /* JADX INFO: renamed from: a̭, reason: contains not printable characters */
    public Bitmap f8331a;

    /* JADX INFO: renamed from: a̮, reason: contains not printable characters */
    public int f8332a;

    /* JADX INFO: renamed from: a̯, reason: contains not printable characters */
    public final boolean f8333a;

    static {
        Log.isLoggable("MediaRouteCtrlDialog", 3);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public DialogC5420j(Context context) {
        ContextThemeWrapper contextThemeWrapperM3483a = AbstractC5121i.m3483a(context, false);
        int iM3500a = AbstractC5121i.m3500a(contextThemeWrapperM3483a, R.attr.mediaRouteTheme);
        super(contextThemeWrapperM3483a, iM3500a == 0 ? AbstractC5121i.m3498a(contextThemeWrapperM3483a) : iM3500a);
        this.f8296a = C5427j.f8354a;
        this.f8298a = new ArrayList();
        this.f8299a = new ArrayList();
        this.f8300a = new ArrayList();
        this.f8301a = new ArrayList();
        this.f8306a = new HandlerC1522(5, this);
        Context context2 = getContext();
        this.f8302a = context2;
        this.f8294a = C5435j.m4237a(context2);
        this.f8333a = C5435j.m4241a();
        this.f8295a = new C2700(4, this);
        this.f8297a = C5435j.m4240a();
        this.f8325a = new C5401j(this, 1);
        m4187a(C5435j.m4238a());
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void m4185a(List list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            C5433j c5433j = (C5433j) list.get(size);
            if (c5433j.m4224a() || !c5433j.f8385a || !c5433j.m4228a(this.f8296a) || this.f8297a == c5433j) {
                list.remove(size);
            }
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void m4186a() {
        MediaDescriptionCompat mediaDescriptionCompat = this.f8326a;
        Bitmap bitmap = mediaDescriptionCompat == null ? null : mediaDescriptionCompat.f6a;
        Uri uri = mediaDescriptionCompat != null ? mediaDescriptionCompat.f7a : null;
        AsyncTaskC5414j asyncTaskC5414j = this.f8327a;
        Bitmap bitmap2 = asyncTaskC5414j == null ? this.f8328a : asyncTaskC5414j.f8268a;
        Uri uri2 = asyncTaskC5414j == null ? this.f8329a : asyncTaskC5414j.f8269a;
        if (bitmap2 != bitmap || (bitmap2 == null && !Objects.equals(uri2, uri))) {
            AsyncTaskC5414j asyncTaskC5414j2 = this.f8327a;
            if (asyncTaskC5414j2 != null) {
                asyncTaskC5414j2.cancel(true);
            }
            AsyncTaskC5414j asyncTaskC5414j3 = new AsyncTaskC5414j(this);
            this.f8327a = asyncTaskC5414j3;
            asyncTaskC5414j3.execute(new Void[0]);
        }
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m4187a(MediaSessionCompat$Token mediaSessionCompat$Token) {
        C2415 c2415 = this.f8324a;
        C5401j c5401j = this.f8325a;
        if (c2415 != null) {
            c2415.m8951a(c5401j);
            this.f8324a = null;
        }
        if (mediaSessionCompat$Token != null && this.f8304a) {
            C2415 c24152 = new C2415(this.f8302a, mediaSessionCompat$Token);
            this.f8324a = c24152;
            c24152.m8946a(c5401j);
            MediaMetadataCompat mediaMetadataCompatM8940a = this.f8324a.m8940a();
            this.f8326a = mediaMetadataCompatM8940a != null ? mediaMetadataCompatM8940a.m5a() : null;
            m4186a();
            m4190a();
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final void m4188a(C5427j c5427j) {
        if (c5427j == null) {
            throw new IllegalArgumentException("selector must not be null");
        }
        if (this.f8296a.equals(c5427j)) {
            return;
        }
        this.f8296a = c5427j;
        if (this.f8304a) {
            C5435j c5435j = this.f8294a;
            C2700 c2700 = this.f8295a;
            c5435j.m4244a(c2700);
            c5435j.m4243a(c5427j, c2700, 1);
            m4191a();
        }
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void m4189a() {
        Context context = this.f8302a;
        getWindow().setLayout(!context.getResources().getBoolean(R.bool.h) ? -1 : AbstractC5122i.m3532a(context), context.getResources().getBoolean(R.bool.h) ? -2 : -1);
        this.f8328a = null;
        this.f8329a = null;
        m4186a();
        m4190a();
        m4192a();
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00a0  */
    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m4190a() {
        /*
            Method dump skipped, instruction units count: 257
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.DialogC5420j.m4190a():void");
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m4191a() {
        ArrayList arrayList = this.f8298a;
        arrayList.clear();
        ArrayList arrayList2 = this.f8299a;
        arrayList2.clear();
        ArrayList arrayList3 = this.f8300a;
        arrayList3.clear();
        arrayList.addAll(Collections.unmodifiableList(this.f8297a.f8400a));
        C5430j c5430jM4222a = this.f8297a.m4222a();
        if (c5430jM4222a != null) {
            C5432j c5432j = this.f8297a.f8379a;
            c5432j.getClass();
            C5435j.m4235a();
            for (C5433j c5433j : Collections.unmodifiableList(c5432j.f8375a)) {
                if (c5430jM4222a.m4214a(c5433j)) {
                    arrayList2.add(c5433j);
                }
                if (c5430jM4222a.m4215a(c5433j)) {
                    arrayList3.add(c5433j);
                }
            }
        }
        m4185a(arrayList2);
        m4185a(arrayList3);
        C5393j c5393j = C5393j.f8181a;
        Collections.sort(arrayList, c5393j);
        Collections.sort(arrayList2, c5393j);
        Collections.sort(arrayList3, c5393j);
        this.f8308a.m4184a();
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final void m4192a() {
        if (this.f8304a) {
            if (SystemClock.uptimeMillis() - this.f8305a < 300) {
                HandlerC1522 handlerC1522 = this.f8306a;
                handlerC1522.removeMessages(1);
                handlerC1522.sendEmptyMessageAtTime(1, this.f8305a + 300);
                return;
            }
            if ((this.f8311a != null || this.f8313a) ? true : !this.f8303a) {
                this.f8314a = true;
                return;
            }
            this.f8314a = false;
            if (!this.f8297a.m4227a() || this.f8297a.m4224a()) {
                dismiss();
            }
            this.f8305a = SystemClock.uptimeMillis();
            this.f8308a.m4183a();
        }
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void m4193a() {
        if (this.f8314a) {
            m4192a();
        }
        if (this.f8315a) {
            m4190a();
        }
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f8304a = true;
        this.f8294a.m4243a(this.f8296a, this.f8295a, 1);
        m4191a();
        m4187a(C5435j.m4238a());
    }

    @Override // defpackage.DialogC1373, defpackage.DialogC2906, android.app.Dialog
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.mr_cast_dialog);
        View decorView = getWindow().getDecorView();
        Context context = this.f8302a;
        decorView.setBackgroundColor(context.getColor(AbstractC5121i.m3503a(context) ? R.color.mr_dynamic_dialog_background_light : R.color.mr_dynamic_dialog_background_dark));
        ImageButton imageButton = (ImageButton) findViewById(R.id.mr_cast_close_button);
        this.f8316a = imageButton;
        imageButton.setColorFilter(-1);
        final int i = 0;
        this.f8316a.setOnClickListener(new View.OnClickListener(this) { // from class: j̾

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ DialogC5420j f8267a;

            {
                this.f8267a = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i) {
                    case 0:
                        this.f8267a.dismiss();
                        break;
                    default:
                        DialogC5420j dialogC5420j = this.f8267a;
                        if (dialogC5420j.f8297a.m4227a()) {
                            dialogC5420j.f8294a.getClass();
                            C5435j.m4242a(2);
                        }
                        dialogC5420j.dismiss();
                        break;
                }
            }
        });
        Button button = (Button) findViewById(R.id.mr_cast_stop_button);
        this.f8317a = button;
        button.setTextColor(-1);
        final int i2 = 1;
        this.f8317a.setOnClickListener(new View.OnClickListener(this) { // from class: j̾

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ DialogC5420j f8267a;

            {
                this.f8267a = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i2) {
                    case 0:
                        this.f8267a.dismiss();
                        break;
                    default:
                        DialogC5420j dialogC5420j = this.f8267a;
                        if (dialogC5420j.f8297a.m4227a()) {
                            dialogC5420j.f8294a.getClass();
                            C5435j.m4242a(2);
                        }
                        dialogC5420j.dismiss();
                        break;
                }
            }
        });
        this.f8308a = new C5418j(this);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.mr_cast_list);
        this.f8307a = recyclerView;
        recyclerView.setAdapter(this.f8308a);
        this.f8307a.setLayoutManager(new LinearLayoutManager(1));
        this.f8309a = new C5419j(this);
        this.f8310a = new HashMap();
        this.f8312a = new HashMap();
        this.f8318a = (ImageView) findViewById(R.id.mr_cast_meta_background);
        this.f8319a = findViewById(R.id.mr_cast_meta_black_scrim);
        this.f8320a = (ImageView) findViewById(R.id.mr_cast_meta_art);
        TextView textView = (TextView) findViewById(R.id.mr_cast_meta_title);
        this.f8321a = textView;
        textView.setTextColor(-1);
        TextView textView2 = (TextView) findViewById(R.id.mr_cast_meta_subtitle);
        this.f8322a = textView2;
        textView2.setTextColor(-1);
        this.f8323a = context.getResources().getString(R.string.mr_cast_dialog_title_view_placeholder);
        this.f8303a = true;
        m4189a();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f8304a = false;
        this.f8294a.m4244a(this.f8295a);
        this.f8306a.removeCallbacksAndMessages(null);
        m4187a(null);
    }
}
