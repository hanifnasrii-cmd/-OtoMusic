package defpackage;

import android.os.IInterface;

/* JADX INFO: renamed from: і̧, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC3018 extends IInterface {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final String f21526a = "android$support$v4$app$INotificationSideChannel".replace('$', '.');
}
