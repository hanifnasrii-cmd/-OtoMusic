package defpackage;

/* JADX INFO: renamed from: οު, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC0583 {
    /* JADX INFO: renamed from: ă */
    void mo673a();
}
