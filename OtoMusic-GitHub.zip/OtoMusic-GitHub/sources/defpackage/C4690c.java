package defpackage;

/* JADX INFO: renamed from: cⷾ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4690c extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public InterfaceC5905o f5670a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public /* synthetic */ Object f5671a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C4691c f5672a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int f5673a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C4690c(C4691c c4691c, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f5672a = c4691c;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f5671a = obj;
        this.f5673a |= Integer.MIN_VALUE;
        return this.f5672a.mo2808a(null, this);
    }
}
