package defpackage;

import android.util.SparseArray;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/* JADX INFO: renamed from: о̭, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2031 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final SparseArray f18104a = new SparseArray();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f18105a = 0;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Set f18106a = Collections.newSetFromMap(new IdentityHashMap());

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C2030 m8414a(int i) {
        SparseArray sparseArray = this.f18104a;
        C2030 c2030 = (C2030) sparseArray.get(i);
        if (c2030 != null) {
            return c2030;
        }
        C2030 c20302 = new C2030();
        sparseArray.put(i, c20302);
        return c20302;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m8415a(int i, int i2) {
        C2030 c2030M8414a = m8414a(i);
        c2030M8414a.f18101a = i2;
        ArrayList arrayList = c2030M8414a.f18100a;
        while (arrayList.size() > i2) {
            arrayList.remove(arrayList.size() - 1);
        }
    }
}
