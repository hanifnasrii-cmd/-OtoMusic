package defpackage;

/* JADX INFO: renamed from: օ݀, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC3878 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f23925a;

    static {
        int[] iArr = new int[EnumC3371.values().length];
        f23925a = iArr;
        try {
            iArr[EnumC3371.NOT_REQUIRED.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            f23925a[EnumC3371.CONNECTED.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            f23925a[EnumC3371.UNMETERED.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            f23925a[EnumC3371.NOT_ROAMING.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            f23925a[EnumC3371.METERED.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
    }
}
