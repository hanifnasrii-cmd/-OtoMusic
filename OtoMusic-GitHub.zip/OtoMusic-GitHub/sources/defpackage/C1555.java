package defpackage;

import java.util.Objects;

/* JADX INFO: renamed from: аܺ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1555 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f16342a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f16343a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f16344a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final boolean f16345a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final boolean f16346a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f16347a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C1528 f16348a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int f16349a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final int f16350a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final boolean f16351a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final boolean f16352a;

    public C1555(C1554 c1554) {
        this.f16342a = c1554.f16331a;
        this.f16343a = c1554.f16332a;
        this.f16344a = c1554.f16333a;
        this.f16345a = c1554.f16334a;
        this.f16346a = c1554.f16335a;
        this.f16347a = c1554.f16336a;
        this.f16348a = c1554.f16337a;
        this.f16349a = c1554.f16338a;
        this.f16350a = c1554.f16339a;
        this.f16351a = c1554.f16340a;
        this.f16352a = c1554.f16341a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C1554 m7891a() {
        C1554 c1554 = new C1554();
        c1554.f16331a = this.f16342a;
        c1554.f16332a = this.f16343a;
        c1554.f16333a = this.f16344a;
        c1554.f16334a = this.f16345a;
        c1554.f16335a = this.f16346a;
        c1554.f16336a = this.f16347a;
        c1554.f16337a = this.f16348a;
        c1554.f16338a = this.f16349a;
        c1554.f16339a = this.f16350a;
        c1554.f16340a = this.f16351a;
        c1554.f16341a = this.f16352a;
        return c1554;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C1555.class != obj.getClass()) {
            return false;
        }
        C1555 c1555 = (C1555) obj;
        return this.f16342a == c1555.f16342a && this.f16343a == c1555.f16343a && this.f16344a == c1555.f16344a && this.f16345a == c1555.f16345a && this.f16346a == c1555.f16346a && this.f16347a == c1555.f16347a && this.f16349a == c1555.f16349a && this.f16350a == c1555.f16350a && this.f16351a == c1555.f16351a && this.f16352a == c1555.f16352a && this.f16348a.equals(c1555.f16348a);
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.f16342a), Integer.valueOf(this.f16343a), Integer.valueOf(this.f16344a), Boolean.valueOf(this.f16345a), Boolean.valueOf(this.f16346a), Integer.valueOf(this.f16347a), this.f16348a, Integer.valueOf(this.f16349a), Integer.valueOf(this.f16350a), Boolean.valueOf(this.f16352a), Boolean.valueOf(this.f16351a));
    }
}
