package defpackage;

import java.io.IOException;

/* JADX INFO: renamed from: ρְ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0810 extends AbstractC0738 {
    private static final C0810 zzb;
    private int zzd;
    private int zze = 0;
    private Object zzf;
    private int zzg;
    private C0826 zzh;
    private int zzi;

    static {
        C0810 c0810 = new C0810();
        zzb = c0810;
        AbstractC0738.m6657a(C0810.class, c0810);
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static /* synthetic */ void m6803a(C0810 c0810, C0841 c0841) {
        c0810.zzf = c0841;
        c0810.zze = 7;
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public static /* synthetic */ void m6804a(C0810 c0810, C0849 c0849) {
        c0810.zzf = c0849;
        c0810.zze = 6;
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public static /* synthetic */ void m6805a(C0810 c0810, int i) {
        c0810.zzg = i - 1;
        c0810.zzd |= 1;
    }

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public static C0809 m6806a() {
        return (C0809) zzb.m6664a();
    }

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public static C0810 m6808a(byte[] bArr) throws C0754 {
        AbstractC0738 abstractC0738 = zzb;
        int length = bArr.length;
        C0729 c0729 = C0729.f13919a;
        int i = AbstractC0714.f13882a;
        C0729 c07292 = C0729.f13919a;
        if (length != 0) {
            AbstractC0738 abstractC0738M6666a = abstractC0738.m6666a();
            try {
                InterfaceC0782 interfaceC0782M6721a = C0777.f13986a.m6721a(abstractC0738M6666a.getClass());
                interfaceC0782M6721a.mo6697a(abstractC0738M6666a, bArr, 0, length, new C0715(c07292));
                interfaceC0782M6721a.mo6695a(abstractC0738M6666a);
                abstractC0738 = abstractC0738M6666a;
            } catch (C0754 e) {
                throw e;
            } catch (IOException e2) {
                if (e2.getCause() instanceof C0754) {
                    throw ((C0754) e2.getCause());
                }
                throw new C0754(e2.getMessage(), e2);
            } catch (IndexOutOfBoundsException unused) {
                throw new C0754("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
            } catch (C0791 e3) {
                throw new C0754(e3.getMessage());
            }
        }
        if (abstractC0738 == null || AbstractC0738.m6658a(abstractC0738, true)) {
            return (C0810) abstractC0738;
        }
        throw new C0754(new C0791().getMessage());
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public static /* synthetic */ void m6809a(C0810 c0810, EnumC0828 enumC0828) {
        c0810.zzi = enumC0828.m6837a();
        c0810.zzd |= 4;
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public static /* synthetic */ void m6810a(C0810 c0810, C0826 c0826) {
        c0810.zzh = c0826;
        c0810.zzd |= 2;
    }

    @Override // defpackage.AbstractC0738
    /* JADX INFO: renamed from: ả */
    public final Object mo6604a(int i) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C0780(zzb, "\u0004\u0006\u0001\u0001\u0001\u0007\u0006\u0000\u0000\u0000\u0001᠌\u0000\u0002ဉ\u0001\u0004<\u0000\u0005᠌\u0002\u0006<\u0000\u0007<\u0000", new Object[]{"zzf", "zze", "zzd", "zzg", C0811.f14061a, "zzh", C0833.class, "zzi", C0811.f14062a, C0849.class, C0841.class});
        }
        if (i2 == 3) {
            return new C0810();
        }
        if (i2 == 4) {
            return new C0809();
        }
        if (i2 == 5) {
            return zzb;
        }
        throw null;
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final C0841 m6811a() {
        return this.zze == 7 ? (C0841) this.zzf : C0841.m6860a();
    }
}
