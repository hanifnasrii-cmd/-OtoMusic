package defpackage;

import android.media.MediaRoute2Info;
import android.media.MediaRouter2;
import android.media.RouteListingPreference;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Set;

/* JADX INFO: renamed from: j̠, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC5383j {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static float m4112a(VelocityTracker velocityTracker, int i) {
        return velocityTracker.getAxisVelocity(i);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static Set m4113a(MediaRoute2Info mediaRoute2Info) {
        return mediaRoute2Info.getDeduplicationIds();
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static int m4114a(ViewConfiguration viewConfiguration, int i, int i2, int i3) {
        return viewConfiguration.getScaledMaximumFlingVelocity(i, i2, i3);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static int m4115a(ViewConfiguration viewConfiguration, int i, int i2, int i3) {
        return viewConfiguration.getScaledMinimumFlingVelocity(i, i2, i3);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static int m4116a(MediaRoute2Info mediaRoute2Info) {
        return mediaRoute2Info.getType();
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static void m4117a(TextView textView, int i, float f) {
        textView.setLineHeight(i, f);
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static void m4118a(MediaRouter2 mediaRouter2, RouteListingPreference routeListingPreference) {
        mediaRouter2.setRouteListingPreference(routeListingPreference);
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static boolean m4119a(MediaRouter2 mediaRouter2) {
        return mediaRouter2.showSystemOutputSwitcher();
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static RouteListingPreference m4120a(C2202 c2202) {
        ArrayList arrayList = new ArrayList();
        for (C2201 c2201 : c2202.f18691a) {
            arrayList.add(new RouteListingPreference.Item.Builder(c2201.f18689a).setFlags(0).setSubText(0).setCustomSubtextMessage(null).setSelectionBehavior(c2201.f18690a).build());
        }
        return new RouteListingPreference.Builder().setItems(arrayList).setLinkedItemComponentName(null).setUseSystemOrdering(c2202.f18692a).build();
    }
}
