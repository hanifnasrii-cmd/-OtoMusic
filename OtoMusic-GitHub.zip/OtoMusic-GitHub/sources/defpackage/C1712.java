package defpackage;

import android.content.Context;
import android.content.SharedPreferences;
import com.piyush.music.widget.fastscroll.FastScrollRecyclerView;
import com.piyush.taglib.AudioProperties;
import java.util.regex.Matcher;

/* JADX INFO: renamed from: е̹, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1712 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16844a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f16845a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ Object f16846a;

    public /* synthetic */ C1712(Object obj, int i, Object obj2) {
        this.f16844a = i;
        this.f16845a = obj;
        this.f16846a = obj2;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        switch (this.f16844a) {
            case 0:
                return FastScrollRecyclerView.m1996a((Context) this.f16845a, (FastScrollRecyclerView) this.f16846a);
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C2054 c2054 = (C2054) this.f16845a;
                CharSequence charSequence = (CharSequence) this.f16846a;
                c2054.getClass();
                AbstractC3098.m10103a(charSequence, "input");
                Matcher matcher = c2054.f18174a.matcher(charSequence);
                AbstractC3098.m10102a(matcher, "matcher(...)");
                if (matcher.find(0)) {
                    return new C0224(matcher, charSequence);
                }
                return null;
            default:
                C0492 c0492 = (C0492) this.f16845a;
                SharedPreferencesOnSharedPreferenceChangeListenerC0481 sharedPreferencesOnSharedPreferenceChangeListenerC0481 = (SharedPreferencesOnSharedPreferenceChangeListenerC0481) this.f16846a;
                C3865 c3865 = c0492.f13166a;
                ((SharedPreferences) c3865.getValue()).registerOnSharedPreferenceChangeListener(sharedPreferencesOnSharedPreferenceChangeListenerC0481);
                return new C5631j(Boolean.valueOf(((SharedPreferences) c3865.getValue()).getBoolean("pref_show_song_duration", false)));
        }
    }
}
