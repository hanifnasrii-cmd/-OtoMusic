package defpackage;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* JADX INFO: renamed from: օִ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public class SubMenuC3793 extends MenuC5487j implements SubMenu {

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final MenuC5487j f23726a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public final C5493j f23727a;

    public SubMenuC3793(Context context, MenuC5487j menuC5487j, C5493j c5493j) {
        super(context);
        this.f23726a = menuC5487j;
        this.f23727a = c5493j;
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: ã */
    public final boolean mo4316a(C5493j c5493j) {
        return this.f23726a.mo4316a(c5493j);
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: ā */
    public final boolean mo4317a(MenuC5487j menuC5487j, MenuItem menuItem) {
        return super.mo4317a(menuC5487j, menuItem) || this.f23726a.mo4317a(menuC5487j, menuItem);
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: a̅ */
    public final boolean mo4318a(C5493j c5493j) {
        return this.f23726a.mo4318a(c5493j);
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: ả */
    public final String mo4322a() {
        C5493j c5493j = this.f23727a;
        int i = c5493j != null ? c5493j.f8605a : 0;
        if (i == 0) {
            return null;
        }
        return AbstractC4072a.m739a(i, "android:menu:actionviewstates:");
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: å */
    public final MenuC5487j mo4323a() {
        return this.f23726a.mo4323a();
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: ǎ */
    public final boolean mo4325a() {
        return this.f23726a.mo4325a();
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: a̍ */
    public final boolean mo4326a() {
        return this.f23726a.mo4326a();
    }

    @Override // defpackage.MenuC5487j
    /* JADX INFO: renamed from: a̎ */
    public final boolean mo4327a() {
        return this.f23726a.mo4327a();
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final MenuC5487j m11014a() {
        return this.f23726a;
    }

    @Override // android.view.SubMenu
    public final MenuItem getItem() {
        return this.f23727a;
    }

    @Override // defpackage.MenuC5487j, android.view.Menu
    public final void setGroupDividerEnabled(boolean z) {
        this.f23726a.setGroupDividerEnabled(z);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(Drawable drawable) {
        m4333a(0, null, 0, drawable, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        m4333a(0, charSequence, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderView(View view) {
        m4333a(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(Drawable drawable) {
        this.f23727a.setIcon(drawable);
        return this;
    }

    @Override // defpackage.MenuC5487j, android.view.Menu
    public final void setQwertyMode(boolean z) {
        this.f23726a.setQwertyMode(z);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(int i) {
        m4333a(0, null, i, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(int i) {
        m4333a(i, null, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(int i) {
        this.f23727a.setIcon(i);
        return this;
    }
}
