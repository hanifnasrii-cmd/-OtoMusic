package defpackage;

import java.util.NoSuchElementException;

/* JADX INFO: renamed from: јⷧ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3616 extends AbstractC4051a {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Object[] f23151a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C6136p f23152a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C3616(int i, int i2, int i3, Object[] objArr, Object[] objArr2) {
        super(i, i2);
        AbstractC3098.m10103a(objArr, "root");
        AbstractC3098.m10103a(objArr2, "tail");
        this.f23151a = objArr2;
        int i4 = (i2 - 1) & (-32);
        this.f23152a = new C6136p(objArr, i > i4 ? i4 : i, i4, i3);
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        C6136p c6136p = this.f23152a;
        if (c6136p.hasNext()) {
            this.f1010a++;
            return c6136p.next();
        }
        int i = this.f1010a;
        this.f1010a = i + 1;
        return this.f23151a[i - c6136p.f1011a];
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        int i = this.f1010a;
        C6136p c6136p = this.f23152a;
        int i2 = c6136p.f1011a;
        if (i <= i2) {
            this.f1010a = i - 1;
            return c6136p.previous();
        }
        int i3 = i - 1;
        this.f1010a = i3;
        return this.f23151a[i3 - i2];
    }
}
