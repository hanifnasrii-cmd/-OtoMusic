package defpackage;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;

/* JADX INFO: renamed from: i͒, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5103i extends AbstractC4080a {
    public static final Parcelable.Creator<C5103i> CREATOR = new C2492(13);

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public static final Scope[] f6987a = new Scope[0];

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public static final C1725[] f6988a = new C1725[0];

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f6989a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f6990a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f6991a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public String f6992a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public IBinder f6993a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public Scope[] f6994a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public Bundle f6995a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public Account f6996a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public C1725[] f6997a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C1725[] f6998a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final boolean f6999a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final int f7000a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public boolean f7001a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final String f7002a;

    public C5103i(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, C1725[] c1725Arr, C1725[] c1725Arr2, boolean z, int i4, boolean z2, String str2) {
        scopeArr = scopeArr == null ? f6987a : scopeArr;
        bundle = bundle == null ? new Bundle() : bundle;
        C1725[] c1725Arr3 = f6988a;
        c1725Arr = c1725Arr == null ? c1725Arr3 : c1725Arr;
        c1725Arr2 = c1725Arr2 == null ? c1725Arr3 : c1725Arr2;
        this.f6989a = i;
        this.f6990a = i2;
        this.f6991a = i3;
        if ("com.google.android.gms".equals(str)) {
            this.f6992a = "com.google.android.gms";
        } else {
            this.f6992a = str;
        }
        if (i < 2) {
            this.f6996a = iBinder != null ? AbstractBinderC4108a.m871a(AbstractBinderC4108a.m870a(iBinder)) : null;
        } else {
            this.f6993a = iBinder;
            this.f6996a = account;
        }
        this.f6994a = scopeArr;
        this.f6995a = bundle;
        this.f6997a = c1725Arr;
        this.f6998a = c1725Arr2;
        this.f6999a = z;
        this.f7000a = i4;
        this.f7001a = z2;
        this.f7002a = str2;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        C2492.m9101a(this, parcel, i);
    }
}
