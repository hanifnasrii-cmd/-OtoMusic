package defpackage;

/* JADX INFO: renamed from: ρ݉, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0908 extends AbstractC6386s {
    private static final C0908 zzf;
    private int zzb;
    private int zzd;
    private int zze;

    static {
        C0908 c0908 = new C0908();
        zzf = c0908;
        AbstractC6386s.m5619a(C0908.class, c0908);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static C0907 m6978a() {
        return (C0907) zzf.m5621a();
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzf, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001᠌\u0000\u0002င\u0001", new Object[]{"zzb", "zzd", C0869.f14193a, "zze"});
        }
        if (i2 == 3) {
            return new C0908();
        }
        if (i2 == 4) {
            return new C0907(zzf);
        }
        if (i2 == 5) {
            return zzf;
        }
        throw null;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final /* synthetic */ void m6979a(int i) {
        this.zzb |= 2;
        this.zze = i;
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final /* synthetic */ void m6980a(int i) {
        this.zzd = i - 1;
        this.zzb |= 1;
    }
}
