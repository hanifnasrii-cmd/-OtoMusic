package defpackage;

/* JADX INFO: renamed from: s̓, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC6408s {
    /* JADX INFO: renamed from: à */
    AbstractC6386s mo5644a();

    /* JADX INFO: renamed from: á */
    int mo5645a(AbstractC6386s abstractC6386s);

    /* JADX INFO: renamed from: â */
    void mo5646a(Object obj, C2480 c2480);

    /* JADX INFO: renamed from: ã */
    void mo5647a(Object obj, Object obj2);

    /* JADX INFO: renamed from: ā */
    int mo5648a(AbstractC6369s abstractC6369s);

    /* JADX INFO: renamed from: a̅ */
    boolean mo5649a(Object obj);

    /* JADX INFO: renamed from: ă */
    boolean mo5650a(AbstractC6386s abstractC6386s, AbstractC6386s abstractC6386s2);

    /* JADX INFO: renamed from: ȧ */
    void mo5651a(Object obj);
}
