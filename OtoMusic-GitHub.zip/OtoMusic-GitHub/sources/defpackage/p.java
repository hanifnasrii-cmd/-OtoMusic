package defpackage;

import com.piyush.music.models.NowPlayingTheme;

/* JADX INFO: renamed from: p̀, reason: invalid class name */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f10317a;

    static {
        int[] iArr = new int[NowPlayingTheme.values().length];
        try {
            iArr[NowPlayingTheme.SHIMMER.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[NowPlayingTheme.BLUR.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[NowPlayingTheme.EDITORIAL_BLUR.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[NowPlayingTheme.GRADIENT_BLUR.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr[NowPlayingTheme.MATERIAL_YOU.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr[NowPlayingTheme.GRADIENT.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            iArr[NowPlayingTheme.SIMPLE_COLOR.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
        try {
            iArr[NowPlayingTheme.GLOW.ordinal()] = 8;
        } catch (NoSuchFieldError unused8) {
        }
        try {
            iArr[NowPlayingTheme.EDITORIAL.ordinal()] = 9;
        } catch (NoSuchFieldError unused9) {
        }
        f10317a = iArr;
    }
}
