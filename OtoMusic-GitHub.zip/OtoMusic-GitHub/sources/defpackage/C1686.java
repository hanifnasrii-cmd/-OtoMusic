package defpackage;

import android.content.Context;
import com.piyush.music.models.Playlist;

/* JADX INFO: renamed from: е̟, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1686 extends AbstractC0802 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f16774a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Context f16775a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C5611j f16776a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1686(Context context, C5611j c5611j, int i) {
        super(2);
        this.f16774a = i;
        this.f16775a = context;
        this.f16776a = c5611j;
    }

    @Override // defpackage.AbstractC0802
    /* JADX INFO: renamed from: á */
    public final void mo1025a() {
        switch (this.f16774a) {
            case 0:
                Playlist playlist = (Playlist) C6174p.f10843a;
                C5482j c5482j = (C5482j) this.f14037a;
                c5482j.mo4305a(C2152.f18533a);
                C5631j c5631j = this.f16776a.f8936a;
                c5482j.m4308a(c5631j, new C4235a(new C4754e(c5482j, c5631j, new C4221a(playlist, 18, this), 1), 26));
                break;
            default:
                C5482j c5482j2 = (C5482j) this.f14037a;
                c5482j2.mo4305a(C2152.f18533a);
                c5482j2.m4308a(this.f16776a.f8937a, new C4235a(new C4032a(23, this), 14));
                break;
        }
    }
}
