package defpackage;

import android.media.MediaRouter;

/* JADX INFO: renamed from: ȏ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5698o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C5433j f9247a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final MediaRouter.UserRouteInfo f9248a;

    public C5698o(C5433j c5433j, MediaRouter.UserRouteInfo userRouteInfo) {
        this.f9247a = c5433j;
        this.f9248a = userRouteInfo;
    }
}
