package defpackage;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextPaint;

/* JADX INFO: renamed from: օⷬ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3952 extends AbstractC1545 {

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ Context f24139a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final /* synthetic */ TextPaint f24140a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final /* synthetic */ AbstractC1545 f24141a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final /* synthetic */ C3953 f24142a;

    public C3952(C3953 c3953, Context context, TextPaint textPaint, AbstractC1545 abstractC1545) {
        super(22);
        this.f24142a = c3953;
        this.f24139a = context;
        this.f24140a = textPaint;
        this.f24141a = abstractC1545;
    }

    @Override // defpackage.AbstractC1545
    /* JADX INFO: renamed from: ḁ */
    public final void mo7887a(int i) {
        this.f24141a.mo7887a(i);
    }

    @Override // defpackage.AbstractC1545
    /* JADX INFO: renamed from: a̦ */
    public final void mo7888a(Typeface typeface, boolean z) {
        this.f24142a.m11117a(this.f24139a, this.f24140a, typeface);
        this.f24141a.mo7888a(typeface, z);
    }
}
