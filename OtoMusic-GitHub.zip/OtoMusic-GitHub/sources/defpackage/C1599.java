package defpackage;

import java.util.Arrays;

/* JADX INFO: renamed from: а⃖, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1599 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float[] f16522a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f16523a;

    public C1599(float[] fArr, int i) {
        this.f16522a = fArr;
        this.f16523a = i;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1599)) {
            return false;
        }
        C1599 c1599 = (C1599) obj;
        return AbstractC3098.m10094a(this.f16522a, c1599.f16522a) && this.f16523a == c1599.f16523a;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f16523a) + (Arrays.hashCode(this.f16522a) * 31);
    }

    public final String toString() {
        return "BandSeries(db=" + Arrays.toString(this.f16522a) + ", color=" + this.f16523a + ")";
    }
}
