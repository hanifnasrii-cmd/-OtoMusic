package defpackage;

import android.media.MediaCodec;
import android.os.Bundle;
import android.os.HandlerThread;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: renamed from: аٰ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1524 implements InterfaceC0305 {

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final ArrayDeque f16200a = new ArrayDeque();

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final Object f16201a = new Object();

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final MediaCodec f16202a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final HandlerThread f16203a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public HandlerC1522 f16204a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final AtomicReference f16205a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C2913 f16206a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public boolean f16207a;

    public C1524(MediaCodec mediaCodec, HandlerThread handlerThread) {
        C2913 c2913 = new C2913();
        this.f16202a = mediaCodec;
        this.f16203a = handlerThread;
        this.f16206a = c2913;
        this.f16205a = new AtomicReference();
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static C1523 m7782a() {
        ArrayDeque arrayDeque = f16200a;
        synchronized (arrayDeque) {
            try {
                if (arrayDeque.isEmpty()) {
                    return new C1523();
                }
                return (C1523) arrayDeque.removeFirst();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.InterfaceC0305
    /* JADX INFO: renamed from: à */
    public final void mo3674a(int i, C1339 c1339, long j) {
        mo3679a();
        C1523 c1523M7782a = m7782a();
        c1523M7782a.f16195a = i;
        c1523M7782a.f16196a = 0;
        c1523M7782a.f16198a = j;
        c1523M7782a.f16199a = 0;
        MediaCodec.CryptoInfo cryptoInfo = c1523M7782a.f16197a;
        c1339.getClass();
        cryptoInfo.numSubSamples = 0;
        int[] iArr = (int[]) c1339.f15648a;
        int[] iArrCopyOf = cryptoInfo.numBytesOfClearData;
        if (iArr != null) {
            if (iArrCopyOf == null || iArrCopyOf.length < iArr.length) {
                iArrCopyOf = Arrays.copyOf(iArr, iArr.length);
            } else {
                System.arraycopy(iArr, 0, iArrCopyOf, 0, iArr.length);
            }
        }
        cryptoInfo.numBytesOfClearData = iArrCopyOf;
        cryptoInfo.numBytesOfEncryptedData = cryptoInfo.numBytesOfEncryptedData;
        byte[] bArr = cryptoInfo.key;
        bArr.getClass();
        cryptoInfo.key = bArr;
        byte[] bArr2 = cryptoInfo.iv;
        bArr2.getClass();
        cryptoInfo.iv = bArr2;
        cryptoInfo.mode = 0;
        cryptoInfo.setPattern(new MediaCodec.CryptoInfo.Pattern(0, 0));
        HandlerC1522 handlerC1522 = this.f16204a;
        String str = AbstractC6205p.f10911a;
        handlerC1522.obtainMessage(2, c1523M7782a).sendToTarget();
    }

    @Override // defpackage.InterfaceC0305
    /* JADX INFO: renamed from: á */
    public final void mo3675a(Bundle bundle) {
        mo3679a();
        HandlerC1522 handlerC1522 = this.f16204a;
        String str = AbstractC6205p.f10911a;
        handlerC1522.obtainMessage(4, bundle).sendToTarget();
    }

    @Override // defpackage.InterfaceC0305
    /* JADX INFO: renamed from: â */
    public final void mo3676a(int i, int i2, long j, int i3) {
        mo3679a();
        C1523 c1523M7782a = m7782a();
        c1523M7782a.f16195a = i;
        c1523M7782a.f16196a = i2;
        c1523M7782a.f16198a = j;
        c1523M7782a.f16199a = i3;
        HandlerC1522 handlerC1522 = this.f16204a;
        String str = AbstractC6205p.f10911a;
        handlerC1522.obtainMessage(1, c1523M7782a).sendToTarget();
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m7783a() {
        HandlerC1522 handlerC1522 = this.f16204a;
        handlerC1522.getClass();
        handlerC1522.removeCallbacksAndMessages(null);
        C2913 c2913 = this.f16206a;
        synchronized (c2913) {
            c2913.f20939a = false;
        }
        HandlerC1522 handlerC15222 = this.f16204a;
        handlerC15222.getClass();
        handlerC15222.obtainMessage(3).sendToTarget();
        C2913 c29132 = this.f16206a;
        synchronized (c29132) {
            while (!c29132.f20939a) {
                c29132.f20938a.getClass();
                c29132.wait();
            }
        }
    }

    @Override // defpackage.InterfaceC0305
    /* JADX INFO: renamed from: ȧ */
    public final void mo3679a() {
        RuntimeException runtimeException = (RuntimeException) this.f16205a.getAndSet(null);
        if (runtimeException != null) {
            throw runtimeException;
        }
    }

    @Override // defpackage.InterfaceC0305
    public final void flush() {
        if (this.f16207a) {
            try {
                m7783a();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e);
            }
        }
    }

    @Override // defpackage.InterfaceC0305
    public final void shutdown() {
        if (this.f16207a) {
            flush();
            this.f16203a.quit();
        }
        this.f16207a = false;
    }

    @Override // defpackage.InterfaceC0305
    public final void start() {
        if (this.f16207a) {
            return;
        }
        HandlerThread handlerThread = this.f16203a;
        handlerThread.start();
        this.f16204a = new HandlerC1522(this, handlerThread.getLooper());
        this.f16207a = true;
    }
}
