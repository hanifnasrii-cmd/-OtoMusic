package defpackage;

/* JADX INFO: renamed from: сٓ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2835 implements InterfaceC2830 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC2178 f20672a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C4557c f20673a = new C4557c(1);

    public C2835(AbstractC2178 abstractC2178) {
        this.f20672a = abstractC2178;
    }
}
