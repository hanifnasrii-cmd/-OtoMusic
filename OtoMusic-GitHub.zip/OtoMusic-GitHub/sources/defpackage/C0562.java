package defpackage;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: renamed from: οܺ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0562 extends AbstractC4070a implements InterfaceC3044 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final C0562 f13492a = new C0562(new Object[0]);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Object[] f13493a;

    public C0562(Object[] objArr) {
        this.f13493a = objArr;
    }

    @Override // defpackage.AbstractC4033a
    /* JADX INFO: renamed from: ã */
    public final int mo684a() {
        return this.f13493a.length;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final AbstractC4070a m6448a(Collection collection) {
        Object[] objArr = this.f13493a;
        if (collection.size() + objArr.length > 32) {
            C3615 c3615M6449a = m6449a();
            c3615M6449a.addAll(collection);
            return c3615M6449a.m10799a();
        }
        Object[] objArrCopyOf = Arrays.copyOf(objArr, collection.size() + objArr.length);
        AbstractC3098.m10102a(objArrCopyOf, "copyOf(...)");
        int length = objArr.length;
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            objArrCopyOf[length] = it.next();
            length++;
        }
        return new C0562(objArrCopyOf);
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C3615 m6449a() {
        return new C3615(this, null, this.f13493a, 0);
    }

    @Override // java.util.List
    public final Object get(int i) {
        AbstractC2451.m9018a(i, mo684a());
        return this.f13493a[i];
    }

    @Override // defpackage.AbstractC4050a, java.util.List
    public final int indexOf(Object obj) {
        return AbstractC1458.m7710a(obj, this.f13493a);
    }

    @Override // defpackage.AbstractC4050a, java.util.List
    public final int lastIndexOf(Object obj) {
        Object[] objArr = this.f13493a;
        AbstractC3098.m10103a(objArr, "<this>");
        if (obj == null) {
            int length = objArr.length - 1;
            if (length >= 0) {
                while (true) {
                    int i = length - 1;
                    if (objArr[length] == null) {
                        return length;
                    }
                    if (i < 0) {
                        break;
                    }
                    length = i;
                }
            }
        } else {
            int length2 = objArr.length - 1;
            if (length2 >= 0) {
                while (true) {
                    int i2 = length2 - 1;
                    if (obj.equals(objArr[length2])) {
                        return length2;
                    }
                    if (i2 < 0) {
                        break;
                    }
                    length2 = i2;
                }
            }
        }
        return -1;
    }

    @Override // defpackage.AbstractC4050a, java.util.List
    public final ListIterator listIterator(int i) {
        Object[] objArr = this.f13493a;
        AbstractC2451.m9019a(i, objArr.length);
        return new C4630c(objArr, i, objArr.length);
    }
}
