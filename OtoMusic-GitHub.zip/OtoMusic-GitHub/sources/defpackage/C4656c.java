package defpackage;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.util.Log;
import com.piyush.taglib.AudioProperties;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

/* JADX INFO: renamed from: c⳯, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4656c implements InterfaceC2125 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f5582a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object f5583a;

    public C4656c(int i) {
        this.f5582a = i;
        switch (i) {
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                this.f5583a = new C4656c(2);
                break;
            case 2:
                this.f5583a = new C0869();
                break;
            default:
                this.f5583a = new C4656c(2);
                break;
        }
    }

    @Override // defpackage.InterfaceC2125
    /* JADX INFO: renamed from: à */
    public final InterfaceC2122 mo1211a(Object obj, int i, int i2, C3515 c3515) {
        switch (this.f5582a) {
            case 0:
                return ((C4656c) this.f5583a).m2740a(ImageDecoder.createSource((ByteBuffer) obj), i, i2, c3515);
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return ((C4656c) this.f5583a).m2740a(ImageDecoder.createSource(AbstractC4662c.m2755a((InputStream) obj)), i, i2, c3515);
            default:
                return m2740a((ImageDecoder.Source) obj, i, i2, c3515);
        }
    }

    @Override // defpackage.InterfaceC2125
    /* JADX INFO: renamed from: á */
    public final /* bridge */ /* synthetic */ boolean mo1212a(Object obj, C3515 c3515) {
        switch (this.f5582a) {
            case 0:
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                break;
            default:
                break;
        }
        return true;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C4547c m2740a(ImageDecoder.Source source, int i, int i2, C3515 c3515) throws IOException {
        Bitmap bitmapDecodeBitmap = ImageDecoder.decodeBitmap(source, new C1216(i, i2, c3515));
        if (Log.isLoggable("BitmapImageDecoder", 2)) {
            bitmapDecodeBitmap.getWidth();
            bitmapDecodeBitmap.getHeight();
        }
        return new C4547c((C0869) this.f5583a, bitmapDecodeBitmap);
    }
}
