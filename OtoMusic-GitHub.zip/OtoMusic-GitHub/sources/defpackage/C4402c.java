package defpackage;

/* JADX INFO: renamed from: c̩, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4402c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static volatile C4402c f4672a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C0869 f4673a = new C0869();
}
