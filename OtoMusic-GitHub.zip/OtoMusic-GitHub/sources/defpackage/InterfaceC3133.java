package defpackage;

/* JADX INFO: renamed from: іֶ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC3133 {
}
