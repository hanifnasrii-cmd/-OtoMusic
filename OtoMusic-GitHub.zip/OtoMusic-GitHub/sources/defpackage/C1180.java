package defpackage;

import android.content.Context;

/* JADX INFO: renamed from: ϲٓ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1180 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f14977a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C1532 f14978a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C1182 f14979a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public boolean f14980a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C4648c f14981a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public C1585 f14982a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public C1339 f14983a;

    public C1180() {
        this.f14977a = null;
        this.f14978a = C1532.f16241a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C1185 m7269a() {
        AbstractC1545.m7850a(!this.f14980a);
        this.f14980a = true;
        if (this.f14979a == null) {
            this.f14979a = new C1182(new InterfaceC1561[0], 0);
        }
        if (this.f14982a == null) {
            C1339 c1339 = this.f14983a;
            Context context = this.f14977a;
            if (c1339 == null) {
                this.f14983a = new C1339(context, 17, (byte) 0);
            }
            if (this.f14981a == null) {
                this.f14981a = C4648c.f5550a;
            }
            C1584 c1584 = new C1584(context);
            C1532 c1532 = context != null ? null : this.f14978a;
            Context context2 = (Context) c1584.f16430a;
            if (context2 == null) {
                c1584.f16433a = c1532;
            }
            C1339 c13392 = this.f14983a;
            c1584.f16431a = c13392;
            c1584.f16432a = this.f14981a;
            if (c13392 == null) {
                c1584.f16431a = new C1339(context2, 17, (byte) 0);
            }
            this.f14982a = new C1585(c1584);
        } else {
            AbstractC1545.m7850a(this.f14983a == null);
            AbstractC1545.m7850a(this.f14981a == null);
        }
        return new C1185(this);
    }

    public C1180(Context context) {
        this.f14977a = context;
        this.f14978a = C1532.f16241a;
    }
}
