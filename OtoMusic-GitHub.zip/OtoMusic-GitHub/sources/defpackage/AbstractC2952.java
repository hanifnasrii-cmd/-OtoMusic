package defpackage;

/* JADX INFO: renamed from: сⷥ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC2952 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f21057a;

    static {
        int[] iArr = new int[EnumC2969.values().length];
        f21057a = iArr;
        try {
            iArr[EnumC2969.FIXED.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            f21057a[EnumC2969.WRAP_CONTENT.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            f21057a[EnumC2969.MATCH_PARENT.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            f21057a[EnumC2969.MATCH_CONSTRAINT.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
    }
}
