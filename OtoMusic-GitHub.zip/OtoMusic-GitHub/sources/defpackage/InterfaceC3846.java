package defpackage;

/* JADX INFO: renamed from: օۚ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC3846 {
    /* JADX INFO: renamed from: à */
    String mo4907a();

    /* JADX INFO: renamed from: a̎ */
    void mo4911a(InterfaceC3845 interfaceC3845);
}
