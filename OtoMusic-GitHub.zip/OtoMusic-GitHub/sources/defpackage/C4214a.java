package defpackage;

import android.content.Context;

/* JADX INFO: renamed from: aۚ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4214a implements InterfaceC5553j {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C3511 f1395a = C3511.m10664a("use_media_store");

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f1396a;

    public C4214a(Context context) {
        this.f1396a = context;
    }

    @Override // defpackage.InterfaceC5553j
    public final C5552j buildLoadData(Object obj, int i, int i2, C3515 c3515) {
        C4247a c4247a = (C4247a) obj;
        return new C5552j(c4247a, new C1538(c4247a.f1511a, this.f1396a, AbstractC3098.m10094a(c3515.m10665a(f1395a), Boolean.TRUE)));
    }

    @Override // defpackage.InterfaceC5553j
    public final /* bridge */ /* synthetic */ boolean handles(Object obj) {
        return true;
    }
}
