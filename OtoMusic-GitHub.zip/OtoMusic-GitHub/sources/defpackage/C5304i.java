package defpackage;

import com.piyush.music.models.Album;
import com.piyush.music.models.Artist;
import com.piyush.taglib.AudioProperties;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: renamed from: i⃥, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5304i implements Comparator {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f7866a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ LinkedHashMap f7867a;

    public /* synthetic */ C5304i(LinkedHashMap linkedHashMap, int i) {
        this.f7866a = i;
        this.f7867a = linkedHashMap;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f7866a) {
            case 0:
                Album album = (Album) obj;
                C5301i c5301i = new C5301i(album.getTitle(), album.getAlbumArtist());
                LinkedHashMap linkedHashMap = this.f7867a;
                Integer num = (Integer) linkedHashMap.get(c5301i);
                Integer numValueOf = Integer.valueOf(num != null ? num.intValue() : Integer.MAX_VALUE);
                Album album2 = (Album) obj2;
                Integer num2 = (Integer) linkedHashMap.get(new C5301i(album2.getTitle(), album2.getAlbumArtist()));
                return AbstractC3098.m10111a(numValueOf, Integer.valueOf(num2 != null ? num2.intValue() : Integer.MAX_VALUE));
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                Map.Entry entry = (Map.Entry) obj2;
                String str = (String) entry.getKey();
                float fIntValue = ((Integer) entry.getValue()).intValue();
                LinkedHashMap linkedHashMap2 = this.f7867a;
                Float f = (Float) linkedHashMap2.get(str);
                float fFloatValue = f != null ? f.floatValue() : 0.0f;
                if (fFloatValue < 0.1f) {
                    fFloatValue = 0.1f;
                }
                Float fValueOf = Float.valueOf(fIntValue * fFloatValue);
                Map.Entry entry2 = (Map.Entry) obj;
                String str2 = (String) entry2.getKey();
                float fIntValue2 = ((Integer) entry2.getValue()).intValue();
                Float f2 = (Float) linkedHashMap2.get(str2);
                float fFloatValue2 = f2 != null ? f2.floatValue() : 0.0f;
                return AbstractC3098.m10111a(fValueOf, Float.valueOf(fIntValue2 * (fFloatValue2 >= 0.1f ? fFloatValue2 : 0.1f)));
            default:
                String actualName = ((Artist) obj).getActualName();
                LinkedHashMap linkedHashMap3 = this.f7867a;
                Integer num3 = (Integer) linkedHashMap3.get(actualName);
                Integer numValueOf2 = Integer.valueOf(num3 != null ? num3.intValue() : Integer.MAX_VALUE);
                Integer num4 = (Integer) linkedHashMap3.get(((Artist) obj2).getActualName());
                return AbstractC3098.m10111a(numValueOf2, Integer.valueOf(num4 != null ? num4.intValue() : Integer.MAX_VALUE));
        }
    }
}
