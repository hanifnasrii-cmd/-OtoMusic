package defpackage;

import android.os.Bundle;

/* JADX INFO: renamed from: а̒, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1342 implements InterfaceC2229 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ AbstractActivityC1344 f15653a;

    public C1342(AbstractActivityC1344 abstractActivityC1344) {
        this.f15653a = abstractActivityC1344;
    }

    @Override // defpackage.InterfaceC2229
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Bundle mo7525a() {
        Bundle bundle = new Bundle();
        this.f15653a.m7526a().getClass();
        return bundle;
    }
}
