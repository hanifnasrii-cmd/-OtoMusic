package defpackage;

/* JADX INFO: renamed from: ο͆, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C0401 extends AbstractC5067i implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C0401 f12904a = new C0401(1, InterfaceC0397.class, "iterator", "iterator()Ljava/util/Iterator;", 0);

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        InterfaceC0397 interfaceC0397 = (InterfaceC0397) obj;
        AbstractC3098.m10103a(interfaceC0397, "p0");
        return interfaceC0397.iterator();
    }
}
