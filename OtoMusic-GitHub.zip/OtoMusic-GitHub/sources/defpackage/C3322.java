package defpackage;

import android.os.Bundle;
import android.os.Parcelable;

/* JADX INFO: renamed from: ј̌, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3322 extends AbstractC3326 {

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final Class f22297a;

    public C3322(Class cls) {
        super(true);
        if (!Parcelable.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException((cls + " does not implement Parcelable.").toString());
        }
        try {
            this.f22297a = Class.forName("[L" + cls.getName() + ';');
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override // defpackage.AbstractC3326
    /* JADX INFO: renamed from: à */
    public final Object mo10388a(String str, Bundle bundle) {
        return (Parcelable[]) AbstractC4164a.m979a(bundle, "bundle", str, "key", str);
    }

    @Override // defpackage.AbstractC3326
    /* JADX INFO: renamed from: á */
    public final String mo10389a() {
        return this.f22297a.getName();
    }

    @Override // defpackage.AbstractC3326
    /* JADX INFO: renamed from: ã */
    public final Object mo10391a(String str) {
        AbstractC3098.m10103a(str, "value");
        throw new UnsupportedOperationException("Arrays don't support default values.");
    }

    @Override // defpackage.AbstractC3326
    /* JADX INFO: renamed from: ā */
    public final void mo10392a(Bundle bundle, String str, Object obj) {
        Parcelable[] parcelableArr = (Parcelable[]) obj;
        AbstractC3098.m10103a(str, "key");
        this.f22297a.cast(parcelableArr);
        bundle.putParcelableArray(str, parcelableArr);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !C3322.class.equals(obj.getClass())) {
            return false;
        }
        return AbstractC3098.m10094a(this.f22297a, ((C3322) obj).f22297a);
    }

    public final int hashCode() {
        return this.f22297a.hashCode();
    }
}
