package defpackage;

/* JADX INFO: renamed from: j͎, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5429j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C5435j f8357a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final AbstractC5428j f8358a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C5427j f8359a = C5427j.f8354a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f8360a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public long f8361a;

    public C5429j(C5435j c5435j, AbstractC5428j abstractC5428j) {
        this.f8357a = c5435j;
        this.f8358a = abstractC5428j;
    }
}
