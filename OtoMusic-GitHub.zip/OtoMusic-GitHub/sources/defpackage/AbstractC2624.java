package defpackage;

/* JADX INFO: renamed from: рⷨ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC2624 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int f19873a = 0;

    static {
        AbstractC2624.class.getClassLoader();
    }
}
