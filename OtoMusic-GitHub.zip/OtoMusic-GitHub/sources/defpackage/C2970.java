package defpackage;

import android.view.View;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: renamed from: сⷷ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C2970 {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public C2725 f21270a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C2725 f21271a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public String f21278a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f21279a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public boolean f21280a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public boolean f21281a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public boolean f21282a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f21283a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public int f21284a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public int f21285a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public int f21286a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public int f21287a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final int[] f21288a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public int f21289a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public int f21290a;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public float f21291a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public int f21292a;

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public int f21293a;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public float f21294a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public int f21295a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public float f21296a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final int[] f21297a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public float f21298a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public boolean f21299a;

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public boolean f21300a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public int f21301a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public int f21302a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final C2946 f21303a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final C2946 f21304a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final C2946 f21305a;

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public final C2946 f21306a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public final C2946 f21307a;

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final C2946 f21308a;

    /* JADX INFO: renamed from: ą, reason: contains not printable characters */
    public final C2946 f21309a;

    /* JADX INFO: renamed from: a̩, reason: contains not printable characters */
    public final C2946 f21310a;

    /* JADX INFO: renamed from: a̪, reason: contains not printable characters */
    public final C2946[] f21311a;

    /* JADX INFO: renamed from: a̫, reason: contains not printable characters */
    public final ArrayList f21312a;

    /* JADX INFO: renamed from: a̬, reason: contains not printable characters */
    public final boolean[] f21313a;

    /* JADX INFO: renamed from: a̭, reason: contains not printable characters */
    public final EnumC2969[] f21314a;

    /* JADX INFO: renamed from: a̮, reason: contains not printable characters */
    public C2970 f21315a;

    /* JADX INFO: renamed from: a̯, reason: contains not printable characters */
    public int f21316a;

    /* JADX INFO: renamed from: a̰, reason: contains not printable characters */
    public int f21317a;

    /* JADX INFO: renamed from: a̱, reason: contains not printable characters */
    public float f21318a;

    /* JADX INFO: renamed from: a̲, reason: contains not printable characters */
    public int f21319a;

    /* JADX INFO: renamed from: a̳, reason: contains not printable characters */
    public int f21320a;

    /* JADX INFO: renamed from: a̴, reason: contains not printable characters */
    public int f21321a;

    /* JADX INFO: renamed from: a̵, reason: contains not printable characters */
    public int f21322a;

    /* JADX INFO: renamed from: a̶, reason: contains not printable characters */
    public int f21323a;

    /* JADX INFO: renamed from: a̷, reason: contains not printable characters */
    public int f21324a;

    /* JADX INFO: renamed from: a̸, reason: contains not printable characters */
    public float f21325a;

    /* JADX INFO: renamed from: a̹, reason: contains not printable characters */
    public float f21326a;

    /* JADX INFO: renamed from: a̺, reason: contains not printable characters */
    public View f21327a;

    /* JADX INFO: renamed from: a̻, reason: contains not printable characters */
    public int f21328a;

    /* JADX INFO: renamed from: a̼, reason: contains not printable characters */
    public String f21329a;

    /* JADX INFO: renamed from: a̽, reason: contains not printable characters */
    public int f21330a;

    /* JADX INFO: renamed from: a̾, reason: contains not printable characters */
    public int f21331a;

    /* JADX INFO: renamed from: a̿, reason: contains not printable characters */
    public final float[] f21332a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C2970[] f21333a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C2970[] f21334a;

    /* JADX INFO: renamed from: a͂, reason: contains not printable characters */
    public int f21335a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public int f21336a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public boolean f21269a = false;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C5336i f21272a = null;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C6234p f21273a = null;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final boolean[] f21274a = {true, true};

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f21275a = true;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f21276a = -1;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public int f21277a = -1;

    public C2970() {
        new HashMap();
        this.f21279a = false;
        this.f21280a = false;
        this.f21281a = false;
        this.f21282a = false;
        this.f21283a = -1;
        this.f21284a = -1;
        this.f21285a = 0;
        this.f21286a = 0;
        this.f21287a = 0;
        this.f21288a = new int[2];
        this.f21289a = 0;
        this.f21290a = 0;
        this.f21291a = 1.0f;
        this.f21292a = 0;
        this.f21293a = 0;
        this.f21294a = 1.0f;
        this.f21295a = -1;
        this.f21296a = 1.0f;
        this.f21297a = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.f21298a = Float.NaN;
        this.f21299a = false;
        this.f21300a = false;
        this.f21301a = 0;
        this.f21302a = 0;
        C2946 c2946 = new C2946(this, EnumC2945.LEFT);
        this.f21303a = c2946;
        C2946 c29462 = new C2946(this, EnumC2945.TOP);
        this.f21304a = c29462;
        C2946 c29463 = new C2946(this, EnumC2945.RIGHT);
        this.f21305a = c29463;
        C2946 c29464 = new C2946(this, EnumC2945.BOTTOM);
        this.f21306a = c29464;
        C2946 c29465 = new C2946(this, EnumC2945.BASELINE);
        this.f21307a = c29465;
        C2946 c29466 = new C2946(this, EnumC2945.CENTER_X);
        this.f21308a = c29466;
        C2946 c29467 = new C2946(this, EnumC2945.CENTER_Y);
        this.f21309a = c29467;
        C2946 c29468 = new C2946(this, EnumC2945.CENTER);
        this.f21310a = c29468;
        this.f21311a = new C2946[]{c2946, c29463, c29462, c29464, c29465, c29468};
        ArrayList arrayList = new ArrayList();
        this.f21312a = arrayList;
        this.f21313a = new boolean[2];
        EnumC2969 enumC2969 = EnumC2969.FIXED;
        this.f21314a = new EnumC2969[]{enumC2969, enumC2969};
        this.f21315a = null;
        this.f21316a = 0;
        this.f21317a = 0;
        this.f21318a = 0.0f;
        this.f21319a = -1;
        this.f21320a = 0;
        this.f21321a = 0;
        this.f21322a = 0;
        this.f21325a = 0.5f;
        this.f21326a = 0.5f;
        this.f21328a = 0;
        this.f21329a = null;
        this.f21330a = 0;
        this.f21331a = 0;
        this.f21332a = new float[]{-1.0f, -1.0f};
        this.f21333a = new C2970[]{null, null};
        this.f21334a = new C2970[]{null, null};
        this.f21335a = -1;
        this.f21336a = -1;
        arrayList.add(c2946);
        arrayList.add(c29462);
        arrayList.add(c29463);
        arrayList.add(c29464);
        arrayList.add(c29466);
        arrayList.add(c29467);
        arrayList.add(c29468);
        arrayList.add(c29465);
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static void m9871a(StringBuilder sb, String str, int i, int i2, int i3, int i4, int i5, float f, EnumC2969 enumC2969) {
        sb.append(str);
        sb.append(" :  {\n");
        String string = enumC2969.toString();
        if (!EnumC2969.FIXED.toString().equals(string)) {
            AbstractC4072a.m757a(sb, "      behavior", " :   ", string, ",\n");
        }
        m9873a(i, 0, "      size", sb);
        m9873a(i2, 0, "      min", sb);
        m9873a(i3, Integer.MAX_VALUE, "      max", sb);
        m9873a(i4, 0, "      matchMin", sb);
        m9873a(i5, 0, "      matchDef", sb);
        m9874a(sb, "      matchPercent", f, 1.0f);
        sb.append("    },\n");
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static void m9872a(StringBuilder sb, String str, C2946 c2946) {
        if (c2946.f21036a == null) {
            return;
        }
        sb.append("    ");
        sb.append(str);
        sb.append(" : [ '");
        sb.append(c2946.f21036a);
        sb.append("'");
        if (c2946.f21038a != Integer.MIN_VALUE || c2946.f21037a != 0) {
            sb.append(",");
            sb.append(c2946.f21037a);
            if (c2946.f21038a != Integer.MIN_VALUE) {
                sb.append(",");
                sb.append(c2946.f21038a);
                sb.append(",");
            }
        }
        sb.append(" ] ,\n");
    }

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public static void m9873a(int i, int i2, String str, StringBuilder sb) {
        if (i == i2) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(i);
        sb.append(",\n");
    }

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public static void m9874a(StringBuilder sb, String str, float f, float f2) {
        if (f == f2) {
            return;
        }
        sb.append(str);
        sb.append(" :   ");
        sb.append(f);
        sb.append(",\n");
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m9875a(C2971 c2971, C0017 c0017, HashSet hashSet, int i, boolean z) {
        if (z) {
            if (!hashSet.contains(this)) {
                return;
            }
            AbstractC2179.m8622a(c2971, c0017, this);
            hashSet.remove(this);
            mo2138a(c0017, c2971.m9913a(64));
        }
        if (i == 0) {
            HashSet hashSet2 = this.f21303a.f21031a;
            if (hashSet2 != null) {
                Iterator it = hashSet2.iterator();
                while (it.hasNext()) {
                    ((C2946) it.next()).f21034a.m9875a(c2971, c0017, hashSet, i, true);
                }
            }
            HashSet hashSet3 = this.f21305a.f21031a;
            if (hashSet3 != null) {
                Iterator it2 = hashSet3.iterator();
                while (it2.hasNext()) {
                    ((C2946) it2.next()).f21034a.m9875a(c2971, c0017, hashSet, i, true);
                }
                return;
            }
            return;
        }
        HashSet hashSet4 = this.f21304a.f21031a;
        if (hashSet4 != null) {
            Iterator it3 = hashSet4.iterator();
            while (it3.hasNext()) {
                ((C2946) it3.next()).f21034a.m9875a(c2971, c0017, hashSet, i, true);
            }
        }
        HashSet hashSet5 = this.f21306a.f21031a;
        if (hashSet5 != null) {
            Iterator it4 = hashSet5.iterator();
            while (it4.hasNext()) {
                ((C2946) it4.next()).f21034a.m9875a(c2971, c0017, hashSet, i, true);
            }
        }
        HashSet hashSet6 = this.f21307a.f21031a;
        if (hashSet6 != null) {
            Iterator it5 = hashSet6.iterator();
            while (it5.hasNext()) {
                ((C2946) it5.next()).f21034a.m9875a(c2971, c0017, hashSet, i, true);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:122:0x0207  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x020f  */
    /* JADX WARN: Removed duplicated region for block: B:129:0x0218  */
    /* JADX WARN: Removed duplicated region for block: B:158:0x028e  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x029d  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x02a6  */
    /* JADX WARN: Removed duplicated region for block: B:166:0x02a9  */
    /* JADX WARN: Removed duplicated region for block: B:169:0x02b9  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x02c0  */
    /* JADX WARN: Removed duplicated region for block: B:174:0x02c7  */
    /* JADX WARN: Removed duplicated region for block: B:176:0x02cc  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x02eb  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:273:0x03fb  */
    /* JADX WARN: Removed duplicated region for block: B:277:0x0413  */
    /* JADX WARN: Removed duplicated region for block: B:281:0x041c  */
    /* JADX WARN: Removed duplicated region for block: B:284:0x0420  */
    /* JADX WARN: Removed duplicated region for block: B:289:0x042c  */
    /* JADX WARN: Removed duplicated region for block: B:292:0x0435  */
    /* JADX WARN: Removed duplicated region for block: B:295:0x043c  */
    /* JADX WARN: Removed duplicated region for block: B:297:0x0440  */
    /* JADX WARN: Removed duplicated region for block: B:300:0x045c  */
    /* JADX WARN: Removed duplicated region for block: B:336:0x054b  */
    /* JADX WARN: Removed duplicated region for block: B:338:0x0561  */
    /* JADX WARN: Removed duplicated region for block: B:354:0x05b2  */
    /* JADX WARN: Removed duplicated region for block: B:357:0x05c2  */
    /* JADX WARN: Removed duplicated region for block: B:359:0x05c5  */
    /* JADX WARN: Removed duplicated region for block: B:381:0x05fb  */
    /* JADX WARN: Removed duplicated region for block: B:396:0x0687  */
    /* JADX WARN: Removed duplicated region for block: B:398:0x068d  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:404:0x06eb  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0100  */
    /* JADX WARN: Type inference failed for: r10v20 */
    /* JADX WARN: Type inference failed for: r10v26 */
    /* JADX WARN: Type inference failed for: r10v27 */
    /* JADX WARN: Type inference failed for: r12v24 */
    /* JADX WARN: Type inference failed for: r12v25 */
    /* JADX WARN: Type inference failed for: r12v36 */
    /* JADX WARN: Type inference failed for: r12v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r17v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r17v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r18v2 */
    /* JADX WARN: Type inference failed for: r19v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r19v11 */
    /* JADX WARN: Type inference failed for: r19v15 */
    /* JADX WARN: Type inference failed for: r19v16 */
    /* JADX WARN: Type inference failed for: r19v5 */
    /* JADX WARN: Type inference failed for: r19v6 */
    /* JADX WARN: Type inference failed for: r19v9 */
    /* JADX WARN: Type inference failed for: r20v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r27v3 */
    /* JADX WARN: Type inference failed for: r27v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r27v6 */
    /* JADX WARN: Type inference failed for: r27v7 */
    /* JADX WARN: Type inference failed for: r27v8 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r3v22 */
    /* JADX WARN: Type inference failed for: r3v23 */
    /* JADX WARN: Type inference failed for: r4v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r60v0, types: [сⷷ] */
    /* JADX INFO: renamed from: á */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void mo2138a(defpackage.C0017 r61, boolean r62) {
        /*
            Method dump skipped, instruction units count: 1954
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2970.mo2138a(ι̑, boolean):void");
    }

    /* JADX INFO: renamed from: â */
    public boolean mo2139a() {
        return this.f21328a != 8;
    }

    /* JADX WARN: Removed duplicated region for block: B:218:0x03b8 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:221:0x03c1  */
    /* JADX WARN: Removed duplicated region for block: B:223:0x03c5  */
    /* JADX WARN: Removed duplicated region for block: B:232:0x03ff  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x041c  */
    /* JADX WARN: Removed duplicated region for block: B:258:0x044f  */
    /* JADX WARN: Removed duplicated region for block: B:260:0x0455  */
    /* JADX WARN: Removed duplicated region for block: B:288:0x0490 A[PHI: r3
      0x0490: PHI (r3v17 int) = (r3v16 int), (r3v21 int), (r3v21 int), (r3v21 int) binds: [B:281:0x0480, B:283:0x0486, B:284:0x0488, B:286:0x048c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:291:0x04a2  */
    /* JADX WARN: Removed duplicated region for block: B:304:0x04c3  */
    /* JADX WARN: Removed duplicated region for block: B:309:0x04d1 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:338:0x0520  */
    /* JADX WARN: Removed duplicated region for block: B:346:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m9876a(defpackage.C0017 r30, boolean r31, boolean r32, boolean r33, boolean r34, defpackage.C0598 r35, defpackage.C0598 r36, defpackage.EnumC2969 r37, boolean r38, defpackage.C2946 r39, defpackage.C2946 r40, int r41, int r42, int r43, int r44, float r45, boolean r46, boolean r47, boolean r48, boolean r49, boolean r50, int r51, int r52, int r53, int r54, float r55, boolean r56) {
        /*
            Method dump skipped, instruction units count: 1322
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2970.m9876a(ι̑, boolean, boolean, boolean, boolean, ο߳, ο߳, сⷶ, boolean, с⵿, с⵿, int, int, int, int, float, boolean, boolean, boolean, boolean, boolean, int, int, int, int, float, boolean):void");
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final void m9877a(EnumC2945 enumC2945, C2970 c2970, EnumC2945 enumC29452, int i) {
        EnumC2945 enumC29453;
        EnumC2945 enumC29454;
        boolean z;
        EnumC2945 enumC29455 = EnumC2945.CENTER;
        if (enumC2945 == enumC29455) {
            if (enumC29452 != enumC29455) {
                EnumC2945 enumC29456 = EnumC2945.LEFT;
                if (enumC29452 == enumC29456 || enumC29452 == EnumC2945.RIGHT) {
                    m9877a(enumC29456, c2970, enumC29452, 0);
                    m9877a(EnumC2945.RIGHT, c2970, enumC29452, 0);
                    mo3831a(enumC29455).m9825a(c2970.mo3831a(enumC29452), 0);
                    return;
                }
                EnumC2945 enumC29457 = EnumC2945.TOP;
                if (enumC29452 == enumC29457 || enumC29452 == EnumC2945.BOTTOM) {
                    m9877a(enumC29457, c2970, enumC29452, 0);
                    m9877a(EnumC2945.BOTTOM, c2970, enumC29452, 0);
                    mo3831a(enumC29455).m9825a(c2970.mo3831a(enumC29452), 0);
                    return;
                }
                return;
            }
            EnumC2945 enumC29458 = EnumC2945.LEFT;
            C2946 c2946Mo3831a = mo3831a(enumC29458);
            EnumC2945 enumC29459 = EnumC2945.RIGHT;
            C2946 c2946Mo3831a2 = mo3831a(enumC29459);
            EnumC2945 enumC294510 = EnumC2945.TOP;
            C2946 c2946Mo3831a3 = mo3831a(enumC294510);
            EnumC2945 enumC294511 = EnumC2945.BOTTOM;
            C2946 c2946Mo3831a4 = mo3831a(enumC294511);
            boolean z2 = true;
            if ((c2946Mo3831a == null || !c2946Mo3831a.m9832a()) && (c2946Mo3831a2 == null || !c2946Mo3831a2.m9832a())) {
                m9877a(enumC29458, c2970, enumC29458, 0);
                m9877a(enumC29459, c2970, enumC29459, 0);
                z = true;
            } else {
                z = false;
            }
            if ((c2946Mo3831a3 == null || !c2946Mo3831a3.m9832a()) && (c2946Mo3831a4 == null || !c2946Mo3831a4.m9832a())) {
                m9877a(enumC294510, c2970, enumC294510, 0);
                m9877a(enumC294511, c2970, enumC294511, 0);
            } else {
                z2 = false;
            }
            if (z && z2) {
                mo3831a(enumC29455).m9825a(c2970.mo3831a(enumC29455), 0);
                return;
            }
            if (z) {
                EnumC2945 enumC294512 = EnumC2945.CENTER_X;
                mo3831a(enumC294512).m9825a(c2970.mo3831a(enumC294512), 0);
                return;
            } else {
                if (z2) {
                    EnumC2945 enumC294513 = EnumC2945.CENTER_Y;
                    mo3831a(enumC294513).m9825a(c2970.mo3831a(enumC294513), 0);
                    return;
                }
                return;
            }
        }
        EnumC2945 enumC294514 = EnumC2945.CENTER_X;
        if (enumC2945 == enumC294514 && (enumC29452 == (enumC29454 = EnumC2945.LEFT) || enumC29452 == EnumC2945.RIGHT)) {
            C2946 c2946Mo3831a5 = mo3831a(enumC29454);
            C2946 c2946Mo3831a6 = c2970.mo3831a(enumC29452);
            C2946 c2946Mo3831a7 = mo3831a(EnumC2945.RIGHT);
            c2946Mo3831a5.m9825a(c2946Mo3831a6, 0);
            c2946Mo3831a7.m9825a(c2946Mo3831a6, 0);
            mo3831a(enumC294514).m9825a(c2946Mo3831a6, 0);
            return;
        }
        EnumC2945 enumC294515 = EnumC2945.CENTER_Y;
        if (enumC2945 == enumC294515 && (enumC29452 == (enumC29453 = EnumC2945.TOP) || enumC29452 == EnumC2945.BOTTOM)) {
            C2946 c2946Mo3831a8 = c2970.mo3831a(enumC29452);
            mo3831a(enumC29453).m9825a(c2946Mo3831a8, 0);
            mo3831a(EnumC2945.BOTTOM).m9825a(c2946Mo3831a8, 0);
            mo3831a(enumC294515).m9825a(c2946Mo3831a8, 0);
            return;
        }
        if (enumC2945 == enumC294514 && enumC29452 == enumC294514) {
            EnumC2945 enumC294516 = EnumC2945.LEFT;
            mo3831a(enumC294516).m9825a(c2970.mo3831a(enumC294516), 0);
            EnumC2945 enumC294517 = EnumC2945.RIGHT;
            mo3831a(enumC294517).m9825a(c2970.mo3831a(enumC294517), 0);
            mo3831a(enumC294514).m9825a(c2970.mo3831a(enumC29452), 0);
            return;
        }
        if (enumC2945 == enumC294515 && enumC29452 == enumC294515) {
            EnumC2945 enumC294518 = EnumC2945.TOP;
            mo3831a(enumC294518).m9825a(c2970.mo3831a(enumC294518), 0);
            EnumC2945 enumC294519 = EnumC2945.BOTTOM;
            mo3831a(enumC294519).m9825a(c2970.mo3831a(enumC294519), 0);
            mo3831a(enumC294515).m9825a(c2970.mo3831a(enumC29452), 0);
            return;
        }
        C2946 c2946Mo3831a9 = mo3831a(enumC2945);
        C2946 c2946Mo3831a10 = c2970.mo3831a(enumC29452);
        if (c2946Mo3831a9.m9833a(c2946Mo3831a10)) {
            EnumC2945 enumC294520 = EnumC2945.BASELINE;
            if (enumC2945 == enumC294520) {
                C2946 c2946Mo3831a11 = mo3831a(EnumC2945.TOP);
                C2946 c2946Mo3831a12 = mo3831a(EnumC2945.BOTTOM);
                if (c2946Mo3831a11 != null) {
                    c2946Mo3831a11.m9834a();
                }
                if (c2946Mo3831a12 != null) {
                    c2946Mo3831a12.m9834a();
                }
            } else if (enumC2945 == EnumC2945.TOP || enumC2945 == EnumC2945.BOTTOM) {
                C2946 c2946Mo3831a13 = mo3831a(enumC294520);
                if (c2946Mo3831a13 != null) {
                    c2946Mo3831a13.m9834a();
                }
                C2946 c2946Mo3831a14 = mo3831a(enumC29455);
                if (c2946Mo3831a14.f21036a != c2946Mo3831a10) {
                    c2946Mo3831a14.m9834a();
                }
                C2946 c2946M9830a = mo3831a(enumC2945).m9830a();
                C2946 c2946Mo3831a15 = mo3831a(enumC294515);
                if (c2946Mo3831a15.m9832a()) {
                    c2946M9830a.m9834a();
                    c2946Mo3831a15.m9834a();
                }
            } else if (enumC2945 == EnumC2945.LEFT || enumC2945 == EnumC2945.RIGHT) {
                C2946 c2946Mo3831a16 = mo3831a(enumC29455);
                if (c2946Mo3831a16.f21036a != c2946Mo3831a10) {
                    c2946Mo3831a16.m9834a();
                }
                C2946 c2946M9830a2 = mo3831a(enumC2945).m9830a();
                C2946 c2946Mo3831a17 = mo3831a(enumC294514);
                if (c2946Mo3831a17.m9832a()) {
                    c2946M9830a2.m9834a();
                    c2946Mo3831a17.m9834a();
                }
            }
            c2946Mo3831a9.m9825a(c2946Mo3831a10, i);
        }
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void m9878a(C2946 c2946, C2946 c29462, int i) {
        if (c2946.f21034a == this) {
            m9877a(c2946.f21035a, c29462.f21034a, c29462.f21035a, i);
        }
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void m9879a(C0017 c0017) {
        c0017.m5767a(this.f21303a);
        c0017.m5767a(this.f21304a);
        c0017.m5767a(this.f21305a);
        c0017.m5767a(this.f21306a);
        if (this.f21322a > 0) {
            c0017.m5767a(this.f21307a);
        }
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m9880a() {
        if (this.f21272a == null) {
            this.f21272a = new C5336i(this);
        }
        if (this.f21273a == null) {
            this.f21273a = new C6234p(this);
        }
    }

    /* JADX INFO: renamed from: ä */
    public C2946 mo3831a(EnumC2945 enumC2945) {
        switch (AbstractC2968.f21268a[enumC2945.ordinal()]) {
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return this.f21303a;
            case 2:
                return this.f21304a;
            case 3:
                return this.f21305a;
            case 4:
                return this.f21306a;
            case 5:
                return this.f21307a;
            case 6:
                return this.f21310a;
            case 7:
                return this.f21308a;
            case 8:
                return this.f21309a;
            case 9:
                return null;
            default:
                throw new AssertionError(enumC2945.name());
        }
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final EnumC2969 m9881a(int i) {
        EnumC2969[] enumC2969Arr = this.f21314a;
        if (i == 0) {
            return enumC2969Arr[0];
        }
        if (i == 1) {
            return enumC2969Arr[1];
        }
        return null;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final int m9882a() {
        if (this.f21328a == 8) {
            return 0;
        }
        return this.f21317a;
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final C2970 m9883a(int i) {
        C2946 c2946;
        C2946 c29462;
        if (i != 0) {
            if (i == 1 && (c29462 = (c2946 = this.f21306a).f21036a) != null && c29462.f21036a == c2946) {
                return c29462.f21034a;
            }
            return null;
        }
        C2946 c29463 = this.f21305a;
        C2946 c29464 = c29463.f21036a;
        if (c29464 == null || c29464.f21036a != c29463) {
            return null;
        }
        return c29464.f21034a;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final C2970 m9884a(int i) {
        C2946 c2946;
        C2946 c29462;
        if (i != 0) {
            if (i == 1 && (c29462 = (c2946 = this.f21304a).f21036a) != null && c29462.f21036a == c2946) {
                return c29462.f21034a;
            }
            return null;
        }
        C2946 c29463 = this.f21303a;
        C2946 c29464 = c29463.f21036a;
        if (c29464 == null || c29464.f21036a != c29463) {
            return null;
        }
        return c29464.f21034a;
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public void mo9885a(StringBuilder sb) {
        sb.append("  " + this.f21278a + ":{\n");
        StringBuilder sb2 = new StringBuilder("    actualWidth:");
        sb2.append(this.f21316a);
        sb.append(sb2.toString());
        sb.append("\n");
        sb.append("    actualHeight:" + this.f21317a);
        sb.append("\n");
        sb.append("    actualLeft:" + this.f21320a);
        sb.append("\n");
        sb.append("    actualTop:" + this.f21321a);
        sb.append("\n");
        m9872a(sb, "left", this.f21303a);
        m9872a(sb, "top", this.f21304a);
        m9872a(sb, "right", this.f21305a);
        m9872a(sb, "bottom", this.f21306a);
        m9872a(sb, "baseline", this.f21307a);
        m9872a(sb, "centerX", this.f21308a);
        m9872a(sb, "centerY", this.f21309a);
        int i = this.f21316a;
        int i2 = this.f21323a;
        int[] iArr = this.f21297a;
        int i3 = iArr[0];
        int i4 = this.f21289a;
        int i5 = this.f21286a;
        float f = this.f21291a;
        EnumC2969[] enumC2969Arr = this.f21314a;
        EnumC2969 enumC2969 = enumC2969Arr[0];
        float[] fArr = this.f21332a;
        float f2 = fArr[0];
        m9871a(sb, "    width", i, i2, i3, i4, i5, f, enumC2969);
        int i6 = this.f21317a;
        int i7 = this.f21324a;
        int i8 = iArr[1];
        int i9 = this.f21292a;
        int i10 = this.f21287a;
        float f3 = this.f21294a;
        EnumC2969 enumC29692 = enumC2969Arr[1];
        float f4 = fArr[1];
        m9871a(sb, "    height", i6, i7, i8, i9, i10, f3, enumC29692);
        float f5 = this.f21318a;
        int i11 = this.f21319a;
        if (f5 != 0.0f) {
            sb.append("    dimensionRatio");
            sb.append(" :  [");
            sb.append(f5);
            sb.append(",");
            sb.append(i11);
            sb.append("");
            sb.append("],\n");
        }
        m9874a(sb, "    horizontalBias", this.f21325a, 0.5f);
        m9874a(sb, "    verticalBias", this.f21326a, 0.5f);
        m9873a(this.f21330a, 0, "    horizontalChainStyle", sb);
        m9873a(this.f21331a, 0, "    verticalChainStyle", sb);
        sb.append("  }");
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final int m9886a() {
        if (this.f21328a == 8) {
            return 0;
        }
        return this.f21316a;
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final int m9887a() {
        C2970 c2970 = this.f21315a;
        return (c2970 == null || !(c2970 instanceof C2971)) ? this.f21320a : ((C2971) c2970).f21344a + this.f21320a;
    }

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final int m9888a() {
        C2970 c2970 = this.f21315a;
        return (c2970 == null || !(c2970 instanceof C2971)) ? this.f21321a : ((C2971) c2970).f21345a + this.f21321a;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x003a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x003b A[RETURN] */
    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean m9889a(int r5) {
        /*
            r4 = this;
            r0 = 2
            r1 = 0
            r2 = 1
            if (r5 != 0) goto L1b
            с⵿ r5 = r4.f21303a
            с⵿ r5 = r5.f21036a
            if (r5 == 0) goto Ld
            r5 = r2
            goto Le
        Ld:
            r5 = r1
        Le:
            с⵿ r3 = r4.f21305a
            с⵿ r3 = r3.f21036a
            if (r3 == 0) goto L16
            r3 = r2
            goto L17
        L16:
            r3 = r1
        L17:
            int r5 = r5 + r3
            if (r5 >= r0) goto L3b
            goto L3a
        L1b:
            с⵿ r5 = r4.f21304a
            с⵿ r5 = r5.f21036a
            if (r5 == 0) goto L23
            r5 = r2
            goto L24
        L23:
            r5 = r1
        L24:
            с⵿ r3 = r4.f21306a
            с⵿ r3 = r3.f21036a
            if (r3 == 0) goto L2c
            r3 = r2
            goto L2d
        L2c:
            r3 = r1
        L2d:
            int r5 = r5 + r3
            с⵿ r3 = r4.f21307a
            с⵿ r3 = r3.f21036a
            if (r3 == 0) goto L36
            r3 = r2
            goto L37
        L36:
            r3 = r1
        L37:
            int r5 = r5 + r3
            if (r5 >= r0) goto L3b
        L3a:
            return r2
        L3b:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2970.m9889a(int):boolean");
    }

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final boolean m9890a(int i, int i2) {
        C2946 c2946;
        C2946 c29462;
        C2946 c29463;
        C2946 c29464;
        if (i == 0) {
            C2946 c29465 = this.f21303a;
            C2946 c29466 = c29465.f21036a;
            if (c29466 == null || !c29466.f21033a || (c29464 = (c29463 = this.f21305a).f21036a) == null || !c29464.f21033a) {
                return false;
            }
            return (c29464.m9828a() - c29463.m9829a()) - (c29465.m9829a() + c29465.f21036a.m9828a()) >= i2;
        }
        C2946 c29467 = this.f21304a;
        C2946 c29468 = c29467.f21036a;
        if (c29468 == null || !c29468.f21033a || (c29462 = (c2946 = this.f21306a).f21036a) == null || !c29462.f21033a) {
            return false;
        }
        return (c29462.m9828a() - c2946.m9829a()) - (c29467.m9829a() + c29467.f21036a.m9828a()) >= i2;
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final void m9891a(EnumC2945 enumC2945, C2970 c2970, EnumC2945 enumC29452, int i, int i2) {
        mo3831a(enumC2945).m9826a(c2970.mo3831a(enumC29452), i, i2, true);
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final boolean m9892a(int i) {
        C2946 c2946;
        C2946 c29462;
        int i2 = i * 2;
        C2946[] c2946Arr = this.f21311a;
        C2946 c29463 = c2946Arr[i2];
        C2946 c29464 = c29463.f21036a;
        return (c29464 == null || c29464.f21036a == c29463 || (c29462 = (c2946 = c2946Arr[i2 + 1]).f21036a) == null || c29462.f21036a != c2946) ? false : true;
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final boolean m9893a() {
        C2946 c2946 = this.f21303a;
        C2946 c29462 = c2946.f21036a;
        if (c29462 != null && c29462.f21036a == c2946) {
            return true;
        }
        C2946 c29463 = this.f21305a;
        C2946 c29464 = c29463.f21036a;
        return c29464 != null && c29464.f21036a == c29463;
    }

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public final boolean m9894a() {
        C2946 c2946 = this.f21304a;
        C2946 c29462 = c2946.f21036a;
        if (c29462 != null && c29462.f21036a == c2946) {
            return true;
        }
        C2946 c29463 = this.f21306a;
        C2946 c29464 = c29463.f21036a;
        return c29464 != null && c29464.f21036a == c29463;
    }

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final boolean m9895a() {
        return this.f21275a && this.f21328a != 8;
    }

    /* JADX INFO: renamed from: a̚ */
    public boolean mo2140a() {
        if (this.f21279a) {
            return true;
        }
        return this.f21303a.f21033a && this.f21305a.f21033a;
    }

    /* JADX INFO: renamed from: a̛ */
    public boolean mo2141a() {
        if (this.f21280a) {
            return true;
        }
        return this.f21304a.f21033a && this.f21306a.f21033a;
    }

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public void mo9896a() {
        this.f21303a.m9834a();
        this.f21304a.m9834a();
        this.f21305a.m9834a();
        this.f21306a.m9834a();
        this.f21307a.m9834a();
        this.f21308a.m9834a();
        this.f21309a.m9834a();
        this.f21310a.m9834a();
        this.f21315a = null;
        this.f21298a = Float.NaN;
        this.f21316a = 0;
        this.f21317a = 0;
        this.f21318a = 0.0f;
        this.f21319a = -1;
        this.f21320a = 0;
        this.f21321a = 0;
        this.f21322a = 0;
        this.f21323a = 0;
        this.f21324a = 0;
        this.f21325a = 0.5f;
        this.f21326a = 0.5f;
        EnumC2969 enumC2969 = EnumC2969.FIXED;
        EnumC2969[] enumC2969Arr = this.f21314a;
        enumC2969Arr[0] = enumC2969;
        enumC2969Arr[1] = enumC2969;
        this.f21327a = null;
        this.f21328a = 0;
        this.f21330a = 0;
        this.f21331a = 0;
        float[] fArr = this.f21332a;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.f21283a = -1;
        this.f21284a = -1;
        int[] iArr = this.f21297a;
        iArr[0] = Integer.MAX_VALUE;
        iArr[1] = Integer.MAX_VALUE;
        this.f21286a = 0;
        this.f21287a = 0;
        this.f21291a = 1.0f;
        this.f21294a = 1.0f;
        this.f21290a = Integer.MAX_VALUE;
        this.f21293a = Integer.MAX_VALUE;
        this.f21289a = 0;
        this.f21292a = 0;
        this.f21295a = -1;
        this.f21296a = 1.0f;
        boolean[] zArr = this.f21274a;
        zArr[0] = true;
        zArr[1] = true;
        this.f21300a = false;
        boolean[] zArr2 = this.f21313a;
        zArr2[0] = false;
        zArr2[1] = false;
        this.f21275a = true;
        int[] iArr2 = this.f21288a;
        iArr2[0] = 0;
        iArr2[1] = 0;
        this.f21276a = -1;
        this.f21277a = -1;
    }

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final void m9897a() {
        C2970 c2970 = this.f21315a;
        if (c2970 != null && (c2970 instanceof C2971)) {
            ((C2971) c2970).getClass();
        }
        ArrayList arrayList = this.f21312a;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((C2946) arrayList.get(i)).m9834a();
        }
    }

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public final void m9898a() {
        this.f21279a = false;
        this.f21280a = false;
        this.f21281a = false;
        this.f21282a = false;
        ArrayList arrayList = this.f21312a;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            C2946 c2946 = (C2946) arrayList.get(i);
            c2946.f21033a = false;
            c2946.f21032a = 0;
        }
    }

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public void mo9899a(C5454j c5454j) {
        this.f21303a.m9835a();
        this.f21304a.m9835a();
        this.f21305a.m9835a();
        this.f21306a.m9835a();
        this.f21307a.m9835a();
        this.f21310a.m9835a();
        this.f21308a.m9835a();
        this.f21309a.m9835a();
    }

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final void m9900a(int i) {
        this.f21322a = i;
        this.f21299a = i > 0;
    }

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final void m9901a(int i, int i2) {
        if (this.f21279a) {
            return;
        }
        this.f21303a.m9836a(i);
        this.f21305a.m9836a(i2);
        this.f21320a = i;
        this.f21316a = i2 - i;
        this.f21279a = true;
    }

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final void m9902a(int i, int i2) {
        if (this.f21280a) {
            return;
        }
        this.f21304a.m9836a(i);
        this.f21306a.m9836a(i2);
        this.f21321a = i;
        this.f21317a = i2 - i;
        if (this.f21299a) {
            this.f21307a.m9836a(i + this.f21322a);
        }
        this.f21280a = true;
    }

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public final void m9903a(int i) {
        this.f21317a = i;
        int i2 = this.f21324a;
        if (i < i2) {
            this.f21317a = i2;
        }
    }

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public final void m9904a(EnumC2969 enumC2969) {
        this.f21314a[0] = enumC2969;
    }

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final void m9905a(EnumC2969 enumC2969) {
        this.f21314a[1] = enumC2969;
    }

    /* JADX INFO: renamed from: ą, reason: contains not printable characters */
    public final void m9906a(int i) {
        this.f21316a = i;
        int i2 = this.f21323a;
        if (i < i2) {
            this.f21316a = i2;
        }
    }

    /* JADX INFO: renamed from: a̩, reason: contains not printable characters */
    public void mo9907a(boolean z, boolean z2) {
        int i;
        int i2;
        C5336i c5336i = this.f21272a;
        boolean z3 = z & c5336i.f19146a;
        C6234p c6234p = this.f21273a;
        boolean z4 = z2 & c6234p.f19146a;
        int i3 = c5336i.f19147a.f15422a;
        int i4 = c6234p.f19147a.f15422a;
        int i5 = c5336i.f19148a.f15422a;
        int i6 = c6234p.f19148a.f15422a;
        int i7 = i6 - i4;
        if (i5 - i3 < 0 || i7 < 0 || i3 == Integer.MIN_VALUE || i3 == Integer.MAX_VALUE || i4 == Integer.MIN_VALUE || i4 == Integer.MAX_VALUE || i5 == Integer.MIN_VALUE || i5 == Integer.MAX_VALUE || i6 == Integer.MIN_VALUE || i6 == Integer.MAX_VALUE) {
            i5 = 0;
            i6 = 0;
            i3 = 0;
            i4 = 0;
        }
        int i8 = i5 - i3;
        int i9 = i6 - i4;
        if (z3) {
            this.f21320a = i3;
        }
        if (z4) {
            this.f21321a = i4;
        }
        if (this.f21328a == 8) {
            this.f21316a = 0;
            this.f21317a = 0;
            return;
        }
        EnumC2969[] enumC2969Arr = this.f21314a;
        if (z3) {
            if (enumC2969Arr[0] == EnumC2969.FIXED && i8 < (i2 = this.f21316a)) {
                i8 = i2;
            }
            this.f21316a = i8;
            int i10 = this.f21323a;
            if (i8 < i10) {
                this.f21316a = i10;
            }
        }
        if (z4) {
            if (enumC2969Arr[1] == EnumC2969.FIXED && i9 < (i = this.f21317a)) {
                i9 = i;
            }
            this.f21317a = i9;
            int i11 = this.f21324a;
            if (i9 < i11) {
                this.f21317a = i11;
            }
        }
    }

    /* JADX INFO: renamed from: a̪ */
    public void mo3832a(C0017 c0017, boolean z) {
        int i;
        int i2;
        C6234p c6234p;
        C5336i c5336i;
        c0017.getClass();
        int iM5756a = C0017.m5756a(this.f21303a);
        int iM5756a2 = C0017.m5756a(this.f21304a);
        int iM5756a3 = C0017.m5756a(this.f21305a);
        int iM5756a4 = C0017.m5756a(this.f21306a);
        if (z && (c5336i = this.f21272a) != null) {
            C1277 c1277 = c5336i.f19147a;
            if (c1277.f15425a) {
                C1277 c12772 = c5336i.f19148a;
                if (c12772.f15425a) {
                    iM5756a = c1277.f15422a;
                    iM5756a3 = c12772.f15422a;
                }
            }
        }
        if (z && (c6234p = this.f21273a) != null) {
            C1277 c12773 = c6234p.f19147a;
            if (c12773.f15425a) {
                C1277 c12774 = c6234p.f19148a;
                if (c12774.f15425a) {
                    iM5756a2 = c12773.f15422a;
                    iM5756a4 = c12774.f15422a;
                }
            }
        }
        int i3 = iM5756a4 - iM5756a2;
        if (iM5756a3 - iM5756a < 0 || i3 < 0 || iM5756a == Integer.MIN_VALUE || iM5756a == Integer.MAX_VALUE || iM5756a2 == Integer.MIN_VALUE || iM5756a2 == Integer.MAX_VALUE || iM5756a3 == Integer.MIN_VALUE || iM5756a3 == Integer.MAX_VALUE || iM5756a4 == Integer.MIN_VALUE || iM5756a4 == Integer.MAX_VALUE) {
            iM5756a = 0;
            iM5756a2 = 0;
            iM5756a3 = 0;
            iM5756a4 = 0;
        }
        int i4 = iM5756a3 - iM5756a;
        int i5 = iM5756a4 - iM5756a2;
        this.f21320a = iM5756a;
        this.f21321a = iM5756a2;
        if (this.f21328a == 8) {
            this.f21316a = 0;
            this.f21317a = 0;
            return;
        }
        EnumC2969[] enumC2969Arr = this.f21314a;
        EnumC2969 enumC2969 = enumC2969Arr[0];
        EnumC2969 enumC29692 = EnumC2969.FIXED;
        if (enumC2969 == enumC29692 && i4 < (i2 = this.f21316a)) {
            i4 = i2;
        }
        if (enumC2969Arr[1] == enumC29692 && i5 < (i = this.f21317a)) {
            i5 = i;
        }
        this.f21316a = i4;
        this.f21317a = i5;
        int i6 = this.f21324a;
        if (i5 < i6) {
            this.f21317a = i6;
        }
        int i7 = this.f21323a;
        if (i4 < i7) {
            this.f21316a = i7;
        }
        int i8 = this.f21290a;
        if (i8 > 0 && enumC2969 == EnumC2969.MATCH_CONSTRAINT) {
            this.f21316a = Math.min(this.f21316a, i8);
        }
        int i9 = this.f21293a;
        if (i9 > 0 && enumC2969Arr[1] == EnumC2969.MATCH_CONSTRAINT) {
            this.f21317a = Math.min(this.f21317a, i9);
        }
        int i10 = this.f21316a;
        if (i4 != i10) {
            this.f21276a = i10;
        }
        int i11 = this.f21317a;
        if (i5 != i11) {
            this.f21277a = i11;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(this.f21329a != null ? AbstractC4072a.m749a(new StringBuilder("id: "), this.f21329a, " ") : "");
        sb.append("(");
        sb.append(this.f21320a);
        sb.append(", ");
        sb.append(this.f21321a);
        sb.append(") - (");
        sb.append(this.f21316a);
        sb.append(" x ");
        return AbstractC4072a.m748a(sb, this.f21317a, ")");
    }
}
