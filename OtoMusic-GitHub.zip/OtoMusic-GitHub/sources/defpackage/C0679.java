package defpackage;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.android.play.core.common.PlayCoreDialogWrapperActivity;

/* JADX INFO: renamed from: ρ̑, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0679 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C0790 f13824a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Handler f13825a = new Handler(Looper.getMainLooper());

    public C0679(C0790 c0790) {
        this.f13824a = c0790;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C6346s m6585a(Activity activity, AbstractC2169 abstractC2169) {
        C2487 c2487 = (C2487) abstractC2169;
        if (c2487.f19573a) {
            C6346s c6346s = new C6346s();
            c6346s.m5551a(null);
            return c6346s;
        }
        Intent intent = new Intent(activity, (Class<?>) PlayCoreDialogWrapperActivity.class);
        intent.putExtra("confirmation_intent", c2487.f19572a);
        intent.putExtra("window_flags", activity.getWindow().getDecorView().getWindowSystemUiVisibility());
        C3943 c3943 = new C3943();
        intent.putExtra("result_receiver", new ResultReceiverC2618(this.f13825a, c3943));
        activity.startActivity(intent);
        return c3943.f24110a;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C6346s m6586a() {
        C0790 c0790 = this.f13824a;
        String str = c0790.f14016a;
        C5948o c5948o = C0790.f14014a;
        c5948o.m4909a("requestInAppReview (%s)", str);
        C0954 c0954 = c0790.f14015a;
        if (c0954 != null) {
            C3943 c3943 = new C3943();
            c0954.m7027a().post(new C0854(c0954, c3943, c3943, new C0726(c0790, c3943, c3943)));
            return c3943.f24110a;
        }
        Object[] objArr = new Object[0];
        if (Log.isLoggable("PlayCore", 6)) {
            Log.e("PlayCore", C5948o.m4906a(c5948o.f10036a, "Play Store app is either not installed or not the official version", objArr));
        }
        C3084 c3084 = new C3084();
        C6346s c6346s = new C6346s();
        c6346s.m5552a(c3084);
        return c6346s;
    }
}
