package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: renamed from: j⃩, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5638j implements InterfaceC2663, InterfaceC2333 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C2665 f8983a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C5639j f8984a;

    public C5638j(C5639j c5639j, C2665 c2665) {
        this.f8984a = c5639j;
        this.f8983a = c2665;
    }

    @Override // defpackage.InterfaceC2333
    /* JADX INFO: renamed from: à */
    public final void mo2618a(AbstractC0361 abstractC0361, int i) {
        this.f8983a.mo2618a(abstractC0361, i);
    }

    @Override // defpackage.InterfaceC2663
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void mo4477a(Object obj, InterfaceC5056i interfaceC5056i) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = C5639j.f8985a;
        C5639j c5639j = this.f8984a;
        atomicReferenceFieldUpdater.set(c5639j, null);
        this.f8983a.m9371a(C6174p.f10843a, new C5104i(c5639j, this));
    }

    @Override // defpackage.InterfaceC2663
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C5948o mo4478a(Object obj, InterfaceC5056i interfaceC5056i) {
        C5639j c5639j = this.f8984a;
        C2664 c2664 = new C2664(c5639j, this);
        C5948o c5948oM9374a = this.f8983a.m9374a((C6174p) obj, c2664);
        if (c5948oM9374a != null) {
            C5639j.f8985a.set(c5639j, null);
        }
        return c5948oM9374a;
    }

    @Override // defpackage.InterfaceC2663
    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void mo4479a(Object obj) {
        this.f8983a.mo4479a(obj);
    }

    @Override // defpackage.InterfaceC1005
    public final InterfaceC1031 getContext() {
        return this.f8983a.f19999a;
    }

    @Override // defpackage.InterfaceC1005
    public final void resumeWith(Object obj) {
        this.f8983a.resumeWith(obj);
    }
}
