package defpackage;

/* JADX INFO: renamed from: сۡ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC2858 {
}
