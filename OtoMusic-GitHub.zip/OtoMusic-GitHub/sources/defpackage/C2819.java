package defpackage;

/* JADX INFO: renamed from: сؓ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2819 implements InterfaceC2220 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final InterfaceC2220 f20636a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f20637a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C2820 f20638a;

    public C2819(C2820 c2820, InterfaceC2220 interfaceC2220) {
        this.f20638a = c2820;
        this.f20636a = interfaceC2220;
    }

    @Override // defpackage.InterfaceC2220
    /* JADX INFO: renamed from: a̅ */
    public final int mo3678a(C1899 c1899, C1164 c1164, int i) {
        C2820 c2820 = this.f20638a;
        if (c2820.m9588a()) {
            return -3;
        }
        if (this.f20637a) {
            c1164.setFlags(4);
            return -4;
        }
        long jMo4034a = c2820.mo4034a();
        int iMo3678a = this.f20636a.mo3678a(c1899, c1164, i);
        if (c2820.f20643a != -9223372036854775807L && iMo3678a != -3) {
            c2820.f20643a = -9223372036854775807L;
        }
        if (iMo3678a != -5) {
            long j = c2820.f20644a;
            if (j != Long.MIN_VALUE) {
                if (iMo3678a != -4 || c1164.f14933a < j) {
                    if (iMo3678a == -3 && jMo4034a == Long.MIN_VALUE) {
                        c1164.getClass();
                    }
                }
                c1164.clear();
                c1164.setFlags(4);
                this.f20637a = true;
                return -4;
            }
            return iMo3678a;
        }
        long j2 = c2820.f20644a;
        C1898 c1898 = c1899.f17638a;
        c1898.getClass();
        int i2 = c1898.f17631a;
        int i3 = c1898.f17630a;
        if (i3 != 0 || i2 != 0) {
            if (j2 != Long.MIN_VALUE) {
                i2 = 0;
            }
            C1897 c1897M8273a = c1898.m8273a();
            c1897M8273a.f17600a = i3;
            c1897M8273a.f17601a = i2;
            c1899.f17638a = new C1898(c1897M8273a);
        }
        return -5;
    }

    @Override // defpackage.InterfaceC2220
    /* JADX INFO: renamed from: a̎ */
    public final boolean mo3684a() {
        return !this.f20638a.m9588a() && this.f20636a.mo3684a();
    }

    @Override // defpackage.InterfaceC2220
    /* JADX INFO: renamed from: a̐ */
    public final void mo3686a() {
        this.f20636a.mo3686a();
    }

    @Override // defpackage.InterfaceC2220
    /* JADX INFO: renamed from: a̒ */
    public final int mo3688a(long j) {
        if (this.f20638a.m9588a()) {
            return -3;
        }
        return this.f20636a.mo3688a(j);
    }
}
