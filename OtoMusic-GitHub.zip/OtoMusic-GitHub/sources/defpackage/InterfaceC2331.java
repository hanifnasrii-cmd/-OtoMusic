package defpackage;

/* JADX INFO: renamed from: р̎, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC2331 {
    /* JADX INFO: renamed from: à */
    void mo4463a();

    /* JADX INFO: renamed from: á */
    void mo4464a();

    /* JADX INFO: renamed from: â */
    void mo4465a(int i);

    void start();

    void stop();
}
