package defpackage;

import android.content.Context;
import android.os.PowerManager;

/* JADX INFO: renamed from: р̔, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC2337 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int f19075a = 0;

    static {
        AbstractC3098.m10102a(C0110.m5884a("WakeLocks"), "tagWithPrefix(\"WakeLocks\")");
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final PowerManager.WakeLock m8747a(Context context, String str) {
        AbstractC3098.m10103a(context, "context");
        AbstractC3098.m10103a(str, "tag");
        Object systemService = context.getApplicationContext().getSystemService("power");
        AbstractC3098.m10101a(systemService, "null cannot be cast to non-null type android.os.PowerManager");
        String strConcat = "WorkManager: ".concat(str);
        PowerManager.WakeLock wakeLockNewWakeLock = ((PowerManager) systemService).newWakeLock(1, strConcat);
        synchronized (C2338.f19076a) {
        }
        AbstractC3098.m10102a(wakeLockNewWakeLock, "wakeLock");
        return wakeLockNewWakeLock;
    }
}
