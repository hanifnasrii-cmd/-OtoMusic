package defpackage;

import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewOutlineProvider;
import com.google.android.material.imageview.ShapeableImageView;

/* JADX INFO: renamed from: ο֨, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0471 extends ViewOutlineProvider {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Rect f13115a = new Rect();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ ShapeableImageView f13116a;

    public C0471(ShapeableImageView shapeableImageView) {
        this.f13116a = shapeableImageView;
    }

    @Override // android.view.ViewOutlineProvider
    public final void getOutline(View view, Outline outline) {
        ShapeableImageView shapeableImageView = this.f13116a;
        if (shapeableImageView.f2382a == null) {
            return;
        }
        if (shapeableImageView.f2381a == null) {
            shapeableImageView.f2381a = new C0262(shapeableImageView.f2382a);
        }
        RectF rectF = shapeableImageView.f2375a;
        Rect rect = this.f13115a;
        rectF.round(rect);
        shapeableImageView.f2381a.setBounds(rect);
        shapeableImageView.f2381a.getOutline(outline);
    }
}
