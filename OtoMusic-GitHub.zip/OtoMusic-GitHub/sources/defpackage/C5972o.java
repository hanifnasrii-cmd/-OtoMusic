package defpackage;

import java.util.ArrayList;

/* JADX INFO: renamed from: o⃭, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5972o extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public ArrayList f10094a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public ArrayList f10095a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f10096a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public /* synthetic */ Object f10097a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ C5973o f10098a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public int f10099a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5972o(C5973o c5973o, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f10098a = c5973o;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f10097a = obj;
        this.f10099a |= Integer.MIN_VALUE;
        return this.f10098a.m4929a(this);
    }
}
