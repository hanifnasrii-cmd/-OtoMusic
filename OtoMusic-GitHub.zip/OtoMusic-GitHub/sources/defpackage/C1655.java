package defpackage;

import android.view.GestureDetector;
import android.view.MotionEvent;
import com.piyush.music.widget.expandablesearchview.ExpandableSearchView;

/* JADX INFO: renamed from: ѐ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1655 extends GestureDetector.SimpleOnGestureListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ ExpandableSearchView f16687a;

    public C1655(ExpandableSearchView expandableSearchView) {
        this.f16687a = expandableSearchView;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public final boolean onSingleTapUp(MotionEvent motionEvent) {
        ExpandableSearchView expandableSearchView = this.f16687a;
        if (!expandableSearchView.m1989a()) {
            return false;
        }
        expandableSearchView.m1986a();
        return false;
    }
}
