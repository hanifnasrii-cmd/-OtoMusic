package defpackage;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.ViewGroup;
import com.piyush.music.R;

/* JADX INFO: renamed from: е̬, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1699 extends AbstractC6341p {
    public C1699(int i) {
        this.f11295a = i;
    }

    /* JADX INFO: renamed from: a̬, reason: contains not printable characters */
    public static float m8101a(C6132p c6132p, float f) {
        Float f2;
        return (c6132p == null || (f2 = (Float) c6132p.f10693a.get("android:fade:transitionAlpha")) == null) ? f : f2.floatValue();
    }

    @Override // defpackage.AbstractC6341p, defpackage.AbstractC6120p
    /* JADX INFO: renamed from: ă */
    public final void mo5113a(C6132p c6132p) {
        AbstractC6341p.m5525a(c6132p);
        View view = c6132p.f10694a;
        Float fValueOf = (Float) view.getTag(R.id.transition_pause_alpha);
        if (fValueOf == null) {
            fValueOf = view.getVisibility() == 0 ? Float.valueOf(AbstractC6325p.m5504a(view)) : Float.valueOf(0.0f);
        }
        c6132p.f10693a.put("android:fade:transitionAlpha", fValueOf);
    }

    @Override // defpackage.AbstractC6341p
    /* JADX INFO: renamed from: a̩ */
    public final Animator mo5527a(ViewGroup viewGroup, View view, C6132p c6132p) {
        AbstractC6325p.m5505a();
        return m8102a(view, m8101a(c6132p, 0.0f), 1.0f);
    }

    @Override // defpackage.AbstractC6341p
    /* JADX INFO: renamed from: a̪ */
    public final Animator mo5528a(ViewGroup viewGroup, View view, C6132p c6132p, C6132p c6132p2) {
        AbstractC6325p.m5505a();
        ObjectAnimator objectAnimatorM8102a = m8102a(view, m8101a(c6132p, 1.0f), 0.0f);
        if (objectAnimatorM8102a == null) {
            AbstractC6325p.m5507a(view, m8101a(c6132p2, 1.0f));
        }
        return objectAnimatorM8102a;
    }

    /* JADX INFO: renamed from: a̫, reason: contains not printable characters */
    public final ObjectAnimator m8102a(View view, float f, float f2) {
        if (f == f2) {
            return null;
        }
        AbstractC6325p.m5507a(view, f);
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, AbstractC6325p.f11237a, f2);
        C1698 c1698 = new C1698(view);
        objectAnimatorOfFloat.addListener(c1698);
        m5122a().m5108a(c1698);
        return objectAnimatorOfFloat;
    }
}
