package defpackage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.piyush.music.R;

/* JADX INFO: renamed from: c݄, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4602c extends AbstractC2015 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int[] f5376a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f5377a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C5872o f5378a;

    public C4602c(int[] iArr, int i, C5872o c5872o) {
        this.f5376a = iArr;
        this.f5377a = i;
        this.f5378a = c5872o;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ā */
    public final int mo1074a() {
        return this.f5376a.length;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̋ */
    public final void mo1037a(AbstractC2042 abstractC2042, int i) {
        View view = abstractC2042.f18146a;
        C5494j c5494j = (C5494j) abstractC2042;
        TextView textView = c5494j.f8635a;
        int[] iArr = this.f5376a;
        textView.setText(String.valueOf(iArr[i]));
        if (this.f5377a == iArr[i]) {
            view.setActivated(true);
        } else {
            c5494j.f8634a.setImageDrawable(null);
            view.setActivated(false);
        }
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̍ */
    public final AbstractC2042 mo1039a(ViewGroup viewGroup, int i) {
        View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.a5, viewGroup, false);
        C5494j c5494j = new C5494j(viewInflate);
        viewInflate.setOnClickListener(new ViewOnClickListenerC4190a(this, 5, c5494j));
        return c5494j;
    }
}
