package defpackage;

import com.google.android.material.chip.ChipGroup;
import com.piyush.music.autoeq.AutoEqProfile;
import com.piyush.music.fragments.equalizer.EqualizerFragment;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: renamed from: eި, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C4941e implements InterfaceC1816, InterfaceC5064i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f6473a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ EqualizerFragment f6474a;

    public /* synthetic */ C4941e(EqualizerFragment equalizerFragment, int i) {
        this.f6473a = i;
        this.f6474a = equalizerFragment;
    }

    @Override // defpackage.InterfaceC5064i
    /* JADX INFO: renamed from: à */
    public final InterfaceC5055i mo675a() {
        switch (this.f6473a) {
            case 0:
                return new C4168a(this.f6474a, EqualizerFragment.class, "renderAutoEqCard", "renderAutoEqCard(Lcom/piyush/music/autoeq/AutoEqProfile;)V");
            default:
                return new C4168a(this.f6474a, EqualizerFragment.class, "renderTiltSelection", "renderTiltSelection(Lcom/piyush/music/autoeq/ToneTilt;)V");
        }
    }

    @Override // defpackage.InterfaceC1816
    /* JADX INFO: renamed from: a̅ */
    public final Object mo674a(Object obj, InterfaceC1005 interfaceC1005) {
        Object next;
        int i = this.f6473a;
        C6174p c6174p = C6174p.f10843a;
        EqualizerFragment equalizerFragment = this.f6474a;
        switch (i) {
            case 0:
                equalizerFragment.m1750a((AutoEqProfile) obj);
                EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                break;
            default:
                EnumC6072p enumC6072p = (EnumC6072p) obj;
                AbstractC6265p abstractC6265p = equalizerFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p);
                ChipGroup chipGroup = ((AbstractC4943e) abstractC6265p).f6479a.f22075a;
                Iterator it = equalizerFragment.f3167a.entrySet().iterator();
                while (true) {
                    if (it.hasNext()) {
                        next = it.next();
                        if (((Map.Entry) next).getValue() == enumC6072p) {
                        }
                    } else {
                        next = null;
                    }
                }
                Map.Entry entry = (Map.Entry) next;
                if (entry != null) {
                    int iIntValue = ((Number) entry.getKey()).intValue();
                    if (chipGroup.getCheckedChipId() != iIntValue) {
                        C2762 c2762 = chipGroup.f2341a;
                        InterfaceC0249 interfaceC0249 = (InterfaceC0249) ((HashMap) c2762.f20393a).get(Integer.valueOf(iIntValue));
                        if (interfaceC0249 != null && c2762.m9485a(interfaceC0249)) {
                            c2762.m9488a();
                        }
                    }
                    AbstractC6265p abstractC6265p2 = equalizerFragment.f4707a;
                    AbstractC3098.m10100a(abstractC6265p2);
                    ((AbstractC4943e) abstractC6265p2).f6479a.f22062a.m1925a((AutoEqProfile) equalizerFragment.m1746a().f16638a.f10306a.getValue(), enumC6072p);
                }
                EnumC1045 enumC10452 = EnumC1045.COROUTINE_SUSPENDED;
                break;
        }
        return c6174p;
    }

    public final boolean equals(Object obj) {
        switch (this.f6473a) {
            case 0:
                if ((obj instanceof InterfaceC1816) && (obj instanceof InterfaceC5064i)) {
                    break;
                }
                break;
            default:
                if ((obj instanceof InterfaceC1816) && (obj instanceof InterfaceC5064i)) {
                    break;
                }
                break;
        }
        return mo675a().equals(((InterfaceC5064i) obj).mo675a());
    }

    public final int hashCode() {
        switch (this.f6473a) {
        }
        return mo675a().hashCode();
    }
}
