package defpackage;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.material.textview.MaterialTextView;
import com.piyush.music.R;

/* JADX INFO: renamed from: е̸, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1711 extends MaterialTextView {

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final /* synthetic */ int f16842a = 0;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final boolean f16843a;

    public C1711(Context context) {
        super(context, null, 0);
        this.f16843a = getLayoutDirection() == 1;
        setMinimumWidth(getResources().getDimensionPixelSize(R.dimen.w4));
        setMinimumHeight(getResources().getDimensionPixelSize(R.dimen.w3));
        setTextAppearance(R.style.y0);
        int color = -16777216;
        try {
            color = context.getTheme().obtainStyledAttributes(new int[]{android.R.attr.colorControlNormal}).getColor(0, -16777216);
        } catch (Exception unused) {
        }
        setTextColor(color);
        setEllipsize(TextUtils.TruncateAt.MIDDLE);
        setGravity(17);
        setIncludeFontPadding(false);
        setAlpha(0.0f);
        setElevation(getResources().getDimensionPixelOffset(R.dimen.w1));
        setBackground(new C1710(this, context));
    }
}
