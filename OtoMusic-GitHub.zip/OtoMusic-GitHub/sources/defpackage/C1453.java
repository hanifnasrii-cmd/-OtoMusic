package defpackage;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: renamed from: а֝, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1453 implements Collection {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C1454 f16005a;

    public C1453(C1454 c1454) {
        this.f16005a = c1454;
    }

    @Override // java.util.Collection
    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Collection
    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Collection
    public final void clear() {
        this.f16005a.clear();
    }

    @Override // java.util.Collection
    public final boolean contains(Object obj) {
        return this.f16005a.m6375a(obj) >= 0;
    }

    @Override // java.util.Collection
    public final boolean containsAll(Collection collection) {
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Collection
    public final boolean isEmpty() {
        return this.f16005a.isEmpty();
    }

    @Override // java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new C1450(this.f16005a, 1);
    }

    @Override // java.util.Collection
    public final boolean remove(Object obj) {
        C1454 c1454 = this.f16005a;
        int iM6375a = c1454.m6375a(obj);
        if (iM6375a < 0) {
            return false;
        }
        c1454.mo2792a(iM6375a);
        return true;
    }

    @Override // java.util.Collection
    public final boolean removeAll(Collection collection) {
        C1454 c1454 = this.f16005a;
        int i = c1454.f13353a;
        int i2 = 0;
        boolean z = false;
        while (i2 < i) {
            if (collection.contains(c1454.m6381a(i2))) {
                c1454.mo2792a(i2);
                i2--;
                i--;
                z = true;
            }
            i2++;
        }
        return z;
    }

    @Override // java.util.Collection
    public final boolean retainAll(Collection collection) {
        C1454 c1454 = this.f16005a;
        int i = c1454.f13353a;
        int i2 = 0;
        boolean z = false;
        while (i2 < i) {
            if (!collection.contains(c1454.m6381a(i2))) {
                c1454.mo2792a(i2);
                i2--;
                i--;
                z = true;
            }
            i2++;
        }
        return z;
    }

    @Override // java.util.Collection
    public final int size() {
        return this.f16005a.f13353a;
    }

    @Override // java.util.Collection
    public final Object[] toArray() {
        C1454 c1454 = this.f16005a;
        int i = c1454.f13353a;
        Object[] objArr = new Object[i];
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = c1454.m6381a(i2);
        }
        return objArr;
    }

    @Override // java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        C1454 c1454 = this.f16005a;
        int i = c1454.f13353a;
        if (objArr.length < i) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), i);
        }
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = c1454.m6381a(i2);
        }
        if (objArr.length > i) {
            objArr[i] = null;
        }
        return objArr;
    }
}
