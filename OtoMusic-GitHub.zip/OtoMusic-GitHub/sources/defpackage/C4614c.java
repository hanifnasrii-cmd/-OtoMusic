package defpackage;

import java.util.List;
import javax.net.ssl.SSLSocket;
import org.bouncycastle.jsse.BCSSLParameters;
import org.bouncycastle.jsse.BCSSLSocket;

/* JADX INFO: renamed from: cޫ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4614c implements InterfaceC0594 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C4613c f5426a = new C4613c();

    @Override // defpackage.InterfaceC0594
    /* JADX INFO: renamed from: à */
    public final boolean mo1176a(SSLSocket sSLSocket) {
        return false;
    }

    @Override // defpackage.InterfaceC0594
    /* JADX INFO: renamed from: á */
    public final boolean mo1177a() {
        boolean z = C4612c.f5424a;
        return AbstractC4611c.m2535a();
    }

    @Override // defpackage.InterfaceC0594
    /* JADX INFO: renamed from: â */
    public final String mo1178a(SSLSocket sSLSocket) {
        String applicationProtocol = ((BCSSLSocket) sSLSocket).getApplicationProtocol();
        if (applicationProtocol == null ? true : applicationProtocol.equals("")) {
            return null;
        }
        return applicationProtocol;
    }

    @Override // defpackage.InterfaceC0594
    /* JADX INFO: renamed from: ã */
    public final void mo1179a(SSLSocket sSLSocket, String str, List list) {
        AbstractC3098.m10103a(list, "protocols");
        if (mo1176a(sSLSocket)) {
            BCSSLSocket bCSSLSocket = (BCSSLSocket) sSLSocket;
            BCSSLParameters parameters = bCSSLSocket.getParameters();
            C5693o c5693o = C5693o.f9228a;
            parameters.setApplicationProtocols((String[]) C3004.m9978a(list).toArray(new String[0]));
            bCSSLSocket.setParameters(parameters);
        }
    }
}
