package defpackage;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.piyush.music.widget.DialogScaffold;

/* JADX INFO: renamed from: ο̤, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0367 extends AbstractC6265p {

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public static final /* synthetic */ int f12828a = 0;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final MaterialCheckBox f12829a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final DialogScaffold f12830a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final RecyclerView f12831a;

    public AbstractC0367(InterfaceC1126 interfaceC1126, View view, MaterialCheckBox materialCheckBox, DialogScaffold dialogScaffold, RecyclerView recyclerView) {
        super(interfaceC1126, view, 0);
        this.f12829a = materialCheckBox;
        this.f12830a = dialogScaffold;
        this.f12831a = recyclerView;
    }
}
