package defpackage;

/* JADX INFO: renamed from: ј߮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3572 extends AbstractC3478 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Class f23027a;

    public C3572(Class cls) {
        this.f23027a = cls;
    }

    @Override // defpackage.AbstractC3478
    /* JADX INFO: renamed from: á */
    public final void mo10647a(C2103 c2103, Object obj) {
        c2103.f18357a.m9731a(obj, this.f23027a);
    }
}
