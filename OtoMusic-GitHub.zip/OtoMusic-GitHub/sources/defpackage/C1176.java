package defpackage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.flexbox.FlexboxLayout;
import com.piyush.music.R;
import com.piyush.music.widget.ExpandableLinearLayout;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: renamed from: ϲُ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1176 implements InterfaceC6244p {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f14957a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Object f14958a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public Object f14959a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public Object f14960a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public Object f14961a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public Object f14962a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public Object f14963a;

    public /* synthetic */ C1176(ViewGroup viewGroup, View view, View view2, View view3, View view4, View view5, int i) {
        this.f14957a = i;
        this.f14958a = viewGroup;
        this.f14959a = view;
        this.f14960a = view2;
        this.f14961a = view3;
        this.f14962a = view4;
        this.f14963a = view5;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static C5466j m7256a(InterfaceC5730o interfaceC5730o, AbstractC3045 abstractC3045, C5466j c5466j, C6035p c6035p) {
        C5001e c5001e = (C5001e) interfaceC5730o;
        AbstractC6037p abstractC6037pM3239a = c5001e.m3239a();
        int iM3236a = c5001e.m3236a();
        Object objMo4742a = abstractC6037pM3239a.m5051a() ? null : abstractC6037pM3239a.mo4742a(iM3236a);
        int iM5039a = (c5001e.m3245a() || abstractC6037pM3239a.m5051a()) ? -1 : abstractC6037pM3239a.mo4734a(iM3236a, c6035p, false).m5039a(AbstractC6205p.m5357a(c5001e.m3237a()) - c6035p.f10386a);
        for (int i = 0; i < abstractC3045.size(); i++) {
            C5466j c5466j2 = (C5466j) abstractC3045.get(i);
            if (m7258a(c5466j2, objMo4742a, c5001e.m3245a(), c5001e.m3233a(), c5001e.m3234a(), iM5039a)) {
                return c5466j2;
            }
        }
        if (abstractC3045.isEmpty() && c5466j != null && m7258a(c5466j, objMo4742a, c5001e.m3245a(), c5001e.m3233a(), c5001e.m3234a(), iM5039a)) {
            return c5466j;
        }
        return null;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static C1176 m7257a(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        View viewInflate = layoutInflater.inflate(R.layout.ee, viewGroup, false);
        int i = R.id.add_button;
        FrameLayout frameLayout = (FrameLayout) AbstractC4611c.m2525a(viewInflate, R.id.add_button);
        if (frameLayout != null) {
            LinearLayout linearLayout = (LinearLayout) viewInflate;
            i = R.id.icon;
            ImageView imageView = (ImageView) AbstractC4611c.m2525a(viewInflate, R.id.icon);
            if (imageView != null) {
                i = R.id.label;
                TextView textView = (TextView) AbstractC4611c.m2525a(viewInflate, R.id.label);
                if (textView != null) {
                    i = R.id.premium_indicator;
                    ImageView imageView2 = (ImageView) AbstractC4611c.m2525a(viewInflate, R.id.premium_indicator);
                    if (imageView2 != null) {
                        return new C1176(linearLayout, frameLayout, linearLayout, imageView, textView, imageView2, 4);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static boolean m7258a(C5466j c5466j, Object obj, boolean z, int i, int i2, int i3) {
        Object obj2 = c5466j.f8485a;
        int i4 = c5466j.f8486a;
        if (!obj2.equals(obj)) {
            return false;
        }
        if (z && i4 == i && c5466j.f8487a == i2) {
            return true;
        }
        return !z && i4 == -1 && c5466j.f8489a == i3;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void m7259a(C2896 c2896, C5466j c5466j, AbstractC6037p abstractC6037p) {
        if (c5466j == null) {
            return;
        }
        if (abstractC6037p.mo4736a(c5466j.f8485a) != -1) {
            c2896.m9782a(c5466j, abstractC6037p);
            return;
        }
        AbstractC6037p abstractC6037p2 = (AbstractC6037p) ((C2073) this.f14960a).get(c5466j);
        if (abstractC6037p2 != null) {
            c2896.m9782a(c5466j, abstractC6037p2);
        }
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C2862 m7260a() {
        C2862 c2862 = new C2862(false);
        c2862.f20794a = new LinkedHashMap();
        c2862.f20791a = (C3005) this.f14958a;
        c2862.f20792a = (String) this.f14959a;
        c2862.f20795a = (AbstractC2101) this.f14961a;
        Map map = (Map) this.f14962a;
        c2862.f20794a = map.isEmpty() ? new LinkedHashMap() : new LinkedHashMap(map);
        c2862.f20793a = ((C5208i) this.f14960a).m3867a();
        return c2862;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public void m7261a(AbstractC6037p abstractC6037p) {
        C2896 c2896 = new C2896(4, 1);
        if (((AbstractC3045) this.f14959a).isEmpty()) {
            m7259a(c2896, (C5466j) this.f14962a, abstractC6037p);
            if (!Objects.equals((C5466j) this.f14963a, (C5466j) this.f14962a)) {
                m7259a(c2896, (C5466j) this.f14963a, abstractC6037p);
            }
            if (!Objects.equals((C5466j) this.f14961a, (C5466j) this.f14962a) && !Objects.equals((C5466j) this.f14961a, (C5466j) this.f14963a)) {
                m7259a(c2896, (C5466j) this.f14961a, abstractC6037p);
            }
        } else {
            for (int i = 0; i < ((AbstractC3045) this.f14959a).size(); i++) {
                m7259a(c2896, (C5466j) ((AbstractC3045) this.f14959a).get(i), abstractC6037p);
            }
            if (!((AbstractC3045) this.f14959a).contains((C5466j) this.f14961a)) {
                m7259a(c2896, (C5466j) this.f14961a, abstractC6037p);
            }
        }
        this.f14960a = c2896.m9777a();
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public C3005 m7262a() {
        return (C3005) this.f14958a;
    }

    @Override // defpackage.InterfaceC6244p
    public View getRoot() {
        switch (this.f14957a) {
            case 2:
                return (LinearLayout) this.f14958a;
            case 3:
                return (ConstraintLayout) this.f14958a;
            case 4:
                return (LinearLayout) this.f14958a;
            case 5:
                return (FrameLayout) this.f14958a;
            default:
                return (LinearLayout) this.f14958a;
        }
    }

    public String toString() {
        switch (this.f14957a) {
            case 6:
                Map map = (Map) this.f14962a;
                StringBuilder sb = new StringBuilder("Request{method=");
                sb.append((String) this.f14959a);
                sb.append(", url=");
                sb.append((C3005) this.f14958a);
                C5208i c5208i = (C5208i) this.f14960a;
                if (c5208i.size() != 0) {
                    sb.append(", headers=[");
                    int i = 0;
                    for (Object obj : c5208i) {
                        int i2 = i + 1;
                        if (i < 0) {
                            AbstractC2852.m9681a();
                            throw null;
                        }
                        C3549 c3549 = (C3549) obj;
                        String str = (String) c3549.f22954a;
                        String str2 = (String) c3549.f22955a;
                        if (i > 0) {
                            sb.append(", ");
                        }
                        sb.append(str);
                        sb.append(':');
                        sb.append(str2);
                        i = i2;
                    }
                    sb.append(']');
                }
                if (!map.isEmpty()) {
                    sb.append(", tags=");
                    sb.append(map);
                }
                sb.append('}');
                String string = sb.toString();
                AbstractC3098.m10102a(string, "StringBuilder().apply(builderAction).toString()");
                return string;
            default:
                return super.toString();
        }
    }

    public C1176(C3005 c3005, String str, C5208i c5208i, AbstractC2101 abstractC2101, Map map) {
        this.f14957a = 6;
        AbstractC3098.m10103a(c3005, "url");
        AbstractC3098.m10103a(str, "method");
        this.f14958a = c3005;
        this.f14959a = str;
        this.f14960a = c5208i;
        this.f14961a = abstractC2101;
        this.f14962a = map;
    }

    public C1176(LinearLayout linearLayout, TextView textView, FlexboxLayout flexboxLayout, LinearLayout linearLayout2, ImageView imageView, TextView textView2, ExpandableLinearLayout expandableLinearLayout, ExpandableLinearLayout expandableLinearLayout2, TextView textView3, TextView textView4) {
        this.f14957a = 7;
        this.f14958a = linearLayout;
        this.f14959a = linearLayout2;
        this.f14960a = imageView;
        this.f14961a = textView2;
        this.f14962a = expandableLinearLayout;
        this.f14963a = expandableLinearLayout2;
    }

    public C1176(C3947 c3947) {
        this.f14957a = 1;
        AbstractC3098.m10103a(c3947, "taskRunner");
        this.f14958a = c3947;
        this.f14963a = AbstractC5349i.f7976a;
    }

    public C1176(C6035p c6035p) {
        this.f14957a = 0;
        this.f14958a = c6035p;
        C3041 c3041 = AbstractC3045.f21557a;
        this.f14959a = C2068.f18238a;
        this.f14960a = C2073.f18250a;
    }
}
