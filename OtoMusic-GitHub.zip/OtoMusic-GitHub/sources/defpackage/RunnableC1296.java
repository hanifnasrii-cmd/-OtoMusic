package defpackage;

import com.piyush.music.activities.main.MainActivity;
import com.piyush.music.models.FileSong;
import com.piyush.music.service.MusicService;
import com.piyush.taglib.AudioProperties;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: renamed from: ϲⷤ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class RunnableC1296 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f15496a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f15497a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ Object f15498a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ Object f15499a;

    public /* synthetic */ RunnableC1296(MusicService musicService, EnumC6121p enumC6121p, int i) {
        this.f15496a = 3;
        this.f15498a = musicService;
        this.f15499a = enumC6121p;
        this.f15497a = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f15496a) {
            case 0:
                C1297 c1297 = (C1297) this.f15498a;
                c1297.f15502a.mo3887a(this.f15497a, this.f15499a);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                CopyOnWriteArraySet<C0055> copyOnWriteArraySet = (CopyOnWriteArraySet) this.f15498a;
                int i = this.f15497a;
                InterfaceC0053 interfaceC0053 = (InterfaceC0053) this.f15499a;
                for (C0055 c0055 : copyOnWriteArraySet) {
                    if (!c0055.f11765a) {
                        if (i != -1) {
                            c0055.f11763a.m8166a(i);
                        }
                        c0055.f11764a = true;
                        interfaceC0053.invoke(c0055.f11762a);
                    }
                }
                break;
            case 2:
                FileSong fileSong = (FileSong) this.f15498a;
                final int i2 = this.f15497a;
                MainActivity mainActivity = (MainActivity) this.f15499a;
                int i3 = MainActivity.f2717a;
                C5763o c5763o = C5601j.f8884a;
                C5601j.m4446a(AbstractC5120i.m3448a(fileSong), 0, true, 8);
                if (i2 > 0) {
                    mainActivity.m1604a().postDelayed(new Runnable() { // from class: ι֯
                        @Override // java.lang.Runnable
                        public final void run() {
                            int i4 = MainActivity.f2717a;
                            C5763o c5763o2 = C5601j.f8884a;
                            MusicService musicService = C5601j.f8886a;
                            if (musicService != null) {
                                musicService.m1913a(i2);
                            }
                        }
                    }, 400L);
                }
                mainActivity.m1597a(true);
                C5762o c5762o = mainActivity.f2746a;
                if (c5762o != null) {
                    c5762o.m4707a();
                    c5762o.f9492a.f12123a.getBehavior().m1647a(3);
                }
                break;
            case 3:
                MusicService musicService = (MusicService) this.f15498a;
                EnumC6121p enumC6121p = (EnumC6121p) this.f15499a;
                int i4 = this.f15497a;
                musicService.f3820a = enumC6121p;
                MusicService.m1871a(musicService, i4, false, 4);
                break;
            default:
                ((C3097) this.f15498a).mo3887a(this.f15497a, this.f15499a);
                break;
        }
    }

    public /* synthetic */ RunnableC1296(Object obj, int i, Object obj2, int i2) {
        this.f15496a = i2;
        this.f15498a = obj;
        this.f15497a = i;
        this.f15499a = obj2;
    }
}
