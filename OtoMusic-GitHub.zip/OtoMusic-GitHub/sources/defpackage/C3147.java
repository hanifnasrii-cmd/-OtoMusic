package defpackage;

import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

/* JADX INFO: renamed from: іؐ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3147 extends C5693o {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final boolean f21916a;

    static {
        String property = System.getProperty("java.specification.version");
        Integer numM11001a = property != null ? AbstractC3785.m11001a(property) : null;
        boolean z = false;
        if (numM11001a == null) {
            try {
                SSLSocket.class.getMethod("getApplicationProtocol", null);
                z = true;
            } catch (NoSuchMethodException unused) {
            }
        } else if (numM11001a.intValue() >= 9) {
            z = true;
        }
        f21916a = z;
    }

    @Override // defpackage.C5693o
    /* JADX INFO: renamed from: ã */
    public final void mo1143a(SSLSocket sSLSocket, String str, List list) {
        AbstractC3098.m10103a(list, "protocols");
        SSLParameters sSLParameters = sSLSocket.getSSLParameters();
        sSLParameters.setApplicationProtocols((String[]) C3004.m9978a(list).toArray(new String[0]));
        sSLSocket.setSSLParameters(sSLParameters);
    }

    @Override // defpackage.C5693o
    /* JADX INFO: renamed from: a̅ */
    public final String mo1144a(SSLSocket sSLSocket) {
        try {
            String applicationProtocol = sSLSocket.getApplicationProtocol();
            if (applicationProtocol == null ? true : applicationProtocol.equals("")) {
                return null;
            }
            return applicationProtocol;
        } catch (UnsupportedOperationException unused) {
            return null;
        }
    }
}
