package defpackage;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: ὀ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0398 implements Iterator, InterfaceC1005, InterfaceC3186 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f12900a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Object f12901a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public Iterator f12902a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public InterfaceC1005 f12903a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final RuntimeException m6250a() {
        int i = this.f12900a;
        if (i == 4) {
            return new NoSuchElementException();
        }
        if (i == 5) {
            return new IllegalStateException("Iterator has failed.");
        }
        return new IllegalStateException("Unexpected state of the iterator: " + this.f12900a);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m6251a(InterfaceC1005 interfaceC1005) {
        this.f12903a = interfaceC1005;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final EnumC1045 m6252a(Object obj, AbstractC2148 abstractC2148) {
        this.f12901a = obj;
        this.f12900a = 3;
        this.f12903a = abstractC2148;
        return EnumC1045.COROUTINE_SUSPENDED;
    }

    @Override // defpackage.InterfaceC1005
    public final InterfaceC1031 getContext() {
        return C4889e.f6318a;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        while (true) {
            int i = this.f12900a;
            if (i != 0) {
                if (i != 1) {
                    if (i == 2 || i == 3) {
                        return true;
                    }
                    if (i == 4) {
                        return false;
                    }
                    throw m6250a();
                }
                Iterator it = this.f12902a;
                AbstractC3098.m10100a(it);
                if (it.hasNext()) {
                    this.f12900a = 2;
                    return true;
                }
                this.f12902a = null;
            }
            this.f12900a = 5;
            InterfaceC1005 interfaceC1005 = this.f12903a;
            AbstractC3098.m10100a(interfaceC1005);
            this.f12903a = null;
            interfaceC1005.resumeWith(C6174p.f10843a);
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i = this.f12900a;
        if (i == 0 || i == 1) {
            if (hasNext()) {
                return next();
            }
            throw new NoSuchElementException();
        }
        if (i == 2) {
            this.f12900a = 1;
            Iterator it = this.f12902a;
            AbstractC3098.m10100a(it);
            return it.next();
        }
        if (i != 3) {
            throw m6250a();
        }
        this.f12900a = 0;
        Object obj = this.f12901a;
        this.f12901a = null;
        return obj;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // defpackage.InterfaceC1005
    public final void resumeWith(Object obj) {
        AbstractC1149.m7200a(obj);
        this.f12900a = 4;
    }
}
