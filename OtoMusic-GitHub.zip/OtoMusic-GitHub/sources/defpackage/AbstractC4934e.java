package defpackage;

/* JADX INFO: renamed from: e݆, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC4934e extends AbstractC0493 {
    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public abstract void mo3128a(C5032i c5032i, Object obj);

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m3129a(Object obj) {
        C5032i c5032iM6364a = m6364a();
        try {
            mo3128a(c5032iM6364a, obj);
            c5032iM6364a.f6897a.executeInsert();
        } finally {
            m6368a(c5032iM6364a);
        }
    }
}
