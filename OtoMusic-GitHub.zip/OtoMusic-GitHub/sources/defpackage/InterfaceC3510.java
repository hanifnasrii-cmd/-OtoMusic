package defpackage;

import java.security.MessageDigest;

/* JADX INFO: renamed from: јٰ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC3510 {
    /* JADX INFO: renamed from: ā */
    void mo3884a(byte[] bArr, Object obj, MessageDigest messageDigest);
}
