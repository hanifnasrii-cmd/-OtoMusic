package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.TextView;
import com.piyush.music.R;
import com.piyush.music.widget.DialogScaffold;

/* JADX INFO: renamed from: ϲ߯, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1256 extends AbstractC1255 {

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public static final SparseIntArray f15364a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public long f15365a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f15364a = sparseIntArray;
        sparseIntArray.put(R.id.content, 1);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C1256(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 2, null, f15364a);
        super(null, view, (TextView) objArrM5440a[1], (DialogScaffold) objArrM5440a[0]);
        this.f15365a = -1L;
        this.f15363a.setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f15365a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f15365a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f15365a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
