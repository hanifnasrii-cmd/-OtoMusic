package defpackage;

/* JADX INFO: renamed from: о̐, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2002 extends AbstractC4493c {

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final /* synthetic */ int f18054a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C2002(InterfaceC6244p interfaceC6244p, int i) {
        super(interfaceC6244p);
        this.f18054a = i;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(21:68|(2:70|(2:72|(22:74|150|75|78|111|(1:113)(2:115|(1:117))|114|118|(1:120)(1:121)|122|158|123|126|(1:128)(1:129)|130|(1:132)(1:134)|133|135|(1:137)|138|(1:140)(1:141)|142)(13:79|162|80|83|154|84|87|(1:89)(2:90|(1:92))|93|(1:95)(1:96)|97|(1:99)(1:100)|101))(3:103|160|104))(3:107|148|108)|102|111|(0)(0)|114|118|(0)(0)|122|158|123|126|(0)(0)|130|(0)(0)|133|135|(0)|138|(0)(0)|142) */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x0957, code lost:
    
        r8 = -16777216;
     */
    /* JADX WARN: Removed duplicated region for block: B:113:0x088c  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0891  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x08b7  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x08ba  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x0960  */
    /* JADX WARN: Removed duplicated region for block: B:129:0x0963  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x0974  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x0979  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x0986  */
    /* JADX WARN: Removed duplicated region for block: B:140:0x0994  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0997  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x04b3 A[PHI: r10
      0x04b3: PHI (r10v68 double) = (r10v67 double), (r10v69 double) binds: [B:58:0x04bf, B:54:0x04b1] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:61:0x04c4  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x04c7  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x04f7  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x04fa  */
    @Override // defpackage.AbstractC4493c
    /* JADX INFO: renamed from: a̕ */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void mo1129a(java.lang.Object r128, defpackage.ComponentCallbacks2C2114 r129) {
        /*
            Method dump skipped, instruction units count: 2514
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2002.mo1129a(java.lang.Object, о֜):void");
    }
}
