package defpackage;

/* JADX INFO: renamed from: eⷭ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5003e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ C5009e f6755a;

    public C5003e(C5009e c5009e) {
        this.f6755a = c5009e;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m3263a() {
        C5009e c5009e = this.f6755a;
        if ((c5009e.f6812a && c5009e.f6811a.f18865a) || c5009e.f6828a) {
            c5009e.f6789a.m11058a(2);
        }
    }
}
