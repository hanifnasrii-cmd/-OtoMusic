package defpackage;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBinderMapperImpl;
import com.piyush.music.R;
import com.piyush.music.widget.DialogScaffold;
import com.piyush.taglib.AudioProperties;
import kotlin.Metadata;

/* JADX INFO: renamed from: о͠, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Lо͠;", "Lć;", "<init>", "()V", "іͪ", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public final class C2082 extends AbstractC4426c {

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final C5404j f18279a;

    public C2082() {
        InterfaceC3238 interfaceC3238M4989a = AbstractC6005o.m4989a(EnumC3247.NONE, new C0188(12, new C0188(11, this)));
        this.f18279a = AbstractC2582.m9230a(this, AbstractC2051.m8456a(C2084.class), new C0187(interfaceC3238M4989a, 18), new C0187(interfaceC3238M4989a, 19), new C4185a(this, 14, interfaceC3238M4989a));
    }

    @Override // androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a
    /* JADX INFO: renamed from: a̟ */
    public final Dialog mo261a() {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(getContext());
        int i = AbstractC4932e.f6455a;
        DataBinderMapperImpl dataBinderMapperImpl = AbstractC1127.f14795a;
        AbstractC4932e abstractC4932e = (AbstractC4932e) AbstractC6265p.m5438a(layoutInflaterFrom, R.layout.aw, null, false, null);
        abstractC4932e.f6457a.setTitle(R.string.tl);
        DialogScaffold dialogScaffold = abstractC4932e.f6457a;
        dialogScaffold.getPositiveButton().setText(R.string.u6);
        abstractC4932e.f6456a.setText(requireArguments().getString("playlistName"));
        dialogScaffold.getPositiveButton().setOnClickListener(new ViewOnClickListenerC4190a(abstractC4932e, 28, this));
        dialogScaffold.getNegativeButton().setOnClickListener(new ViewOnClickListenerC1620(26, this));
        C0225 c0225M2175a = m2175a();
        ((C4269a) c0225M2175a.f13791a).f1566a = abstractC4932e.f11082a;
        return c0225M2175a.mo5995a();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ((C2084) this.f18279a.getValue()).f18283a.mo4301a(this, new C4461c(2, new C5872o(8, this)));
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }
}
