package defpackage;

import android.os.Parcelable;
import com.piyush.music.models.DetailSection;
import com.piyush.music.models.Song;

/* JADX INFO: renamed from: a݇, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4253a extends AbstractC5120i {

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static final C4253a f1522a = new C4253a();

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: â */
    public final boolean mo1112a(Object obj, Object obj2) {
        Parcelable parcelable = (Parcelable) obj;
        Parcelable parcelable2 = (Parcelable) obj2;
        if ((parcelable instanceof Song) && (parcelable2 instanceof Song)) {
            Song song = (Song) parcelable;
            Song song2 = (Song) parcelable2;
            return song.equals(song2) && song.getDateModified() == song2.getDateModified();
        }
        if ((parcelable instanceof DetailSection.DiscSeparator) && (parcelable2 instanceof DetailSection.DiscSeparator)) {
            return parcelable.equals(parcelable2);
        }
        return false;
    }

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: ã */
    public final boolean mo1113a(Object obj, Object obj2) {
        Parcelable parcelable = (Parcelable) obj;
        Parcelable parcelable2 = (Parcelable) obj2;
        return ((parcelable instanceof Song) && (parcelable2 instanceof Song)) ? ((Song) parcelable).getId() == ((Song) parcelable2).getId() : (parcelable instanceof DetailSection.DiscSeparator) && (parcelable2 instanceof DetailSection.DiscSeparator) && ((DetailSection.DiscSeparator) parcelable).getDiscNo() == ((DetailSection.DiscSeparator) parcelable2).getDiscNo();
    }

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: a̔ */
    public final Object mo1114a(Object obj, Object obj2) {
        Parcelable parcelable = (Parcelable) obj;
        Parcelable parcelable2 = (Parcelable) obj2;
        return ((parcelable instanceof Song) && (parcelable2 instanceof Song)) ? ((Song) parcelable).equals((Song) parcelable2) ? C5974o.f10108a : C5974o.f10107a : Boolean.FALSE;
    }
}
