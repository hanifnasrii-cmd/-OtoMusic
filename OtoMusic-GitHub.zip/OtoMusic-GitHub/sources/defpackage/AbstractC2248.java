package defpackage;

import java.util.concurrent.Executor;

/* JADX INFO: renamed from: о߮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2248 extends AbstractC4970e {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public ExecutorC1043 f18778a;

    @Override // defpackage.AbstractC1033
    /* JADX INFO: renamed from: a̿ */
    public final void mo3151a(InterfaceC1031 interfaceC1031, Runnable runnable) {
        ExecutorC1043.m7069a(this.f18778a, runnable, 6);
    }

    @Override // defpackage.AbstractC1033
    /* JADX INFO: renamed from: à */
    public final void mo5291a(InterfaceC1031 interfaceC1031, Runnable runnable) {
        ExecutorC1043.m7069a(this.f18778a, runnable, 2);
    }

    @Override // defpackage.AbstractC4970e
    /* JADX INFO: renamed from: a̓ */
    public final Executor mo3178a() {
        return this.f18778a;
    }
}
