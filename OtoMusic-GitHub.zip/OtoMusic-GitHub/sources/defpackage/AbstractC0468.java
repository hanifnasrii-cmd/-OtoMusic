package defpackage;

import android.graphics.Path;
import android.graphics.RectF;
import com.google.android.material.carousel.MaskableFrameLayout;

/* JADX INFO: renamed from: ο֥, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0468 {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public C0456 f13110a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public boolean f13109a = false;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public RectF f13111a = new RectF();

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Path f13112a = new Path();

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public abstract void mo6305a(MaskableFrameLayout maskableFrameLayout);

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public abstract boolean mo6306a();

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m6307a() {
        C0456 c0456;
        RectF rectF = this.f13111a;
        if (rectF.left > rectF.right || rectF.top > rectF.bottom || (c0456 = this.f13110a) == null) {
            return;
        }
        AbstractC0457.f13070a.m6296a(c0456, null, 1.0f, rectF, null, this.f13112a);
    }
}
