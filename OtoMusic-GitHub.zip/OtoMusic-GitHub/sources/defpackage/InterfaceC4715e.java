package defpackage;

import java.io.File;

/* JADX INFO: renamed from: e̘, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC4715e {
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    File mo2824a(InterfaceC3196 interfaceC3196);

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    void mo2825a(InterfaceC3196 interfaceC3196, C5924o c5924o);
}
