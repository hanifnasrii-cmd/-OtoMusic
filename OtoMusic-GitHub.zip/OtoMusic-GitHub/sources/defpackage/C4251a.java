package defpackage;

import com.piyush.music.models.Album;
import com.piyush.music.models.Artist;
import com.piyush.music.models.Genre;
import com.piyush.music.models.Song;
import com.piyush.taglib.AudioProperties;
import java.text.Collator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: renamed from: a݅, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C4251a implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f1519a;

    public /* synthetic */ C4251a(int i) {
        this.f1519a = i;
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) throws JSONException {
        switch (this.f1519a) {
            case 0:
                return Integer.valueOf(((Song) obj).getTitle().compareTo(((Song) obj2).getTitle()));
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return Integer.valueOf(AbstractC3098.m10110a(((Song) obj).getTrackNumber(), ((Song) obj2).getTrackNumber()));
            case 2:
                return Integer.valueOf(AbstractC3098.m10110a(((Song) obj).getDiscNumber(), ((Song) obj2).getDiscNumber()));
            case 3:
                Collator collator = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Album) obj).getYear(), ((Album) obj2).getYear()));
            case 4:
                Collator collator2 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getTitle(), ((Album) obj2).getTitle()));
            case 5:
                Collator collator3 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Album) obj).getSongCount(), ((Album) obj2).getSongCount()));
            case 6:
                Collator collator4 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getAlbumArtist(), ((Album) obj2).getAlbumArtist()));
            case 7:
                Collator collator5 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getTitle(), ((Album) obj2).getTitle()));
            case 8:
                Collator collator6 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getAlbumArtist(), ((Album) obj2).getAlbumArtist()));
            case 9:
                Collator collator7 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9772a(((Album) obj2).getDateAdded(), ((Album) obj).getDateAdded()));
            case 10:
                Collator collator8 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getAlbumArtist(), ((Album) obj2).getAlbumArtist()));
            case 11:
                Collator collator9 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getTitle(), ((Album) obj2).getTitle()));
            case 12:
                Collator collator10 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getTitle(), ((Album) obj2).getTitle()));
            case 13:
                Collator collator11 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Album) obj).getYear(), ((Album) obj2).getYear()));
            case 14:
                Collator collator12 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getAlbumArtist(), ((Album) obj2).getAlbumArtist()));
            case 15:
                Collator collator13 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getTitle(), ((Album) obj2).getTitle()));
            case 16:
                Collator collator14 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Album) obj2).getYear(), ((Album) obj).getYear()));
            case 17:
                Collator collator15 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Album) obj).getAlbumArtist(), ((Album) obj2).getAlbumArtist()));
            case 18:
                JSONObject jSONObject = (JSONObject) obj;
                String str = (String) obj2;
                AbstractC3098.m10103a(jSONObject, "$this$forEachObject");
                AbstractC3098.m10103a(str, "key");
                String string = jSONObject.getString("name");
                AbstractC3098.m10102a(string, "getString(...)");
                return new C3275(string, jSONObject.optString("url"), jSONObject.optString("year"), jSONObject.optString("spdxId"), jSONObject.optString("content"), str);
            case 19:
                Collator collator16 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Artist) obj).getActualName(), ((Artist) obj2).getActualName()));
            case 20:
                Collator collator17 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Artist) obj).getActualName(), ((Artist) obj2).getActualName()));
            case 21:
                Collator collator18 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Artist) obj).getSongCount(), ((Artist) obj2).getSongCount()));
            case 22:
                Collator collator19 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Artist) obj).getActualName(), ((Artist) obj2).getActualName()));
            case 23:
                Collator collator20 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Artist) obj).getAlbumCount(), ((Artist) obj2).getAlbumCount()));
            case 24:
                String str2 = (String) obj;
                InterfaceC1029 interfaceC1029 = (InterfaceC1029) obj2;
                AbstractC3098.m10103a(str2, "acc");
                AbstractC3098.m10103a(interfaceC1029, "element");
                if (str2.length() == 0) {
                    return interfaceC1029.toString();
                }
                return str2 + ", " + interfaceC1029;
            case 25:
                Collator collator21 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Genre) obj).getName(), ((Genre) obj2).getName()));
            case 26:
                Collator collator22 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9770a(((Genre) obj).getName(), ((Genre) obj2).getName()));
            case 27:
                Collator collator23 = AbstractC2885.f20871a;
                return Integer.valueOf(AbstractC2885.m9771a(((Genre) obj).getSongs().size(), ((Genre) obj2).getSongs().size()));
            case 28:
                return (Map) obj;
            default:
                C3549 c3549 = (C3549) obj2;
                return new C3752((Song) c3549.f22954a, ((Number) c3549.f22955a).intValue(), ((Integer) obj).intValue());
        }
    }
}
