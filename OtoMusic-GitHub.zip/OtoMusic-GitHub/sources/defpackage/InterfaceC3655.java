package defpackage;

import java.io.Closeable;

/* JADX INFO: renamed from: օ̎, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC3655 extends Closeable {
    /* JADX INFO: renamed from: a̅ */
    C6040p mo2431a();

    /* JADX INFO: renamed from: a̯ */
    long mo2593a(C4628c c4628c, long j);
}
