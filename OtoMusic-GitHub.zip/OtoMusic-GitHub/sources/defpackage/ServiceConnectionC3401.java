package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/* JADX INFO: renamed from: ј͛, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class ServiceConnectionC3401 implements Handler.Callback, ServiceConnection {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Context f22565a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Handler f22566a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final HashMap f22567a = new HashMap();

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public Set f22568a = new HashSet();

    public ServiceConnectionC3401(Context context) {
        this.f22565a = context;
        HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
        handlerThread.start();
        this.f22566a = new Handler(handlerThread.getLooper(), this);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m10549a(C3400 c3400) {
        boolean z;
        ArrayDeque arrayDeque = c3400.f22563a;
        ComponentName componentName = c3400.f22560a;
        if (Log.isLoggable("NotifManCompat", 3)) {
            Objects.toString(componentName);
            arrayDeque.size();
        }
        if (arrayDeque.isEmpty()) {
            return;
        }
        if (c3400.f22561a) {
            z = true;
        } else {
            Intent component = new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(componentName);
            Context context = this.f22565a;
            boolean zBindService = context.bindService(component, this, 33);
            c3400.f22561a = zBindService;
            if (zBindService) {
                c3400.f22564a = 0;
            } else {
                Objects.toString(componentName);
                context.unbindService(this);
            }
            z = c3400.f22561a;
        }
        if (!z || c3400.f22562a == null) {
            m10550a(c3400);
            return;
        }
        while (true) {
            C3398 c3398 = (C3398) arrayDeque.peek();
            if (c3398 == null) {
                break;
            }
            try {
                if (Log.isLoggable("NotifManCompat", 3)) {
                    c3398.toString();
                }
                c3398.m10548a(c3400.f22562a);
                arrayDeque.remove();
            } catch (DeadObjectException unused) {
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Objects.toString(componentName);
                }
            } catch (RemoteException unused2) {
                Objects.toString(componentName);
            }
        }
        if (arrayDeque.isEmpty()) {
            return;
        }
        m10550a(c3400);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m10550a(C3400 c3400) {
        ComponentName componentName = c3400.f22560a;
        ArrayDeque arrayDeque = c3400.f22563a;
        Handler handler = this.f22566a;
        if (handler.hasMessages(3, componentName)) {
            return;
        }
        int i = c3400.f22564a + 1;
        c3400.f22564a = i;
        if (i <= 6) {
            Log.isLoggable("NotifManCompat", 3);
            handler.sendMessageDelayed(handler.obtainMessage(3, componentName), (1 << r4) * 1000);
        } else {
            arrayDeque.size();
            Objects.toString(componentName);
            arrayDeque.clear();
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i = message.what;
        InterfaceC3018 interfaceC3018 = null;
        Context context = this.f22565a;
        HashMap map = this.f22567a;
        if (i == 0) {
            C3398 c3398 = (C3398) message.obj;
            Set setM10552a = C3402.m10552a(context);
            if (!setM10552a.equals(this.f22568a)) {
                this.f22568a = setM10552a;
                List<ResolveInfo> listQueryIntentServices = context.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
                HashSet<ComponentName> hashSet = new HashSet();
                for (ResolveInfo resolveInfo : listQueryIntentServices) {
                    if (((HashSet) setM10552a).contains(resolveInfo.serviceInfo.packageName)) {
                        ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                        ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                        if (resolveInfo.serviceInfo.permission != null) {
                            componentName.toString();
                        } else {
                            hashSet.add(componentName);
                        }
                    }
                }
                for (ComponentName componentName2 : hashSet) {
                    if (!map.containsKey(componentName2)) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Objects.toString(componentName2);
                        }
                        map.put(componentName2, new C3400(componentName2));
                    }
                }
                Iterator it = map.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    if (!hashSet.contains(entry.getKey())) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Objects.toString(entry.getKey());
                        }
                        C3400 c3400 = (C3400) entry.getValue();
                        if (c3400.f22561a) {
                            context.unbindService(this);
                            c3400.f22561a = false;
                        }
                        c3400.f22562a = null;
                        it.remove();
                    }
                }
            }
            for (C3400 c34002 : map.values()) {
                c34002.f22563a.add(c3398);
                m10549a(c34002);
            }
        } else if (i == 1) {
            C3399 c3399 = (C3399) message.obj;
            ComponentName componentName3 = c3399.f22558a;
            IBinder iBinder = c3399.f22559a;
            C3400 c34003 = (C3400) map.get(componentName3);
            if (c34003 != null) {
                int i2 = AbstractBinderC3017.f21525a;
                if (iBinder != null) {
                    IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(InterfaceC3018.f21526a);
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof InterfaceC3018)) {
                        C3016 c3016 = new C3016();
                        c3016.f21524a = iBinder;
                        interfaceC3018 = c3016;
                    } else {
                        interfaceC3018 = (InterfaceC3018) iInterfaceQueryLocalInterface;
                    }
                }
                c34003.f22562a = interfaceC3018;
                c34003.f22564a = 0;
                m10549a(c34003);
                return true;
            }
        } else if (i == 2) {
            C3400 c34004 = (C3400) map.get((ComponentName) message.obj);
            if (c34004 != null) {
                if (c34004.f22561a) {
                    context.unbindService(this);
                    c34004.f22561a = false;
                }
                c34004.f22562a = null;
                return true;
            }
        } else {
            if (i != 3) {
                return false;
            }
            C3400 c34005 = (C3400) map.get((ComponentName) message.obj);
            if (c34005 != null) {
                m10549a(c34005);
                return true;
            }
        }
        return true;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            Objects.toString(componentName);
        }
        this.f22566a.obtainMessage(1, new C3399(componentName, iBinder)).sendToTarget();
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        if (Log.isLoggable("NotifManCompat", 3)) {
            Objects.toString(componentName);
        }
        this.f22566a.obtainMessage(2, componentName).sendToTarget();
    }
}
