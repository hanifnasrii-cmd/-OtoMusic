package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import androidx.fragment.app.AbstractC3995a;
import androidx.fragment.app.AbstractComponentCallbacksC3990a;
import androidx.fragment.app.C3994a;
import com.piyush.taglib.AudioProperties;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;
import kotlin.Metadata;

/* JADX INFO: renamed from: е⃧, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
@InterfaceC3343("fragment")
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0017\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0002¨\u0006\u0004"}, d2 = {"Lе⃧;", "Lј̢;", "Lе⃨;", "à", "navigation-fragment_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {AudioProperties.ChannelMode.JOINT_STEREO, 8, 0}, xi = 48)
public class C1940 extends AbstractC3344 {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Context f17806a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final AbstractC3995a f17807a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f17808a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final LinkedHashSet f17809a = new LinkedHashSet();

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final ArrayList f17810a = new ArrayList();

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C1938 f17811a = new C1938(0, this);

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C3447 f17812a = new C3447(2, this);

    /* JADX INFO: renamed from: е⃧$à, reason: invalid class name */
    public static final class a extends AbstractC6278p {

        /* JADX INFO: renamed from: á, reason: contains not printable characters */
        public WeakReference f17813a;

        @Override // defpackage.AbstractC6278p
        /* JADX INFO: renamed from: ã */
        public final void mo331a() {
            WeakReference weakReference = this.f17813a;
            if (weakReference == null) {
                AbstractC3098.m10141a("completeTransition");
                throw null;
            }
            InterfaceC5038i interfaceC5038i = (InterfaceC5038i) weakReference.get();
            if (interfaceC5038i != null) {
                interfaceC5038i.invoke();
            }
        }
    }

    public C1940(Context context, AbstractC3995a abstractC3995a, int i) {
        this.f17806a = context;
        this.f17807a = abstractC3995a;
        this.f17808a = i;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static void m8307a(C1940 c1940, String str, int i) {
        boolean z = (i & 2) == 0;
        boolean z2 = (i & 4) != 0;
        ArrayList arrayList = c1940.f17810a;
        if (z2) {
            AbstractC2857.m9686a(arrayList, new C1429(2, str));
        }
        arrayList.add(new C3549(str, Boolean.valueOf(z)));
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static boolean m8308a() {
        return Log.isLoggable("FragmentManager", 2) || Log.isLoggable("FragmentNavigator", 2);
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: à */
    public final AbstractC5679j mo939a() {
        return new C1941(this);
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: ã */
    public final void mo7460a(List list, C3317 c3317) {
        AbstractC3995a abstractC3995a = this.f17807a;
        if (abstractC3995a.m312a()) {
            return;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            C5662j c5662j = (C5662j) it.next();
            boolean zIsEmpty = ((List) m10414a().f9098a.f10306a.getValue()).isEmpty();
            if (c3317 == null || zIsEmpty || !c3317.f22281a || !this.f17809a.remove(c5662j.f9079a)) {
                androidx.fragment.app.a aVarM8312a = m8312a(c5662j, c3317);
                String str = c5662j.f9079a;
                if (!zIsEmpty) {
                    C5662j c5662j2 = (C5662j) AbstractC2851.m9653a((List) m10414a().f9098a.f10306a.getValue());
                    if (c5662j2 != null) {
                        m8307a(this, c5662j2.f9079a, 6);
                    }
                    m8307a(this, str, 6);
                    if (!aVarM8312a.f406a) {
                        throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
                    }
                    aVarM8312a.f405a = true;
                    aVarM8312a.f407a = str;
                }
                aVarM8312a.m235a(false);
                if (m8308a()) {
                    c5662j.toString();
                }
                m10414a().m4525a(c5662j);
            } else {
                abstractC3995a.m300a(new C3994a(abstractC3995a, c5662j.f9079a, 0), false);
                m10414a().m4525a(c5662j);
            }
        }
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: ā */
    public final void mo7461a(final C5666j c5666j) {
        super.mo7461a(c5666j);
        m8308a();
        InterfaceC1946 interfaceC1946 = new InterfaceC1946() { // from class: е⃦
            @Override // defpackage.InterfaceC1946
            /* JADX INFO: renamed from: á */
            public final void mo7459a(AbstractC3995a abstractC3995a, AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a) {
                Object objPrevious;
                AbstractC3098.m10103a(abstractC3995a, "<anonymous parameter 0>");
                C5666j c5666j2 = c5666j;
                List list = (List) c5666j2.f9098a.f10306a.getValue();
                ListIterator listIterator = list.listIterator(list.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        objPrevious = null;
                        break;
                    } else {
                        objPrevious = listIterator.previous();
                        if (AbstractC3098.m10094a(((C5662j) objPrevious).f9079a, abstractComponentCallbacksC3990a.getTag())) {
                            break;
                        }
                    }
                }
                C5662j c5662j = (C5662j) objPrevious;
                boolean zM8308a = C1940.m8308a();
                C1940 c1940 = this;
                if (zM8308a) {
                    abstractComponentCallbacksC3990a.toString();
                    Objects.toString(c5662j);
                    Objects.toString(c1940.f17807a);
                }
                if (c5662j != null) {
                    abstractComponentCallbacksC3990a.getViewLifecycleOwnerLiveData().mo4301a(abstractComponentCallbacksC3990a, new C4021a(new C1942(c1940, abstractComponentCallbacksC3990a, c5662j), 6));
                    abstractComponentCallbacksC3990a.getLifecycle().mo10357a(c1940.f17811a);
                    c1940.m8311a(abstractComponentCallbacksC3990a, c5662j, c5666j2);
                }
            }
        };
        AbstractC3995a abstractC3995a = this.f17807a;
        abstractC3995a.f491a.add(interfaceC1946);
        C1944 c1944 = new C1944(c5666j, this);
        if (abstractC3995a.f489a == null) {
            abstractC3995a.f489a = new ArrayList();
        }
        abstractC3995a.f489a.add(c1944);
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: a̅ */
    public final void mo7462a(C5662j c5662j) {
        String str = c5662j.f9079a;
        AbstractC3995a abstractC3995a = this.f17807a;
        if (abstractC3995a.m312a()) {
            return;
        }
        androidx.fragment.app.a aVarM8312a = m8312a(c5662j, null);
        List list = (List) m10414a().f9098a.f10306a.getValue();
        if (list.size() > 1) {
            C5662j c5662j2 = (C5662j) AbstractC2851.m9648a(AbstractC2852.m9676a(list) - 1, list);
            if (c5662j2 != null) {
                m8307a(this, c5662j2.f9079a, 6);
            }
            m8307a(this, str, 4);
            abstractC3995a.m300a(new C1932(abstractC3995a, str, -1), false);
            m8307a(this, str, 2);
            if (!aVarM8312a.f406a) {
                throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
            }
            aVarM8312a.f405a = true;
            aVarM8312a.f407a = str;
        }
        aVarM8312a.m235a(false);
        m10414a().m4520a(c5662j);
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void mo8309a(Bundle bundle) {
        ArrayList<String> stringArrayList = bundle.getStringArrayList("androidx-nav-fragment:navigator:savedIds");
        if (stringArrayList != null) {
            LinkedHashSet linkedHashSet = this.f17809a;
            linkedHashSet.clear();
            AbstractC2857.m9685a(linkedHashSet, stringArrayList);
        }
    }

    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final Bundle mo8310a() {
        LinkedHashSet linkedHashSet = this.f17809a;
        if (linkedHashSet.isEmpty()) {
            return null;
        }
        return AbstractC3573.m10733a(new C3549("androidx-nav-fragment:navigator:savedIds", new ArrayList(linkedHashSet)));
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0092, code lost:
    
        if (r10 < 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0094, code lost:
    
        r8 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0096, code lost:
    
        r8 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0097, code lost:
    
        if (r8 != false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00a1, code lost:
    
        if (defpackage.AbstractC3098.m10094a(r12.f9079a, r7.f9079a) != false) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00a3, code lost:
    
        r11 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00a4, code lost:
    
        if (r11 == false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00a6, code lost:
    
        r4.add(r9);
     */
    @Override // defpackage.AbstractC3344
    /* JADX INFO: renamed from: ä */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void mo7463a(defpackage.C5662j r19, boolean r20) {
        /*
            Method dump skipped, instruction units count: 271
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C1940.mo7463a(jⷬ, boolean):void");
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m8311a(AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a, C5662j c5662j, C5666j c5666j) {
        AbstractC3098.m10103a(abstractComponentCallbacksC3990a, "fragment");
        C6284p viewModelStore = abstractComponentCallbacksC3990a.getViewModelStore();
        AbstractC3098.m10102a(viewModelStore, "fragment.viewModelStore");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        C2807 c2807M8456a = AbstractC2051.m8456a(a.class);
        if (linkedHashMap.containsKey(c2807M8456a)) {
            throw new IllegalArgumentException(("A `initializer` with the same `clazz` has already been added: " + c2807M8456a.m9578a() + '.').toString());
        }
        linkedHashMap.put(c2807M8456a, new C6280p(c2807M8456a));
        Collection collectionValues = linkedHashMap.values();
        AbstractC3098.m10103a(collectionValues, "initializers");
        C6280p[] c6280pArr = (C6280p[]) collectionValues.toArray(new C6280p[0]);
        C4156a c4156a = new C4156a((C6280p[]) Arrays.copyOf(c6280pArr, c6280pArr.length));
        C1069 c1069 = C1069.f14537a;
        AbstractC3098.m10103a(c1069, "defaultCreationExtras");
        C5454j c5454j = new C5454j(viewModelStore, (InterfaceC6282p) c4156a, (AbstractC1070) c1069);
        C2807 c2807M8456a2 = AbstractC2051.m8456a(a.class);
        String strM9578a = c2807M8456a2.m9578a();
        if (strM9578a == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        ((a) c5454j.m4272a(c2807M8456a2, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strM9578a))).f17813a = new WeakReference(new C4244a(c5662j, c5666j, this, abstractComponentCallbacksC3990a));
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final androidx.fragment.app.a m8312a(C5662j c5662j, C3317 c3317) {
        AbstractC5679j abstractC5679j = c5662j.f9075a;
        AbstractC3098.m10101a(abstractC5679j, "null cannot be cast to non-null type androidx.navigation.fragment.FragmentNavigator.Destination");
        Bundle bundleM4512a = c5662j.m4512a();
        String str = ((C1941) abstractC5679j).f17814a;
        if (str == null) {
            throw new IllegalStateException("Fragment class was not set");
        }
        char cCharAt = str.charAt(0);
        Context context = this.f17806a;
        if (cCharAt == '.') {
            str = context.getPackageName() + str;
        }
        AbstractC3995a abstractC3995a = this.f17807a;
        C1926 c1926M309a = abstractC3995a.m309a();
        context.getClassLoader();
        AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990aM8304a = c1926M309a.m8304a(str);
        AbstractC3098.m10102a(abstractComponentCallbacksC3990aM8304a, "fragmentManager.fragment…t.classLoader, className)");
        abstractComponentCallbacksC3990aM8304a.setArguments(bundleM4512a);
        androidx.fragment.app.a aVar = new androidx.fragment.app.a(abstractC3995a);
        int i = c3317 != null ? c3317.f22285a : -1;
        int i2 = c3317 != null ? c3317.f22286a : -1;
        int i3 = c3317 != null ? c3317.f22287a : -1;
        int i4 = c3317 != null ? c3317.f22288a : -1;
        if (i != -1 || i2 != -1 || i3 != -1 || i4 != -1) {
            if (i == -1) {
                i = 0;
            }
            if (i2 == -1) {
                i2 = 0;
            }
            if (i3 == -1) {
                i3 = 0;
            }
            int i5 = i4 != -1 ? i4 : 0;
            aVar.f400a = i;
            aVar.f401a = i2;
            aVar.f402a = i3;
            aVar.f403a = i5;
        }
        aVar.m239a(this.f17808a, abstractComponentCallbacksC3990aM8304a, c5662j.f9079a);
        aVar.m240a(abstractComponentCallbacksC3990aM8304a);
        aVar.f414a = true;
        return aVar;
    }
}
