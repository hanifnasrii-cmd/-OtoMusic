package defpackage;

/* JADX INFO: renamed from: јަ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC3558 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f22984a;

    static {
        int[] iArr = new int[EnumC3557.values().length];
        try {
            iArr[EnumC3557.A1.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[EnumC3557.A2.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[EnumC3557.A3.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        f22984a = iArr;
    }
}
