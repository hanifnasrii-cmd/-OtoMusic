package defpackage;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: renamed from: ι⃜, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0281 implements InterfaceC2134 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C5853o f12568a = new C5853o(5);

    @Override // defpackage.InterfaceC2134
    /* JADX INFO: renamed from: a̎ */
    public final InterfaceC2122 mo2414a(InterfaceC2122 interfaceC2122, C3515 c3515) {
        C0279 c0279;
        int i;
        double d;
        int i2;
        Bitmap bitmap = (Bitmap) interfaceC2122.get();
        C2339 c2339M8748a = C2339.m8748a(bitmap);
        Map mapM8749a = c2339M8748a.m8749a();
        Iterator it = mapM8749a.values().iterator();
        if (!it.hasNext()) {
            throw new UnsupportedOperationException("Empty collection can't be reduced.");
        }
        Object next = it.next();
        while (it.hasNext()) {
            next = Integer.valueOf(((Integer) it.next()).intValue() + ((Integer) next).intValue());
        }
        double dIntValue = ((Number) next).intValue();
        double dM9329a = 0.0d;
        float f = 5.0f;
        if (dIntValue == 0.0d) {
            Iterator it2 = c2339M8748a.m8750a().iterator();
            while (true) {
                if (!it2.hasNext()) {
                    c0279 = new C0279(-16777216, Float.NaN);
                    break;
                }
                int argb = ((Color) it2.next()).toArgb();
                if (C2649.m9328a(argb).m9329a() >= 5.0f) {
                    c0279 = new C0279(argb, Float.NaN);
                    break;
                }
            }
        } else {
            int size = mapM8749a.size();
            int[] iArr = new int[size];
            C2649[] c2649Arr = new C2649[size];
            double[] dArr = new double[360];
            int i3 = 0;
            for (Map.Entry entry : mapM8749a.entrySet()) {
                Integer num = (Integer) entry.getKey();
                Integer num2 = (Integer) entry.getValue();
                C2649 c2649M9328a = C2649.m9328a(num.intValue());
                iArr[i3] = num.intValue();
                c2649Arr[i3] = c2649M9328a;
                double dIntValue2 = ((double) num2.intValue()) / dIntValue;
                float f2 = f;
                C2649[] c2649Arr2 = c2649Arr;
                dM9329a += ((double) c2649M9328a.m9329a()) * dIntValue2;
                if (c2649M9328a.m9329a() > f2) {
                    int iM8929a = AbstractC2411.m8929a(c2649M9328a.m9330a()) % 360;
                    dArr[iM8929a] = dArr[iM8929a] + dIntValue2;
                }
                i3++;
                f = f2;
                c2649Arr = c2649Arr2;
            }
            float f3 = f;
            C2649[] c2649Arr3 = c2649Arr;
            double d2 = Double.NEGATIVE_INFINITY;
            int i4 = 0;
            int i5 = -16777216;
            while (i4 < size) {
                C2649 c2649 = c2649Arr3[i4];
                AbstractC3098.m10100a(c2649);
                int iM8929a2 = AbstractC2411.m8929a(c2649.m9330a());
                int i6 = iM8929a2 - 15;
                int i7 = iM8929a2 + 15;
                if (i6 <= i7) {
                    d = 0.0d;
                    while (true) {
                        if (i6 < 0) {
                            i = size;
                            i2 = (i6 % 360) + 360;
                        } else {
                            i = size;
                            i2 = i6 >= 360 ? i6 % 360 : i6;
                        }
                        d += dArr[i2];
                        if (i6 == i7) {
                            break;
                        }
                        i6++;
                        size = i;
                    }
                } else {
                    i = size;
                    d = 0.0d;
                }
                if (c2649.m9329a() >= f3 && d > 0.01d) {
                    double dM5226a = AbstractC6161p.m5226a(c2649, d);
                    if (dM5226a > d2) {
                        i5 = iArr[i4];
                        d2 = dM5226a;
                    }
                }
                i4++;
                size = i;
            }
            c0279 = new C0279(i5, (float) dM9329a);
        }
        C3701 c3701 = new C3701(c0279.m6074a());
        C5853o c5853o = f12568a;
        c5853o.getClass();
        C2448 c2448 = (C2448) c5853o.f9776a;
        return new C4316a(4, new C0271(new C0272(new C4827e(new C0273(c2448), c3701, c2448, (C3701) c5853o.f9777a), c0279.m6075a() < 4.5f), bitmap));
    }
}
