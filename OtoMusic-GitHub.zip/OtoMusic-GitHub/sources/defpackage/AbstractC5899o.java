package defpackage;

/* JADX INFO: renamed from: o۬, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC5899o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int f9923a = 0;

    static {
        AbstractC3098.m10102a(C0110.m5884a("ProcessUtils"), "tagWithPrefix(\"ProcessUtils\")");
    }
}
