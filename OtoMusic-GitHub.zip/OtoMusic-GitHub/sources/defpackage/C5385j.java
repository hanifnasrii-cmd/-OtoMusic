package defpackage;

import android.media.MediaRoute2Info;
import android.media.MediaRouter2;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Messenger;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: renamed from: j̢, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5385j extends AbstractC5423j {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final String f8142a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final MediaRouter2.RoutingController f8143a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final Messenger f8144a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final Messenger f8145a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final Handler f8147a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public C5405j f8151a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final /* synthetic */ C5389j f8152a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final SparseArray f8146a = new SparseArray();

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final AtomicInteger f8148a = new AtomicInteger(1);

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final RunnableC1797 f8149a = new RunnableC1797(6, this);

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f8150a = -1;

    public C5385j(C5389j c5389j, MediaRouter2.RoutingController routingController, String str) {
        this.f8152a = c5389j;
        this.f8143a = routingController;
        this.f8142a = str;
        int i = C5389j.f8158a;
        Bundle controlHints = routingController.getControlHints();
        Messenger messenger = controlHints == null ? null : (Messenger) controlHints.getParcelable("androidx.mediarouter.media.KEY_MESSENGER");
        this.f8144a = messenger;
        this.f8145a = messenger != null ? new Messenger(new HandlerC1522(this)) : null;
        this.f8147a = new Handler(Looper.getMainLooper());
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void mo4121a() {
        this.f8143a.release();
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void mo4122a(int i) {
        MediaRouter2.RoutingController routingController = this.f8143a;
        if (routingController == null) {
            return;
        }
        routingController.setVolume(i);
        this.f8150a = i;
        Handler handler = this.f8147a;
        RunnableC1797 runnableC1797 = this.f8149a;
        handler.removeCallbacks(runnableC1797);
        handler.postDelayed(runnableC1797, 1000L);
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final void mo4123a(int i) {
        MediaRouter2.RoutingController routingController = this.f8143a;
        if (routingController == null) {
            return;
        }
        int volume = this.f8150a;
        if (volume < 0) {
            volume = routingController.getVolume();
        }
        int iMax = Math.max(0, Math.min(volume + i, this.f8143a.getVolumeMax()));
        this.f8150a = iMax;
        this.f8143a.setVolume(iMax);
        Handler handler = this.f8147a;
        RunnableC1797 runnableC1797 = this.f8149a;
        handler.removeCallbacks(runnableC1797);
        handler.postDelayed(runnableC1797, 1000L);
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final void mo4124a(String str) {
        MediaRoute2Info mediaRoute2InfoM4132a;
        if (str == null || str.isEmpty() || (mediaRoute2InfoM4132a = this.f8152a.m4132a(str)) == null) {
            return;
        }
        this.f8143a.selectRoute(mediaRoute2InfoM4132a);
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void mo4125a(String str) {
        MediaRoute2Info mediaRoute2InfoM4132a;
        if (str == null || str.isEmpty() || (mediaRoute2InfoM4132a = this.f8152a.m4132a(str)) == null) {
            return;
        }
        this.f8143a.deselectRoute(mediaRoute2InfoM4132a);
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final void mo4126a(ArrayList arrayList) {
        if (arrayList.isEmpty()) {
            return;
        }
        String str = (String) arrayList.get(0);
        C5389j c5389j = this.f8152a;
        MediaRoute2Info mediaRoute2InfoM4132a = c5389j.m4132a(str);
        if (mediaRoute2InfoM4132a == null) {
            return;
        }
        c5389j.f8159a.transferTo(mediaRoute2InfoM4132a);
    }
}
