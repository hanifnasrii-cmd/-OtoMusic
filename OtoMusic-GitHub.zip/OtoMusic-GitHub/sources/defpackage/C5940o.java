package defpackage;

/* JADX INFO: renamed from: o߫, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5940o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public String f10024a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f10025a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int f10026a;

    public C5940o(String str, int i, int i2) {
        this.f10024a = str;
        this.f10025a = i;
        this.f10026a = i2;
    }
}
