package defpackage;

import com.piyush.music.sort.Sort;

/* JADX INFO: renamed from: o֣, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC5816o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f9659a;

    static {
        int[] iArr = new int[Sort.values().length];
        try {
            iArr[Sort.NAME.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[Sort.SONG_COUNT.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[Sort.DATE_MODIFIED.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[Sort.DATE_ADDED.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        f9659a = iArr;
    }
}
