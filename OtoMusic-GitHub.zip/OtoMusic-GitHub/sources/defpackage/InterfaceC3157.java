package defpackage;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* JADX INFO: renamed from: іؚ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
@Retention(RetentionPolicy.RUNTIME)
public @interface InterfaceC3157 {
    boolean ignore() default false;

    String name() default "\u0000";
}
