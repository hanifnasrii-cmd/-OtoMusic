package defpackage;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

/* JADX INFO: renamed from: о⃙, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC2264 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
