package defpackage;

/* JADX INFO: renamed from: ο֘, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0455 {
    /* JADX INFO: renamed from: â */
    InterfaceC1027 mo6033a(InterfaceC1027 interfaceC1027);
}
