package defpackage;

/* JADX INFO: renamed from: іⷡ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3279 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static EnumC3281 m10353a(EnumC3282 enumC3282) {
        AbstractC3098.m10103a(enumC3282, "state");
        int i = AbstractC3278.f22193a[enumC3282.ordinal()];
        if (i == 1) {
            return EnumC3281.ON_DESTROY;
        }
        if (i == 2) {
            return EnumC3281.ON_STOP;
        }
        if (i != 3) {
            return null;
        }
        return EnumC3281.ON_PAUSE;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static EnumC3281 m10354a(EnumC3282 enumC3282) {
        AbstractC3098.m10103a(enumC3282, "state");
        int i = AbstractC3278.f22193a[enumC3282.ordinal()];
        if (i == 1) {
            return EnumC3281.ON_START;
        }
        if (i == 2) {
            return EnumC3281.ON_RESUME;
        }
        if (i != 5) {
            return null;
        }
        return EnumC3281.ON_CREATE;
    }
}
