package defpackage;

import android.os.Handler;

/* JADX INFO: renamed from: o۪, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5897o implements InterfaceC3292 {

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static final C5897o f9909a = new C5897o();

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f9910a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f9911a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public Handler f9914a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public boolean f9912a = true;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f9913a = true;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C3294 f9915a = new C3294(this);

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final RunnableC4311a f9916a = new RunnableC4311a(12, this);

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final C3097 f9917a = new C3097(13, this);

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m4831a() {
        int i = this.f9911a + 1;
        this.f9911a = i;
        if (i == 1) {
            if (this.f9912a) {
                this.f9915a.m10362a(EnumC3281.ON_RESUME);
                this.f9912a = false;
            } else {
                Handler handler = this.f9914a;
                AbstractC3098.m10100a(handler);
                handler.removeCallbacks(this.f9916a);
            }
        }
    }

    @Override // defpackage.InterfaceC3292
    public final AbstractC3284 getLifecycle() {
        return this.f9915a;
    }
}
