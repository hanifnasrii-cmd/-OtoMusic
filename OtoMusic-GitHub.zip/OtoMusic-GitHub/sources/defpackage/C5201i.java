package defpackage;

/* JADX INFO: renamed from: iٌ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5201i {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final double f7442a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final double f7443a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final double f7444a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f7445a;

    public C5201i(int i) {
        this.f7445a = i;
        C6332p c6332p = C6332p.f11242a;
        int i2 = i & 255;
        double dM8641a = AbstractC2179.m8641a((16711680 & i) >> 16);
        double dM8641a2 = AbstractC2179.m8641a((65280 & i) >> 8);
        double dM8641a3 = AbstractC2179.m8641a(i2);
        double d = (0.18051042d * dM8641a3) + (0.35762064d * dM8641a2) + (0.41233895d * dM8641a);
        double d2 = (0.0722d * dM8641a3) + (0.7152d * dM8641a2) + (0.2126d * dM8641a);
        double d3 = (dM8641a3 * 0.95034478d) + (dM8641a2 * 0.11916382d) + (dM8641a * 0.01932141d);
        double[][] dArr = AbstractC5121i.f7084a;
        double[] dArr2 = dArr[0];
        double d4 = (dArr2[2] * d3) + (dArr2[1] * d2) + (dArr2[0] * d);
        double[] dArr3 = dArr[1];
        double d5 = (dArr3[2] * d3) + (dArr3[1] * d2) + (dArr3[0] * d);
        double[] dArr4 = dArr[2];
        double d6 = (d3 * dArr4[2]) + (d2 * dArr4[1]) + (d * dArr4[0]);
        double[] dArr5 = c6332p.f11249a;
        double d7 = c6332p.f11251a;
        double d8 = c6332p.f11246a;
        double d9 = c6332p.f11243a;
        double d10 = dArr5[0] * d4;
        double d11 = dArr5[1] * d5;
        double d12 = dArr5[2] * d6;
        double d13 = c6332p.f11250a;
        double dPow = Math.pow(AbstractC4072a.m731a(d10, d13, 100.0d), 0.42d);
        double dPow2 = Math.pow(AbstractC4072a.m731a(d11, d13, 100.0d), 0.42d);
        double dPow3 = Math.pow(AbstractC4072a.m731a(d12, d13, 100.0d), 0.42d);
        double dM758a = AbstractC4072a.m758a(d10, 400.0d, dPow) / (dPow + 27.13d);
        double dM758a2 = AbstractC4072a.m758a(d11, 400.0d, dPow2) / (dPow2 + 27.13d);
        double dM758a3 = AbstractC4072a.m758a(d12, 400.0d, dPow3) / (dPow3 + 27.13d);
        double dM733a = AbstractC4072a.m733a(dM758a2, -12.0d, dM758a * 11.0d, dM758a3, 11.0d);
        double d14 = ((dM758a + dM758a2) - (dM758a3 * 2.0d)) / 9.0d;
        double d15 = dM758a2 * 20.0d;
        double dM732a = AbstractC4072a.m732a(dM758a3, 21.0d, (dM758a * 20.0d) + d15, 20.0d);
        double dM733a2 = AbstractC4072a.m733a(dM758a, 40.0d, d15, dM758a3, 20.0d);
        double degrees = Math.toDegrees(Math.atan2(d14, dM733a));
        if (degrees < 0.0d) {
            degrees += 360.0d;
        } else if (degrees >= 360.0d) {
            degrees -= 360.0d;
        }
        double d16 = degrees;
        double radians = Math.toRadians(d16);
        double dPow4 = (Math.pow((dM733a2 * c6332p.f11244a) / d9, c6332p.f11252a * d8) * 100.0d) / 100.0d;
        Math.sqrt(dPow4);
        double d17 = d9 + 4.0d;
        double dPow5 = Math.pow((Math.hypot(dM733a, d14) * (((((Math.cos(Math.toRadians(d16 < 20.14d ? d16 + 360.0d : d16) + 2.0d) + 3.8d) * 0.25d) * 3846.153846153846d) * c6332p.f11247a) * c6332p.f11245a)) / (dM732a + 0.305d), 0.9d) * Math.pow(1.64d - Math.pow(0.29d, c6332p.f11248a), 0.73d);
        double dSqrt = Math.sqrt(dPow4) * dPow5;
        Math.sqrt((dPow5 * d8) / d17);
        Math.log1p(dSqrt * d7 * 0.0228d);
        Math.cos(radians);
        Math.sin(radians);
        this.f7442a = d16;
        this.f7443a = dSqrt;
        this.f7444a = (AbstractC2179.m8639a(AbstractC2582.m9244a(new double[]{AbstractC2179.m8641a(AbstractC2179.m8647a(i)), AbstractC2179.m8641a(AbstractC2179.m8638a(i)), AbstractC2179.m8641a(i2)}, AbstractC2179.f18598a)[1] / 100.0d) * 116.0d) - 16.0d;
    }

    /* JADX WARN: Removed duplicated region for block: B:85:0x02aa  */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static defpackage.C5201i m3850a(double r44, double r46, double r48) {
        /*
            Method dump skipped, instruction units count: 1042
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5201i.m3850a(double, double, double):iٌ");
    }
}
