package defpackage;

import android.os.StrictMode;

/* JADX INFO: renamed from: рⷤ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2620 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static StrictMode.VmPolicy.Builder m9307a(StrictMode.VmPolicy.Builder builder) {
        return builder.permitUnsafeIntentLaunch();
    }
}
