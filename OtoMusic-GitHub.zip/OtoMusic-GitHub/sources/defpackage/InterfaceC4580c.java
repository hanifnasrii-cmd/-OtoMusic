package defpackage;

/* JADX INFO: renamed from: cۭ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC4580c extends InterfaceC3339 {
}
