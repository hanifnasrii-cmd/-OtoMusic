package defpackage;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: ο⃰, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0625 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC2178 f13669a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C4557c f13670a = new C4557c(10);

    public C0625(AbstractC2178 abstractC2178) {
        this.f13669a = abstractC2178;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void m6518a(ArrayList arrayList) {
        if (arrayList.size() <= 900) {
            m6519a(arrayList);
            return;
        }
        ArrayList arrayListM9640a = AbstractC2851.m9640a(arrayList);
        int size = arrayListM9640a.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListM9640a.get(i);
            i++;
            m6519a((List) obj);
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m6519a(List list) {
        StringBuilder sb = new StringBuilder();
        sb.append("DELETE FROM song_lyrics WHERE song_path IN (");
        AbstractC5121i.m3478a(list.size(), sb);
        sb.append(")");
        AbstractC6161p.m5222a(this.f13669a, false, true, new C0605(1, sb.toString(), list));
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String m6520a(String str) {
        return (String) AbstractC6161p.m5222a(this.f13669a, true, false, new C4556c(str, 6));
    }
}
