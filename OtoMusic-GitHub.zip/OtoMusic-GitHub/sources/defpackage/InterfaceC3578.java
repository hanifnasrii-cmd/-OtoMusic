package defpackage;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* JADX INFO: renamed from: ј߽, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
@Retention(RetentionPolicy.RUNTIME)
public @interface InterfaceC3578 {
    String encoding() default "binary";

    String value() default "";
}
