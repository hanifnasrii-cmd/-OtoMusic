package defpackage;

/* JADX INFO: renamed from: ι֙, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C0125 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f12024a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C0126 f12025a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C5220i f12026a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f12027a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f12028a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f12029a;

    public C0125(int i) {
        this.f12024a = i;
        if (i <= 0) {
            AbstractC3478.m10624a("maxSize <= 0");
            throw null;
        }
        this.f12025a = new C0126(0);
        this.f12026a = new C5220i(2);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public Object mo5911a(Object obj) {
        AbstractC3098.m10103a(obj, "key");
        return null;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public void mo5912a(boolean z, Object obj, Object obj2, Object obj3) {
        AbstractC3098.m10103a(obj, "key");
        AbstractC3098.m10103a(obj2, "oldValue");
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Object m5913a(Object obj) {
        Object objPut;
        AbstractC3098.m10103a(obj, "key");
        synchronized (this.f12026a) {
            C0126 c0126 = this.f12025a;
            c0126.getClass();
            Object obj2 = c0126.f12030a.get(obj);
            if (obj2 != null) {
                this.f12028a++;
                return obj2;
            }
            this.f12029a++;
            Object objMo5911a = mo5911a(obj);
            if (objMo5911a == null) {
                return null;
            }
            synchronized (this.f12026a) {
                try {
                    C0126 c01262 = this.f12025a;
                    c01262.getClass();
                    objPut = c01262.f12030a.put(obj, objMo5911a);
                    if (objPut != null) {
                        C0126 c01263 = this.f12025a;
                        c01263.getClass();
                        c01263.f12030a.put(obj, objPut);
                    } else {
                        this.f12027a++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (objPut != null) {
                mo5912a(false, obj, objMo5911a, objPut);
                return objPut;
            }
            m5915a(this.f12024a);
            return objMo5911a;
        }
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Object m5914a(Object obj, Object obj2) {
        Object objPut;
        AbstractC3098.m10103a(obj, "key");
        synchronized (this.f12026a) {
            this.f12027a++;
            C0126 c0126 = this.f12025a;
            c0126.getClass();
            objPut = c0126.f12030a.put(obj, obj2);
            if (objPut != null) {
                this.f12027a--;
            }
        }
        if (objPut != null) {
            mo5912a(false, obj, objPut, obj2);
        }
        m5915a(this.f12024a);
        return objPut;
    }

    /* JADX WARN: Code restructure failed: missing block: B:36:0x0088, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0089, code lost:
    
        defpackage.AbstractC3478.m10625a("LruCache.sizeOf() is reporting inconsistent results!");
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x008e, code lost:
    
        throw null;
     */
    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m5915a(int r7) {
        /*
            r6 = this;
        L0:
            iٟ r0 = r6.f12026a
            monitor-enter(r0)
            int r1 = r6.f12027a     // Catch: java.lang.Throwable -> L17
            r2 = 0
            if (r1 < 0) goto L89
            ι֚ r1 = r6.f12025a     // Catch: java.lang.Throwable -> L17
            java.util.LinkedHashMap r1 = r1.f12030a     // Catch: java.lang.Throwable -> L17
            boolean r1 = r1.isEmpty()     // Catch: java.lang.Throwable -> L17
            if (r1 == 0) goto L1a
            int r1 = r6.f12027a     // Catch: java.lang.Throwable -> L17
            if (r1 != 0) goto L89
            goto L1a
        L17:
            r7 = move-exception
            goto L8f
        L1a:
            int r1 = r6.f12027a     // Catch: java.lang.Throwable -> L17
            if (r1 <= r7) goto L87
            ι֚ r1 = r6.f12025a     // Catch: java.lang.Throwable -> L17
            java.util.LinkedHashMap r1 = r1.f12030a     // Catch: java.lang.Throwable -> L17
            boolean r1 = r1.isEmpty()     // Catch: java.lang.Throwable -> L17
            if (r1 == 0) goto L29
            goto L87
        L29:
            ι֚ r1 = r6.f12025a     // Catch: java.lang.Throwable -> L17
            java.util.LinkedHashMap r1 = r1.f12030a     // Catch: java.lang.Throwable -> L17
            java.util.Set r1 = r1.entrySet()     // Catch: java.lang.Throwable -> L17
            java.lang.String r3 = "<get-entries>(...)"
            defpackage.AbstractC3098.m10102a(r1, r3)     // Catch: java.lang.Throwable -> L17
            boolean r3 = r1 instanceof java.util.List     // Catch: java.lang.Throwable -> L17
            if (r3 == 0) goto L4a
            java.util.List r1 = (java.util.List) r1     // Catch: java.lang.Throwable -> L17
            boolean r3 = r1.isEmpty()     // Catch: java.lang.Throwable -> L17
            if (r3 == 0) goto L44
        L42:
            r1 = r2
            goto L59
        L44:
            r3 = 0
            java.lang.Object r1 = r1.get(r3)     // Catch: java.lang.Throwable -> L17
            goto L59
        L4a:
            java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Throwable -> L17
            boolean r3 = r1.hasNext()     // Catch: java.lang.Throwable -> L17
            if (r3 != 0) goto L55
            goto L42
        L55:
            java.lang.Object r1 = r1.next()     // Catch: java.lang.Throwable -> L17
        L59:
            java.util.Map$Entry r1 = (java.util.Map.Entry) r1     // Catch: java.lang.Throwable -> L17
            if (r1 != 0) goto L5f
            monitor-exit(r0)
            return
        L5f:
            java.lang.Object r3 = r1.getKey()     // Catch: java.lang.Throwable -> L17
            java.lang.Object r1 = r1.getValue()     // Catch: java.lang.Throwable -> L17
            ι֚ r4 = r6.f12025a     // Catch: java.lang.Throwable -> L17
            r4.getClass()     // Catch: java.lang.Throwable -> L17
            java.lang.String r5 = "key"
            defpackage.AbstractC3098.m10103a(r3, r5)     // Catch: java.lang.Throwable -> L17
            java.util.LinkedHashMap r4 = r4.f12030a     // Catch: java.lang.Throwable -> L17
            r4.remove(r3)     // Catch: java.lang.Throwable -> L17
            int r4 = r6.f12027a     // Catch: java.lang.Throwable -> L17
            java.lang.String r5 = "value"
            defpackage.AbstractC3098.m10103a(r1, r5)     // Catch: java.lang.Throwable -> L17
            r5 = 1
            int r4 = r4 - r5
            r6.f12027a = r4     // Catch: java.lang.Throwable -> L17
            monitor-exit(r0)
            r6.mo5912a(r5, r3, r1, r2)
            goto L0
        L87:
            monitor-exit(r0)
            return
        L89:
            java.lang.String r7 = "LruCache.sizeOf() is reporting inconsistent results!"
            defpackage.AbstractC3478.m10625a(r7)     // Catch: java.lang.Throwable -> L17
            throw r2     // Catch: java.lang.Throwable -> L17
        L8f:
            monitor-exit(r0)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C0125.m5915a(int):void");
    }

    public final String toString() {
        String str;
        synchronized (this.f12026a) {
            try {
                int i = this.f12028a;
                int i2 = this.f12029a + i;
                str = "LruCache[maxSize=" + this.f12024a + ",hits=" + this.f12028a + ",misses=" + this.f12029a + ",hitRate=" + (i2 != 0 ? (i * 100) / i2 : 0) + "%]";
            } catch (Throwable th) {
                throw th;
            }
        }
        return str;
    }
}
