package defpackage;

import android.text.Editable;
import android.view.View;
import com.piyush.music.fragments.settings.SettingsMainFragment;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: сׄ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class ViewOnFocusChangeListenerC2813 implements View.OnFocusChangeListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f20621a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ Object f20622a;

    public /* synthetic */ ViewOnFocusChangeListenerC2813(int i, Object obj) {
        this.f20621a = i;
        this.f20622a = obj;
    }

    @Override // android.view.View.OnFocusChangeListener
    public final void onFocusChange(View view, boolean z) {
        switch (this.f20621a) {
            case 0:
                C2816 c2816 = (C2816) this.f20622a;
                c2816.m9586a(c2816.m9587a());
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C4814e c4814e = (C4814e) this.f20622a;
                c4814e.f6111a = z;
                c4814e.m3108a();
                if (!z) {
                    c4814e.m2977a(false);
                    c4814e.f6112a = false;
                }
                break;
            case 2:
                SettingsMainFragment settingsMainFragment = (SettingsMainFragment) this.f20622a;
                if (!z) {
                    AbstractC6265p abstractC6265p = settingsMainFragment.f4707a;
                    AbstractC3098.m10100a(abstractC6265p);
                    Editable text = ((AbstractC0425) abstractC6265p).f12960a.getText();
                    if (text == null || text.length() == 0) {
                        settingsMainFragment.m1808a();
                    }
                } else {
                    settingsMainFragment.m1810a();
                }
                break;
            default:
                C3860 c3860 = (C3860) this.f20622a;
                if (!z && c3860.f23871a.getVisibility() == 0) {
                    c3860.m11034a();
                    break;
                }
                break;
        }
    }
}
