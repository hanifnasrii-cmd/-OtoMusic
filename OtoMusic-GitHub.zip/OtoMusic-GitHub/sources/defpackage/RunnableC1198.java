package defpackage;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;

/* JADX INFO: renamed from: ϲۚ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class RunnableC1198 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f15090a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ ArrayList f15091a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C1206 f15092a;

    public /* synthetic */ RunnableC1198(C1206 c1206, ArrayList arrayList, int i) {
        this.f15090a = i;
        this.f15092a = c1206;
        this.f15091a = arrayList;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f15090a) {
            case 0:
                ArrayList arrayList = this.f15091a;
                int size = arrayList.size();
                int i = 0;
                while (true) {
                    C1206 c1206 = this.f15092a;
                    if (i >= size) {
                        arrayList.clear();
                        c1206.f15133a.remove(arrayList);
                    } else {
                        Object obj = arrayList.get(i);
                        i++;
                        C1205 c1205 = (C1205) obj;
                        AbstractC2042 abstractC2042 = c1205.f15122a;
                        int i2 = c1205.f15123a;
                        int i3 = c1205.f15124a;
                        int i4 = c1205.f15125a;
                        int i5 = c1205.f15126a;
                        View view = abstractC2042.f18146a;
                        int i6 = i4 - i2;
                        int i7 = i5 - i3;
                        if (i6 != 0) {
                            view.animate().translationX(0.0f);
                        }
                        if (i7 != 0) {
                            view.animate().translationY(0.0f);
                        }
                        ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
                        c1206.f15136a.add(abstractC2042);
                        viewPropertyAnimatorAnimate.setDuration(c1206.f18088a).setListener(new C1202(c1206, abstractC2042, i6, view, i7, viewPropertyAnimatorAnimate)).start();
                    }
                    break;
                }
                break;
            default:
                ArrayList arrayList2 = this.f15091a;
                int size2 = arrayList2.size();
                int i8 = 0;
                while (true) {
                    C1206 c12062 = this.f15092a;
                    if (i8 >= size2) {
                        arrayList2.clear();
                        c12062.f15134a.remove(arrayList2);
                        break;
                    } else {
                        Object obj2 = arrayList2.get(i8);
                        i8++;
                        C1204 c1204 = (C1204) obj2;
                        ArrayList arrayList3 = c12062.f15138a;
                        long j = c12062.f18089a;
                        AbstractC2042 abstractC20422 = c1204.f15116a;
                        View view2 = abstractC20422 == null ? null : abstractC20422.f18146a;
                        AbstractC2042 abstractC20423 = c1204.f15117a;
                        View view3 = abstractC20423 != null ? abstractC20423.f18146a : null;
                        if (view2 != null) {
                            ViewPropertyAnimator duration = view2.animate().setDuration(j);
                            arrayList3.add(c1204.f15116a);
                            duration.translationX(c1204.f15120a - c1204.f15118a);
                            duration.translationY(c1204.f15121a - c1204.f15119a);
                            duration.alpha(0.0f).setListener(new C1203(c12062, c1204, duration, view2, 0)).start();
                        }
                        if (view3 != null) {
                            ViewPropertyAnimator viewPropertyAnimatorAnimate2 = view3.animate();
                            arrayList3.add(c1204.f15117a);
                            viewPropertyAnimatorAnimate2.translationX(0.0f).translationY(0.0f).setDuration(j).alpha(1.0f).setListener(new C1203(c12062, c1204, viewPropertyAnimatorAnimate2, view3, 1)).start();
                        }
                    }
                }
                break;
        }
    }
}
