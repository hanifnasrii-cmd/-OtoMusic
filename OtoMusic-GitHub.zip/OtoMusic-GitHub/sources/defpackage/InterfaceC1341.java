package defpackage;

import com.google.android.material.appbar.AppBarLayout;

/* JADX INFO: renamed from: а̑, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1341 {
    /* JADX INFO: renamed from: ä */
    void mo1099a(AppBarLayout appBarLayout, int i);
}
