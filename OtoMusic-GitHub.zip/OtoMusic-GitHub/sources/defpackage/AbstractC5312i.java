package defpackage;

/* JADX INFO: renamed from: i⃭, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC5312i {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f7874a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final EnumC5300i f7875a;

    public AbstractC5312i(String str, EnumC5300i enumC5300i) {
        this.f7874a = str;
        this.f7875a = enumC5300i;
    }
}
