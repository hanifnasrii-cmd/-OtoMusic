package defpackage;

import com.piyush.music.models.tag.TagField;

/* JADX INFO: renamed from: jؒ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC5521j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final /* synthetic */ int[] f8686a;

    static {
        int[] iArr = new int[TagField.values().length];
        try {
            iArr[TagField.TITLE.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[TagField.ARTIST.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[TagField.ALBUM.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[TagField.ALBUM_ARTIST.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr[TagField.YEAR.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr[TagField.TRACK.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            iArr[TagField.DISC_NO.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
        try {
            iArr[TagField.GENRE.ordinal()] = 8;
        } catch (NoSuchFieldError unused8) {
        }
        try {
            iArr[TagField.COMPOSER.ordinal()] = 9;
        } catch (NoSuchFieldError unused9) {
        }
        try {
            iArr[TagField.RELEASE_TYPE.ordinal()] = 10;
        } catch (NoSuchFieldError unused10) {
        }
        try {
            iArr[TagField.TRACK_TOTAL.ordinal()] = 11;
        } catch (NoSuchFieldError unused11) {
        }
        try {
            iArr[TagField.DISC_TOTAL.ordinal()] = 12;
        } catch (NoSuchFieldError unused12) {
        }
        try {
            iArr[TagField.LYRICS.ordinal()] = 13;
        } catch (NoSuchFieldError unused13) {
        }
        f8686a = iArr;
    }
}
