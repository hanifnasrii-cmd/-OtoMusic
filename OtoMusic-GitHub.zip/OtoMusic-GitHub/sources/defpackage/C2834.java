package defpackage;

import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: сْ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C2834 implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f20668a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f20669a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ List f20670a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ Object f20671a;

    public /* synthetic */ C2834(C5813o c5813o, int i, List list, int i2) {
        this.f20668a = i2;
        this.f20671a = c5813o;
        this.f20669a = i;
        this.f20670a = list;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) throws Exception {
        switch (this.f20668a) {
            case 0:
                String str = (String) this.f20671a;
                ArrayList arrayList = (ArrayList) this.f20670a;
                int i = this.f20669a;
                InterfaceC2207 interfaceC2207Mo8687a = ((InterfaceC2205) obj).mo8687a(str);
                try {
                    int size = arrayList.size();
                    int i2 = 0;
                    int i3 = 1;
                    while (i2 < size) {
                        Object obj2 = arrayList.get(i2);
                        i2++;
                        interfaceC2207Mo8687a.mo4766a(i3, (String) obj2);
                        i3++;
                    }
                    interfaceC2207Mo8687a.mo4763a(i + 1, 200);
                    int iM9236a = AbstractC2582.m9236a(interfaceC2207Mo8687a, "song_path_a");
                    int iM9236a2 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "song_path_b");
                    int iM9236a3 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "weight");
                    int iM9236a4 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "co_play_count");
                    int iM9236a5 = AbstractC2582.m9236a(interfaceC2207Mo8687a, "last_updated");
                    ArrayList arrayList2 = new ArrayList();
                    while (interfaceC2207Mo8687a.mo4767a()) {
                        arrayList2.add(new C2829(interfaceC2207Mo8687a.mo4765a(iM9236a), interfaceC2207Mo8687a.mo4765a(iM9236a2), (float) interfaceC2207Mo8687a.getDouble(iM9236a3), (int) interfaceC2207Mo8687a.getLong(iM9236a4), interfaceC2207Mo8687a.getLong(iM9236a5)));
                        break;
                    }
                    interfaceC2207Mo8687a.close();
                    return arrayList2;
                } catch (Throwable th) {
                    interfaceC2207Mo8687a.close();
                    throw th;
                }
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C5813o c5813o = (C5813o) this.f20671a;
                AbstractC2178 abstractC2178 = c5813o.f9654a;
                ArrayList arrayList3 = (ArrayList) this.f20670a;
                int i4 = this.f20669a;
                List listM4730a = c5813o.m4730a(i4);
                if (!AbstractC3098.m10094a(listM4730a, arrayList3)) {
                    if (arrayList3.isEmpty()) {
                        AbstractC6161p.m5222a(abstractC2178, false, true, new C0059(i4, 2));
                    } else if (listM4730a.isEmpty()) {
                        ArrayList arrayList4 = new ArrayList(AbstractC2853.m9682a(arrayList3, 10));
                        int size2 = arrayList3.size();
                        int i5 = 0;
                        int i6 = 0;
                        while (i6 < size2) {
                            Object obj3 = arrayList3.get(i6);
                            i6++;
                            int i7 = i5 + 1;
                            if (i5 < 0) {
                                AbstractC2852.m9681a();
                                throw null;
                            }
                            arrayList4.add(new C5810o((String) obj3, i4, i5));
                            i5 = i7;
                        }
                        AbstractC6161p.m5222a(abstractC2178, false, true, new C5774o(c5813o, 3, arrayList4));
                    } else {
                        ArrayList arrayList5 = new ArrayList();
                        ArrayList arrayList6 = new ArrayList();
                        int iMax = Math.max(listM4730a.size(), arrayList3.size());
                        for (int i8 = 0; i8 < iMax; i8++) {
                            String str2 = (String) AbstractC2851.m9648a(i8, listM4730a);
                            String str3 = (String) AbstractC2851.m9648a(i8, arrayList3);
                            if (!AbstractC3098.m10094a(str2, str3)) {
                                if (str2 == null) {
                                    AbstractC3098.m10100a(str3);
                                    arrayList6.add(new C5810o(str3, i4, i8));
                                } else if (str3 == null) {
                                    arrayList5.add(Integer.valueOf(i8));
                                } else {
                                    arrayList5.add(Integer.valueOf(i8));
                                    arrayList6.add(new C5810o(str3, i4, i8));
                                }
                            }
                        }
                        if (!arrayList5.isEmpty()) {
                            if (arrayList5.size() <= 900) {
                                c5813o.m4733a(i4, arrayList5);
                            } else {
                                ArrayList arrayListM9640a = AbstractC2851.m9640a(arrayList5);
                                int size3 = arrayListM9640a.size();
                                int i9 = 0;
                                while (i9 < size3) {
                                    Object obj4 = arrayListM9640a.get(i9);
                                    i9++;
                                    c5813o.m4733a(i4, (List) obj4);
                                }
                            }
                        }
                        if (!arrayList6.isEmpty()) {
                            AbstractC6161p.m5222a(abstractC2178, false, true, new C5774o(c5813o, 3, arrayList6));
                        }
                    }
                }
                return C6174p.f10843a;
            default:
                C5813o c5813o2 = (C5813o) this.f20671a;
                AbstractC2178 abstractC21782 = c5813o2.f9654a;
                List list = this.f20670a;
                if (!list.isEmpty()) {
                    int i10 = this.f20669a;
                    int iIntValue = ((Number) AbstractC6161p.m5222a(abstractC21782, true, false, new C0059(i10, 3))).intValue() + 1;
                    List list2 = list;
                    ArrayList arrayList7 = new ArrayList(AbstractC2853.m9682a(list2, 10));
                    int i11 = 0;
                    for (Object obj5 : list2) {
                        int i12 = i11 + 1;
                        if (i11 < 0) {
                            AbstractC2852.m9681a();
                            throw null;
                        }
                        arrayList7.add(new C5810o((String) obj5, i10, i11 + iIntValue));
                        i11 = i12;
                    }
                    AbstractC6161p.m5222a(abstractC21782, false, true, new C5774o(c5813o2, 3, arrayList7));
                }
                return C6174p.f10843a;
        }
    }

    public /* synthetic */ C2834(String str, ArrayList arrayList, int i) {
        this.f20668a = 0;
        this.f20671a = str;
        this.f20670a = arrayList;
        this.f20669a = i;
    }
}
