package defpackage;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import com.google.android.datatransport.runtime.EncodedPayload;
import com.google.android.datatransport.runtime.EventInternal;
import com.google.android.datatransport.runtime.backends.BackendRequest;
import com.google.android.datatransport.runtime.backends.BackendResponse;
import com.google.android.datatransport.runtime.backends.TransportBackend;
import com.google.android.datatransport.runtime.logging.Logging;
import com.google.android.datatransport.runtime.retries.Retries;
import com.google.android.datatransport.runtime.time.Clock;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/* JADX INFO: renamed from: с͇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2719 implements TransportBackend {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C3097 f20270a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final ConnectivityManager f20271a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Context f20272a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final URL f20273a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Clock f20274a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Clock f20275a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f20276a;

    public C2719(Context context, Clock clock, Clock clock2) {
        C3165 c3165 = new C3165();
        C4842e.f6190a.configure(c3165);
        c3165.f21945a = true;
        this.f20270a = new C3097(1, c3165);
        this.f20272a = context;
        this.f20271a = (ConnectivityManager) context.getSystemService("connectivity");
        this.f20273a = m9457a(C4664c.f5602a);
        this.f20274a = clock2;
        this.f20275a = clock;
        this.f20276a = 130000;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static URL m9457a(String str) {
        try {
            return new URL(str);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(AbstractC4072a.m759a("Invalid url: ", str), e);
        }
    }

    @Override // com.google.android.datatransport.runtime.backends.TransportBackend
    public final EventInternal decorate(EventInternal eventInternal) {
        int subtype;
        NetworkInfo activeNetworkInfo = this.f20271a.getActiveNetworkInfo();
        EventInternal.Builder builderAddMetadata = eventInternal.toBuilder().addMetadata("sdk-version", Build.VERSION.SDK_INT).addMetadata("model", Build.MODEL).addMetadata("hardware", Build.HARDWARE).addMetadata("device", Build.DEVICE).addMetadata("product", Build.PRODUCT).addMetadata("os-uild", Build.ID).addMetadata("manufacturer", Build.MANUFACTURER).addMetadata("fingerprint", Build.FINGERPRINT);
        Calendar.getInstance();
        EventInternal.Builder builderAddMetadata2 = builderAddMetadata.addMetadata("tz-offset", TimeZone.getDefault().getOffset(Calendar.getInstance().getTimeInMillis()) / 1000).addMetadata("net-type", activeNetworkInfo == null ? EnumC3363.NONE.m10454a() : activeNetworkInfo.getType());
        int i = -1;
        if (activeNetworkInfo == null) {
            subtype = EnumC3362.UNKNOWN_MOBILE_SUBTYPE.m10452a();
        } else {
            subtype = activeNetworkInfo.getSubtype();
            if (subtype == -1) {
                subtype = EnumC3362.COMBINED.m10452a();
            } else if (EnumC3362.m10451a(subtype) == null) {
                subtype = 0;
            }
        }
        EventInternal.Builder builderAddMetadata3 = builderAddMetadata2.addMetadata("mobile-subtype", subtype).addMetadata("country", Locale.getDefault().getCountry()).addMetadata("locale", Locale.getDefault().getLanguage());
        Context context = this.f20272a;
        EventInternal.Builder builderAddMetadata4 = builderAddMetadata3.addMetadata("mcc_mnc", ((TelephonyManager) context.getSystemService("phone")).getSimOperator());
        try {
            i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Logging.e("CctTransportBackend", "Unable to find version code for package", e);
        }
        return builderAddMetadata4.addMetadata("application_build", Integer.toString(i)).build();
    }

    @Override // com.google.android.datatransport.runtime.backends.TransportBackend
    public final BackendResponse send(BackendRequest backendRequest) {
        C1654 c1654;
        HashMap map = new HashMap();
        for (EventInternal eventInternal : backendRequest.getEvents()) {
            String transportName = eventInternal.getTransportName();
            if (map.containsKey(transportName)) {
                ((List) map.get(transportName)).add(eventInternal);
            } else {
                ArrayList arrayList = new ArrayList();
                arrayList.add(eventInternal);
                map.put(transportName, arrayList);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        for (Map.Entry entry : map.entrySet()) {
            EventInternal eventInternal2 = (EventInternal) ((List) entry.getValue()).get(0);
            C1654 c16542 = new C1654();
            c16542.m8069a(EnumC5937o.DEFAULT);
            c16542.m8070a(this.f20275a.getTime());
            c16542.m8071a(this.f20274a.getTime());
            C1339 c1339 = new C1339(6, false);
            c1339.m7517a(EnumC2817.ANDROID_FIREBASE);
            C1649 c1649 = new C1649();
            c1649.m8059a(Integer.valueOf(eventInternal2.getInteger("sdk-version")));
            c1649.m8056a(eventInternal2.get("model"));
            c1649.m8052a(eventInternal2.get("hardware"));
            c1649.m8050a(eventInternal2.get("device"));
            c1649.m8058a(eventInternal2.get("product"));
            c1649.m8057a(eventInternal2.get("os-uild"));
            c1649.m8054a(eventInternal2.get("manufacturer"));
            c1649.m8051a(eventInternal2.get("fingerprint"));
            c1649.m8049a(eventInternal2.get("country"));
            c1649.m8053a(eventInternal2.get("locale"));
            c1649.m8055a(eventInternal2.get("mcc_mnc"));
            c1649.m8048a(eventInternal2.get("application_build"));
            c1339.m7513a(c1649.m8047a());
            c16542.m8063a(c1339.m7489a());
            try {
                c16542.m8072a(Integer.parseInt((String) entry.getKey()));
            } catch (NumberFormatException unused) {
                c16542.m8073a((String) entry.getKey());
            }
            ArrayList arrayList3 = new ArrayList();
            for (EventInternal eventInternal3 : (List) entry.getValue()) {
                EncodedPayload encodedPayload = eventInternal3.getEncodedPayload();
                C4907e encoding = encodedPayload.getEncoding();
                if (encoding.equals(new C4907e("proto"))) {
                    byte[] bytes = encodedPayload.getBytes();
                    c1654 = new C1654();
                    c1654.m8074a(bytes);
                } else if (encoding.equals(new C4907e("json"))) {
                    String str = new String(encodedPayload.getBytes(), Charset.forName("UTF-8"));
                    C1654 c16543 = new C1654();
                    c16543.m8075a(str);
                    c1654 = c16543;
                } else {
                    Logging.w("CctTransportBackend", "Received event of unsupported encoding %s. Skipping...", encoding);
                }
                c1654.m8065a(eventInternal3.getEventMillis());
                c1654.m8066a(eventInternal3.getUptimeMillis());
                c1654.m8076a(eventInternal3.getLong("tz-offset"));
                C1339 c13392 = new C1339(7, false);
                c13392.m7520a(EnumC3363.m10453a(eventInternal3.getInteger("net-type")));
                c13392.m7519a(EnumC3362.m10451a(eventInternal3.getInteger("mobile-subtype")));
                c1654.m8068a(c13392.m7490a());
                if (eventInternal3.getCode() != null) {
                    c1654.m8064a(eventInternal3.getCode());
                }
                arrayList3.add(c1654.m8060a());
            }
            c16542.m8067a(arrayList3);
            arrayList2.add(c16542.m8061a());
        }
        C1651 c1651 = new C1651(arrayList2);
        byte[] extras = backendRequest.getExtras();
        URL urlM9457a = this.f20273a;
        if (extras != null) {
            try {
                C4664c c4664cM2770a = C4664c.m2770a(backendRequest.getExtras());
                String str2 = c4664cM2770a.f5606a;
                str = str2 != null ? str2 : null;
                String str3 = c4664cM2770a.f5605a;
                if (str3 != null) {
                    urlM9457a = m9457a(str3);
                }
            } catch (IllegalArgumentException unused2) {
                return BackendResponse.fatalError();
            }
        }
        try {
            C2718 c2718 = (C2718) Retries.retry(5, new C2717(urlM9457a, c1651, str), new C1467(8, this), new C0118(7));
            int i = c2718.f20267a;
            if (i == 200) {
                return BackendResponse.ok(c2718.f20269a);
            }
            if (i < 500 && i != 404) {
                return i == 400 ? BackendResponse.invalidPayload() : BackendResponse.fatalError();
            }
            return BackendResponse.transientError();
        } catch (IOException e) {
            Logging.e("CctTransportBackend", "Could not make request to the backend", e);
            return BackendResponse.transientError();
        }
    }
}
