package defpackage;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

/* JADX INFO: renamed from: а߬, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1584 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float f16429a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object f16430a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public Object f16431a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public Object f16432a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Object f16433a;

    public C1584(float f) {
        this.f16429a = f * 84.0f;
        Paint paint = new Paint();
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        this.f16430a = paint;
        Paint paint2 = new Paint(7);
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        this.f16431a = paint2;
    }

    public C1584(Context context) {
        this.f16430a = context != null ? context.getApplicationContext() : null;
        this.f16432a = C4648c.f5550a;
        if (context == null) {
            this.f16433a = C1532.f16241a;
        }
        this.f16429a = 8.0f;
    }
}
