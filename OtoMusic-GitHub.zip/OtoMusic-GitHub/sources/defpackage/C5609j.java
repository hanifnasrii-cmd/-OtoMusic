package defpackage;

/* JADX INFO: renamed from: jް, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5609j extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public Object f8914a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Object f8915a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public Object f8916a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f8917a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f8918a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public /* synthetic */ Object f8919a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final /* synthetic */ C5611j f8920a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final /* synthetic */ boolean f8921a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5609j(C5611j c5611j, boolean z, InterfaceC1005 interfaceC1005) {
        super(2, interfaceC1005);
        this.f8920a = c5611j;
        this.f8921a = z;
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        C5609j c5609j = new C5609j(this.f8920a, this.f8921a, interfaceC1005);
        c5609j.f8919a = obj;
        return c5609j;
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        return ((C5609j) create((InterfaceC1044) obj, (InterfaceC1005) obj2)).invokeSuspend(C6174p.f10843a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x0144, code lost:
    
        if (r5 == r10) goto L96;
     */
    /* JADX WARN: Removed duplicated region for block: B:54:0x017d A[LOOP:4: B:52:0x0177->B:54:0x017d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:57:0x019f  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01be  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x01c7  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01e6 A[LOOP:0: B:67:0x01e0->B:69:0x01e6, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:72:0x020b  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x021b A[LOOP:1: B:74:0x0215->B:76:0x021b, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x023f  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x025a A[LOOP:3: B:84:0x0258->B:85:0x025a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:97:0x02a0  */
    /* JADX WARN: Type inference failed for: r11v22, types: [ϲ̦, ϲ̷] */
    /* JADX WARN: Type inference failed for: r11v30 */
    /* JADX WARN: Type inference failed for: r11v31 */
    @Override // defpackage.AbstractC4415c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r20) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 718
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5609j.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
