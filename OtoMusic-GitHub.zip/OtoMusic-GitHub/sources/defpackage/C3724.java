package defpackage;

/* JADX INFO: renamed from: օ͓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3724 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C2406 f23534a;

    public C3724(C2406 c2406) {
        this.f23534a = c2406;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C2406 m10929a() {
        return this.f23534a;
    }
}
