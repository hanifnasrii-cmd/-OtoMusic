package defpackage;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: renamed from: іִ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3131 extends GestureDetector.SimpleOnGestureListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public boolean f21847a = true;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ C3132 f21848a;

    public C3131(C3132 c3132) {
        this.f21848a = c3132;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public final boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public final void onLongPress(MotionEvent motionEvent) {
        View viewM10182a;
        AbstractC2042 abstractC2042M523a;
        C3132 c3132 = this.f21848a;
        AbstractC3130 abstractC3130 = c3132.f21861a;
        if (!this.f21847a || (viewM10182a = c3132.m10182a(motionEvent)) == null || (abstractC2042M523a = c3132.f21866a.m523a(viewM10182a)) == null) {
            return;
        }
        if ((AbstractC3130.m10164a(abstractC3130.mo10168a(abstractC2042M523a), c3132.f21866a.getLayoutDirection()) & 16711680) != 0) {
            int pointerId = motionEvent.getPointerId(0);
            int i = c3132.f21860a;
            if (pointerId == i) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i);
                float x = motionEvent.getX(iFindPointerIndex);
                float y = motionEvent.getY(iFindPointerIndex);
                c3132.f21852a = x;
                c3132.f21853a = y;
                c3132.f21857a = 0.0f;
                c3132.f21856a = 0.0f;
                abstractC3130.getClass();
            }
        }
    }
}
