package defpackage;

import android.animation.TimeInterpolator;
import android.graphics.Rect;
import android.util.Property;
import android.view.View;
import com.piyush.music.widget.SlideNumberView;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;

/* JADX INFO: renamed from: сְ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2796 extends Property {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f20564a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C2796(int i, Class cls, String str) {
        super(cls, str);
        this.f20564a = i;
    }

    @Override // android.util.Property
    public final Object get(Object obj) {
        switch (this.f20564a) {
            case 0:
                return Float.valueOf(((C2797) obj).f20575a);
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return Float.valueOf(((C2797) obj).f20576a);
            case 2:
                return Float.valueOf(((C0005) obj).f11533a);
            case 3:
                return Float.valueOf(((C5716o) obj).f9341a);
            case 4:
                return Float.valueOf(((SlideNumberView) obj).getNumberRoll());
            case 5:
                return Float.valueOf(AbstractC6325p.f11236a.mo5520a((View) obj));
            default:
                return ((View) obj).getClipBounds();
        }
    }

    @Override // android.util.Property
    public final void set(Object obj, Object obj2) {
        switch (this.f20564a) {
            case 0:
                C2797 c2797 = (C2797) obj;
                float fFloatValue = ((Float) obj2).floatValue();
                c2797.f20575a = fFloatValue;
                int i = (int) (fFloatValue * 6000.0f);
                TimeInterpolator timeInterpolator = c2797.f20572a;
                ArrayList arrayList = (ArrayList) c2797.f7359a;
                C4796e c4796e = (C4796e) arrayList.get(0);
                float f = c2797.f20575a * 1080.0f;
                int[] iArr = C2797.f20566a;
                float interpolation = 0.0f;
                for (int i2 : iArr) {
                    interpolation += timeInterpolator.getInterpolation(AbstractC5177i.m3808a(i, i2, 500)) * 90.0f;
                }
                c4796e.f6064a = f + interpolation;
                float interpolation2 = timeInterpolator.getInterpolation(AbstractC5177i.m3808a(i, 0, 3000)) - timeInterpolator.getInterpolation(AbstractC5177i.m3808a(i, 3000, 3000));
                c4796e.f6058a = 0.0f;
                float[] fArr = C2797.f20567a;
                float fM2690a = AbstractC4647c.m2690a(fArr[0], fArr[1], interpolation2);
                c4796e.f6059a = fM2690a;
                float f2 = c2797.f20576a;
                if (f2 > 0.0f) {
                    c4796e.f6059a = (1.0f - f2) * fM2690a;
                }
                int i3 = 0;
                while (true) {
                    if (i3 < iArr.length) {
                        float fM3808a = AbstractC5177i.m3808a(i, iArr[i3], 100);
                        if (fM3808a < 0.0f || fM3808a > 1.0f) {
                            i3++;
                        } else {
                            int i4 = i3 + c2797.f20574a;
                            int[] iArr2 = c2797.f20573a.f4898a;
                            int length = i4 % iArr2.length;
                            int length2 = (length + 1) % iArr2.length;
                            ((C4796e) arrayList.get(0)).f6060a = AbstractC1440.m7662a(timeInterpolator.getInterpolation(fM3808a), Integer.valueOf(iArr2[length]), Integer.valueOf(iArr2[length2])).intValue();
                        }
                    }
                }
                ((C3063) c2797.f7358a).invalidateSelf();
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                ((C2797) obj).f20576a = ((Float) obj2).floatValue();
                break;
            case 2:
                C0005 c0005 = (C0005) obj;
                float fFloatValue2 = ((Float) obj2).floatValue();
                c0005.f11533a = fFloatValue2;
                ArrayList arrayList2 = (ArrayList) c0005.f7359a;
                ((C4796e) arrayList2.get(0)).f6058a = 0.0f;
                float fM3808a2 = AbstractC5177i.m3808a((int) (fFloatValue2 * 333.0f), 0, 667);
                C4796e c4796e2 = (C4796e) arrayList2.get(0);
                C4796e c4796e3 = (C4796e) arrayList2.get(1);
                C1708 c1708 = c0005.f11529a;
                float interpolation3 = c1708.getInterpolation(fM3808a2);
                c4796e3.f6058a = interpolation3;
                c4796e2.f6059a = interpolation3;
                C4796e c4796e4 = (C4796e) arrayList2.get(1);
                C4796e c4796e5 = (C4796e) arrayList2.get(2);
                float interpolation4 = c1708.getInterpolation(fM3808a2 + 0.49925038f);
                c4796e5.f6058a = interpolation4;
                c4796e4.f6059a = interpolation4;
                ((C4796e) arrayList2.get(2)).f6059a = 1.0f;
                if (c0005.f11532a && ((C4796e) arrayList2.get(1)).f6059a < 1.0f) {
                    ((C4796e) arrayList2.get(2)).f6060a = ((C4796e) arrayList2.get(1)).f6060a;
                    ((C4796e) arrayList2.get(1)).f6060a = ((C4796e) arrayList2.get(0)).f6060a;
                    ((C4796e) arrayList2.get(0)).f6060a = c0005.f11530a.f4898a[c0005.f11531a];
                    c0005.f11532a = false;
                }
                ((C3063) c0005.f7358a).invalidateSelf();
                break;
            case 3:
                C5716o c5716o = (C5716o) obj;
                c5716o.f9341a = ((Number) obj2).floatValue();
                c5716o.invalidateSelf();
                break;
            case 4:
                ((SlideNumberView) obj).setNumberRoll(((Number) obj2).floatValue());
                break;
            case 5:
                AbstractC6325p.m5507a((View) obj, ((Float) obj2).floatValue());
                break;
            default:
                ((View) obj).setClipBounds((Rect) obj2);
                break;
        }
    }
}
