package defpackage;

import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import com.google.android.material.chip.Chip;
import com.piyush.music.R;
import java.util.ArrayList;

/* JADX INFO: renamed from: с֚, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2774 extends AbstractC1664 {

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final /* synthetic */ Chip f20415a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2774(Chip chip, Chip chip2) {
        super(chip2);
        this.f20415a = chip;
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̍ */
    public final int mo2268a(float f, float f2) {
        Rect rect = Chip.f2316a;
        Chip chip = this.f20415a;
        return (chip.m1498a() && chip.getCloseIconTouchBounds().contains(f, f2)) ? 1 : 0;
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̎ */
    public final void mo2269a(ArrayList arrayList) {
        C2776 c2776;
        arrayList.add(0);
        Rect rect = Chip.f2316a;
        Chip chip = this.f20415a;
        if (!chip.m1498a() || (c2776 = chip.f2319a) == null || !c2776.f20431a || chip.f2322a == null) {
            return;
        }
        arrayList.add(1);
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̒ */
    public final boolean mo2270a(int i, int i2, Bundle bundle) {
        boolean z = false;
        if (i2 == 16) {
            Chip chip = this.f20415a;
            if (i == 0) {
                return chip.performClick();
            }
            if (i == 1) {
                chip.playSoundEffect(0);
                View.OnClickListener onClickListener = chip.f2322a;
                if (onClickListener != null) {
                    onClickListener.onClick(chip);
                    z = true;
                }
                if (chip.f2334a) {
                    chip.f2333a.m8095a(1, 1);
                }
            }
        }
        return z;
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̓ */
    public final void mo8092a(C4098a c4098a) {
        AccessibilityNodeInfo accessibilityNodeInfo = c4098a.f1096a;
        Chip chip = this.f20415a;
        C2776 c2776 = chip.f2319a;
        accessibilityNodeInfo.setCheckable(c2776 != null && c2776.f20437a);
        accessibilityNodeInfo.setClickable(chip.isClickable());
        c4098a.m866a(chip.getAccessibilityClassName());
        accessibilityNodeInfo.setText(chip.getText());
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̔ */
    public final void mo2271a(int i, C4098a c4098a) {
        AccessibilityNodeInfo accessibilityNodeInfo = c4098a.f1096a;
        if (i != 1) {
            accessibilityNodeInfo.setContentDescription("");
            accessibilityNodeInfo.setBoundsInParent(Chip.f2316a);
            return;
        }
        Chip chip = this.f20415a;
        CharSequence closeIconContentDescription = chip.getCloseIconContentDescription();
        if (closeIconContentDescription != null) {
            accessibilityNodeInfo.setContentDescription(closeIconContentDescription);
        } else {
            CharSequence text = chip.getText();
            accessibilityNodeInfo.setContentDescription(chip.getContext().getString(R.string.o3, TextUtils.isEmpty(text) ? "" : text).trim());
        }
        accessibilityNodeInfo.setBoundsInParent(chip.getCloseIconTouchBoundsInt());
        c4098a.m860a(C4091a.f1080a);
        accessibilityNodeInfo.setEnabled(chip.isEnabled());
        c4098a.m866a(Button.class.getName());
    }

    @Override // defpackage.AbstractC1664
    /* JADX INFO: renamed from: a̕ */
    public final void mo8093a(int i, boolean z) {
        Chip chip = this.f20415a;
        if (i == 1) {
            chip.f2328a = z;
        }
        C2776 c2776 = chip.f2319a;
        boolean z2 = chip.f2328a;
        boolean zM9539a = false;
        if (c2776.f20432a != null) {
            zM9539a = c2776.m9539a(z2 ? new int[]{android.R.attr.state_pressed, android.R.attr.state_enabled} : C2776.f20416a);
        }
        if (zM9539a) {
            chip.refreshDrawableState();
        }
    }
}
