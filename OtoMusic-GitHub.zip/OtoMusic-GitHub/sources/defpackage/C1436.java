package defpackage;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: renamed from: а҃, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1436 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final /* synthetic */ int f15955a = 0;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f15956a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public Boolean f15957a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final ArrayList f15958a;

    static {
        AbstractC2852.m9677a("QW5kcm9pZA==", "UGl5dXNoIE1hbWlkd2Fy");
    }

    public C1436(Context context) {
        this.f15956a = context;
        List listM10982a = AbstractC3778.m10982a("NzMzMTQ1MTBCMzY0RDI3MkRERjMzMTQ2MzIzQ0ZDRTJDMzNGM0REOA==,QzM2MkUzOTI1RjkxQkUwNUJGMzYzOTYwRDlGNjgxMEJBRTVEMjQzQg==", new String[]{","}, 6);
        ArrayList arrayList = new ArrayList(AbstractC2853.m9682a(listM10982a, 10));
        Iterator it = listM10982a.iterator();
        while (it.hasNext()) {
            arrayList.add(AbstractC3778.m10991a((String) it.next()).toString());
        }
        this.f15958a = arrayList;
    }
}
