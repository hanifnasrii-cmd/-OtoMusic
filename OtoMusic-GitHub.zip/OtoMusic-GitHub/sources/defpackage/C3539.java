package defpackage;

import java.util.Set;

/* JADX INFO: renamed from: јܸ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3539 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f22929a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f22930a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f22931a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final String f22932a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Set f22933a;

    public C3539(String str, String str2, int i, String str3, Set set) {
        this.f22929a = str;
        this.f22930a = str2;
        this.f22931a = i;
        this.f22932a = str3;
        this.f22933a = set;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3539)) {
            return false;
        }
        C3539 c3539 = (C3539) obj;
        return AbstractC3098.m10094a(this.f22929a, c3539.f22929a) && AbstractC3098.m10094a(this.f22930a, c3539.f22930a) && this.f22931a == c3539.f22931a && AbstractC3098.m10094a(this.f22932a, c3539.f22932a) && AbstractC3098.m10094a(this.f22933a, c3539.f22933a);
    }

    public final int hashCode() {
        int iM975a = AbstractC4164a.m975a(this.f22931a, AbstractC4072a.m735a(this.f22930a, this.f22929a.hashCode() * 31, 31), 31);
        String str = this.f22932a;
        return this.f22933a.hashCode() + ((iM975a + (str == null ? 0 : str.hashCode())) * 31);
    }

    public final String toString() {
        StringBuilder sbM753a = AbstractC4072a.m753a("CallerPackageInfo(name=", this.f22929a, ", packageName=", this.f22930a, ", uid=");
        sbM753a.append(this.f22931a);
        sbM753a.append(", signature=");
        sbM753a.append(this.f22932a);
        sbM753a.append(", permissions=");
        sbM753a.append(this.f22933a);
        sbM753a.append(")");
        return sbM753a.toString();
    }
}
