package defpackage;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

/* JADX INFO: renamed from: eٗ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4882e extends AbstractC2179 {

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final TextView f6308a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final C4878e f6309a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public boolean f6310a = true;

    public C4882e(TextView textView) {
        this.f6308a = textView;
        this.f6309a = new C4878e(textView);
    }

    @Override // defpackage.AbstractC2179
    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final InputFilter[] mo3065a(InputFilter[] inputFilterArr) {
        if (!this.f6310a) {
            SparseArray sparseArray = new SparseArray(1);
            for (int i = 0; i < inputFilterArr.length; i++) {
                InputFilter inputFilter = inputFilterArr[i];
                if (inputFilter instanceof C4878e) {
                    sparseArray.put(i, inputFilter);
                }
            }
            if (sparseArray.size() == 0) {
                return inputFilterArr;
            }
            int length = inputFilterArr.length;
            InputFilter[] inputFilterArr2 = new InputFilter[inputFilterArr.length - sparseArray.size()];
            int i2 = 0;
            for (int i3 = 0; i3 < length; i3++) {
                if (sparseArray.indexOfKey(i3) < 0) {
                    inputFilterArr2[i2] = inputFilterArr[i3];
                    i2++;
                }
            }
            return inputFilterArr2;
        }
        int length2 = inputFilterArr.length;
        int i4 = 0;
        while (true) {
            C4878e c4878e = this.f6309a;
            if (i4 >= length2) {
                InputFilter[] inputFilterArr3 = new InputFilter[inputFilterArr.length + 1];
                System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                inputFilterArr3[length2] = c4878e;
                return inputFilterArr3;
            }
            if (inputFilterArr[i4] == c4878e) {
                return inputFilterArr;
            }
            i4++;
        }
    }

    @Override // defpackage.AbstractC2179
    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final boolean mo3066a() {
        return this.f6310a;
    }

    @Override // defpackage.AbstractC2179
    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final void mo3067a(boolean z) {
        if (z) {
            TextView textView = this.f6308a;
            textView.setTransformationMethod(mo3069a(textView.getTransformationMethod()));
        }
    }

    @Override // defpackage.AbstractC2179
    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public final void mo3068a(boolean z) {
        this.f6310a = z;
        TextView textView = this.f6308a;
        textView.setTransformationMethod(mo3069a(textView.getTransformationMethod()));
        textView.setFilters(mo3065a(textView.getFilters()));
    }

    @Override // defpackage.AbstractC2179
    /* JADX INFO: renamed from: a̰, reason: contains not printable characters */
    public final TransformationMethod mo3069a(TransformationMethod transformationMethod) {
        return this.f6310a ? ((transformationMethod instanceof C4886e) || (transformationMethod instanceof PasswordTransformationMethod)) ? transformationMethod : new C4886e(transformationMethod) : transformationMethod instanceof C4886e ? ((C4886e) transformationMethod).m3071a() : transformationMethod;
    }
}
