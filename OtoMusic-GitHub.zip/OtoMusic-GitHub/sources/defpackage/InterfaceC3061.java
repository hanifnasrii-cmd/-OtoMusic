package defpackage;

/* JADX INFO: renamed from: і͒, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC3061 {
    /* JADX INFO: renamed from: à */
    boolean mo3072a();

    /* JADX INFO: renamed from: ã */
    C3378 mo3073a();
}
