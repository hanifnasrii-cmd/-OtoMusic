package defpackage;

import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: еި, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1905 extends C6040p {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C6040p f17653a;

    public C1905(C6040p c6040p) {
        AbstractC3098.m10103a(c6040p, "delegate");
        this.f17653a = c6040p;
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: à */
    public final C6040p mo5055a() {
        return this.f17653a.mo5055a();
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: á */
    public final C6040p mo5056a() {
        return this.f17653a.mo5056a();
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: â */
    public final long mo5057a() {
        return this.f17653a.mo5057a();
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: ã */
    public final C6040p mo5052a(long j) {
        return this.f17653a.mo5052a(j);
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: ā */
    public final boolean mo5058a() {
        return this.f17653a.mo5058a();
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: a̅ */
    public final void mo5053a() throws InterruptedIOException {
        this.f17653a.mo5053a();
    }

    @Override // defpackage.C6040p
    /* JADX INFO: renamed from: ă */
    public final C6040p mo5054a(long j) {
        AbstractC3098.m10103a(TimeUnit.MILLISECONDS, "unit");
        return this.f17653a.mo5054a(j);
    }
}
