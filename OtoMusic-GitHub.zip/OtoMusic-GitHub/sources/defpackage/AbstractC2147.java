package defpackage;

/* JADX INFO: renamed from: оֽ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC2147 extends AbstractC4415c {
    public AbstractC2147(InterfaceC1005 interfaceC1005) {
        super(interfaceC1005);
        if (interfaceC1005 != null && interfaceC1005.getContext() != C4889e.f6318a) {
            throw new IllegalArgumentException("Coroutines with restricted suspension must have EmptyCoroutineContext");
        }
    }

    @Override // defpackage.InterfaceC1005
    public final InterfaceC1031 getContext() {
        return C4889e.f6318a;
    }
}
