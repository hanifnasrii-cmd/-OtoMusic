package defpackage;

/* JADX INFO: renamed from: ϲ̥, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1030 {
}
