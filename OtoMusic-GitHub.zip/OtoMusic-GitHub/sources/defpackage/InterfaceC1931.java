package defpackage;

import java.util.ArrayList;

/* JADX INFO: renamed from: е⃗, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1931 {
    /* JADX INFO: renamed from: à */
    boolean mo232a(ArrayList arrayList, ArrayList arrayList2);
}
