package defpackage;

import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import com.piyush.taglib.AudioProperties;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: а̡, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1357 extends AbstractC0284 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f15692a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f15693a;

    public /* synthetic */ C1357(int i, Object obj) {
        this.f15692a = i;
        this.f15693a = obj;
    }

    @Override // defpackage.InterfaceC6312p
    /* JADX INFO: renamed from: á */
    public final void mo671a(View view) {
        int i = this.f15692a;
        Object obj = this.f15693a;
        switch (i) {
            case 0:
                LayoutInflaterFactory2C1371 layoutInflaterFactory2C1371 = (LayoutInflaterFactory2C1371) ((RunnableC1358) obj).f15695a;
                layoutInflaterFactory2C1371.f15744a.setAlpha(1.0f);
                layoutInflaterFactory2C1371.f15747a.m5497a(null);
                layoutInflaterFactory2C1371.f15747a = null;
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                LayoutInflaterFactory2C1371 layoutInflaterFactory2C13712 = (LayoutInflaterFactory2C1371) obj;
                layoutInflaterFactory2C13712.f15744a.setAlpha(1.0f);
                layoutInflaterFactory2C13712.f15747a.m5497a(null);
                layoutInflaterFactory2C13712.f15747a = null;
                break;
            default:
                LayoutInflaterFactory2C1371 layoutInflaterFactory2C13713 = (LayoutInflaterFactory2C1371) ((C1339) obj).f15649a;
                layoutInflaterFactory2C13713.f15744a.setVisibility(8);
                PopupWindow popupWindow = layoutInflaterFactory2C13713.f15745a;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (layoutInflaterFactory2C13713.f15744a.getParent() instanceof View) {
                    View view2 = (View) layoutInflaterFactory2C13713.f15744a.getParent();
                    WeakHashMap weakHashMap = AbstractC6260p.f11065a;
                    view2.requestApplyInsets();
                }
                layoutInflaterFactory2C13713.f15744a.m81a();
                layoutInflaterFactory2C13713.f15747a.m5497a(null);
                layoutInflaterFactory2C13713.f15747a = null;
                ViewGroup viewGroup = layoutInflaterFactory2C13713.f15750a;
                WeakHashMap weakHashMap2 = AbstractC6260p.f11065a;
                viewGroup.requestApplyInsets();
                break;
        }
    }

    @Override // defpackage.AbstractC0284, defpackage.InterfaceC6312p
    /* JADX INFO: renamed from: â */
    public void mo672a() {
        int i = this.f15692a;
        Object obj = this.f15693a;
        switch (i) {
            case 0:
                ((LayoutInflaterFactory2C1371) ((RunnableC1358) obj).f15695a).f15744a.setVisibility(0);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                LayoutInflaterFactory2C1371 layoutInflaterFactory2C1371 = (LayoutInflaterFactory2C1371) obj;
                layoutInflaterFactory2C1371.f15744a.setVisibility(0);
                if (layoutInflaterFactory2C1371.f15744a.getParent() instanceof View) {
                    View view = (View) layoutInflaterFactory2C1371.f15744a.getParent();
                    WeakHashMap weakHashMap = AbstractC6260p.f11065a;
                    view.requestApplyInsets();
                }
                break;
        }
    }
}
