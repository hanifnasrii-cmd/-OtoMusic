package defpackage;

import android.os.Looper;
import com.piyush.music.models.Progress;

/* JADX INFO: renamed from: jެ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5605j extends C5631j {

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public boolean f8900a = true;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public Progress f8901a = new Progress(0, 0);

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final HandlerC0298 f8902a = new HandlerC0298(this, Looper.getMainLooper(), 3);

    @Override // defpackage.AbstractC0077
    /* JADX INFO: renamed from: a̟ */
    public final void mo4302a() {
        this.f8900a = true;
        HandlerC0298 handlerC0298 = this.f8902a;
        handlerC0298.removeMessages(108);
        handlerC0298.sendMessage(handlerC0298.obtainMessage(108));
    }

    @Override // defpackage.AbstractC0077
    /* JADX INFO: renamed from: a̡ */
    public final void mo4303a() {
        this.f8900a = false;
        this.f8902a.removeMessages(108);
    }
}
