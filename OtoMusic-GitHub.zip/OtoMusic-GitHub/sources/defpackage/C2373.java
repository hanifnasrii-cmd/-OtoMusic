package defpackage;

/* JADX INFO: renamed from: р̸, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C2373 extends C2372 {
    public C2373() {
    }

    public C2373(C2390 c2390) {
        super(c2390);
    }
}
