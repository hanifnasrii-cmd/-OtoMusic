package defpackage;

/* JADX INFO: renamed from: іؗ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3154 extends AbstractC3152 {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C3156 f21922a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C3155 f21923a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final C2768 f21924a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final Object f21925a;

    public C3154(C3156 c3156, C3155 c3155, C2768 c2768, Object obj) {
        this.f21922a = c3156;
        this.f21923a = c3155;
        this.f21924a = c2768;
        this.f21925a = obj;
    }

    @Override // defpackage.AbstractC3152
    /* JADX INFO: renamed from: å */
    public final boolean mo2020a() {
        return false;
    }

    @Override // defpackage.AbstractC3152
    /* JADX INFO: renamed from: a̋ */
    public final void mo2021a(Throwable th) {
        C2768 c2768 = this.f21924a;
        C2768 c2768M10205a = C3156.m10205a(c2768);
        C3156 c3156 = this.f21922a;
        C3155 c3155 = this.f21923a;
        Object obj = this.f21925a;
        if (c2768M10205a == null || !c3156.m10227a(c3155, c2768M10205a, obj)) {
            c3155.f21929a.m5868a(new C0030(2), 2);
            C2768 c2768M10205a2 = C3156.m10205a(c2768);
            if (c2768M10205a2 == null || !c3156.m10227a(c3155, c2768M10205a2, obj)) {
                c3156.mo2447a(c3156.m10213a(c3155, obj));
            }
        }
    }
}
