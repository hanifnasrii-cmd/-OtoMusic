package defpackage;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.cast.framework.media.MediaIntentReceiver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: renamed from: ј͝, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3403 extends AbstractC4080a {
    public static final Parcelable.Creator<C3403> CREATOR;

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public static final C0794 f22575a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public static final int[] f22576a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final ArrayList f22577a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int[] f22578a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final long f22579a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final String f22580a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int f22581a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final int f22582a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final int f22583a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final int f22584a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final int f22585a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final int f22586a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final int f22587a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final int f22588a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final int f22589a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final int f22590a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final int f22591a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final int f22592a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final int f22593a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final int f22594a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final int f22595a;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final int f22596a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final int f22597a;

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public final int f22598a;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final int f22599a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public final int f22600a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final int f22601a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final int f22602a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final int f22603a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public final int f22604a;

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public final int f22605a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public final int f22606a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public final int f22607a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final C0703 f22608a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final boolean f22609a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final boolean f22610a;

    static {
        C0784 c0784 = AbstractC0786.f14008a;
        Object[] objArr = {MediaIntentReceiver.ACTION_TOGGLE_PLAYBACK, MediaIntentReceiver.ACTION_STOP_CASTING};
        for (int i = 0; i < 2; i++) {
            AbstractC1149.m7218a(i, objArr[i]);
        }
        f22575a = AbstractC0786.m6756a(2, objArr);
        f22576a = new int[]{0, 1};
        CREATOR = new C2492(16);
    }

    public C3403(List list, int[] iArr, long j, String str, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19, int i20, int i21, int i22, int i23, int i24, int i25, int i26, int i27, IBinder iBinder, boolean z, boolean z2) {
        C0703 c0703;
        this.f22577a = new ArrayList(list);
        this.f22578a = Arrays.copyOf(iArr, iArr.length);
        this.f22579a = j;
        this.f22580a = str;
        this.f22581a = i;
        this.f22582a = i2;
        this.f22583a = i3;
        this.f22584a = i4;
        this.f22585a = i5;
        this.f22586a = i6;
        this.f22587a = i7;
        this.f22588a = i8;
        this.f22589a = i9;
        this.f22590a = i10;
        this.f22591a = i11;
        this.f22592a = i12;
        this.f22593a = i13;
        this.f22594a = i14;
        this.f22595a = i15;
        this.f22596a = i16;
        this.f22597a = i17;
        this.f22598a = i18;
        this.f22599a = i19;
        this.f22600a = i20;
        this.f22601a = i21;
        this.f22602a = i22;
        this.f22603a = i23;
        this.f22604a = i24;
        this.f22605a = i25;
        this.f22606a = i26;
        this.f22607a = i27;
        this.f22609a = z;
        this.f22610a = z2;
        if (iBinder == null) {
            c0703 = null;
        } else {
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.media.INotificationActionsProvider");
            c0703 = iInterfaceQueryLocalInterface instanceof C0703 ? (C0703) iInterfaceQueryLocalInterface : new C0703(iBinder);
        }
        this.f22608a = c0703;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int iM7217a = AbstractC1149.m7217a(parcel, 20293);
        AbstractC1149.m7213a(parcel, 2, this.f22577a);
        int[] iArr = this.f22578a;
        AbstractC1149.m7208a(parcel, 3, Arrays.copyOf(iArr, iArr.length));
        AbstractC1149.m7216a(parcel, 4, 8);
        parcel.writeLong(this.f22579a);
        AbstractC1149.m7212a(parcel, 5, this.f22580a);
        AbstractC1149.m7216a(parcel, 6, 4);
        parcel.writeInt(this.f22581a);
        AbstractC1149.m7216a(parcel, 7, 4);
        parcel.writeInt(this.f22582a);
        AbstractC1149.m7216a(parcel, 8, 4);
        parcel.writeInt(this.f22583a);
        AbstractC1149.m7216a(parcel, 9, 4);
        parcel.writeInt(this.f22584a);
        AbstractC1149.m7216a(parcel, 10, 4);
        parcel.writeInt(this.f22585a);
        AbstractC1149.m7216a(parcel, 11, 4);
        parcel.writeInt(this.f22586a);
        AbstractC1149.m7216a(parcel, 12, 4);
        parcel.writeInt(this.f22587a);
        AbstractC1149.m7216a(parcel, 13, 4);
        parcel.writeInt(this.f22588a);
        AbstractC1149.m7216a(parcel, 14, 4);
        parcel.writeInt(this.f22589a);
        AbstractC1149.m7216a(parcel, 15, 4);
        parcel.writeInt(this.f22590a);
        AbstractC1149.m7216a(parcel, 16, 4);
        parcel.writeInt(this.f22591a);
        AbstractC1149.m7216a(parcel, 17, 4);
        parcel.writeInt(this.f22592a);
        AbstractC1149.m7216a(parcel, 18, 4);
        parcel.writeInt(this.f22593a);
        AbstractC1149.m7216a(parcel, 19, 4);
        parcel.writeInt(this.f22594a);
        AbstractC1149.m7216a(parcel, 20, 4);
        parcel.writeInt(this.f22595a);
        AbstractC1149.m7216a(parcel, 21, 4);
        parcel.writeInt(this.f22596a);
        AbstractC1149.m7216a(parcel, 22, 4);
        parcel.writeInt(this.f22597a);
        AbstractC1149.m7216a(parcel, 23, 4);
        parcel.writeInt(this.f22598a);
        AbstractC1149.m7216a(parcel, 24, 4);
        parcel.writeInt(this.f22599a);
        AbstractC1149.m7216a(parcel, 25, 4);
        parcel.writeInt(this.f22600a);
        AbstractC1149.m7216a(parcel, 26, 4);
        parcel.writeInt(this.f22601a);
        AbstractC1149.m7216a(parcel, 27, 4);
        parcel.writeInt(this.f22602a);
        AbstractC1149.m7216a(parcel, 28, 4);
        parcel.writeInt(this.f22603a);
        AbstractC1149.m7216a(parcel, 29, 4);
        parcel.writeInt(this.f22604a);
        AbstractC1149.m7216a(parcel, 30, 4);
        parcel.writeInt(this.f22605a);
        AbstractC1149.m7216a(parcel, 31, 4);
        parcel.writeInt(this.f22606a);
        AbstractC1149.m7216a(parcel, 32, 4);
        parcel.writeInt(this.f22607a);
        C0703 c0703 = this.f22608a;
        AbstractC1149.m7207a(parcel, 33, c0703 == null ? null : c0703.f19568a);
        AbstractC1149.m7216a(parcel, 34, 4);
        parcel.writeInt(this.f22609a ? 1 : 0);
        AbstractC1149.m7216a(parcel, 35, 4);
        parcel.writeInt(this.f22610a ? 1 : 0);
        AbstractC1149.m7219a(parcel, iM7217a);
    }
}
