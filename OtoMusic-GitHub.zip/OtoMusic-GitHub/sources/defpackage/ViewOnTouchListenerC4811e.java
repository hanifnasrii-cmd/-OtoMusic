package defpackage;

import android.content.Context;
import android.os.SystemClock;
import android.text.Editable;
import android.text.Layout;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.PopupWindow;
import com.piyush.music.fragments.lyrics.EditLyricsFragment;
import com.piyush.music.widget.SmoothScrollEditText;
import com.piyush.music.widget.expandablesearchview.ExpandableSearchView;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: e֔, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class ViewOnTouchListenerC4811e implements View.OnTouchListener {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f6100a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f6101a;

    public /* synthetic */ ViewOnTouchListenerC4811e(int i, Object obj) {
        this.f6100a = i;
        this.f6101a = obj;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        Editable text;
        int totalPaddingTop;
        Editable text2;
        int i;
        int i2 = this.f6100a;
        Object obj = this.f6101a;
        switch (i2) {
            case 0:
                C4814e c4814e = (C4814e) obj;
                if (motionEvent.getAction() == 1) {
                    long jUptimeMillis = SystemClock.uptimeMillis() - c4814e.f6114a;
                    if (jUptimeMillis < 0 || jUptimeMillis > 300) {
                        c4814e.f6112a = false;
                    }
                    c4814e.m2978a();
                    c4814e.f6112a = true;
                    c4814e.f6114a = SystemClock.uptimeMillis();
                }
                return false;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                EditLyricsFragment editLyricsFragment = (EditLyricsFragment) obj;
                if (!editLyricsFragment.f3245a && editLyricsFragment.f3243a == EnumC0134.SYNCED) {
                    int actionMasked = motionEvent.getActionMasked();
                    C3090 c3090M5235a = null;
                    if (actionMasked == 0) {
                        float x = motionEvent.getX();
                        float y = motionEvent.getY();
                        C1920 c1920 = editLyricsFragment.f3241a;
                        AbstractC3098.m10100a(c1920);
                        SmoothScrollEditText smoothScrollEditText = c1920.f17746a;
                        Layout layout = smoothScrollEditText.getLayout();
                        if (layout != null && (text = smoothScrollEditText.getText()) != null && (totalPaddingTop = (int) ((y - smoothScrollEditText.getTotalPaddingTop()) + smoothScrollEditText.getScrollY())) >= 0) {
                            int lineForVertical = layout.getLineForVertical(totalPaddingTop);
                            if (totalPaddingTop <= layout.getLineBottom(lineForVertical)) {
                                float totalPaddingLeft = (x - smoothScrollEditText.getTotalPaddingLeft()) + smoothScrollEditText.getScrollX();
                                C6044p[] c6044pArr = (C6044p[]) text.getSpans(layout.getLineStart(lineForVertical), layout.getLineEnd(lineForVertical), C6044p.class);
                                int length = c6044pArr.length;
                                int i3 = 0;
                                while (true) {
                                    if (i3 < length) {
                                        C6044p c6044p = c6044pArr[i3];
                                        int spanStart = text.getSpanStart(c6044p);
                                        int spanEnd = text.getSpanEnd(c6044p);
                                        if (spanStart >= 0 && spanEnd >= 0) {
                                            float primaryHorizontal = layout.getPrimaryHorizontal(spanStart);
                                            float primaryHorizontal2 = layout.getPrimaryHorizontal(spanEnd);
                                            if (primaryHorizontal <= totalPaddingLeft && totalPaddingLeft <= primaryHorizontal2) {
                                                c3090M5235a = AbstractC6161p.m5235a(spanStart, spanEnd);
                                            }
                                        }
                                        i3++;
                                    }
                                }
                            }
                        }
                        editLyricsFragment.f3247a = c3090M5235a;
                        if (c3090M5235a != null) {
                            return true;
                        }
                    } else if (actionMasked == 1) {
                        C3090 c3090 = editLyricsFragment.f3247a;
                        editLyricsFragment.f3247a = null;
                        if (c3090 != null) {
                            C1322 c1322 = editLyricsFragment.f3246a;
                            if (c1322 == null) {
                                C1920 c19202 = editLyricsFragment.f3241a;
                                AbstractC3098.m10100a(c19202);
                                c1322 = new C1322(c19202.f17746a, new C4851e(3, editLyricsFragment, EditLyricsFragment.class, "scopedTimestampReplace", "scopedTimestampReplace(IILjava/lang/String;)V", 0));
                                editLyricsFragment.f3246a = c1322;
                            }
                            View view2 = (View) c1322.f15605a;
                            View view3 = (View) c1322.f15610a;
                            Context context = (Context) c1322.f15608a;
                            PopupWindow popupWindow = (PopupWindow) c1322.f15612a;
                            c1322.f15609a = c3090;
                            EditText editText = (EditText) c1322.f15607a;
                            Layout layout2 = editText.getLayout();
                            if (layout2 == null || (text2 = editText.getText()) == null) {
                                return true;
                            }
                            int length2 = text2.length();
                            int i4 = c3090.f21700a;
                            int i5 = c3090.f21701a;
                            if (i4 < 0 || (i = i5 + 1) > length2) {
                                return true;
                            }
                            View contentView = popupWindow.getContentView();
                            contentView.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
                            int measuredWidth = contentView.getMeasuredWidth();
                            int measuredHeight = contentView.getMeasuredHeight();
                            int lineForOffset = layout2.getLineForOffset(i4);
                            int[] iArr = new int[2];
                            editText.getLocationOnScreen(iArr);
                            int totalPaddingLeft2 = editText.getTotalPaddingLeft() - editText.getScrollX();
                            int totalPaddingTop2 = editText.getTotalPaddingTop() - editText.getScrollY();
                            float f = totalPaddingLeft2;
                            float primaryHorizontal3 = (((layout2.getPrimaryHorizontal(i4) + f) + (layout2.getPrimaryHorizontal(i) + f)) / 2.0f) + iArr[0];
                            int lineTop = layout2.getLineTop(lineForOffset) + iArr[1] + totalPaddingTop2;
                            int lineBottom = layout2.getLineBottom(lineForOffset) + iArr[1] + totalPaddingTop2;
                            int iM3432a = (int) AbstractC5120i.m3432a(8.0f, context);
                            float fM3432a = AbstractC5120i.m3432a(1.0f, context);
                            int i6 = ((int) (lineTop - fM3432a)) - measuredHeight;
                            boolean z = i6 >= iM3432a;
                            view3.setVisibility(!z ? 0 : 8);
                            view2.setVisibility(z ? 0 : 8);
                            if (!z) {
                                i6 = (int) (lineBottom + fM3432a);
                            }
                            int i7 = (int) (primaryHorizontal3 - (measuredWidth / 2.0f));
                            int i8 = (context.getResources().getDisplayMetrics().widthPixels - measuredWidth) - iM3432a;
                            if (i8 < iM3432a) {
                                i8 = iM3432a;
                            }
                            int iM5206a = AbstractC6161p.m5206a(i7, iM3432a, i8);
                            if (!z) {
                                view2 = view3;
                            }
                            int i9 = view2.getLayoutParams().width;
                            int iM3432a2 = (int) AbstractC5120i.m3432a(22.0f, context);
                            int i10 = (int) ((primaryHorizontal3 - iM5206a) - (i9 / 2.0f));
                            int i11 = (measuredWidth - i9) - iM3432a2;
                            if (i11 < iM3432a2) {
                                i11 = iM3432a2;
                            }
                            int iM5206a2 = AbstractC6161p.m5206a(i10, iM3432a2, i11);
                            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                            if (layoutParams == null) {
                                throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
                            }
                            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
                            marginLayoutParams.setMarginStart(iM5206a2);
                            view2.setLayoutParams(marginLayoutParams);
                            if (popupWindow.isShowing()) {
                                popupWindow.dismiss();
                            }
                            popupWindow.showAtLocation(editText, 0, iM5206a, i6);
                            return true;
                        }
                    } else if (actionMasked == 3) {
                        editLyricsFragment.f3247a = null;
                    } else if (editLyricsFragment.f3247a != null) {
                        return true;
                    }
                }
                return false;
            default:
                GestureDetector gestureDetector = (GestureDetector) obj;
                int i12 = ExpandableSearchView.f4273a;
                if (motionEvent != null) {
                    gestureDetector.onTouchEvent(motionEvent);
                }
                return false;
        }
    }
}
