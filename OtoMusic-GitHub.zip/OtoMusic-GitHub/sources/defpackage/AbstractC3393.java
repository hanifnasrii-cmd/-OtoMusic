package defpackage;

import android.app.Notification;
import android.os.Trace;

/* JADX INFO: renamed from: ј͓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC3393 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static boolean m10539a() {
        return Trace.isEnabled();
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static boolean m10540a() {
        return Trace.isEnabled();
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static void m10541a(Notification.Builder builder, boolean z) {
        builder.setAllowSystemGeneratedContextualActions(z);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static void m10542a(Notification.Builder builder) {
        builder.setBubbleMetadata(null);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static void m10543a(Notification.Action.Builder builder, boolean z) {
        builder.setContextual(z);
    }
}
