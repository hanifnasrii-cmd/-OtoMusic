package defpackage;

import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

/* JADX INFO: renamed from: p⃖, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC6286p extends AbstractC1020 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public C6287p f11177a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f11178a = 0;

    public AbstractC6286p() {
    }

    @Override // defpackage.AbstractC1020
    /* JADX INFO: renamed from: a̋ */
    public boolean mo1389a(CoordinatorLayout coordinatorLayout, View view, int i) {
        mo3854a(coordinatorLayout, view, i);
        if (this.f11177a == null) {
            this.f11177a = new C6287p(view);
        }
        C6287p c6287p = this.f11177a;
        View view2 = c6287p.f11179a;
        c6287p.f11180a = view2.getTop();
        c6287p.f11181a = view2.getLeft();
        this.f11177a.m5484a();
        int i2 = this.f11178a;
        if (i2 == 0) {
            return true;
        }
        this.f11177a.m5485a(i2);
        this.f11178a = 0;
        return true;
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final int m5483a() {
        C6287p c6287p = this.f11177a;
        if (c6287p != null) {
            return c6287p.f11182a;
        }
        return 0;
    }

    /* JADX INFO: renamed from: a̘ */
    public void mo3854a(CoordinatorLayout coordinatorLayout, View view, int i) {
        coordinatorLayout.m171a(view, i);
    }

    public AbstractC6286p(int i) {
    }
}
