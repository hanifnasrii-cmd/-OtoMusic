package defpackage;

import android.media.MediaRouter;

/* JADX INFO: renamed from: ȍ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5696o extends AbstractC5424j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final MediaRouter.RouteInfo f9243a;

    public C5696o(MediaRouter.RouteInfo routeInfo) {
        this.f9243a = routeInfo;
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: a̅ */
    public final void mo4122a(int i) {
        this.f9243a.requestSetVolume(i);
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ä */
    public final void mo4123a(int i) {
        this.f9243a.requestUpdateVolume(i);
    }
}
