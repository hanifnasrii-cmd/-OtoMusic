package defpackage;

/* JADX INFO: renamed from: ј֕, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3431 extends C4842e {

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final C0217 f22663a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final float f22664a;

    public C3431(C0217 c0217, float f) {
        super(0);
        this.f22663a = c0217;
        this.f22664a = f;
    }

    @Override // defpackage.C4842e
    /* JADX INFO: renamed from: ȃ */
    public final boolean mo3029a() {
        return true;
    }

    @Override // defpackage.C4842e
    /* JADX INFO: renamed from: a̒ */
    public final void mo3030a(float f, float f2, float f3, C0466 c0466) {
        this.f22663a.mo3030a(f, f2 - this.f22664a, f3, c0466);
    }
}
