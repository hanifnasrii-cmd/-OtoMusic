package defpackage;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: pͭ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC6120p implements Cloneable {

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public static final Animator[] f10648a = new Animator[0];

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public static final int[] f10649a = {2, 1, 3, 4};

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public static final C5220i f10650a = new C5220i(19);

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public static final ThreadLocal f10651a = new ThreadLocal();

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public ArrayList f10664a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public ArrayList f10665a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public InterfaceC6118p[] f10666a;

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public AbstractC1545 f10675a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final String f10652a = getClass().getName();

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public long f10653a = -1;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public long f10654a = -1;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public TimeInterpolator f10655a = null;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final ArrayList f10656a = new ArrayList();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final ArrayList f10657a = new ArrayList();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public ArrayList f10658a = null;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public ArrayList f10659a = null;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public C3877 f10660a = new C3877(4);

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C3877 f10661a = new C3877(4);

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public C6129p f10662a = null;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final int[] f10663a = f10649a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final ArrayList f10667a = new ArrayList();

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public Animator[] f10668a = f10648a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public int f10669a = 0;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public boolean f10670a = false;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public boolean f10671a = false;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public AbstractC6120p f10672a = null;

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public ArrayList f10673a = null;

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public ArrayList f10674a = new ArrayList();

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public C5220i f10676a = f10650a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static void m5105a(C3877 c3877, View view, C6132p c6132p) {
        C1454 c1454 = (C1454) c3877.f23921a;
        C1454 c14542 = (C1454) c3877.f23924a;
        SparseArray sparseArray = (SparseArray) c3877.f23922a;
        C0113 c0113 = (C0113) c3877.f23923a;
        c1454.put(view, c6132p);
        int id = view.getId();
        if (id >= 0) {
            if (sparseArray.indexOfKey(id) >= 0) {
                sparseArray.put(id, null);
            } else {
                sparseArray.put(id, view);
            }
        }
        WeakHashMap weakHashMap = AbstractC6260p.f11065a;
        String transitionName = view.getTransitionName();
        if (transitionName != null) {
            if (c14542.containsKey(transitionName)) {
                c14542.put(transitionName, null);
            } else {
                c14542.put(transitionName, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            ListView listView = (ListView) view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                if (c0113.f11969a) {
                    int i = c0113.f11972a;
                    long[] jArr = c0113.f11970a;
                    Object[] objArr = c0113.f11971a;
                    int i2 = 0;
                    for (int i3 = 0; i3 < i; i3++) {
                        Object obj = objArr[i3];
                        if (obj != AbstractC5120i.f7074a) {
                            if (i3 != i2) {
                                jArr[i2] = jArr[i3];
                                objArr[i2] = obj;
                                objArr[i3] = null;
                            }
                            i2++;
                        }
                    }
                    c0113.f11969a = false;
                    c0113.f11972a = i2;
                }
                if (AbstractC2411.m8890a(c0113.f11970a, c0113.f11972a, itemIdAtPosition) < 0) {
                    view.setHasTransientState(true);
                    c0113.m5893a(itemIdAtPosition, view);
                    return;
                }
                View view2 = (View) c0113.m5891a(itemIdAtPosition);
                if (view2 != null) {
                    view2.setHasTransientState(false);
                    c0113.m5893a(itemIdAtPosition, null);
                }
            }
        }
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public static C1454 m5106a() {
        ThreadLocal threadLocal = f10651a;
        C1454 c1454 = (C1454) threadLocal.get();
        if (c1454 != null) {
            return c1454;
        }
        C1454 c14542 = new C1454(0);
        threadLocal.set(c14542);
        return c14542;
    }

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public static boolean m5107a(C6132p c6132p, C6132p c6132p2, String str) {
        Object obj = c6132p.f10693a.get(str);
        Object obj2 = c6132p2.f10693a.get(str);
        if (obj == null && obj2 == null) {
            return false;
        }
        if (obj == null || obj2 == null) {
            return true;
        }
        return !obj.equals(obj2);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void m5108a(InterfaceC6118p interfaceC6118p) {
        if (this.f10673a == null) {
            this.f10673a = new ArrayList();
        }
        this.f10673a.add(interfaceC6118p);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public void mo5109a(View view) {
        this.f10657a.add(view);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public abstract void mo5110a(C6132p c6132p);

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final void m5111a(View view, boolean z) {
        if (view == null) {
            return;
        }
        view.getId();
        ArrayList arrayList = this.f10658a;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (((Class) this.f10658a.get(i)).isInstance(view)) {
                    return;
                }
            }
        }
        if (view.getParent() instanceof ViewGroup) {
            C6132p c6132p = new C6132p(view);
            if (z) {
                mo5113a(c6132p);
            } else {
                mo5110a(c6132p);
            }
            c6132p.f10695a.add(this);
            mo5112a(c6132p);
            if (z) {
                m5105a(this.f10660a, view, c6132p);
            } else {
                m5105a(this.f10661a, view, c6132p);
            }
        }
        if (view instanceof ViewGroup) {
            ArrayList arrayList2 = this.f10659a;
            if (arrayList2 == null || !arrayList2.contains(view)) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    m5111a(viewGroup.getChildAt(i2), z);
                }
            }
        }
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public void mo5112a(C6132p c6132p) {
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public abstract void mo5113a(C6132p c6132p);

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m5114a(ViewGroup viewGroup, boolean z) {
        m5115a(z);
        ArrayList arrayList = this.f10656a;
        int size = arrayList.size();
        ArrayList arrayList2 = this.f10657a;
        if (size <= 0 && arrayList2.size() <= 0) {
            m5111a(viewGroup, z);
            return;
        }
        for (int i = 0; i < arrayList.size(); i++) {
            View viewFindViewById = viewGroup.findViewById(((Integer) arrayList.get(i)).intValue());
            if (viewFindViewById != null) {
                C6132p c6132p = new C6132p(viewFindViewById);
                if (z) {
                    mo5113a(c6132p);
                } else {
                    mo5110a(c6132p);
                }
                c6132p.f10695a.add(this);
                mo5112a(c6132p);
                if (z) {
                    m5105a(this.f10660a, viewFindViewById, c6132p);
                } else {
                    m5105a(this.f10661a, viewFindViewById, c6132p);
                }
            }
        }
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            View view = (View) arrayList2.get(i2);
            C6132p c6132p2 = new C6132p(view);
            if (z) {
                mo5113a(c6132p2);
            } else {
                mo5110a(c6132p2);
            }
            c6132p2.f10695a.add(this);
            mo5112a(c6132p2);
            if (z) {
                m5105a(this.f10660a, view, c6132p2);
            } else {
                m5105a(this.f10661a, view, c6132p2);
            }
        }
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void m5115a(boolean z) {
        if (z) {
            ((C1454) this.f10660a.f23921a).clear();
            ((SparseArray) this.f10660a.f23922a).clear();
            ((C0113) this.f10660a.f23923a).m5890a();
        } else {
            ((C1454) this.f10661a.f23921a).clear();
            ((SparseArray) this.f10661a.f23922a).clear();
            ((C0113) this.f10661a.f23923a).m5890a();
        }
    }

    @Override // 
    /* JADX INFO: renamed from: å, reason: contains not printable characters and merged with bridge method [inline-methods] */
    public AbstractC6120p clone() {
        try {
            AbstractC6120p abstractC6120p = (AbstractC6120p) super.clone();
            abstractC6120p.f10674a = new ArrayList();
            abstractC6120p.f10660a = new C3877(4);
            abstractC6120p.f10661a = new C3877(4);
            abstractC6120p.f10664a = null;
            abstractC6120p.f10665a = null;
            abstractC6120p.f10672a = this;
            abstractC6120p.f10673a = null;
            return abstractC6120p;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public Animator mo5117a(ViewGroup viewGroup, C6132p c6132p, C6132p c6132p2) {
        return null;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public void mo5118a(ViewGroup viewGroup, C3877 c3877, C3877 c38772, ArrayList arrayList, ArrayList arrayList2) {
        Animator animator;
        View view;
        C6132p c6132p;
        C6132p c6132p2;
        AbstractC6120p abstractC6120p = this;
        C1454 c1454M5106a = m5106a();
        SparseIntArray sparseIntArray = new SparseIntArray();
        int size = arrayList.size();
        abstractC6120p.m5122a().getClass();
        for (int i = 0; i < size; i++) {
            C6132p c6132p3 = (C6132p) arrayList.get(i);
            C6132p c6132p4 = (C6132p) arrayList2.get(i);
            if (c6132p3 != null && !c6132p3.f10695a.contains(abstractC6120p)) {
                c6132p3 = null;
            }
            if (c6132p4 != null && !c6132p4.f10695a.contains(abstractC6120p)) {
                c6132p4 = null;
            }
            if ((c6132p3 != null || c6132p4 != null) && (c6132p3 == null || c6132p4 == null || abstractC6120p.mo5125a(c6132p3, c6132p4))) {
                Animator animatorMo5117a = abstractC6120p.mo5117a(viewGroup, c6132p3, c6132p4);
                if (animatorMo5117a != null) {
                    String str = abstractC6120p.f10652a;
                    if (c6132p4 != null) {
                        view = c6132p4.f10694a;
                        String[] strArrMo5123a = abstractC6120p.mo5123a();
                        if (strArrMo5123a != null && strArrMo5123a.length > 0) {
                            c6132p2 = new C6132p(view);
                            C6132p c6132p5 = (C6132p) ((C1454) c38772.f23921a).get(view);
                            if (c6132p5 != null) {
                                int i2 = 0;
                                while (i2 < strArrMo5123a.length) {
                                    String str2 = strArrMo5123a[i2];
                                    c6132p2.f10693a.put(str2, c6132p5.f10693a.get(str2));
                                    i2++;
                                    strArrMo5123a = strArrMo5123a;
                                    animatorMo5117a = animatorMo5117a;
                                }
                            }
                            animator = animatorMo5117a;
                            int i3 = c1454M5106a.f13353a;
                            int i4 = 0;
                            while (true) {
                                if (i4 >= i3) {
                                    break;
                                }
                                C6117p c6117p = (C6117p) c1454M5106a.get((Animator) c1454M5106a.m6380a(i4));
                                if (c6117p.f10644a != null && c6117p.f10642a == view && c6117p.f10643a.equals(str) && c6117p.f10644a.equals(c6132p2)) {
                                    animator = null;
                                    break;
                                }
                                i4++;
                            }
                        } else {
                            animator = animatorMo5117a;
                            c6132p2 = null;
                        }
                        c6132p = c6132p2;
                    } else {
                        animator = animatorMo5117a;
                        view = c6132p3.f10694a;
                        c6132p = null;
                    }
                    View view2 = view;
                    Animator animator2 = animator;
                    if (animator2 != null) {
                        abstractC6120p = this;
                        c1454M5106a.put(animator2, new C6117p(view2, str, abstractC6120p, viewGroup.getWindowId(), c6132p, animator2));
                        abstractC6120p.f10674a.add(animator2);
                    } else {
                        abstractC6120p = this;
                    }
                }
            }
        }
        if (sparseIntArray.size() != 0) {
            for (int i5 = 0; i5 < sparseIntArray.size(); i5++) {
                C6117p c6117p2 = (C6117p) c1454M5106a.get((Animator) abstractC6120p.f10674a.get(sparseIntArray.keyAt(i5)));
                c6117p2.f10647a.setStartDelay(c6117p2.f10647a.getStartDelay() + (((long) sparseIntArray.valueAt(i5)) - Long.MAX_VALUE));
            }
        }
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void m5119a() {
        int i = this.f10669a - 1;
        this.f10669a = i;
        if (i == 0) {
            m5127a(this, C1175.f14952a);
            for (int i2 = 0; i2 < ((C0113) this.f10660a.f23923a).m5894a(); i2++) {
                View view = (View) ((C0113) this.f10660a.f23923a).m5895a(i2);
                if (view != null) {
                    view.setHasTransientState(false);
                }
            }
            for (int i3 = 0; i3 < ((C0113) this.f10661a.f23923a).m5894a(); i3++) {
                View view2 = (View) ((C0113) this.f10661a.f23923a).m5895a(i3);
                if (view2 != null) {
                    view2.setHasTransientState(false);
                }
            }
            this.f10671a = true;
        }
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public void mo5120a() {
        ArrayList arrayList = this.f10658a;
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        if (!arrayList.contains(TextView.class)) {
            arrayList.add(TextView.class);
        }
        this.f10658a = arrayList;
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:0x002c, code lost:
    
        if (r2 < 0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x002e, code lost:
    
        if (r6 == false) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0030, code lost:
    
        r5 = r4.f10665a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0033, code lost:
    
        r5 = r4.f10664a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x003b, code lost:
    
        return (defpackage.C6132p) r5.get(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x003c, code lost:
    
        return null;
     */
    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final defpackage.C6132p m5121a(android.view.View r5, boolean r6) {
        /*
            r4 = this;
            p֒ r0 = r4.f10662a
            if (r0 == 0) goto L9
            p֕ r5 = r0.m5121a(r5, r6)
            return r5
        L9:
            if (r6 == 0) goto Le
            java.util.ArrayList r0 = r4.f10664a
            goto L10
        Le:
            java.util.ArrayList r0 = r4.f10665a
        L10:
            if (r0 != 0) goto L13
            goto L3c
        L13:
            int r1 = r0.size()
            r2 = 0
        L18:
            if (r2 >= r1) goto L2b
            java.lang.Object r3 = r0.get(r2)
            p֕ r3 = (defpackage.C6132p) r3
            if (r3 != 0) goto L23
            goto L3c
        L23:
            android.view.View r3 = r3.f10694a
            if (r3 != r5) goto L28
            goto L2c
        L28:
            int r2 = r2 + 1
            goto L18
        L2b:
            r2 = -1
        L2c:
            if (r2 < 0) goto L3c
            if (r6 == 0) goto L33
            java.util.ArrayList r5 = r4.f10665a
            goto L35
        L33:
            java.util.ArrayList r5 = r4.f10664a
        L35:
            java.lang.Object r5 = r5.get(r2)
            p֕ r5 = (defpackage.C6132p) r5
            return r5
        L3c:
            r5 = 0
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.AbstractC6120p.m5121a(android.view.View, boolean):p֕");
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final AbstractC6120p m5122a() {
        C6129p c6129p = this.f10662a;
        return c6129p != null ? c6129p.m5122a() : this;
    }

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public String[] mo5123a() {
        return null;
    }

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final C6132p m5124a(View view, boolean z) {
        C6129p c6129p = this.f10662a;
        if (c6129p != null) {
            return c6129p.m5124a(view, z);
        }
        return (C6132p) ((C1454) (z ? this.f10660a : this.f10661a).f23921a).get(view);
    }

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public boolean mo5125a(C6132p c6132p, C6132p c6132p2) {
        if (c6132p != null && c6132p2 != null) {
            String[] strArrMo5123a = mo5123a();
            if (strArrMo5123a != null) {
                for (String str : strArrMo5123a) {
                    if (m5107a(c6132p, c6132p2, str)) {
                        return true;
                    }
                }
            } else {
                Iterator it = c6132p.f10693a.keySet().iterator();
                while (it.hasNext()) {
                    if (m5107a(c6132p, c6132p2, (String) it.next())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final boolean m5126a(View view) {
        int id = view.getId();
        ArrayList arrayList = this.f10658a;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (((Class) this.f10658a.get(i)).isInstance(view)) {
                    return false;
                }
            }
        }
        ArrayList arrayList2 = this.f10656a;
        int size2 = arrayList2.size();
        ArrayList arrayList3 = this.f10657a;
        return (size2 == 0 && arrayList3.size() == 0) || arrayList2.contains(Integer.valueOf(id)) || arrayList3.contains(view);
    }

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final void m5127a(AbstractC6120p abstractC6120p, C1175 c1175) {
        AbstractC6120p abstractC6120p2 = this.f10672a;
        if (abstractC6120p2 != null) {
            abstractC6120p2.m5127a(abstractC6120p, c1175);
        }
        ArrayList arrayList = this.f10673a;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        int size = this.f10673a.size();
        InterfaceC6118p[] interfaceC6118pArr = this.f10666a;
        if (interfaceC6118pArr == null) {
            interfaceC6118pArr = new InterfaceC6118p[size];
        }
        this.f10666a = null;
        InterfaceC6118p[] interfaceC6118pArr2 = (InterfaceC6118p[]) this.f10673a.toArray(interfaceC6118pArr);
        for (int i = 0; i < size; i++) {
            c1175.m7255a(interfaceC6118pArr2[i], abstractC6120p);
            interfaceC6118pArr2[i] = null;
        }
        this.f10666a = interfaceC6118pArr2;
    }

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public void mo5128a(View view) {
        if (this.f10671a) {
            return;
        }
        ArrayList arrayList = this.f10667a;
        int size = arrayList.size();
        Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f10668a);
        this.f10668a = f10648a;
        for (int i = size - 1; i >= 0; i--) {
            Animator animator = animatorArr[i];
            animatorArr[i] = null;
            animator.pause();
        }
        this.f10668a = animatorArr;
        m5127a(this, C1175.f14954a);
        this.f10670a = true;
    }

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public AbstractC6120p mo5129a(InterfaceC6118p interfaceC6118p) {
        AbstractC6120p abstractC6120p;
        ArrayList arrayList = this.f10673a;
        if (arrayList != null) {
            if (!arrayList.remove(interfaceC6118p) && (abstractC6120p = this.f10672a) != null) {
                abstractC6120p.mo5129a(interfaceC6118p);
            }
            if (this.f10673a.size() == 0) {
                this.f10673a = null;
            }
        }
        return this;
    }

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public void mo5130a(View view) {
        this.f10657a.remove(view);
    }

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public void mo5131a(View view) {
        if (this.f10670a) {
            if (!this.f10671a) {
                ArrayList arrayList = this.f10667a;
                int size = arrayList.size();
                Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f10668a);
                this.f10668a = f10648a;
                for (int i = size - 1; i >= 0; i--) {
                    Animator animator = animatorArr[i];
                    animatorArr[i] = null;
                    animator.resume();
                }
                this.f10668a = animatorArr;
                m5127a(this, C1175.f14955a);
            }
            this.f10670a = false;
        }
    }

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public void mo5132a() {
        m5139a();
        C1454 c1454M5106a = m5106a();
        ArrayList arrayList = this.f10674a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            Animator animator = (Animator) obj;
            if (c1454M5106a.containsKey(animator)) {
                m5139a();
                if (animator != null) {
                    animator.addListener(new C2656(this, c1454M5106a));
                    long j = this.f10654a;
                    if (j >= 0) {
                        animator.setDuration(j);
                    }
                    long j2 = this.f10653a;
                    if (j2 >= 0) {
                        animator.setStartDelay(animator.getStartDelay() + j2);
                    }
                    TimeInterpolator timeInterpolator = this.f10655a;
                    if (timeInterpolator != null) {
                        animator.setInterpolator(timeInterpolator);
                    }
                    animator.addListener(new C4112a(19, this));
                    animator.start();
                }
            }
        }
        this.f10674a.clear();
        m5119a();
    }

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public void mo5133a(long j) {
        this.f10654a = j;
    }

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public void mo5134a(AbstractC1545 abstractC1545) {
        this.f10675a = abstractC1545;
    }

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public void mo5135a(TimeInterpolator timeInterpolator) {
        this.f10655a = timeInterpolator;
    }

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public void mo5136a(C5220i c5220i) {
        if (c5220i == null) {
            this.f10676a = f10650a;
        } else {
            this.f10676a = c5220i;
        }
    }

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public void mo5137a() {
    }

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public void mo5138a(long j) {
        this.f10653a = j;
    }

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public final void m5139a() {
        if (this.f10669a == 0) {
            m5127a(this, C1175.f14951a);
            this.f10671a = false;
        }
        this.f10669a++;
    }

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public String mo5140a(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.append(getClass().getSimpleName());
        sb.append("@");
        sb.append(Integer.toHexString(hashCode()));
        sb.append(": ");
        if (this.f10654a != -1) {
            sb.append("dur(");
            sb.append(this.f10654a);
            sb.append(") ");
        }
        if (this.f10653a != -1) {
            sb.append("dly(");
            sb.append(this.f10653a);
            sb.append(") ");
        }
        if (this.f10655a != null) {
            sb.append("interp(");
            sb.append(this.f10655a);
            sb.append(") ");
        }
        ArrayList arrayList = this.f10656a;
        int size = arrayList.size();
        ArrayList arrayList2 = this.f10657a;
        if (size > 0 || arrayList2.size() > 0) {
            sb.append("tgts(");
            if (arrayList.size() > 0) {
                for (int i = 0; i < arrayList.size(); i++) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(arrayList.get(i));
                }
            }
            if (arrayList2.size() > 0) {
                for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                    if (i2 > 0) {
                        sb.append(", ");
                    }
                    sb.append(arrayList2.get(i2));
                }
            }
            sb.append(")");
        }
        return sb.toString();
    }

    public void cancel() {
        ArrayList arrayList = this.f10667a;
        int size = arrayList.size();
        Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f10668a);
        this.f10668a = f10648a;
        for (int i = size - 1; i >= 0; i--) {
            Animator animator = animatorArr[i];
            animatorArr[i] = null;
            animator.cancel();
        }
        this.f10668a = animatorArr;
        m5127a(this, C1175.f14953a);
    }

    public final String toString() {
        return mo5140a("");
    }
}
