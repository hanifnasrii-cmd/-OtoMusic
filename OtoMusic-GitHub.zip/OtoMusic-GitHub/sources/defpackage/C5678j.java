package defpackage;

/* JADX INFO: renamed from: jⷼ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5678j extends AbstractC3210 implements InterfaceC5040i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f9180a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C5676j f9181a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C5678j(C5676j c5676j, int i) {
        super(1);
        this.f9180a = i;
        this.f9181a = c5676j;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        switch (this.f9180a) {
            case 0:
                AbstractC3098.m10103a((String) obj, "key");
                return Boolean.valueOf(!this.f9181a.m4553a().contains(r2));
            default:
                AbstractC3098.m10103a((String) obj, "key");
                return Boolean.valueOf(!this.f9181a.m4553a().contains(r2));
        }
    }
}
