package defpackage;

/* JADX INFO: renamed from: ϲ̏, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1008 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final double f14394a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final double f14395a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final double f14396a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final double f14397a;

    public C1008(double d, double d2, double d3, double d4) {
        this.f14394a = d;
        this.f14395a = d2;
        this.f14396a = d3;
        this.f14397a = d4;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final double m7053a(double d) {
        if (d <= -1.0d) {
            return this.f14394a;
        }
        if (d < 0.0d) {
            return AbstractC2582.m9242a(this.f14394a, this.f14395a, (d - (-1.0d)) / 1.0d);
        }
        if (d < 0.5d) {
            return AbstractC2582.m9242a(this.f14395a, this.f14396a, (d - 0.0d) / 0.5d);
        }
        if (d >= 1.0d) {
            return this.f14397a;
        }
        return AbstractC2582.m9242a(this.f14396a, this.f14397a, (d - 0.5d) / 0.5d);
    }
}
