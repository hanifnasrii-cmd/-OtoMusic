package defpackage;

import android.view.View;
import com.piyush.music.fabmenu.SpeedDialView;

/* JADX INFO: renamed from: pⷹ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6335p extends AbstractC6265p {

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final SpeedDialView f11267a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public long f11268a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C6335p(View view) {
        super(null, view, 0);
        SpeedDialView speedDialView = (SpeedDialView) AbstractC6265p.m5440a(view, 1, null, null)[0];
        this.f11267a = speedDialView;
        this.f11268a = -1L;
        this.f11267a.setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f11268a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f11268a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f11268a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
