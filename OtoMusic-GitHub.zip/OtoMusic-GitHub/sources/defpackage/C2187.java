package defpackage;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.piyush.music.R;
import com.piyush.music.models.Song;
import com.piyush.music.service.MusicService;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: renamed from: оۖ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2187 implements InterfaceC5510j, InterfaceC5485j, InterfaceC3445, InterfaceC2134, InterfaceC0411, InterfaceC6300p, InterfaceC1195, InterfaceC4107a, InterfaceC1695, InterfaceC3113, InterfaceC1135 {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static C2187 f18640a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final C2188 f18641a = new C2188(0, 0, 0, false, false);

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final int[] f18642a = {0, 1, 2};

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final C5220i f18643a = new C5220i(27);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f18644a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Object f18645a;

    public /* synthetic */ C2187(int i, Object obj) {
        this.f18644a = i;
        this.f18645a = obj;
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public static synchronized C2187 m8669a() {
        try {
            if (f18640a == null) {
                f18640a = new C2187(0, false);
            }
        } catch (Throwable th) {
            throw th;
        }
        return f18640a;
    }

    @Override // defpackage.InterfaceC5510j
    /* JADX INFO: renamed from: à */
    public void mo3748a(MenuC5487j menuC5487j, boolean z) {
        if (menuC5487j instanceof SubMenuC3793) {
            menuC5487j.mo4323a().m4315a(false);
        }
        InterfaceC5510j interfaceC5510j = ((C4126a) this.f18645a).f1136a;
        if (interfaceC5510j != null) {
            interfaceC5510j.mo3748a(menuC5487j, z);
        }
    }

    @Override // defpackage.InterfaceC1195
    /* JADX INFO: renamed from: á */
    public int mo2748a(byte[] bArr, int i) throws C1194 {
        int i2 = 0;
        int i3 = 0;
        while (i2 < i && (i3 = ((InputStream) this.f18645a).read(bArr, i2, i - i2)) != -1) {
            i2 += i3;
        }
        if (i2 == 0 && i3 == -1) {
            throw new C1194();
        }
        return i2;
    }

    @Override // defpackage.InterfaceC1195
    /* JADX INFO: renamed from: â */
    public short mo2749a() throws IOException {
        int i = ((InputStream) this.f18645a).read();
        if (i != -1) {
            return (short) i;
        }
        throw new C1194();
    }

    @Override // defpackage.InterfaceC4107a
    /* JADX INFO: renamed from: ã */
    public boolean mo869a(View view) {
        DrawerLayout drawerLayout = (DrawerLayout) this.f18645a;
        if (!DrawerLayout.m213a(view) || drawerLayout.m222a(view) == 2) {
            return false;
        }
        drawerLayout.m217a(view);
        return true;
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: ā */
    public /* bridge */ /* synthetic */ void mo3677a(AbstractC0409 abstractC0409, int i) {
    }

    @Override // defpackage.InterfaceC3113
    /* JADX INFO: renamed from: a̅ */
    public void mo1100a(Object obj) {
        C5763o c5763o = C5601j.f8884a;
        C5601j.m4446a(AbstractC5120i.m3448a((Song) obj), 0, true, 8);
    }

    @Override // defpackage.InterfaceC5485j
    /* JADX INFO: renamed from: ă */
    public boolean mo4311a(MenuC5487j menuC5487j, MenuItem menuItem) {
        boolean zOnMenuItemClick;
        InterfaceC4129a interfaceC4129a = ((ActionMenuView) this.f18645a).f173a;
        if (interfaceC4129a != null) {
            Toolbar toolbar = ((C6074p) interfaceC4129a).f10462a;
            Iterator it = ((CopyOnWriteArrayList) toolbar.f234a.f8444a).iterator();
            while (true) {
                if (!it.hasNext()) {
                    InterfaceC6078p interfaceC6078p = toolbar.f236a;
                    zOnMenuItemClick = interfaceC6078p != null ? interfaceC6078p.onMenuItemClick(menuItem) : false;
                } else if (((C1925) it.next()).f17772a.m293a(menuItem)) {
                    zOnMenuItemClick = true;
                    break;
                }
            }
            if (zOnMenuItemClick) {
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.InterfaceC1195
    /* JADX INFO: renamed from: ȧ */
    public int mo2753a() {
        return (mo2749a() << 8) | mo2749a();
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: ä */
    public void mo3680a(AbstractC0409 abstractC0409, int i) {
        MusicService musicService = ((C2691) this.f18645a).f20105a;
        InterfaceC5717o interfaceC5717o = musicService.f3791a;
        if (interfaceC5717o != null && (interfaceC5717o instanceof C2697)) {
            ((C2697) interfaceC5717o).f20171a = false;
        }
        if (interfaceC5717o instanceof C2697) {
            musicService.m1917a(musicService.m1890a());
        }
    }

    @Override // defpackage.InterfaceC1695
    /* JADX INFO: renamed from: ả */
    public Object mo3749a() {
        switch (this.f18644a) {
            case 20:
                C1380 c1380 = (C1380) this.f18645a;
                return new RunnableC1156((C1001) c1380.f15804a, (C2426) c1380.f15805a);
            default:
                C4914e c4914e = (C4914e) this.f18645a;
                return new C4922e(c4914e.f6374a, c4914e.f6375a, c4914e.f6376a, c4914e.f6377a, c4914e.f6378a, c4914e.f6379a, c4914e.f6380a);
        }
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: å */
    public void mo3681a(AbstractC0409 abstractC0409) {
        MusicService musicService = ((C2691) this.f18645a).f20105a;
        if (musicService.f3791a instanceof C2697) {
            musicService.m1917a(musicService.m1890a());
        }
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: a̋ */
    public /* bridge */ /* synthetic */ void mo3682a(AbstractC0409 abstractC0409, int i) {
    }

    @Override // defpackage.InterfaceC6300p
    /* JADX INFO: renamed from: ǎ */
    public void mo3224a(View view, float f) {
        if (((ViewGroup) this.f18645a) == null) {
            ViewParent parent = view.getParent();
            AbstractC3098.m10101a(parent, "null cannot be cast to non-null type android.view.ViewGroup");
            this.f18645a = (ViewGroup) parent;
        }
        if (f <= -1.0f || f >= 1.0f) {
            view.setTranslationX(view.getWidth() * f);
            view.setAlpha(0.0f);
            return;
        }
        if (f == 0.0f) {
            view.setTranslationX(view.getWidth() * f);
            view.setAlpha(1.0f);
            return;
        }
        int left = view.getLeft();
        ViewGroup viewGroup = (ViewGroup) this.f18645a;
        AbstractC3098.m10100a(viewGroup);
        int measuredWidth = (view.getMeasuredWidth() / 2) + (left - viewGroup.getScrollX());
        ViewGroup viewGroup2 = (ViewGroup) this.f18645a;
        AbstractC3098.m10100a(viewGroup2);
        float measuredWidth2 = measuredWidth - (viewGroup2.getMeasuredWidth() / 2);
        AbstractC3098.m10100a((ViewGroup) this.f18645a);
        float measuredWidth3 = 1 - (measuredWidth2 / r2.getMeasuredWidth());
        AbstractC3098.m10100a((ViewGroup) this.f18645a);
        float measuredWidth4 = measuredWidth2 / r2.getMeasuredWidth();
        AbstractC3098.m10100a((ViewGroup) this.f18645a);
        view.setTranslationX((-r2.getMeasuredWidth()) * measuredWidth4);
        if (measuredWidth3 >= 0.0f) {
            view.setAlpha(measuredWidth3);
        }
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: a̍ */
    public void mo3683a(AbstractC0409 abstractC0409, boolean z) {
        C2702 c2702 = (C2702) abstractC0409;
        MusicService musicService = ((C2691) this.f18645a).f20105a;
        if (musicService.f3791a instanceof C2697) {
            return;
        }
        musicService.m1917a(new C2697(c2702, musicService));
    }

    @Override // defpackage.InterfaceC2134
    /* JADX INFO: renamed from: a̎ */
    public InterfaceC2122 mo2414a(InterfaceC2122 interfaceC2122, C3515 c3515) {
        return C3239.m10319a((Resources) this.f18645a, interfaceC2122);
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: ȁ */
    public void mo3685a(AbstractC0409 abstractC0409, String str) {
        C2702 c2702 = (C2702) abstractC0409;
        MusicService musicService = ((C2691) this.f18645a).f20105a;
        if (musicService.f3791a instanceof C2697) {
            return;
        }
        musicService.m1917a(new C2697(c2702, musicService));
    }

    @Override // defpackage.InterfaceC1135
    /* JADX INFO: renamed from: a̐ */
    public Object mo1243a() {
        C2011 c2011 = (C2011) this.f18645a;
        c2011.reset();
        return c2011;
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: ȃ */
    public /* bridge */ /* synthetic */ void mo3687a(AbstractC0409 abstractC0409) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.InterfaceC3445
    /* JADX INFO: renamed from: a̒ */
    public C2390 mo4799a(View view, C2390 c2390) {
        int i = 0;
        switch (this.f18644a) {
            case 6:
                AppBarLayout appBarLayout = (AppBarLayout) this.f18645a;
                C2390 c23902 = appBarLayout.getFitsSystemWindows() ? c2390 : null;
                if (!Objects.equals(appBarLayout.f2045a, c23902)) {
                    appBarLayout.f2045a = c23902;
                    if (appBarLayout.f2062a != null && appBarLayout.getTopInset() > 0) {
                        i = 1;
                    }
                    appBarLayout.setWillNotDraw(1 ^ i);
                    appBarLayout.requestLayout();
                }
                break;
            case 9:
                DialogC4600c dialogC4600c = (DialogC4600c) this.f18645a;
                C4599c c4599c = dialogC4600c.f5372a;
                if (c4599c != null) {
                    dialogC4600c.f5365a.f2204a.remove(c4599c);
                }
                C4599c c4599c2 = new C4599c(dialogC4600c.f5368a, c2390);
                dialogC4600c.f5372a = c4599c2;
                c4599c2.m2490a(dialogC4600c.getWindow());
                BottomSheetBehavior bottomSheetBehavior = dialogC4600c.f5365a;
                C4599c c4599c3 = dialogC4600c.f5372a;
                ArrayList arrayList = bottomSheetBehavior.f2204a;
                if (!arrayList.contains(c4599c3)) {
                    arrayList.add(c4599c3);
                }
                break;
            default:
                C2386 c2386 = c2390.f19244a;
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) this.f18645a;
                if (!Objects.equals(coordinatorLayout.f296a, c2390)) {
                    coordinatorLayout.f296a = c2390;
                    boolean z = c2390.m8867a() > 0;
                    coordinatorLayout.f297a = z;
                    coordinatorLayout.setWillNotDraw(!z && coordinatorLayout.getBackground() == null);
                    if (!c2386.mo8852a()) {
                        int childCount = coordinatorLayout.getChildCount();
                        while (i < childCount) {
                            View childAt = coordinatorLayout.getChildAt(i);
                            WeakHashMap weakHashMap = AbstractC6260p.f11065a;
                            if (!childAt.getFitsSystemWindows() || ((C1023) childAt.getLayoutParams()).f14429a == null || !c2386.mo8852a()) {
                                i++;
                            }
                        }
                    }
                    coordinatorLayout.requestLayout();
                }
                break;
        }
        return c2390;
    }

    @Override // defpackage.InterfaceC3113
    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public void mo8670a(Song song) {
        C5281i c5281i = (C5281i) this.f18645a;
        int i = C5281i.f7746a;
        c5281i.m2168a().m1616a(song);
    }

    @Override // defpackage.InterfaceC5485j
    /* JADX INFO: renamed from: a̔ */
    public void mo4312a(MenuC5487j menuC5487j) {
        C6074p c6074p = ((ActionMenuView) this.f18645a).f168a;
        if (c6074p != null) {
            c6074p.mo4312a(menuC5487j);
        }
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: a̕ */
    public /* bridge */ /* synthetic */ void mo3689a(AbstractC0409 abstractC0409, String str) {
    }

    @Override // defpackage.InterfaceC5510j
    /* JADX INFO: renamed from: a̖ */
    public boolean mo3757a(MenuC5487j menuC5487j) {
        C4126a c4126a = (C4126a) this.f18645a;
        if (menuC5487j == c4126a.f1134a) {
            return false;
        }
        c4126a.f1156a = ((C5493j) ((SubMenuC3793) menuC5487j).getItem()).f8605a;
        InterfaceC5510j interfaceC5510j = c4126a.f1136a;
        if (interfaceC5510j != null) {
            return interfaceC5510j.mo3757a(menuC5487j);
        }
        return false;
    }

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public void m8671a() {
        ((C1915) this.f18645a).f17767a.m314a();
    }

    @Override // defpackage.InterfaceC0411
    /* JADX INFO: renamed from: a̙ */
    public /* bridge */ /* synthetic */ void mo3693a(AbstractC0409 abstractC0409, int i) {
    }

    @Override // defpackage.InterfaceC1135
    public void cleanup() {
        ((C2011) this.f18645a).m8386a();
    }

    @Override // defpackage.InterfaceC1195
    public long skip(long j) throws IOException {
        InputStream inputStream = (InputStream) this.f18645a;
        if (j < 0) {
            return 0L;
        }
        long j2 = j;
        while (j2 > 0) {
            long jSkip = inputStream.skip(j2);
            if (jSkip <= 0) {
                if (inputStream.read() == -1) {
                    break;
                }
                jSkip = 1;
            }
            j2 -= jSkip;
        }
        return j - j2;
    }

    public /* synthetic */ C2187(int i, boolean z) {
        this.f18644a = i;
    }

    public C2187(int i) {
        this.f18644a = i;
        switch (i) {
            case 10:
                char[] cArr = AbstractC6202p.f10898a;
                this.f18645a = new ArrayDeque(0);
                break;
            case 17:
                this.f18645a = Handler.createAsync(Looper.getMainLooper());
                break;
            case 25:
                this.f18645a = null;
                break;
            default:
                int i2 = AbstractC0714.f13882a;
                C3097 c3097 = new C3097(25, new InterfaceC0766[]{C4842e.f6197a, f18643a});
                Charset charset = AbstractC0752.f13947a;
                this.f18645a = c3097;
                break;
        }
    }

    public C2187(InputStream inputStream, C0121 c0121) {
        this.f18644a = 29;
        C2011 c2011 = new C2011(inputStream, c0121);
        this.f18645a = c2011;
        c2011.mark(5242880);
    }

    public C2187(C1137 c1137) {
        this.f18644a = 26;
        this.f18645a = Collections.unmodifiableMap(new HashMap(c1137.f14810a));
    }

    public C2187(int i, long j, TimeUnit timeUnit) {
        this.f18644a = 13;
        AbstractC3098.m10103a(timeUnit, "timeUnit");
        this.f18645a = new C1991(C3947.f24119a, i, j, timeUnit);
    }

    public C2187(Context context) {
        this.f18644a = 1;
        C4906e c4906e = new C4906e();
        c4906e.f6340a = new ArrayList();
        try {
            XmlResourceParser xml = context.getResources().getXml(R.xml.d);
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType != 0 && eventType != 3) {
                    if (eventType == 2) {
                        if (xml.getName().equals("palettes")) {
                            c4906e.m3083a(xml);
                        }
                    } else {
                        throw new XmlPullParserException("Invalid XML event " + eventType + " - " + xml.getName(), xml, null);
                    }
                }
            }
            ArrayList arrayList = c4906e.f6340a;
            arrayList.remove(0);
            this.f18645a = new C2863[3];
            for (int i = 0; i < 3; i++) {
                ((C2863[]) this.f18645a)[f18642a[i]] = new C2863();
            }
        } catch (IOException e) {
            e = e;
            throw new RuntimeException(e);
        } catch (XmlPullParserException e2) {
            e = e2;
            throw new RuntimeException(e);
        }
    }

    public C2187(TextView textView) {
        this.f18644a = 19;
        this.f18645a = new C4883e(textView);
    }
}
