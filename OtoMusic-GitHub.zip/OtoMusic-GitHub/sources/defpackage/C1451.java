package defpackage;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: renamed from: а֛, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1451 implements Set {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C1454 f16000a;

    public C1451(C1454 c1454) {
        this.f16000a = c1454;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        this.f16000a.clear();
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        return this.f16000a.containsKey(obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        return this.f16000a.m7684a(collection);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean equals(Object obj) {
        C1454 c1454 = this.f16000a;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set = (Set) obj;
        try {
            if (c1454.f13353a == set.size()) {
                return c1454.m7684a(set);
            }
            return false;
        } catch (ClassCastException | NullPointerException unused) {
            return false;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final int hashCode() {
        C1454 c1454 = this.f16000a;
        int iHashCode = 0;
        for (int i = c1454.f13353a - 1; i >= 0; i--) {
            Object objM6380a = c1454.m6380a(i);
            iHashCode += objM6380a == null ? 0 : objM6380a.hashCode();
        }
        return iHashCode;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        return this.f16000a.isEmpty();
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new C1450(this.f16000a, 0);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        C1454 c1454 = this.f16000a;
        int iM6378a = c1454.m6378a(obj);
        if (iM6378a < 0) {
            return false;
        }
        c1454.mo2792a(iM6378a);
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        return this.f16000a.m7685a(collection);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        return this.f16000a.m7686a(collection);
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        return this.f16000a.f13353a;
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        C1454 c1454 = this.f16000a;
        int i = c1454.f13353a;
        Object[] objArr = new Object[i];
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = c1454.m6380a(i2);
        }
        return objArr;
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        C1454 c1454 = this.f16000a;
        int i = c1454.f13353a;
        if (objArr.length < i) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), i);
        }
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = c1454.m6380a(i2);
        }
        if (objArr.length > i) {
            objArr[i] = null;
        }
        return objArr;
    }
}
