package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* JADX INFO: renamed from: ι߲, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0266 extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ boolean f12532a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ int f12533a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final /* synthetic */ C0267 f12534a;

    public C0266(C0267 c0267, boolean z, int i) {
        this.f12534a = c0267;
        this.f12532a = z;
        this.f12533a = i;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        C0267 c0267 = this.f12534a;
        c0267.f12330a.setTranslationX(0.0f);
        c0267.m6066a(0.0f, this.f12532a, this.f12533a);
    }
}
