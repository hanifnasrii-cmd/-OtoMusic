package defpackage;

import java.util.regex.Pattern;

/* JADX INFO: renamed from: cⷯ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4675c implements InterfaceC3095 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f5656a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object f5657a;

    public /* synthetic */ C4675c(int i, Object obj) {
        this.f5656a = i;
        this.f5657a = obj;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static int m2787a(C2141 c2141, int i) {
        String strM8589a = C2141.m8589a(c2141, "Retry-After");
        if (strM8589a == null) {
            return i;
        }
        Pattern patternCompile = Pattern.compile("\\d+");
        AbstractC3098.m10102a(patternCompile, "compile(...)");
        if (!patternCompile.matcher(strM8589a).matches()) {
            return Integer.MAX_VALUE;
        }
        Integer numValueOf = Integer.valueOf(strM8589a);
        AbstractC3098.m10102a(numValueOf, "valueOf(header)");
        return numValueOf.intValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:219:0x04f8  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x0500  */
    /* JADX WARN: Removed duplicated region for block: B:225:0x050f  */
    /* JADX WARN: Removed duplicated region for block: B:226:0x0517  */
    /* JADX WARN: Removed duplicated region for block: B:229:0x051d  */
    /* JADX WARN: Removed duplicated region for block: B:232:0x052b  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x0533  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x0575  */
    /* JADX WARN: Removed duplicated region for block: B:266:0x05e8  */
    /* JADX WARN: Removed duplicated region for block: B:338:0x07c1  */
    /* JADX WARN: Removed duplicated region for block: B:372:0x0868  */
    @Override // defpackage.InterfaceC3095
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final defpackage.C2141 mo2788a(defpackage.C1992 r47) {
        /*
            Method dump skipped, instruction units count: 2286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C4675c.mo2788a(о̆):оַ");
    }

    /* JADX WARN: Removed duplicated region for block: B:66:0x00c5  */
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public defpackage.C1176 m2789a(defpackage.C2141 r12, defpackage.C4670c r13) throws java.net.ProtocolException {
        /*
            Method dump skipped, instruction units count: 376
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C4675c.m2789a(оַ, cⷪ):ϲُ");
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x008b  */
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m2790a(java.io.IOException r4, defpackage.C1987 r5, defpackage.C1176 r6, boolean r7) {
        /*
            r3 = this;
            java.lang.Object r6 = r3.f5657a
            ј֜ r6 = (defpackage.C3438) r6
            boolean r6 = r6.f22713a
            r0 = 0
            if (r6 != 0) goto Lb
            goto La7
        Lb:
            if (r7 == 0) goto L12
            boolean r6 = r4 instanceof java.io.FileNotFoundException
            if (r6 == 0) goto L12
            return r0
        L12:
            boolean r6 = r4 instanceof java.net.ProtocolException
            if (r6 == 0) goto L17
            return r0
        L17:
            boolean r6 = r4 instanceof java.io.InterruptedIOException
            if (r6 == 0) goto L22
            boolean r4 = r4 instanceof java.net.SocketTimeoutException
            if (r4 == 0) goto La7
            if (r7 != 0) goto La7
            goto L35
        L22:
            boolean r6 = r4 instanceof javax.net.ssl.SSLHandshakeException
            if (r6 == 0) goto L30
            java.lang.Throwable r6 = r4.getCause()
            boolean r6 = r6 instanceof java.security.cert.CertificateException
            if (r6 == 0) goto L30
            goto La7
        L30:
            boolean r4 = r4 instanceof javax.net.ssl.SSLPeerUnverifiedException
            if (r4 == 0) goto L35
            return r0
        L35:
            e⃗ r4 = r5.f17992a
            defpackage.AbstractC3098.m10100a(r4)
            int r5 = r4.f6566a
            r6 = 1
            if (r5 != 0) goto L49
            int r7 = r4.f6567a
            if (r7 != 0) goto L49
            int r7 = r4.f6568a
            if (r7 != 0) goto L49
            r4 = r0
            goto La5
        L49:
            java.lang.Object r7 = r4.f6574a
            оۤ r7 = (defpackage.C2199) r7
            if (r7 == 0) goto L50
            goto La0
        L50:
            r7 = 0
            if (r5 > r6) goto L87
            int r5 = r4.f6567a
            if (r5 > r6) goto L87
            int r5 = r4.f6568a
            if (r5 <= 0) goto L5c
            goto L87
        L5c:
            java.lang.Cloneable r5 = r4.f6571a
            о́ r5 = (defpackage.C1987) r5
            о̄ r5 = r5.f17993a
            if (r5 != 0) goto L65
            goto L87
        L65:
            monitor-enter(r5)
            int r1 = r5.f18015a     // Catch: java.lang.Throwable -> L84
            if (r1 == 0) goto L6c
            monitor-exit(r5)
            goto L87
        L6c:
            оۤ r1 = r5.f18005a     // Catch: java.lang.Throwable -> L84
            aْ r1 = r1.f18684a     // Catch: java.lang.Throwable -> L84
            і̚ r1 = r1.f1352a     // Catch: java.lang.Throwable -> L84
            java.lang.Object r2 = r4.f6570a     // Catch: java.lang.Throwable -> L84
            aْ r2 = (defpackage.C4195a) r2     // Catch: java.lang.Throwable -> L84
            і̚ r2 = r2.f1352a     // Catch: java.lang.Throwable -> L84
            boolean r1 = defpackage.AbstractC6204p.m5320a(r1, r2)     // Catch: java.lang.Throwable -> L84
            if (r1 != 0) goto L80
            monitor-exit(r5)
            goto L87
        L80:
            оۤ r7 = r5.f18005a     // Catch: java.lang.Throwable -> L84
            monitor-exit(r5)
            goto L87
        L84:
            r4 = move-exception
            monitor-exit(r5)
            throw r4
        L87:
            if (r7 == 0) goto L8d
            r4.f6574a = r7
        L8b:
            r4 = r6
            goto La5
        L8d:
            java.lang.Object r5 = r4.f6572a
            ρ́ r5 = (defpackage.C0663) r5
            if (r5 == 0) goto L9a
            boolean r5 = r5.m6567a()
            if (r5 != r6) goto L9a
            goto La0
        L9a:
            java.lang.Object r4 = r4.f6573a
            c̓ r4 = (defpackage.C4380c) r4
            if (r4 != 0) goto La1
        La0:
            goto L8b
        La1:
            boolean r4 = r4.m2079a()
        La5:
            if (r4 != 0) goto La8
        La7:
            return r0
        La8:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C4675c.m2790a(java.io.IOException, о́, ϲُ, boolean):boolean");
    }

    public C4675c(C5165i c5165i) {
        this.f5656a = 1;
        AbstractC3098.m10103a(c5165i, "cookieJar");
        this.f5657a = c5165i;
    }
}
