package defpackage;

import java.util.RandomAccess;

/* JADX INFO: renamed from: ρͥ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0763 extends AbstractC0713 implements RandomAccess {
}
