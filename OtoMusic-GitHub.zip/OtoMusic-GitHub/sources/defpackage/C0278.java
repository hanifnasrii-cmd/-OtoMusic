package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import com.piyush.music.R;

/* JADX INFO: renamed from: ι⃙, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0278 extends AbstractC0277 {

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public static final SparseIntArray f12563a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public long f12564a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f12563a = sparseIntArray;
        sparseIntArray.put(R.id.page_grid, 1);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C0278(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 2, null, f12563a);
        super(null, view, (GridLayout) objArrM5440a[1]);
        this.f12564a = -1L;
        ((FrameLayout) objArrM5440a[0]).setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f12564a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f12564a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f12564a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
