package defpackage;

import android.app.Application;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.view.ViewStub;
import android.widget.TextView;
import com.bumptech.glide.a;
import com.piyush.music.App;
import com.piyush.music.R;
import com.piyush.music.activities.main.MainActivityViewModel;
import com.piyush.music.fragments.main.main.MainFragment;
import com.piyush.music.glide.artist.ArtistSignatureUtil;
import com.piyush.music.models.tag.JAudioTag;
import com.piyush.music.widget.NavigationBarContentFrameLayout;
import com.piyush.music.widget.expandablesearchbar.ExpandableSearchBar;
import com.piyush.taglib.AudioProperties;
import java.io.File;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;

/* JADX INFO: renamed from: aܻ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C4241a implements InterfaceC5038i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f1498a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f1499a;

    public /* synthetic */ C4241a(int i, Object obj) {
        this.f1498a = i;
        this.f1499a = obj;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        C5029i c5029i;
        int i = 2;
        switch (this.f1498a) {
            case 0:
                C4245a c4245a = (C4245a) this.f1499a;
                int i2 = C4245a.f1507a;
                return new C4203a(c4245a.m2180a(), c4245a, c4245a, AbstractC6161p.m5214a(c4245a), a.m1237a(c4245a.getContext()).m8566a(c4245a), c4245a.m6562a());
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                App app = (App) this.f1499a;
                App app2 = App.f2643a;
                C5144i c5144i = app.f2649a;
                if (c5144i == null) {
                    AbstractC3098.m10141a("globalNotifier");
                    throw null;
                }
                C0477 c0477 = c5144i.f7229a;
                C6174p c6174p = C6174p.f10843a;
                c0477.mo4474a(c6174p);
                return c6174p;
            case 2:
                C1480 c1480 = (C1480) this.f1499a;
                int i3 = C1480.f16071a;
                ComponentCallbacks2C2114 componentCallbacks2C2114M8566a = a.m1237a(c1480.getContext()).m8566a(c1480);
                return new C1464(AbstractC6161p.m5214a(c1480), componentCallbacks2C2114M8566a, c1480.m2180a(), c1480, c1480.m6562a());
            case 3:
                return ArtistSignatureUtil.cache_delegate$lambda$0((ArtistSignatureUtil) this.f1499a);
            case 4:
                Object systemService = ((C1541) this.f1499a).f16276a.getSystemService("audio");
                AbstractC3098.m10101a(systemService, "null cannot be cast to non-null type android.media.AudioManager");
                return (AudioManager) systemService;
            case 5:
                File file = new File(((C1646) this.f1499a).f16626a.getFilesDir(), "autoeq_cache");
                file.mkdirs();
                return file;
            case 6:
                AbstractC4431c abstractC4431c = (AbstractC4431c) this.f1499a;
                return new C4702e(abstractC4431c.mo2190a(), abstractC4431c, 0);
            case 7:
                MainActivityViewModel mainActivityViewModel = (MainActivityViewModel) ((AbstractC4452c) this.f1499a).f4829a.getValue();
                C5763o c5763o = C5601j.f8884a;
                mainActivityViewModel.m1621a(C5601j.m4435a(), R.id.edit_lyrics);
                return C6174p.f10843a;
            case 8:
                C4517c c4517c = (C4517c) this.f1499a;
                C4842e c4842e = C4531c.f5186a;
                Application application = (Application) c4517c.f5143a;
                String[] strArr = c4517c.f5147a;
                String[] strArr2 = c4517c.f5146a;
                C4531c c4531c = C4531c.f5188a;
                if (c4531c == null) {
                    synchronized (c4842e) {
                        c4531c = C4531c.f5188a;
                        if (c4531c == null) {
                            c4531c = new C4531c(application, strArr, strArr2);
                            C4531c.f5188a = c4531c;
                        }
                        break;
                    }
                }
                return c4531c;
            case 9:
                ((AbstractActivityC2905) this.f1499a).reportFullyDrawn();
                return null;
            case 10:
                return ((C1058) this.f1499a).f14502a.getSharedPreferences("crash_handler_prefs", 0);
            case 11:
                C4702e c4702e = (C4702e) this.f1499a;
                C4540c c4540c = new C4540c(c4702e.f5781a, c4702e.f5780a);
                AbstractC5120i abstractC5120i = c4702e.f5779a;
                synchronized (AbstractC5120i.f7070a) {
                    try {
                        if (AbstractC5120i.f7071a == null) {
                            AbstractC5120i.f7071a = Executors.newFixedThreadPool(2);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                return new C1512(c4540c, new C1274(AbstractC5120i.f7071a, 3, abstractC5120i));
            case 12:
                return new C4499c(((C4838e) this.f1499a).f6181a);
            case 13:
                ExpandableSearchBar expandableSearchBar = (ExpandableSearchBar) this.f1499a;
                int i4 = ExpandableSearchBar.f4261a;
                return (TextView) expandableSearchBar.findViewById(R.id.open_search_bar_text_view);
            case 14:
                C5030i c5030i = (C5030i) this.f1499a;
                String str = c5030i.f6890a;
                if (str == null || !c5030i.f6892a) {
                    c5029i = new C5029i(c5030i.f6889a, c5030i.f6890a, new C2187(25), c5030i.f6891a, c5030i.f6893a);
                } else {
                    Context context = c5030i.f6889a;
                    AbstractC3098.m10103a(context, "context");
                    File noBackupFilesDir = context.getNoBackupFilesDir();
                    AbstractC3098.m10102a(noBackupFilesDir, "getNoBackupFilesDir(...)");
                    c5029i = new C5029i(c5030i.f6889a, new File(noBackupFilesDir, str).getAbsolutePath(), new C2187(25), c5030i.f6891a, c5030i.f6893a);
                }
                c5029i.setWriteAheadLoggingEnabled(c5030i.f6895a);
                return c5029i;
            case 15:
                C5097i c5097i = (C5097i) this.f1499a;
                int i5 = C5097i.f6972a;
                return new C5086i(AbstractC6161p.m5214a(c5097i), a.m1237a(c5097i.getContext()).m8566a(c5097i), c5097i.m2180a(), c5097i, c5097i.m6562a());
            case 16:
                return AbstractC5121i.m3492a(((C5170i) this.f1499a).f7334a.getApplicationContext());
            case 17:
                return new C4702e(new C5974o(i), (C5273i) this.f1499a, 0);
            case 18:
                return JAudioTag.audioHeader_delegate$lambda$0((JAudioTag) this.f1499a);
            case 19:
                return Float.valueOf(AbstractC5120i.m3432a(100.0f, ((MainFragment) this.f1499a).requireContext()));
            case 20:
                AbstractC1082 abstractC1082 = (AbstractC1082) this.f1499a;
                return new C4702e(abstractC1082.mo1060a(), abstractC1082, abstractC1082.mo4708a());
            case 21:
                NavigationBarContentFrameLayout navigationBarContentFrameLayout = (NavigationBarContentFrameLayout) this.f1499a;
                int i6 = NavigationBarContentFrameLayout.f4017a;
                ColorDrawable colorDrawable = new ColorDrawable(navigationBarContentFrameLayout.navigationBarDividerColor);
                colorDrawable.setCallback(navigationBarContentFrameLayout);
                return colorDrawable;
            case 22:
                C3589 c3589 = (C3589) this.f1499a;
                return c3589.f23078a.mo7486a(c3589.f23079a);
            case 23:
                return ((C5706o) this.f1499a).f9276a.getSharedPreferences("play_event_collector_state", 0);
            case 24:
                C5785o c5785o = (C5785o) this.f1499a;
                int i7 = C5785o.f9579a;
                return new C5771o(a.m1237a(c5785o.getContext()).m8566a(c5785o), c5785o.m2180a(), c5785o, AbstractC6161p.m5214a(c5785o), c5785o, c5785o.m6562a(), c5785o);
            case 25:
                return ((Callable) this.f1499a).call();
            case 26:
                ((Runnable) this.f1499a).run();
                return C6174p.f10843a;
            case 27:
                C2067 c2067 = (C2067) this.f1499a;
                ViewStub viewStub = (ViewStub) ((C3877) c2067.f18235a).f23921a;
                AbstractC3098.m10100a(viewStub);
                viewStub.inflate();
                AbstractC6265p abstractC6265p = (AbstractC6265p) ((C3877) c2067.f18235a).f23922a;
                AbstractC3098.m10100a(abstractC6265p);
                return (AbstractC2245) abstractC6265p;
            case 28:
                return this.f1499a;
            default:
                return ((AbstractC0493) this.f1499a).m6367a();
        }
    }
}
