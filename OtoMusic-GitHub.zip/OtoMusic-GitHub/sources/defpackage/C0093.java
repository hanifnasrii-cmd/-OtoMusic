package defpackage;

import java.util.Objects;

/* JADX INFO: renamed from: ι͝, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0093 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final long f11903a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float f11904a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final long f11905a;

    public C0093(C0092 c0092) {
        this.f11903a = c0092.f11900a;
        this.f11904a = c0092.f11901a;
        this.f11905a = c0092.f11902a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0093)) {
            return false;
        }
        C0093 c0093 = (C0093) obj;
        return this.f11903a == c0093.f11903a && this.f11904a == c0093.f11904a && this.f11905a == c0093.f11905a;
    }

    public final int hashCode() {
        return Objects.hash(Long.valueOf(this.f11903a), Float.valueOf(this.f11904a), Long.valueOf(this.f11905a));
    }
}
