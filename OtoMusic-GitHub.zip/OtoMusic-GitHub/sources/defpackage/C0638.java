package defpackage;

import android.os.Bundle;
import android.os.Parcelable;
import com.piyush.music.fragments.list.OpenMode;
import java.io.Serializable;
import java.util.HashMap;

/* JADX INFO: renamed from: οⷨ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0638 implements InterfaceC5659j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final HashMap f13696a = new HashMap();

    public static C0638 fromBundle(Bundle bundle) {
        C0638 c0638 = new C0638();
        bundle.setClassLoader(C0638.class.getClassLoader());
        if (!bundle.containsKey("openMode")) {
            throw new IllegalArgumentException("Required argument \"openMode\" is missing and does not have an android:defaultValue");
        }
        if (!Parcelable.class.isAssignableFrom(OpenMode.class) && !Serializable.class.isAssignableFrom(OpenMode.class)) {
            throw new UnsupportedOperationException(OpenMode.class.getName().concat(" must implement Parcelable or Serializable or must be an Enum."));
        }
        OpenMode openMode = (OpenMode) bundle.get("openMode");
        if (openMode == null) {
            throw new IllegalArgumentException("Argument \"openMode\" is marked as non-null but was passed a null value.");
        }
        c0638.f13696a.put("openMode", openMode);
        return c0638;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final OpenMode m6528a() {
        return (OpenMode) this.f13696a.get("openMode");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0638.class != obj.getClass()) {
            return false;
        }
        C0638 c0638 = (C0638) obj;
        if (this.f13696a.containsKey("openMode") != c0638.f13696a.containsKey("openMode")) {
            return false;
        }
        return m6528a() == null ? c0638.m6528a() == null : m6528a().equals(c0638.m6528a());
    }

    public final int hashCode() {
        return 31 + (m6528a() != null ? m6528a().hashCode() : 0);
    }

    public final String toString() {
        return "SongsListFragmentArgs{openMode=" + m6528a() + "}";
    }
}
