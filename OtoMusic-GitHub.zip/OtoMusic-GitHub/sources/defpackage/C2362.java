package defpackage;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;
import java.util.Collections;

/* JADX INFO: renamed from: р̭, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2362 implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ C2369 f19188a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ C2390 f19189a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final /* synthetic */ C2390 f19190a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f19191a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ View f19192a;

    public C2362(C2369 c2369, C2390 c2390, C2390 c23902, int i, View view) {
        this.f19188a = c2369;
        this.f19189a = c2390;
        this.f19190a = c23902;
        this.f19191a = i;
        this.f19192a = view;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        float animatedFraction = valueAnimator.getAnimatedFraction();
        C2369 c2369 = this.f19188a;
        AbstractC2368 abstractC2368 = c2369.f19208a;
        abstractC2368.mo8810a(animatedFraction);
        C2390 c2390 = this.f19189a;
        C2386 c2386 = c2390.f19244a;
        float fMo8808a = abstractC2368.mo8808a();
        PathInterpolator pathInterpolator = C2364.f19195a;
        int i = Build.VERSION.SDK_INT;
        AbstractC2377 c2376 = i >= 36 ? new C2376(c2390) : i >= 35 ? new C2375(c2390) : i >= 34 ? new C2374(c2390) : i >= 31 ? new C2373(c2390) : i >= 30 ? new C2372(c2390) : i >= 29 ? new C2371(c2390) : new C2370(c2390);
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            if ((this.f19191a & i2) == 0) {
                c2376.mo8818a(i2, c2386.mo8832a(i2));
            } else {
                C3082 c3082Mo8832a = c2386.mo8832a(i2);
                C3082 c3082Mo8832a2 = this.f19190a.f19244a.mo8832a(i2);
                float f = 1.0f - fMo8808a;
                c2376.mo8818a(i2, C2390.m8862a(c3082Mo8832a, (int) (((double) ((c3082Mo8832a.f21682a - c3082Mo8832a2.f21682a) * f)) + 0.5d), (int) (((double) ((c3082Mo8832a.f21683a - c3082Mo8832a2.f21683a) * f)) + 0.5d), (int) (((double) ((c3082Mo8832a.f21684a - c3082Mo8832a2.f21684a) * f)) + 0.5d), (int) (((double) ((c3082Mo8832a.f21685a - c3082Mo8832a2.f21685a) * f)) + 0.5d)));
            }
        }
        C2364.m8786a(this.f19192a, c2376.mo8812a(), Collections.singletonList(c2369));
    }
}
