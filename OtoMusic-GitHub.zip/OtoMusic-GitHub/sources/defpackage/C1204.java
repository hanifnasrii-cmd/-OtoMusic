package defpackage;

/* JADX INFO: renamed from: ϲۢ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1204 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public AbstractC2042 f15116a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public AbstractC2042 f15117a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f15118a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f15119a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f15120a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f15121a;

    public C1204(AbstractC2042 abstractC2042, AbstractC2042 abstractC20422, int i, int i2, int i3, int i4) {
        this.f15116a = abstractC2042;
        this.f15117a = abstractC20422;
        this.f15118a = i;
        this.f15119a = i2;
        this.f15120a = i3;
        this.f15121a = i4;
    }

    public final String toString() {
        return "ChangeInfo{oldHolder=" + this.f15116a + ", newHolder=" + this.f15117a + ", fromX=" + this.f15118a + ", fromY=" + this.f15119a + ", toX=" + this.f15120a + ", toY=" + this.f15121a + '}';
    }
}
