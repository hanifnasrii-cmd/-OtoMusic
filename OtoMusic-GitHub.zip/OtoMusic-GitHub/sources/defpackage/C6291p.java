package defpackage;

import androidx.viewpager2.widget.ViewPager2;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

/* JADX INFO: renamed from: p⃛, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6291p extends AbstractC6297p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f11189a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object f11190a;

    public /* synthetic */ C6291p(ViewPager2 viewPager2, int i) {
        this.f11189a = i;
        this.f11190a = viewPager2;
    }

    @Override // defpackage.AbstractC6297p
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void mo5487a(int i) {
        switch (this.f11189a) {
            case 0:
                if (i == 0) {
                    ((ViewPager2) this.f11190a).m630a();
                    return;
                }
                return;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
            default:
                return;
            case 2:
                try {
                    ArrayList arrayList = (ArrayList) this.f11190a;
                    int size = arrayList.size();
                    int i2 = 0;
                    while (i2 < size) {
                        Object obj = arrayList.get(i2);
                        i2++;
                        ((AbstractC6297p) obj).mo5487a(i);
                    }
                    return;
                } catch (ConcurrentModificationException e) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e);
                }
        }
    }

    @Override // defpackage.AbstractC6297p
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public void mo5488a(int i, float f, int i2) {
        switch (this.f11189a) {
            case 2:
                try {
                    ArrayList arrayList = (ArrayList) this.f11190a;
                    int size = arrayList.size();
                    int i3 = 0;
                    while (i3 < size) {
                        Object obj = arrayList.get(i3);
                        i3++;
                        ((AbstractC6297p) obj).mo5488a(i, f, i2);
                    }
                    return;
                } catch (ConcurrentModificationException e) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e);
                }
            default:
                return;
        }
    }

    @Override // defpackage.AbstractC6297p
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void mo5489a(int i) {
        switch (this.f11189a) {
            case 0:
                ViewPager2 viewPager2 = (ViewPager2) this.f11190a;
                if (viewPager2.f861a != i) {
                    viewPager2.f861a = i;
                    viewPager2.f877a.m10728a();
                    return;
                }
                return;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                ViewPager2 viewPager22 = (ViewPager2) this.f11190a;
                viewPager22.clearFocus();
                if (viewPager22.hasFocus()) {
                    viewPager22.f867a.requestFocus(2);
                    return;
                }
                return;
            default:
                try {
                    ArrayList arrayList = (ArrayList) this.f11190a;
                    int size = arrayList.size();
                    int i2 = 0;
                    while (i2 < size) {
                        Object obj = arrayList.get(i2);
                        i2++;
                        ((AbstractC6297p) obj).mo5489a(i);
                    }
                    return;
                } catch (ConcurrentModificationException e) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e);
                }
        }
    }

    public C6291p() {
        this.f11189a = 2;
        this.f11190a = new ArrayList(3);
    }
}
