package defpackage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/* JADX INFO: renamed from: іّ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3164 implements InterfaceC6210p {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final SimpleDateFormat f21937a;

    static {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f21937a = simpleDateFormat;
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    @Override // defpackage.InterfaceC4902e
    public final void encode(Object obj, Object obj2) {
        ((InterfaceC6211p) obj2).mo4892a(f21937a.format((Date) obj));
    }
}
