package defpackage;

/* JADX INFO: renamed from: o͙, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC5770o {
}
