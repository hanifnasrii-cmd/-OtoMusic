package defpackage;

import java.util.Set;
import java.util.UUID;

/* JADX INFO: renamed from: јׅ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3476 extends AbstractC0493 {
    public C3476(Class cls) {
        super(cls);
    }

    @Override // defpackage.AbstractC0493
    /* JADX INFO: renamed from: â */
    public final AbstractC2419 mo6366a() {
        return new C3477((UUID) this.f13296a, (C2422) this.f13297a, (Set) this.f13298a);
    }
}
