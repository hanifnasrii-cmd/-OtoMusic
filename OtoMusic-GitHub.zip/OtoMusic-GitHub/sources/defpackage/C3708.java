package defpackage;

import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import java.util.Arrays;

/* JADX INFO: renamed from: օ̓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3708 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public int f23434a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f23435a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public boolean f23436a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public boolean f23437a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f23438a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int[] f23439a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ StaggeredGridLayoutManager f23440a;

    public C3708(StaggeredGridLayoutManager staggeredGridLayoutManager) {
        this.f23440a = staggeredGridLayoutManager;
        m10907a();
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m10907a() {
        this.f23434a = -1;
        this.f23435a = Integer.MIN_VALUE;
        this.f23436a = false;
        this.f23437a = false;
        this.f23438a = false;
        int[] iArr = this.f23439a;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
    }
}
