package defpackage;

import android.view.View;
import android.widget.FrameLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentContainerView;
import com.google.android.material.imageview.ShapeableImageView;
import com.piyush.music.activities.main.MainActivityViewModel;
import com.piyush.music.fragments.player.PlayerSheet;
import com.piyush.music.widget.NavigationBarContentFrameLayout;
import com.piyush.music.widget.OtoBottomNavigationView;
import com.piyush.music.widget.PlayButtonParent;

/* JADX INFO: renamed from: ιָ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0156 extends AbstractC6265p {

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final ShapeableImageView f12113a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final OtoBottomNavigationView f12114a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final FrameLayout f12115a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public final DrawerLayout f12116a;

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public final AbstractC5958o f12117a;

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public final FragmentContainerView f12118a;

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public final FragmentContainerView f12119a;

    /* JADX INFO: renamed from: a̢, reason: contains not printable characters */
    public final FragmentContainerView f12120a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final FragmentContainerView f12121a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public final NavigationBarContentFrameLayout f12122a;

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public final PlayerSheet f12123a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public final PlayButtonParent f12124a;

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final CoordinatorLayout f12125a;

    /* JADX INFO: renamed from: ą, reason: contains not printable characters */
    public final C3877 f12126a;

    /* JADX INFO: renamed from: a̩, reason: contains not printable characters */
    public MainActivityViewModel f12127a;

    public AbstractC0156(InterfaceC1126 interfaceC1126, View view, ShapeableImageView shapeableImageView, OtoBottomNavigationView otoBottomNavigationView, FrameLayout frameLayout, DrawerLayout drawerLayout, AbstractC5958o abstractC5958o, FragmentContainerView fragmentContainerView, FragmentContainerView fragmentContainerView2, FragmentContainerView fragmentContainerView3, FragmentContainerView fragmentContainerView4, NavigationBarContentFrameLayout navigationBarContentFrameLayout, PlayerSheet playerSheet, PlayButtonParent playButtonParent, CoordinatorLayout coordinatorLayout, C3877 c3877) {
        super(interfaceC1126, view, 1);
        this.f12113a = shapeableImageView;
        this.f12114a = otoBottomNavigationView;
        this.f12115a = frameLayout;
        this.f12116a = drawerLayout;
        this.f12117a = abstractC5958o;
        this.f12118a = fragmentContainerView;
        this.f12119a = fragmentContainerView2;
        this.f12120a = fragmentContainerView3;
        this.f12121a = fragmentContainerView4;
        this.f12122a = navigationBarContentFrameLayout;
        this.f12123a = playerSheet;
        this.f12124a = playButtonParent;
        this.f12125a = coordinatorLayout;
        this.f12126a = c3877;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public abstract void mo5941a(MainActivityViewModel mainActivityViewModel);
}
