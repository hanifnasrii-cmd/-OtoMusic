package defpackage;

/* JADX INFO: renamed from: еٜ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1851 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f17433a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C1836 f17434a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f17435a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1851(C1836 c1836, InterfaceC1005 interfaceC1005) {
        super(interfaceC1005);
        this.f17434a = c1836;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f17433a = obj;
        this.f17435a |= Integer.MIN_VALUE;
        return this.f17434a.mo674a(null, this);
    }
}
