package defpackage;

/* JADX INFO: renamed from: еַ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1810 extends C0262 {
    @Override // defpackage.C0262, android.graphics.drawable.Drawable
    public final boolean isStateful() {
        return true;
    }
}
