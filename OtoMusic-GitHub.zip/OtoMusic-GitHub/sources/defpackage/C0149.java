package defpackage;

/* JADX INFO: renamed from: ιֱ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0149 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f12094a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C0150 f12095a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f12096a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0149(C0150 c0150, InterfaceC1005 interfaceC1005) {
        super(interfaceC1005);
        this.f12095a = c0150;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f12094a = obj;
        this.f12096a |= Integer.MIN_VALUE;
        return this.f12095a.m5934a(false, this);
    }
}
