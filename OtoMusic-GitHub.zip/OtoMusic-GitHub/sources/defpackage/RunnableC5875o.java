package defpackage;

import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import com.piyush.music.R;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: oٚ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class RunnableC5875o implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f9869a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ View f9870a;

    public /* synthetic */ RunnableC5875o(View view, int i) {
        this.f9869a = i;
        this.f9870a = view;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f9869a) {
            case 0:
                View view = this.f9870a;
                int iM10120a = (AbstractC3098.m10120a(view, R.attr.colorPrimary) & 16777215) | 855638016;
                Drawable background = view.getBackground();
                ValueAnimator valueAnimatorOfArgb = ValueAnimator.ofArgb(0, iM10120a, 0);
                valueAnimatorOfArgb.setDuration(500L);
                valueAnimatorOfArgb.setRepeatCount(1);
                valueAnimatorOfArgb.addUpdateListener(new C1750(view, 1));
                valueAnimatorOfArgb.addListener(new C2656(view, 4, background));
                valueAnimatorOfArgb.start();
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                this.f9870a.setVisibility(8);
                break;
            case 2:
                View view2 = this.f9870a;
                ((ViewGroup) view2.getParent()).removeView(view2);
                break;
            default:
                View view3 = this.f9870a;
                ((InputMethodManager) view3.getContext().getSystemService(InputMethodManager.class)).showSoftInput(view3, 1);
                break;
        }
    }
}
