package defpackage;

import android.graphics.Color;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: сܳ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2872 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final ThreadLocal f20828a = new ThreadLocal();

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static int m9745a(float[] fArr) {
        int iRound;
        int iRound2;
        int iRound3 = 0;
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float fAbs = (1.0f - Math.abs((f3 * 2.0f) - 1.0f)) * f2;
        float f4 = f3 - (0.5f * fAbs);
        float fAbs2 = (1.0f - Math.abs(((f / 60.0f) % 2.0f) - 1.0f)) * fAbs;
        switch (((int) f) / 60) {
            case 0:
                iRound3 = Math.round((fAbs + f4) * 255.0f);
                iRound = Math.round((fAbs2 + f4) * 255.0f);
                iRound2 = Math.round(f4 * 255.0f);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                iRound3 = Math.round((fAbs2 + f4) * 255.0f);
                iRound = Math.round((fAbs + f4) * 255.0f);
                iRound2 = Math.round(f4 * 255.0f);
                break;
            case 2:
                iRound3 = Math.round(f4 * 255.0f);
                iRound = Math.round((fAbs + f4) * 255.0f);
                iRound2 = Math.round((fAbs2 + f4) * 255.0f);
                break;
            case 3:
                iRound3 = Math.round(f4 * 255.0f);
                iRound = Math.round((fAbs2 + f4) * 255.0f);
                iRound2 = Math.round((fAbs + f4) * 255.0f);
                break;
            case 4:
                iRound3 = Math.round((fAbs2 + f4) * 255.0f);
                iRound = Math.round(f4 * 255.0f);
                iRound2 = Math.round((fAbs + f4) * 255.0f);
                break;
            case 5:
            case 6:
                iRound3 = Math.round((fAbs + f4) * 255.0f);
                iRound = Math.round(f4 * 255.0f);
                iRound2 = Math.round((fAbs2 + f4) * 255.0f);
                break;
            default:
                iRound2 = 0;
                iRound = 0;
                break;
        }
        return Color.rgb(m9758a(iRound3), m9758a(iRound), m9758a(iRound2));
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static int m9746a(double d, double d2, double d3) {
        ThreadLocal threadLocal = f20828a;
        double[] dArr = (double[]) threadLocal.get();
        if (dArr == null) {
            dArr = new double[3];
            threadLocal.set(dArr);
        }
        double d4 = (d + 16.0d) / 116.0d;
        double d5 = (d2 / 500.0d) + d4;
        double d6 = d4 - (d3 / 200.0d);
        double dPow = Math.pow(d5, 3.0d);
        if (dPow <= 0.008856d) {
            dPow = ((d5 * 116.0d) - 16.0d) / 903.3d;
        }
        double dPow2 = d > 7.9996247999999985d ? Math.pow(d4, 3.0d) : d / 903.3d;
        double dPow3 = Math.pow(d6, 3.0d);
        if (dPow3 <= 0.008856d) {
            dPow3 = ((d6 * 116.0d) - 16.0d) / 903.3d;
        }
        double d7 = dPow * 95.047d;
        dArr[0] = d7;
        double d8 = dPow2 * 100.0d;
        dArr[1] = d8;
        double d9 = dPow3 * 108.883d;
        dArr[2] = d9;
        return m9749a(d7, d8, d9);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static void m9747a(int i, int i2, int i3, float[] fArr) {
        float f;
        float fAbs;
        float f2 = i / 255.0f;
        float f3 = i2 / 255.0f;
        float f4 = i3 / 255.0f;
        float fMax = Math.max(f2, Math.max(f3, f4));
        float fMin = Math.min(f2, Math.min(f3, f4));
        float f5 = fMax - fMin;
        float f6 = (fMax + fMin) / 2.0f;
        if (fMax == fMin) {
            f = 0.0f;
            fAbs = 0.0f;
        } else {
            f = fMax == f2 ? ((f3 - f4) / f5) % 6.0f : fMax == f3 ? ((f4 - f2) / f5) + 2.0f : 4.0f + ((f2 - f3) / f5);
            fAbs = f5 / (1.0f - Math.abs((2.0f * f6) - 1.0f));
        }
        float f7 = (f * 60.0f) % 360.0f;
        if (f7 < 0.0f) {
            f7 += 360.0f;
        }
        fArr[0] = f7 < 0.0f ? 0.0f : Math.min(f7, 360.0f);
        fArr[1] = fAbs < 0.0f ? 0.0f : Math.min(fAbs, 1.0f);
        fArr[2] = f6 >= 0.0f ? Math.min(f6, 1.0f) : 0.0f;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static void m9748a(int i, int i2, int i3, double[] dArr) {
        if (dArr.length != 3) {
            throw new IllegalArgumentException("outXyz must have a length of 3.");
        }
        double d = ((double) i) / 255.0d;
        double dPow = d < 0.04045d ? d / 12.92d : Math.pow((d + 0.055d) / 1.055d, 2.4d);
        double d2 = ((double) i2) / 255.0d;
        double dPow2 = d2 < 0.04045d ? d2 / 12.92d : Math.pow((d2 + 0.055d) / 1.055d, 2.4d);
        double d3 = ((double) i3) / 255.0d;
        double dPow3 = d3 < 0.04045d ? d3 / 12.92d : Math.pow((d3 + 0.055d) / 1.055d, 2.4d);
        dArr[0] = ((0.1805d * dPow3) + (0.3576d * dPow2) + (0.4124d * dPow)) * 100.0d;
        dArr[1] = ((0.0722d * dPow3) + (0.7152d * dPow2) + (0.2126d * dPow)) * 100.0d;
        dArr[2] = ((dPow3 * 0.9505d) + (dPow2 * 0.1192d) + (dPow * 0.0193d)) * 100.0d;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static int m9749a(double d, double d2, double d3) {
        double dM732a = AbstractC4072a.m732a(d3, -0.4986d, ((-1.5372d) * d2) + (3.2406d * d), 100.0d);
        double dM732a2 = AbstractC4072a.m732a(d3, 0.0415d, (1.8758d * d2) + ((-0.9689d) * d), 100.0d);
        double dM732a3 = AbstractC4072a.m732a(d3, 1.057d, ((-0.204d) * d2) + (0.0557d * d), 100.0d);
        return Color.rgb(m9758a((int) Math.round((dM732a > 0.0031308d ? (Math.pow(dM732a, 0.4166666666666667d) * 1.055d) - 0.055d : dM732a * 12.92d) * 255.0d)), m9758a((int) Math.round((dM732a2 > 0.0031308d ? (Math.pow(dM732a2, 0.4166666666666667d) * 1.055d) - 0.055d : dM732a2 * 12.92d) * 255.0d)), m9758a((int) Math.round((dM732a3 > 0.0031308d ? (Math.pow(dM732a3, 0.4166666666666667d) * 1.055d) - 0.055d : dM732a3 * 12.92d) * 255.0d)));
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static int m9750a(int i, float f, int i2) {
        float f2 = 1.0f - f;
        return Color.argb((int) ((Color.alpha(i2) * f) + (Color.alpha(i) * f2)), (int) ((Color.red(i2) * f) + (Color.red(i) * f2)), (int) ((Color.green(i2) * f) + (Color.green(i) * f2)), (int) ((Color.blue(i2) * f) + (Color.blue(i) * f2)));
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static double m9751a(int i, int i2) {
        if (Color.alpha(i2) != 255) {
            throw new IllegalArgumentException("background can not be translucent: #" + Integer.toHexString(i2));
        }
        if (Color.alpha(i) < 255) {
            i = m9756a(i, i2);
        }
        double dM9752a = m9752a(i) + 0.05d;
        double dM9752a2 = m9752a(i2) + 0.05d;
        return Math.max(dM9752a, dM9752a2) / Math.min(dM9752a, dM9752a2);
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static double m9752a(int i) {
        ThreadLocal threadLocal = f20828a;
        double[] dArr = (double[]) threadLocal.get();
        if (dArr == null) {
            dArr = new double[3];
            threadLocal.set(dArr);
        }
        m9748a(Color.red(i), Color.green(i), Color.blue(i), dArr);
        return dArr[1] / 100.0d;
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static int m9753a(int i, float f, int i2) {
        int i3 = 255;
        if (Color.alpha(i2) != 255) {
            throw new IllegalArgumentException("background can not be translucent: #" + Integer.toHexString(i2));
        }
        double d = f;
        if (m9751a(m9760a(i, 255), i2) < d) {
            return -1;
        }
        int i4 = 0;
        for (int i5 = 0; i5 <= 10 && i3 - i4 > 1; i5++) {
            int i6 = (i4 + i3) / 2;
            if (m9751a(m9760a(i, i6), i2) < d) {
                i4 = i6;
            } else {
                i3 = i6;
            }
        }
        return i3;
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static void m9754a(float[] fArr, int i) {
        m9747a(Color.red(i), Color.green(i), Color.blue(i), fArr);
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static void m9755a(int i, double[] dArr) {
        m9748a(Color.red(i), Color.green(i), Color.blue(i), dArr);
        double d = dArr[0];
        double d2 = dArr[1];
        double d3 = dArr[2];
        if (dArr.length != 3) {
            throw new IllegalArgumentException("outLab must have a length of 3.");
        }
        double dM9759a = m9759a(d / 95.047d);
        double dM9759a2 = m9759a(d2 / 100.0d);
        double dM9759a3 = m9759a(d3 / 108.883d);
        dArr[0] = Math.max(0.0d, (116.0d * dM9759a2) - 16.0d);
        dArr[1] = (dM9759a - dM9759a2) * 500.0d;
        dArr[2] = (dM9759a2 - dM9759a3) * 200.0d;
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static int m9756a(int i, int i2) {
        int iAlpha = Color.alpha(i2);
        int iAlpha2 = Color.alpha(i);
        int i3 = 255 - (((255 - iAlpha2) * (255 - iAlpha)) / 255);
        return Color.argb(i3, m9757a(Color.red(i), iAlpha2, Color.red(i2), iAlpha, i3), m9757a(Color.green(i), iAlpha2, Color.green(i2), iAlpha, i3), m9757a(Color.blue(i), iAlpha2, Color.blue(i2), iAlpha, i3));
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public static int m9757a(int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            return 0;
        }
        return (((255 - i2) * (i3 * i4)) + ((i * 255) * i2)) / (i5 * 255);
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static int m9758a(int i) {
        if (i < 0) {
            return 0;
        }
        return Math.min(i, 255);
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static double m9759a(double d) {
        return d > 0.008856d ? Math.pow(d, 0.3333333333333333d) : AbstractC4072a.m732a(d, 903.3d, 16.0d, 116.0d);
    }

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static int m9760a(int i, int i2) {
        if (i2 < 0 || i2 > 255) {
            throw new IllegalArgumentException("alpha must be between 0 and 255.");
        }
        return (i & 16777215) | (i2 << 24);
    }
}
