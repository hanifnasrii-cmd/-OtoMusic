package defpackage;

/* JADX INFO: renamed from: аⷱ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1640 implements InterfaceC1814 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16607a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C3735 f16608a;

    public /* synthetic */ C1640(C3735 c3735, int i) {
        this.f16607a = i;
        this.f16608a = c3735;
    }

    @Override // defpackage.InterfaceC1814
    /* JADX INFO: renamed from: à */
    public final Object mo2389a(InterfaceC1816 interfaceC1816, InterfaceC1005 interfaceC1005) {
        switch (this.f16607a) {
            case 0:
                Object objMo2389a = this.f16608a.mo2389a(new C1613(interfaceC1816, 3), interfaceC1005);
                if (objMo2389a != EnumC1045.COROUTINE_SUSPENDED) {
                    break;
                }
                break;
            default:
                Object objMo2389a2 = this.f16608a.mo2389a(new C1613(interfaceC1816, 4), interfaceC1005);
                if (objMo2389a2 != EnumC1045.COROUTINE_SUSPENDED) {
                    break;
                }
                break;
        }
        return C6174p.f10843a;
    }
}
