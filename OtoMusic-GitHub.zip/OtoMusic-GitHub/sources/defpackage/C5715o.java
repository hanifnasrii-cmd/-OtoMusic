package defpackage;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import com.piyush.music.R;
import com.piyush.music.activities.base.MusicServiceViewModel;

/* JADX INFO: renamed from: o̢, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5715o extends C3097 implements InterfaceC1207 {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Context f9328a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final CardView f9329a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public ValueAnimator f9330a;

    public C5715o(Context context, boolean z, MusicServiceViewModel musicServiceViewModel, InterfaceC3292 interfaceC3292, AbstractC3284 abstractC3284, ImageButton imageButton, CardView cardView) {
        super(context, z, musicServiceViewModel, interfaceC3292, imageButton);
        this.f9328a = context;
        this.f9329a = cardView;
        abstractC3284.mo10357a(this);
    }

    @Override // defpackage.C3097
    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final void mo4614a(boolean z, boolean z2) {
        Context context = this.f9328a;
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(R.dimen.amj);
        int dimensionPixelSize2 = context.getResources().getDimensionPixelSize(R.dimen.amk);
        if (dimensionPixelSize > dimensionPixelSize2) {
            dimensionPixelSize = dimensionPixelSize2;
        }
        Drawable drawable = ((ImageView) this.f21718a).getDrawable();
        AbstractC3098.m10101a(drawable, "null cannot be cast to non-null type com.piyush.music.widget.PlayPauseDrawable");
        ((C5713o) drawable).m4612a(z2, z);
        CardView cardView = this.f9329a;
        if (z2) {
            m4615a(cardView, dimensionPixelSize / 3.5f, true, z);
        } else {
            m4615a(cardView, dimensionPixelSize / 2.0f, false, z);
        }
    }

    /* JADX INFO: renamed from: a̠, reason: contains not printable characters */
    public final void m4615a(final CardView cardView, final float f, final boolean z, boolean z2) {
        if (cardView.getMeasuredWidth() == 0) {
            cardView.setRadius(f);
            ViewGroup.LayoutParams layoutParams = cardView.getLayoutParams();
            if (layoutParams == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
            }
            layoutParams.width = z ? (int) (((double) layoutParams.height) * 1.5d) : layoutParams.height;
            cardView.setLayoutParams(layoutParams);
            return;
        }
        if (cardView.getRadius() == f) {
            return;
        }
        ValueAnimator valueAnimator = this.f9330a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        final float radius = cardView.getRadius();
        final int measuredWidth = cardView.getMeasuredWidth();
        if (z2) {
            final ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
            valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: o̡
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    ValueAnimator valueAnimator3 = valueAnimatorOfFloat;
                    Object animatedValue = valueAnimator3.getAnimatedValue();
                    AbstractC3098.m10101a(animatedValue, "null cannot be cast to non-null type kotlin.Float");
                    float fM2687a = AbstractC4647c.m2687a(radius, f, ((Float) animatedValue).floatValue());
                    CardView cardView2 = cardView;
                    cardView2.setRadius(fM2687a);
                    ViewGroup.LayoutParams layoutParams2 = cardView2.getLayoutParams();
                    if (layoutParams2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
                    }
                    int i = z ? (int) (((double) layoutParams2.height) * 1.5d) : layoutParams2.height;
                    Object animatedValue2 = valueAnimator3.getAnimatedValue();
                    AbstractC3098.m10101a(animatedValue2, "null cannot be cast to non-null type kotlin.Float");
                    float fFloatValue = ((Float) animatedValue2).floatValue();
                    layoutParams2.width = AbstractC2411.m8929a((fFloatValue * (i - r1)) + measuredWidth);
                    cardView2.setLayoutParams(layoutParams2);
                }
            });
            valueAnimatorOfFloat.setDuration(400L);
            valueAnimatorOfFloat.setInterpolator(AbstractC0257.f12454a);
            valueAnimatorOfFloat.start();
            this.f9330a = valueAnimatorOfFloat;
            return;
        }
        ViewGroup.LayoutParams layoutParams2 = cardView.getLayoutParams();
        if (layoutParams2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
        }
        int i = layoutParams2.height;
        if (z) {
            i = (int) (((double) i) * 1.5d);
        }
        layoutParams2.width = i;
        cardView.setLayoutParams(layoutParams2);
    }

    @Override // defpackage.InterfaceC1207
    public final void onDestroy(InterfaceC3292 interfaceC3292) {
        ValueAnimator valueAnimator = this.f9330a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.f9330a = null;
    }
}
