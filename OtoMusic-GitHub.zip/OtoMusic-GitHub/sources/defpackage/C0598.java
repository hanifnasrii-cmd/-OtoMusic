package defpackage;

import java.util.Arrays;

/* JADX INFO: renamed from: ο߳, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0598 implements Comparable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public boolean f13574a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public float f13578a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public EnumC0597 f13582a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f13575a = -1;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f13576a = -1;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int f13577a = 0;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public boolean f13579a = false;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final float[] f13580a = new float[9];

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final float[] f13581a = new float[9];

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C1455[] f13583a = new C1455[16];

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f13584a = 0;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f13585a = 0;

    public C0598(EnumC0597 enumC0597) {
        this.f13582a = enumC0597;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m6478a(C1455 c1455) {
        int i = 0;
        while (true) {
            int i2 = this.f13584a;
            if (i >= i2) {
                C1455[] c1455Arr = this.f13583a;
                if (i2 >= c1455Arr.length) {
                    this.f13583a = (C1455[]) Arrays.copyOf(c1455Arr, c1455Arr.length * 2);
                }
                C1455[] c1455Arr2 = this.f13583a;
                int i3 = this.f13584a;
                c1455Arr2[i3] = c1455;
                this.f13584a = i3 + 1;
                return;
            }
            if (this.f13583a[i] == c1455) {
                return;
            } else {
                i++;
            }
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m6479a(C1455 c1455) {
        int i = this.f13584a;
        int i2 = 0;
        while (i2 < i) {
            if (this.f13583a[i2] == c1455) {
                while (i2 < i - 1) {
                    C1455[] c1455Arr = this.f13583a;
                    int i3 = i2 + 1;
                    c1455Arr[i2] = c1455Arr[i3];
                    i2 = i3;
                }
                this.f13584a--;
                return;
            }
            i2++;
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m6480a() {
        this.f13582a = EnumC0597.UNKNOWN;
        this.f13577a = 0;
        this.f13575a = -1;
        this.f13576a = -1;
        this.f13578a = 0.0f;
        this.f13579a = false;
        int i = this.f13584a;
        for (int i2 = 0; i2 < i; i2++) {
            this.f13583a[i2] = null;
        }
        this.f13584a = 0;
        this.f13585a = 0;
        this.f13574a = false;
        Arrays.fill(this.f13581a, 0.0f);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m6481a(C0017 c0017, float f) {
        this.f13578a = f;
        this.f13579a = true;
        int i = this.f13584a;
        this.f13576a = -1;
        for (int i2 = 0; i2 < i; i2++) {
            this.f13583a[i2].m7692a(c0017, this, false);
        }
        this.f13584a = 0;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final void m6482a(C0017 c0017, C1455 c1455) {
        int i = this.f13584a;
        for (int i2 = 0; i2 < i; i2++) {
            this.f13583a[i2].mo4827a(c0017, c1455, false);
        }
        this.f13584a = 0;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.f13575a - ((C0598) obj).f13575a;
    }

    public final String toString() {
        return "" + this.f13575a;
    }
}
