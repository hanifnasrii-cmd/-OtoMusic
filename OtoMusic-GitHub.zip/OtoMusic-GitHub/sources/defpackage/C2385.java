package defpackage;

import android.graphics.Rect;
import android.view.WindowInsets;
import java.util.List;

/* JADX INFO: renamed from: р̈́, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2385 extends C2384 {
    public C2385(C2390 c2390, WindowInsets windowInsets) {
        super(c2390, windowInsets);
    }

    @Override // defpackage.AbstractC2378, defpackage.C2386
    /* JADX INFO: renamed from: ā */
    public List<Rect> mo8830a(int i) {
        return this.f19225a.getBoundingRects(AbstractC2389.m8861a(i));
    }

    @Override // defpackage.AbstractC2378, defpackage.C2386
    /* JADX INFO: renamed from: a̅ */
    public List<Rect> mo8831a(int i) {
        return this.f19225a.getBoundingRectsIgnoringVisibility(AbstractC2389.m8861a(i));
    }

    @Override // defpackage.AbstractC2378, defpackage.C2386
    /* JADX INFO: renamed from: a̎ */
    public void mo8835a() {
    }
}
