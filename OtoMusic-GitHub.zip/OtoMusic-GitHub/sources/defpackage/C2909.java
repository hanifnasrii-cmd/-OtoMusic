package defpackage;

/* JADX INFO: renamed from: с߭, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2909 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC4453c f20932a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C2908 f20933a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C0869 f20934a;

    public C2909(AbstractC4453c abstractC4453c, C2908 c2908, C0869 c0869) {
        this.f20932a = abstractC4453c;
        this.f20933a = c2908;
        this.f20934a = c0869;
    }
}
