package defpackage;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;
import java.util.Iterator;

/* JADX INFO: renamed from: ι⳱, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class RunnableC0297 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C5141i f12623a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f12624a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ String f12625a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ int f12626a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ C3097 f12627a;

    public RunnableC0297(int i, int i2, C5141i c5141i, C3097 c3097, Bundle bundle, String str) {
        this.f12627a = c3097;
        this.f12623a = c5141i;
        this.f12624a = i;
        this.f12625a = str;
        this.f12626a = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0287 c0287;
        C5141i c5141i = this.f12623a;
        IBinder binder = ((Messenger) c5141i.f7193a).getBinder();
        C3097 c3097 = this.f12627a;
        ((AbstractServiceC0299) c3097.f21718a).f12634a.remove(binder);
        AbstractServiceC0299 abstractServiceC0299 = (AbstractServiceC0299) c3097.f21718a;
        Iterator it = abstractServiceC0299.f12633a.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            C0287 c02872 = (C0287) it.next();
            if (c02872.f12588a == this.f12624a) {
                c0287 = (TextUtils.isEmpty(this.f12625a) || this.f12626a <= 0) ? new C0287(abstractServiceC0299, c02872.f12586a, c02872.f12587a, c02872.f12588a, c5141i) : null;
                it.remove();
            }
        }
        if (c0287 == null) {
            c0287 = new C0287(abstractServiceC0299, this.f12625a, this.f12626a, this.f12624a, c5141i);
        }
        abstractServiceC0299.f12634a.put(binder, c0287);
        try {
            binder.linkToDeath(c0287, 0);
        } catch (RemoteException unused) {
        }
    }
}
