package defpackage;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: ј⃥, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3593 extends AbstractC0493 {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C3593(Class cls, long j) {
        super(cls);
        TimeUnit timeUnit = TimeUnit.DAYS;
        AbstractC3098.m10103a(timeUnit, "repeatIntervalTimeUnit");
        C2422 c2422 = (C2422) this.f13297a;
        long millis = timeUnit.toMillis(j);
        c2422.getClass();
        if (millis < 900000) {
            C0110.m5883a().getClass();
        }
        long j2 = millis < 900000 ? 900000L : millis;
        long j3 = millis < 900000 ? 900000L : millis;
        if (j2 < 900000) {
            C0110.m5883a().getClass();
        }
        c2422.f19354a = j2 >= 900000 ? j2 : 900000L;
        if (j3 < 300000) {
            C0110.m5883a().getClass();
        }
        if (j3 > c2422.f19354a) {
            C0110.m5883a().getClass();
        }
        c2422.f19355a = AbstractC6161p.m5207a(j3, 300000L, c2422.f19354a);
    }

    @Override // defpackage.AbstractC0493
    /* JADX INFO: renamed from: â */
    public final AbstractC2419 mo6366a() {
        C2422 c2422 = (C2422) this.f13297a;
        if (c2422.f19363a) {
            throw new IllegalArgumentException("PeriodicWorkRequests cannot be expedited");
        }
        return new C3594((UUID) this.f13296a, c2422, (Set) this.f13298a);
    }
}
