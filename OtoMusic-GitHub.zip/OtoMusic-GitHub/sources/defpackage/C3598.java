package defpackage;

import java.util.Map;

/* JADX INFO: renamed from: ј⃪, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3598 extends AbstractC4052a {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final C3598 f23101a = new C3598(C6137p.f10699a, 0);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C6137p f23102a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f23103a;

    public C3598(C6137p c6137p, int i) {
        AbstractC3098.m10103a(c6137p, "node");
        this.f23102a = c6137p;
        this.f23103a = i;
    }

    @Override // java.util.Map
    public final boolean containsKey(Object obj) {
        return this.f23102a.m5156a(obj != null ? obj.hashCode() : 0, 0, obj);
    }

    @Override // defpackage.AbstractC4052a, java.util.Map
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Map)) {
            return false;
        }
        Map map = (Map) obj;
        if (this.f23103a != map.size()) {
            return false;
        }
        boolean z = map instanceof C3598;
        C6137p c6137p = this.f23102a;
        return z ? c6137p.m5159a(((C3598) obj).f23102a, C3597.f23092a) : map instanceof C3600 ? c6137p.m5159a(((C3600) obj).f23109a, C3597.f23093a) : super.equals(obj);
    }

    @Override // java.util.Map
    public final Object get(Object obj) {
        return this.f23102a.m5160a(obj != null ? obj.hashCode() : 0, 0, obj);
    }
}
