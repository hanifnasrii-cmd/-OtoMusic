package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

/* JADX INFO: renamed from: с݉, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C2894 {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f20885a = AtomicIntegerFieldUpdater.newUpdater(C2894.class, "_handled$volatile");
    private volatile /* synthetic */ int _handled$volatile;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Throwable f20886a;

    public C2894(Throwable th, boolean z) {
        this.f20886a = th;
        this._handled$volatile = z ? 1 : 0;
    }

    public final String toString() {
        return getClass().getSimpleName() + '[' + this.f20886a + ']';
    }
}
