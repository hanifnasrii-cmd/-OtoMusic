package defpackage;

import android.os.IInterface;
import android.os.RemoteCallbackList;
import androidx.room.MultiInstanceInvalidationService;

/* JADX INFO: renamed from: jܴ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class RemoteCallbackListC5576j extends RemoteCallbackList {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ MultiInstanceInvalidationService f8840a;

    public RemoteCallbackListC5576j(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f8840a = multiInstanceInvalidationService;
    }

    @Override // android.os.RemoteCallbackList
    public final void onCallbackDied(IInterface iInterface, Object obj) {
        AbstractC3098.m10103a((InterfaceC3014) iInterface, "callback");
        AbstractC3098.m10103a(obj, "cookie");
        this.f8840a.f854a.remove((Integer) obj);
    }
}
