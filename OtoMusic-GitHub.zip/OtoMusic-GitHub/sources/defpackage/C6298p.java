package defpackage;

import android.view.View;
import com.piyush.music.widget.viewpager2.ViewPager2;

/* JADX INFO: renamed from: p⃩, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C6298p implements InterfaceC4107a {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f11193a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C3877 f11194a;

    public /* synthetic */ C6298p(C3877 c3877, int i) {
        this.f11193a = i;
        this.f11194a = c3877;
    }

    @Override // defpackage.InterfaceC4107a
    /* JADX INFO: renamed from: ã */
    public final boolean mo869a(View view) {
        switch (this.f11193a) {
            case 0:
                int currentItem = ((ViewPager2) view).getCurrentItem() + 1;
                ViewPager2 viewPager2 = (ViewPager2) this.f11194a.f23924a;
                if (viewPager2.f4463a) {
                    viewPager2.m2017a(currentItem, true);
                }
                break;
            default:
                int currentItem2 = ((ViewPager2) view).getCurrentItem() - 1;
                ViewPager2 viewPager22 = (ViewPager2) this.f11194a.f23924a;
                if (viewPager22.f4463a) {
                    viewPager22.m2017a(currentItem2, true);
                }
                break;
        }
        return true;
    }
}
