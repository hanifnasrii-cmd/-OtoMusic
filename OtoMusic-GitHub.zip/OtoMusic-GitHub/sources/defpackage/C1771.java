package defpackage;

/* JADX INFO: renamed from: е҇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1771 extends AbstractC1773 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float f17051a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float f17052a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final float f17053a;

    public C1771(float f, float f2, float f3) {
        this.f17051a = f;
        this.f17052a = f2;
        this.f17053a = f3;
    }

    @Override // defpackage.AbstractC1773
    /* JADX INFO: renamed from: à */
    public final float mo8160a() {
        return this.f17051a;
    }

    @Override // defpackage.AbstractC1773
    /* JADX INFO: renamed from: á */
    public final float mo8161a() {
        return this.f17052a;
    }
}
