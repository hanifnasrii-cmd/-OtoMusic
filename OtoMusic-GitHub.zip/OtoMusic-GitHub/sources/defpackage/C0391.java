package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: renamed from: ο̼, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C0391 {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f12885a = AtomicReferenceFieldUpdater.newUpdater(C0391.class, Object.class, "head$volatile");

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final /* synthetic */ AtomicLongFieldUpdater f12886a = AtomicLongFieldUpdater.newUpdater(C0391.class, "deqIdx$volatile");

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f12887a = AtomicReferenceFieldUpdater.newUpdater(C0391.class, Object.class, "tail$volatile");

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final /* synthetic */ AtomicLongFieldUpdater f12888a = AtomicLongFieldUpdater.newUpdater(C0391.class, "enqIdx$volatile");

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f12889a = AtomicIntegerFieldUpdater.newUpdater(C0391.class, "_availablePermits$volatile");
    private volatile /* synthetic */ int _availablePermits$volatile;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f12890a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C2664 f12891a;
    private volatile /* synthetic */ long deqIdx$volatile;
    private volatile /* synthetic */ long enqIdx$volatile;
    private volatile /* synthetic */ Object head$volatile;
    private volatile /* synthetic */ Object tail$volatile;

    public C0391(int i) {
        this.f12890a = i;
        if (i <= 0) {
            throw new IllegalArgumentException(AbstractC4072a.m739a(i, "Semaphore should have at least 1 permit, but had ").toString());
        }
        if (i < 0) {
            throw new IllegalArgumentException(AbstractC4072a.m739a(i, "The number of acquired permits should be in 0..").toString());
        }
        C0394 c0394 = new C0394(0L, null, 2);
        this.head$volatile = c0394;
        this.tail$volatile = c0394;
        this._availablePermits$volatile = i;
        this.f12891a = new C2664(2, this);
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0025, code lost:
    
        r5.mo4477a(r3, r4.f12891a);
     */
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object m6247a(defpackage.AbstractC1006 r5) {
        /*
            r4 = this;
        L0:
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = defpackage.C0391.f12889a
            int r1 = r0.getAndDecrement(r4)
            int r2 = r4.f12890a
            if (r1 > r2) goto L0
            pׁ r3 = defpackage.C6174p.f10843a
            if (r1 <= 0) goto Lf
            goto L3e
        Lf:
            ϲ̌ r5 = defpackage.AbstractC5120i.m3446a(r5)
            с̑ r5 = defpackage.AbstractC5121i.m3497a(r5)
            boolean r1 = r4.m6248a(r5)     // Catch: java.lang.Throwable -> L3f
            if (r1 != 0) goto L31
        L1d:
            int r1 = r0.getAndDecrement(r4)     // Catch: java.lang.Throwable -> L3f
            if (r1 > r2) goto L1d
            if (r1 <= 0) goto L2b
            с̐ r0 = r4.f12891a     // Catch: java.lang.Throwable -> L3f
            r5.mo4477a(r3, r0)     // Catch: java.lang.Throwable -> L3f
            goto L31
        L2b:
            boolean r1 = r4.m6248a(r5)     // Catch: java.lang.Throwable -> L3f
            if (r1 == 0) goto L1d
        L31:
            java.lang.Object r5 = r5.m9363a()
            ϲ̴ r0 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            if (r5 != r0) goto L3a
            goto L3b
        L3a:
            r5 = r3
        L3b:
            if (r5 != r0) goto L3e
            return r5
        L3e:
            return r3
        L3f:
            r0 = move-exception
            r5.m9370a()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C0391.m6247a(ϲ̍):java.lang.Object");
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final boolean m6248a(InterfaceC2333 interfaceC2333) {
        Object objM5210a;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f12887a;
        C0394 c0394 = (C0394) atomicReferenceFieldUpdater.get(this);
        long andIncrement = f12888a.getAndIncrement(this);
        C0389 c0389 = C0389.f12883a;
        long j = andIncrement / ((long) AbstractC0393.f12897a);
        loop0: while (true) {
            objM5210a = AbstractC6161p.m5210a(c0394, j, c0389);
            if (!AbstractC2582.m9241a(objM5210a)) {
                AbstractC0361 abstractC0361M9240a = AbstractC2582.m9240a(objM5210a);
                while (true) {
                    AbstractC0361 abstractC0361 = (AbstractC0361) atomicReferenceFieldUpdater.get(this);
                    if (abstractC0361.f12816a >= abstractC0361M9240a.f12816a) {
                        break loop0;
                    }
                    if (!abstractC0361M9240a.m6224a()) {
                        break;
                    }
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, abstractC0361, abstractC0361M9240a)) {
                        if (atomicReferenceFieldUpdater.get(this) != abstractC0361) {
                            if (abstractC0361M9240a.m6220a()) {
                                abstractC0361M9240a.m9798a();
                            }
                        }
                    }
                    if (abstractC0361.m6220a()) {
                        abstractC0361.m9798a();
                    }
                }
            } else {
                break;
            }
        }
        C0394 c03942 = (C0394) AbstractC2582.m9240a(objM5210a);
        AtomicReferenceArray atomicReferenceArray = c03942.f12898a;
        int i = (int) (andIncrement % ((long) AbstractC0393.f12897a));
        while (!atomicReferenceArray.compareAndSet(i, null, interfaceC2333)) {
            if (atomicReferenceArray.get(i) != null) {
                C5948o c5948o = AbstractC0393.f12893a;
                C5948o c5948o2 = AbstractC0393.f12894a;
                while (!atomicReferenceArray.compareAndSet(i, c5948o, c5948o2)) {
                    if (atomicReferenceArray.get(i) != c5948o) {
                        return false;
                    }
                }
                ((InterfaceC2663) interfaceC2333).mo4477a(C6174p.f10843a, this.f12891a);
                return true;
            }
        }
        interfaceC2333.mo2618a(c03942, i);
        return true;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m6249a() {
        int i;
        Object objM5210a;
        boolean z;
        do {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f12889a;
            int andIncrement = atomicIntegerFieldUpdater.getAndIncrement(this);
            int i2 = this.f12890a;
            if (andIncrement >= i2) {
                do {
                    i = atomicIntegerFieldUpdater.get(this);
                    if (i <= i2) {
                        break;
                    }
                } while (!atomicIntegerFieldUpdater.compareAndSet(this, i, i2));
                throw new IllegalStateException(("The number of released permits cannot be greater than " + i2).toString());
            }
            if (andIncrement >= 0) {
                return;
            }
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f12885a;
            C0394 c0394 = (C0394) atomicReferenceFieldUpdater.get(this);
            long andIncrement2 = f12886a.getAndIncrement(this);
            long j = andIncrement2 / ((long) AbstractC0393.f12897a);
            C0390 c0390 = C0390.f12884a;
            while (true) {
                objM5210a = AbstractC6161p.m5210a(c0394, j, c0390);
                if (AbstractC2582.m9241a(objM5210a)) {
                    break;
                }
                AbstractC0361 abstractC0361M9240a = AbstractC2582.m9240a(objM5210a);
                while (true) {
                    AbstractC0361 abstractC0361 = (AbstractC0361) atomicReferenceFieldUpdater.get(this);
                    if (abstractC0361.f12816a >= abstractC0361M9240a.f12816a) {
                        break;
                    }
                    if (!abstractC0361M9240a.m6224a()) {
                        break;
                    }
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, abstractC0361, abstractC0361M9240a)) {
                        if (atomicReferenceFieldUpdater.get(this) != abstractC0361) {
                            if (abstractC0361M9240a.m6220a()) {
                                abstractC0361M9240a.m9798a();
                            }
                        }
                    }
                    if (abstractC0361.m6220a()) {
                        abstractC0361.m9798a();
                    }
                }
            }
            C0394 c03942 = (C0394) AbstractC2582.m9240a(objM5210a);
            AtomicReferenceArray atomicReferenceArray = c03942.f12898a;
            c03942.m9796a();
            z = false;
            if (c03942.f12816a <= j) {
                int i3 = (int) (andIncrement2 % ((long) AbstractC0393.f12897a));
                Object andSet = atomicReferenceArray.getAndSet(i3, AbstractC0393.f12893a);
                if (andSet == null) {
                    int i4 = AbstractC0393.f12892a;
                    for (int i5 = 0; i5 < i4; i5++) {
                        if (atomicReferenceArray.get(i3) == AbstractC0393.f12894a) {
                            z = true;
                            break;
                        }
                    }
                    C5948o c5948o = AbstractC0393.f12893a;
                    C5948o c5948o2 = AbstractC0393.f12895a;
                    while (true) {
                        if (!atomicReferenceArray.compareAndSet(i3, c5948o, c5948o2)) {
                            if (atomicReferenceArray.get(i3) != c5948o) {
                                break;
                            }
                        } else {
                            z = true;
                            break;
                        }
                    }
                    z = !z;
                } else if (andSet != AbstractC0393.f12896a) {
                    boolean z2 = andSet instanceof InterfaceC2663;
                    C6174p c6174p = C6174p.f10843a;
                    if (!z2) {
                        if (!(andSet instanceof InterfaceC0380)) {
                            throw new IllegalStateException(("unexpected: " + andSet).toString());
                        }
                        if (((C0379) ((InterfaceC0380) andSet)).m6238a(this, c6174p) == 0) {
                            z = true;
                            break;
                            break;
                        }
                    } else {
                        InterfaceC2663 interfaceC2663 = (InterfaceC2663) andSet;
                        C5948o c5948oMo4478a = interfaceC2663.mo4478a(c6174p, this.f12891a);
                        if (c5948oMo4478a != null) {
                            interfaceC2663.mo4479a(c5948oMo4478a);
                            z = true;
                            break;
                            break;
                        }
                    }
                }
            }
        } while (!z);
    }
}
