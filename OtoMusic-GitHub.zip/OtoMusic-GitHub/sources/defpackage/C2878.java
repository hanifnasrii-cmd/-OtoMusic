package defpackage;

/* JADX INFO: renamed from: сܹ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2878 extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public InterfaceC2742 f20848a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public byte[] f20849a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f20850a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int f20851a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f20852a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public /* synthetic */ Object f20853a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC1814[] f20854a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5038i f20855a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final /* synthetic */ AbstractC3855 f20856a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC1816 f20857a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C2878(InterfaceC1005 interfaceC1005, InterfaceC1816 interfaceC1816, InterfaceC5038i interfaceC5038i, InterfaceC5056i interfaceC5056i, InterfaceC1814[] interfaceC1814Arr) {
        super(2, interfaceC1005);
        this.f20854a = interfaceC1814Arr;
        this.f20855a = interfaceC5038i;
        this.f20856a = (AbstractC3855) interfaceC5056i;
        this.f20857a = interfaceC1816;
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [ị, օۧ] */
    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        C2878 c2878 = new C2878(interfaceC1005, this.f20857a, this.f20855a, this.f20856a, this.f20854a);
        c2878.f20853a = obj;
        return c2878;
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        return ((C2878) create((InterfaceC1044) obj, (InterfaceC1005) obj2)).invokeSuspend(C6174p.f10843a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:41:0x00dc, code lost:
    
        if (r9 != 0) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00de, code lost:
    
        r13 = (java.lang.Object[]) r19.f20855a.invoke();
        r14 = r19.f20857a;
        r15 = r19.f20856a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        if (r13 != null) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ec, code lost:
    
        r19.f20853a = r10;
        r19.f20848a = r11;
        r19.f20849a = r3;
        r19.f20850a = r9;
        r19.f20851a = r12;
        r19.f20852a = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00fc, code lost:
    
        if (r15.mo2172a(r14, r10, r19) != r2) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00ff, code lost:
    
        defpackage.AbstractC1458.m7700a(0, 0, 14, r10, r13);
        r19.f20853a = r10;
        r19.f20848a = r11;
        r19.f20849a = r3;
        r19.f20850a = r9;
        r19.f20851a = r12;
        r19.f20852a = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0114, code lost:
    
        if (r15.mo2172a(r14, r13, r19) != r2) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0099, code lost:
    
        if (r9 != 0) goto L19;
     */
    /* JADX WARN: Path cross not found for [B:41:0x00dc, B:35:0x00cb], limit reached: 50 */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00bb A[LOOP:0: B:30:0x00bb->B:53:?, LOOP_START, PHI: r9 r13
      0x00bb: PHI (r9v3 int) = (r9v2 int), (r9v4 int) binds: [B:27:0x00b6, B:53:?] A[DONT_GENERATE, DONT_INLINE]
      0x00bb: PHI (r13v4 і͖) = (r13v3 і͖), (r13v10 і͖) binds: [B:27:0x00b6, B:53:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r15v2, types: [ị, օۧ] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$ArrayArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:45:0x00fc -> B:19:0x0099). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0114 -> B:50:0x0117). Please report as a decompilation issue!!! */
    @Override // defpackage.AbstractC4415c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r20) {
        /*
            Method dump skipped, instruction units count: 281
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C2878.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
