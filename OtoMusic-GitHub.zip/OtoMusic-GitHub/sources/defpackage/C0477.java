package defpackage;

import java.util.Arrays;

/* JADX INFO: renamed from: ο֮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C0477 extends AbstractC4082a implements InterfaceC5635j, InterfaceC1814, InterfaceC5072i {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int f13129a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final int f13130a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final EnumC4631c f13131a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public Object[] f13132a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public long f13133a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public long f13134a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f13135a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f13136a;

    public C0477(int i, int i2, EnumC4631c enumC4631c) {
        this.f13129a = i;
        this.f13130a = i2;
        this.f13131a = enumC4631c;
    }

    /* JADX WARN: Code restructure failed: missing block: B:37:0x0092, code lost:
    
        if (r8 == null) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0098, code lost:
    
        if (r8.mo10193a() != false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009f, code lost:
    
        throw r8.mo10196a();
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00a0, code lost:
    
        r0.f13122a = r5;
        r0.f13123a = r2;
        r0.f13124a = r9;
        r0.f13125a = r8;
        r0.f13128a = 3;
        r10 = r2.mo674a(r10, r0);
        r2 = r2;
        r5 = r5;
        r9 = r9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ae, code lost:
    
        if (r10 != r1) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0081 A[Catch: all -> 0x0038, TryCatch #1 {all -> 0x0038, blocks: (B:15:0x0031, B:32:0x0079, B:34:0x0081, B:38:0x0094, B:41:0x009b, B:42:0x009f, B:43:0x00a0, B:22:0x004b), top: B:52:0x0020 }] */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0092 A[EDGE_INSN: B:56:0x0092->B:37:0x0092 BREAK  A[LOOP:0: B:32:0x0079->B:59:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r10v10 */
    /* JADX WARN: Type inference failed for: r10v11 */
    /* JADX WARN: Type inference failed for: r10v12 */
    /* JADX WARN: Type inference failed for: r10v13 */
    /* JADX WARN: Type inference failed for: r10v4 */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v4, types: [еֽ] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r5v1, types: [a͉] */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v4, types: [ο֮] */
    /* JADX WARN: Type inference failed for: r5v5 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r8v10 */
    /* JADX WARN: Type inference failed for: r8v18 */
    /* JADX WARN: Type inference failed for: r8v7 */
    /* JADX WARN: Type inference failed for: r9v0, types: [еֽ] */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v12 */
    /* JADX WARN: Type inference failed for: r9v13 */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v17 */
    /* JADX WARN: Type inference failed for: r9v18 */
    /* JADX WARN: Type inference failed for: r9v2, types: [a͊] */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5, types: [ο֯] */
    /* JADX WARN: Type inference failed for: r9v6 */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8, types: [ο֯] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:44:0x00ae -> B:16:0x0034). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static defpackage.EnumC1045 m6310a(defpackage.C0477 r8, defpackage.InterfaceC1816 r9, defpackage.InterfaceC1005 r10) throws java.lang.Throwable {
        /*
            boolean r0 = r10 instanceof defpackage.C0476
            if (r0 == 0) goto L13
            r0 = r10
            ο֭ r0 = (defpackage.C0476) r0
            int r1 = r0.f13128a
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f13128a = r1
            goto L18
        L13:
            ο֭ r0 = new ο֭
            r0.<init>(r8, r10)
        L18:
            java.lang.Object r10 = r0.f13126a
            ϲ̴ r1 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r2 = r0.f13128a
            r3 = 3
            r4 = 2
            if (r2 == 0) goto L5e
            r8 = 1
            if (r2 == r8) goto L4f
            if (r2 == r4) goto L43
            if (r2 != r3) goto L3b
            іؑ r8 = r0.f13125a
            ο֯ r9 = r0.f13124a
            еֽ r2 = r0.f13123a
            ο֮ r5 = r0.f13122a
            defpackage.AbstractC1149.m7200a(r10)     // Catch: java.lang.Throwable -> L38
        L34:
            r10 = r2
            r2 = r8
            r8 = r5
            goto L76
        L38:
            r8 = move-exception
            goto Lb4
        L3b:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L43:
            іؑ r8 = r0.f13125a
            ο֯ r9 = r0.f13124a
            еֽ r2 = r0.f13123a
            ο֮ r5 = r0.f13122a
            defpackage.AbstractC1149.m7200a(r10)     // Catch: java.lang.Throwable -> L38
            goto L79
        L4f:
            ο֯ r9 = r0.f13124a
            еֽ r8 = r0.f13123a
            ο֮ r2 = r0.f13122a
            defpackage.AbstractC1149.m7200a(r10)     // Catch: java.lang.Throwable -> L5b
            r10 = r8
            r8 = r2
            goto L6a
        L5b:
            r8 = move-exception
            r5 = r2
            goto Lb4
        L5e:
            defpackage.AbstractC1149.m7200a(r10)
            a͊ r10 = r8.m772a()
            ο֯ r10 = (defpackage.C0478) r10
            r7 = r10
            r10 = r9
            r9 = r7
        L6a:
            ϲ̦ r2 = r0.getContext()     // Catch: java.lang.Throwable -> Lb1
            i֬ r5 = defpackage.C5165i.f7306a     // Catch: java.lang.Throwable -> Lb1
            ϲ̤ r2 = r2.get(r5)     // Catch: java.lang.Throwable -> Lb1
            іؑ r2 = (defpackage.InterfaceC3148) r2     // Catch: java.lang.Throwable -> Lb1
        L76:
            r5 = r8
            r8 = r2
            r2 = r10
        L79:
            java.lang.Object r10 = r5.m6320a(r9)     // Catch: java.lang.Throwable -> L38
            o߳ r6 = defpackage.AbstractC1149.f14852a     // Catch: java.lang.Throwable -> L38
            if (r10 != r6) goto L92
            r0.f13122a = r5     // Catch: java.lang.Throwable -> L38
            r0.f13123a = r2     // Catch: java.lang.Throwable -> L38
            r0.f13124a = r9     // Catch: java.lang.Throwable -> L38
            r0.f13125a = r8     // Catch: java.lang.Throwable -> L38
            r0.f13128a = r4     // Catch: java.lang.Throwable -> L38
            java.lang.Object r10 = r5.m6311a(r9, r0)     // Catch: java.lang.Throwable -> L38
            if (r10 != r1) goto L79
            goto Lb0
        L92:
            if (r8 == 0) goto La0
            boolean r6 = r8.mo10193a()     // Catch: java.lang.Throwable -> L38
            if (r6 == 0) goto L9b
            goto La0
        L9b:
            java.util.concurrent.CancellationException r8 = r8.mo10196a()     // Catch: java.lang.Throwable -> L38
            throw r8     // Catch: java.lang.Throwable -> L38
        La0:
            r0.f13122a = r5     // Catch: java.lang.Throwable -> L38
            r0.f13123a = r2     // Catch: java.lang.Throwable -> L38
            r0.f13124a = r9     // Catch: java.lang.Throwable -> L38
            r0.f13125a = r8     // Catch: java.lang.Throwable -> L38
            r0.f13128a = r3     // Catch: java.lang.Throwable -> L38
            java.lang.Object r10 = r2.mo674a(r10, r0)     // Catch: java.lang.Throwable -> L38
            if (r10 != r1) goto L34
        Lb0:
            return r1
        Lb1:
            r10 = move-exception
            r5 = r8
            r8 = r10
        Lb4:
            r5.m775a(r9)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C0477.m6310a(ο֮, еֽ, ϲ̌):ϲ̴");
    }

    @Override // defpackage.InterfaceC1814
    /* JADX INFO: renamed from: à */
    public final Object mo2389a(InterfaceC1816 interfaceC1816, InterfaceC1005 interfaceC1005) {
        return m6310a(this, interfaceC1816, interfaceC1005);
    }

    @Override // defpackage.InterfaceC5072i
    /* JADX INFO: renamed from: á */
    public final InterfaceC1814 mo3380a(InterfaceC1031 interfaceC1031, int i, EnumC4631c enumC4631c) {
        return AbstractC1149.m7178a(this, interfaceC1031, i, enumC4631c);
    }

    @Override // defpackage.AbstractC4082a
    /* JADX INFO: renamed from: ã */
    public final AbstractC4083a mo773a() {
        C0478 c0478 = new C0478();
        c0478.f13137a = -1L;
        return c0478;
    }

    @Override // defpackage.InterfaceC5635j
    /* JADX INFO: renamed from: ā */
    public final void mo4473a() throws Throwable {
        synchronized (this) {
            try {
                try {
                    m6321a(m6316a() + ((long) this.f13135a), this.f13134a, m6316a() + ((long) this.f13135a), m6316a() + ((long) this.f13135a) + ((long) this.f13136a));
                } catch (Throwable th) {
                    th = th;
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }

    @Override // defpackage.InterfaceC1816
    /* JADX INFO: renamed from: a̅ */
    public final Object mo674a(Object obj, InterfaceC1005 interfaceC1005) throws Throwable {
        Throwable th;
        InterfaceC1005[] interfaceC1005ArrM6315a;
        C0474 c0474;
        if (mo4474a(obj)) {
            return C6174p.f10843a;
        }
        C2665 c2665 = new C2665(1, AbstractC5120i.m3446a(interfaceC1005));
        c2665.m9364a();
        InterfaceC1005[] interfaceC1005ArrM6315a2 = AbstractC1149.f14848a;
        synchronized (this) {
            try {
                if (m6318a(obj)) {
                    try {
                        c2665.resumeWith(C6174p.f10843a);
                        interfaceC1005ArrM6315a = m6315a(interfaceC1005ArrM6315a2);
                        c0474 = null;
                    } catch (Throwable th2) {
                        th = th2;
                        throw th;
                    }
                } else {
                    try {
                        C0474 c04742 = new C0474(this, m6316a() + ((long) (this.f13135a + this.f13136a)), obj, c2665);
                        m6314a(c04742);
                        this.f13136a++;
                        if (this.f13130a == 0) {
                            interfaceC1005ArrM6315a2 = m6315a(interfaceC1005ArrM6315a2);
                        }
                        interfaceC1005ArrM6315a = interfaceC1005ArrM6315a2;
                        c0474 = c04742;
                    } catch (Throwable th3) {
                        th = th3;
                        th = th;
                        throw th;
                    }
                }
                if (c0474 != null) {
                    c2665.m9367a(new C2652(1, c0474));
                }
                for (InterfaceC1005 interfaceC10052 : interfaceC1005ArrM6315a) {
                    if (interfaceC10052 != null) {
                        interfaceC10052.resumeWith(C6174p.f10843a);
                    }
                }
                Object objM9363a = c2665.m9363a();
                EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                if (objM9363a != enumC1045) {
                    objM9363a = C6174p.f10843a;
                }
                return objM9363a == enumC1045 ? objM9363a : C6174p.f10843a;
            } catch (Throwable th4) {
                th = th4;
            }
        }
    }

    @Override // defpackage.InterfaceC5635j
    /* JADX INFO: renamed from: ă */
    public final boolean mo4474a(Object obj) {
        int i;
        boolean z;
        InterfaceC1005[] interfaceC1005ArrM6315a = AbstractC1149.f14848a;
        synchronized (this) {
            if (m6318a(obj)) {
                interfaceC1005ArrM6315a = m6315a(interfaceC1005ArrM6315a);
                z = true;
            } else {
                z = false;
            }
        }
        for (InterfaceC1005 interfaceC1005 : interfaceC1005ArrM6315a) {
            if (interfaceC1005 != null) {
                interfaceC1005.resumeWith(C6174p.f10843a);
            }
        }
        return z;
    }

    @Override // defpackage.AbstractC4082a
    /* JADX INFO: renamed from: ȧ */
    public final AbstractC4083a[] mo774a() {
        return new C0478[2];
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final Object m6311a(C0478 c0478, C0476 c0476) {
        C2665 c2665 = new C2665(1, AbstractC5120i.m3446a(c0476));
        c2665.m9364a();
        synchronized (this) {
            try {
                if (m6319a(c0478) < 0) {
                    c0478.f13138a = c2665;
                } else {
                    c2665.resumeWith(C6174p.f10843a);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        Object objM9363a = c2665.m9363a();
        return objM9363a == EnumC1045.COROUTINE_SUSPENDED ? objM9363a : C6174p.f10843a;
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m6312a() {
        if (this.f13130a != 0 || this.f13136a > 1) {
            Object[] objArr = this.f13132a;
            AbstractC3098.m10100a(objArr);
            while (this.f13136a > 0) {
                long jM6316a = m6316a();
                int i = this.f13135a;
                int i2 = this.f13136a;
                if (objArr[((int) ((jM6316a + ((long) (i + i2))) - 1)) & (objArr.length - 1)] != AbstractC1149.f14852a) {
                    return;
                }
                this.f13136a = i2 - 1;
                AbstractC1149.m7157a(objArr, m6316a() + ((long) (this.f13135a + this.f13136a)), null);
            }
        }
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void m6313a() {
        AbstractC4083a[] abstractC4083aArr;
        Object[] objArr = this.f13132a;
        AbstractC3098.m10100a(objArr);
        AbstractC1149.m7157a(objArr, m6316a(), null);
        this.f13135a--;
        long jM6316a = m6316a() + 1;
        if (this.f13133a < jM6316a) {
            this.f13133a = jM6316a;
        }
        if (this.f13134a < jM6316a) {
            if (this.f1068a != 0 && (abstractC4083aArr = this.f1067a) != null) {
                for (AbstractC4083a abstractC4083a : abstractC4083aArr) {
                    if (abstractC4083a != null) {
                        C0478 c0478 = (C0478) abstractC4083a;
                        long j = c0478.f13137a;
                        if (j >= 0 && j < jM6316a) {
                            c0478.f13137a = jM6316a;
                        }
                    }
                }
            }
            this.f13134a = jM6316a;
        }
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final void m6314a(Object obj) {
        int i = this.f13135a + this.f13136a;
        Object[] objArrM6317a = this.f13132a;
        if (objArrM6317a == null) {
            objArrM6317a = m6317a(null, 0, 2);
        } else if (i >= objArrM6317a.length) {
            objArrM6317a = m6317a(objArrM6317a, i, objArrM6317a.length * 2);
        }
        AbstractC1149.m7157a(objArrM6317a, m6316a() + ((long) i), obj);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v0, types: [ϲ̌[]] */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v3, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r11v7 */
    /* JADX WARN: Type inference failed for: r11v8 */
    /* JADX WARN: Type inference failed for: r11v9 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final InterfaceC1005[] m6315a(InterfaceC1005[] interfaceC1005Arr) {
        AbstractC4083a[] abstractC4083aArr;
        C0478 c0478;
        C2665 c2665;
        int length = interfaceC1005Arr.length;
        if (this.f1068a != 0 && (abstractC4083aArr = this.f1067a) != null) {
            int length2 = abstractC4083aArr.length;
            int i = 0;
            interfaceC1005Arr = interfaceC1005Arr;
            while (i < length2) {
                AbstractC4083a abstractC4083a = abstractC4083aArr[i];
                if (abstractC4083a != null && (c2665 = (c0478 = (C0478) abstractC4083a).f13138a) != null && m6319a(c0478) >= 0) {
                    int length3 = interfaceC1005Arr.length;
                    interfaceC1005Arr = interfaceC1005Arr;
                    if (length >= length3) {
                        Object[] objArrCopyOf = Arrays.copyOf((Object[]) interfaceC1005Arr, Math.max(2, interfaceC1005Arr.length * 2));
                        AbstractC3098.m10102a(objArrCopyOf, "copyOf(...)");
                        interfaceC1005Arr = objArrCopyOf;
                    }
                    ((InterfaceC1005[]) interfaceC1005Arr)[length] = c2665;
                    c0478.f13138a = null;
                    length++;
                }
                i++;
                interfaceC1005Arr = interfaceC1005Arr;
            }
        }
        return (InterfaceC1005[]) interfaceC1005Arr;
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final long m6316a() {
        return Math.min(this.f13134a, this.f13133a);
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final Object[] m6317a(Object[] objArr, int i, int i2) {
        if (i2 <= 0) {
            throw new IllegalStateException("Buffer size overflow");
        }
        Object[] objArr2 = new Object[i2];
        this.f13132a = objArr2;
        if (objArr != null) {
            long jM6316a = m6316a();
            for (int i3 = 0; i3 < i; i3++) {
                long j = ((long) i3) + jM6316a;
                AbstractC1149.m7157a(objArr2, j, objArr[((int) j) & (objArr.length - 1)]);
            }
        }
        return objArr2;
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0068  */
    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean m6318a(java.lang.Object r13) {
        /*
            r12 = this;
            int r1 = r12.f1068a
            int r2 = r12.f13129a
            r9 = 1
            if (r1 != 0) goto L23
            if (r2 != 0) goto Lb
            goto L85
        Lb:
            r12.m6314a(r13)
            int r1 = r12.f13135a
            int r1 = r1 + r9
            r12.f13135a = r1
            if (r1 <= r2) goto L18
            r12.m6313a()
        L18:
            long r1 = r12.m6316a()
            int r3 = r12.f13135a
            long r3 = (long) r3
            long r1 = r1 + r3
            r12.f13134a = r1
            return r9
        L23:
            int r1 = r12.f13135a
            int r3 = r12.f13130a
            if (r1 < r3) goto L4d
            long r4 = r12.f13134a
            long r6 = r12.f13133a
            int r1 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r1 > 0) goto L4d
            int[] r1 = defpackage.AbstractC0475.f13121a
            c⃑ r4 = r12.f13131a
            int r4 = r4.ordinal()
            r1 = r1[r4]
            if (r1 == r9) goto L4b
            r4 = 2
            if (r1 == r4) goto L85
            r4 = 3
            if (r1 != r4) goto L44
            goto L4d
        L44:
            с݊ r1 = new с݊
            r2 = 0
            r1.<init>(r2)
            throw r1
        L4b:
            r1 = 0
            return r1
        L4d:
            r12.m6314a(r13)
            int r1 = r12.f13135a
            int r1 = r1 + r9
            r12.f13135a = r1
            if (r1 <= r3) goto L5a
            r12.m6313a()
        L5a:
            long r3 = r12.m6316a()
            int r1 = r12.f13135a
            long r5 = (long) r1
            long r3 = r3 + r5
            long r5 = r12.f13133a
            long r3 = r3 - r5
            int r1 = (int) r3
            if (r1 <= r2) goto L85
            r1 = 1
            long r1 = r1 + r5
            long r3 = r12.f13134a
            long r5 = r12.m6316a()
            int r7 = r12.f13135a
            long r7 = (long) r7
            long r5 = r5 + r7
            long r7 = r12.m6316a()
            int r10 = r12.f13135a
            long r10 = (long) r10
            long r7 = r7 + r10
            int r10 = r12.f13136a
            long r10 = (long) r10
            long r7 = r7 + r10
            r0 = r12
            r0.m6321a(r1, r3, r5, r7)
        L85:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C0477.m6318a(java.lang.Object):boolean");
    }

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final long m6319a(C0478 c0478) {
        long j = c0478.f13137a;
        if (j < m6316a() + ((long) this.f13135a)) {
            return j;
        }
        if (this.f13130a <= 0 && j <= m6316a() && this.f13136a != 0) {
            return j;
        }
        return -1L;
    }

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final Object m6320a(C0478 c0478) {
        Object obj;
        InterfaceC1005[] interfaceC1005ArrM6322a = AbstractC1149.f14848a;
        synchronized (this) {
            try {
                long jM6319a = m6319a(c0478);
                if (jM6319a < 0) {
                    obj = AbstractC1149.f14852a;
                } else {
                    long j = c0478.f13137a;
                    Object[] objArr = this.f13132a;
                    AbstractC3098.m10100a(objArr);
                    Object obj2 = objArr[((int) jM6319a) & (objArr.length - 1)];
                    if (obj2 instanceof C0474) {
                        obj2 = ((C0474) obj2).f13119a;
                    }
                    c0478.f13137a = jM6319a + 1;
                    Object obj3 = obj2;
                    interfaceC1005ArrM6322a = m6322a(j);
                    obj = obj3;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        for (InterfaceC1005 interfaceC1005 : interfaceC1005ArrM6322a) {
            if (interfaceC1005 != null) {
                interfaceC1005.resumeWith(C6174p.f10843a);
            }
        }
        return obj;
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final void m6321a(long j, long j2, long j3, long j4) {
        long jMin = Math.min(j2, j);
        for (long jM6316a = m6316a(); jM6316a < jMin; jM6316a++) {
            Object[] objArr = this.f13132a;
            AbstractC3098.m10100a(objArr);
            AbstractC1149.m7157a(objArr, jM6316a, null);
        }
        this.f13133a = j;
        this.f13134a = j2;
        this.f13135a = (int) (j3 - jMin);
        this.f13136a = (int) (j4 - j3);
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final InterfaceC1005[] m6322a(long j) {
        long j2;
        long j3;
        long j4;
        InterfaceC1005[] interfaceC1005Arr;
        InterfaceC1005[] interfaceC1005Arr2;
        AbstractC4083a[] abstractC4083aArr;
        C5948o c5948o = AbstractC1149.f14852a;
        InterfaceC1005[] interfaceC1005Arr3 = AbstractC1149.f14848a;
        if (j <= this.f13134a) {
            long jM6316a = m6316a();
            long j5 = ((long) this.f13135a) + jM6316a;
            int i = this.f13130a;
            if (i == 0 && this.f13136a > 0) {
                j5++;
            }
            int i2 = 0;
            if (this.f1068a != 0 && (abstractC4083aArr = this.f1067a) != null) {
                for (AbstractC4083a abstractC4083a : abstractC4083aArr) {
                    if (abstractC4083a != null) {
                        long j6 = ((C0478) abstractC4083a).f13137a;
                        if (j6 >= 0 && j6 < j5) {
                            j5 = j6;
                        }
                    }
                }
            }
            if (j5 > this.f13134a) {
                long jM6316a2 = m6316a() + ((long) this.f13135a);
                int iMin = this.f1068a > 0 ? Math.min(this.f13136a, i - ((int) (jM6316a2 - j5))) : this.f13136a;
                long j7 = ((long) this.f13136a) + jM6316a2;
                if (iMin > 0) {
                    j4 = 1;
                    Object[] objArr = this.f13132a;
                    AbstractC3098.m10100a(objArr);
                    j2 = jM6316a;
                    InterfaceC1005[] interfaceC1005Arr4 = new InterfaceC1005[iMin];
                    long j8 = jM6316a2;
                    while (true) {
                        if (jM6316a2 >= j7) {
                            interfaceC1005Arr2 = interfaceC1005Arr4;
                            j3 = j5;
                            break;
                        }
                        interfaceC1005Arr2 = interfaceC1005Arr4;
                        Object obj = objArr[(objArr.length - 1) & ((int) jM6316a2)];
                        if (obj != c5948o) {
                            AbstractC3098.m10101a(obj, "null cannot be cast to non-null type kotlinx.coroutines.flow.SharedFlowImpl.Emitter");
                            C0474 c0474 = (C0474) obj;
                            int i3 = i2 + 1;
                            j3 = j5;
                            interfaceC1005Arr2[i2] = c0474.f13120a;
                            AbstractC1149.m7157a(objArr, jM6316a2, c5948o);
                            AbstractC1149.m7157a(objArr, j8, c0474.f13119a);
                            j8++;
                            if (i3 >= iMin) {
                                break;
                            }
                            i2 = i3;
                        } else {
                            j3 = j5;
                        }
                        jM6316a2++;
                        interfaceC1005Arr4 = interfaceC1005Arr2;
                        j5 = j3;
                    }
                    jM6316a2 = j8;
                    interfaceC1005Arr = interfaceC1005Arr2;
                } else {
                    j2 = jM6316a;
                    j3 = j5;
                    j4 = 1;
                    interfaceC1005Arr = interfaceC1005Arr3;
                }
                int i4 = (int) (jM6316a2 - j2);
                long j9 = this.f1068a == 0 ? jM6316a2 : j3;
                long jMax = Math.max(this.f13133a, jM6316a2 - ((long) Math.min(this.f13129a, i4)));
                if (i == 0 && jMax < j7) {
                    Object[] objArr2 = this.f13132a;
                    AbstractC3098.m10100a(objArr2);
                    if (AbstractC3098.m10094a(objArr2[((int) jMax) & (objArr2.length - 1)], c5948o)) {
                        jM6316a2 += j4;
                        jMax += j4;
                    }
                }
                m6321a(jMax, j9, jM6316a2, j7);
                m6312a();
                return interfaceC1005Arr.length == 0 ? interfaceC1005Arr : m6315a(interfaceC1005Arr);
            }
        }
        return interfaceC1005Arr3;
    }
}
