package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.AbstractActivityC3991a;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

/* JADX INFO: renamed from: ρۜ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public class C0869 implements InterfaceC6399s, InterfaceC4546c, InterfaceC4653c, InterfaceC5468j, InterfaceC4801e {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C0869 f14186a = new C0869();

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final C0869 f14187a = new C0869();

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final C0869 f14188a = new C0869();

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final C0869 f14189a = new C0869();

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final C0869 f14190a = new C0869();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static final C0869 f14191a = new C0869();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final C0869 f14192a = new C0869();

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final C0869 f14193a = new C0869();

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static final C0869 f14194a = new C0869();

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public static final C0869 f14195a = new C0869();

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static final C0869 f14196a = new C0869();

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static final C0869 f14197a = new C0869();

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public static final C0869 f14198a = new C0869();

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public static final C0869 f14199a = new C0869();

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public static final C0869 f14200a = new C0869();

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public static final C0869 f14201a = new C0869();

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public static final C0869 f14202a = new C0869();

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public static final C0869 f14203a = new C0869();

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public static final C0869 f14204a = new C0869();

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public static final C0869 f14205a = new C0869();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static C4257a m6907a(ViewGroup viewGroup, boolean z) {
        int i = AbstractC5178i.f7360a;
        return new C4257a(AbstractC3478.m10613a(viewGroup, z));
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static C1490 m6908a(ViewGroup viewGroup, boolean z) {
        int i = AbstractC5178i.f7360a;
        C1490 c1490 = new C1490(AbstractC3478.m10613a(viewGroup, z), EnumC5179i.CIRCULAR);
        if (z) {
            View view = c1490.f7366a;
            if (view != null) {
                view.setVisibility(8);
            }
            AbstractC5120i.m3457a(c1490.f7365a);
            c1490.f7362a.setGravity(17);
        }
        c1490.f7364a.setShapeAppearanceModel(C1490.f16097a);
        return c1490;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static C0869 m6909a(Context context, int i) {
        AbstractC5120i.m3425a("Cannot create a CalendarItemStyle with a styleResId of 0", i != 0);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i, AbstractC5986o.f10176a);
        Rect rect = new Rect(typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(2, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0), typedArrayObtainStyledAttributes.getDimensionPixelOffset(3, 0));
        AbstractC6005o.m4974a(context, typedArrayObtainStyledAttributes, 4);
        AbstractC6005o.m4974a(context, typedArrayObtainStyledAttributes, 9);
        AbstractC6005o.m4974a(context, typedArrayObtainStyledAttributes, 7);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        C0456.m6288a(context, typedArrayObtainStyledAttributes.getResourceId(5, 0), typedArrayObtainStyledAttributes.getResourceId(6, 0)).m6286a();
        typedArrayObtainStyledAttributes.recycle();
        C0869 c0869 = new C0869();
        AbstractC5120i.m3426a(rect.left);
        AbstractC5120i.m3426a(rect.top);
        AbstractC5120i.m3426a(rect.right);
        AbstractC5120i.m3426a(rect.bottom);
        return c0869;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public static void m6911a(AbstractActivityC3991a abstractActivityC3991a, ArrayList arrayList, int i) {
        if ((i & 2) != 0) {
            arrayList = new ArrayList();
        }
        C1064 c1064 = new C1064();
        Bundle bundle = new Bundle();
        bundle.putString("songsKey", AbstractC0635.m6527a(arrayList));
        bundle.putString("name", null);
        c1064.setArguments(bundle);
        c1064.m264a(abstractActivityC3991a.m275a(), "create_playlist");
    }

    @Override // defpackage.InterfaceC4546c
    /* JADX INFO: renamed from: à */
    public Bitmap mo2418a(int i, int i2, Bitmap.Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    @Override // defpackage.InterfaceC6399s
    /* JADX INFO: renamed from: á */
    public boolean mo5501a(Class cls) {
        return AbstractC6386s.class.isAssignableFrom(cls);
    }

    @Override // defpackage.InterfaceC6399s
    /* JADX INFO: renamed from: â */
    public C6407s mo5502a(Class cls) {
        if (!AbstractC6386s.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Unsupported message type: ".concat(cls.getName()));
        }
        try {
            return (C6407s) AbstractC6386s.m5618a(cls.asSubclass(AbstractC6386s.class)).mo5529a(3, null);
        } catch (Exception e) {
            throw new RuntimeException("Unable to get message info for ".concat(cls.getName()), e);
        }
    }

    @Override // defpackage.InterfaceC4546c
    /* JADX INFO: renamed from: ã */
    public Bitmap mo2419a(int i, int i2, Bitmap.Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    /* JADX INFO: renamed from: ā */
    public void mo2420a(Bitmap bitmap) {
        bitmap.recycle();
    }

    @Override // defpackage.InterfaceC4653c
    /* JADX INFO: renamed from: a̅ */
    public Object mo2739a(byte[] bArr) {
        return new ByteArrayInputStream(bArr);
    }

    @Override // defpackage.InterfaceC4546c
    /* JADX INFO: renamed from: ă */
    public void mo2421a(int i) {
    }

    @Override // defpackage.InterfaceC4546c
    /* JADX INFO: renamed from: ȧ */
    public void mo2422a() {
    }

    @Override // defpackage.InterfaceC4653c
    public Class getDataClass() {
        return InputStream.class;
    }
}
