package defpackage;

import android.os.Bundle;
import com.piyush.music.fragments.detail.artist.ArtistDetailFragment;

/* JADX INFO: renamed from: аְ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1472 extends AbstractC3210 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f16039a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ ArtistDetailFragment f16040a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1472(ArtistDetailFragment artistDetailFragment, int i) {
        super(0);
        this.f16039a = i;
        this.f16040a = artistDetailFragment;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        switch (this.f16039a) {
            case 0:
                ArtistDetailFragment artistDetailFragment = this.f16040a;
                Bundle arguments = artistDetailFragment.getArguments();
                if (arguments != null) {
                    return arguments;
                }
                throw new IllegalStateException("Fragment " + artistDetailFragment + " has null arguments");
            default:
                return this.f16040a;
        }
    }
}
