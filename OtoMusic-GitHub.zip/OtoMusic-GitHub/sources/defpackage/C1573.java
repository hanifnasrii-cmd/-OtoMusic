package defpackage;

/* JADX INFO: renamed from: аާ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1573 extends Exception {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f16382a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final boolean f16383a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C1898 f16384a;

    public C1573(int i, C1898 c1898, boolean z) {
        super(AbstractC4072a.m739a(i, "AudioTrack write failed: "));
        this.f16383a = z;
        this.f16382a = i;
        this.f16384a = c1898;
    }
}
