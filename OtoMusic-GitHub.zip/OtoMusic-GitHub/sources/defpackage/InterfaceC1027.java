package defpackage;

import android.graphics.RectF;

/* JADX INFO: renamed from: ϲ̢, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1027 {
    /* JADX INFO: renamed from: à */
    float mo683a(RectF rectF);
}
