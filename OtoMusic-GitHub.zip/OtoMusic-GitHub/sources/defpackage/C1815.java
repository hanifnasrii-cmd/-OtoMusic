package defpackage;

import java.util.ArrayList;

/* JADX INFO: renamed from: еּ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1815 extends AbstractC6338p {

    /* JADX INFO: renamed from: a͑, reason: contains not printable characters */
    public int f17290a;

    /* JADX INFO: renamed from: a͒, reason: contains not printable characters */
    public int f17291a;

    /* JADX INFO: renamed from: a͓, reason: contains not printable characters */
    public int f17292a;

    /* JADX INFO: renamed from: a͔, reason: contains not printable characters */
    public int f17293a;

    /* JADX INFO: renamed from: a͕, reason: contains not printable characters */
    public int f17294a;

    /* JADX INFO: renamed from: a͖, reason: contains not printable characters */
    public int f17295a;

    /* JADX INFO: renamed from: a͗, reason: contains not printable characters */
    public float f17296a;

    /* JADX INFO: renamed from: a͘, reason: contains not printable characters */
    public float f17297a;

    /* JADX INFO: renamed from: a͙, reason: contains not printable characters */
    public float f17298a;

    /* JADX INFO: renamed from: a͚, reason: contains not printable characters */
    public float f17299a;

    /* JADX INFO: renamed from: a͛, reason: contains not printable characters */
    public float f17300a;

    /* JADX INFO: renamed from: a͜, reason: contains not printable characters */
    public float f17301a;

    /* JADX INFO: renamed from: a͝, reason: contains not printable characters */
    public int f17302a;

    /* JADX INFO: renamed from: a͞, reason: contains not printable characters */
    public int f17303a;

    /* JADX INFO: renamed from: a͟, reason: contains not printable characters */
    public int f17304a;

    /* JADX INFO: renamed from: a͠, reason: contains not printable characters */
    public int f17305a;

    /* JADX INFO: renamed from: a͡, reason: contains not printable characters */
    public int f17306a;

    /* JADX INFO: renamed from: a͢, reason: contains not printable characters */
    public int f17307a;

    /* JADX INFO: renamed from: aͣ, reason: contains not printable characters */
    public int f17308a;

    /* JADX INFO: renamed from: aͤ, reason: contains not printable characters */
    public ArrayList f17309a;

    /* JADX INFO: renamed from: aͥ, reason: contains not printable characters */
    public C2970[] f17310a;

    /* JADX INFO: renamed from: aͦ, reason: contains not printable characters */
    public C2970[] f17311a;

    /* JADX INFO: renamed from: aͧ, reason: contains not printable characters */
    public int[] f17312a;

    /* JADX INFO: renamed from: aͨ, reason: contains not printable characters */
    public C2970[] f17313a;

    /* JADX INFO: renamed from: aͩ, reason: contains not printable characters */
    public int f17314a;

    @Override // defpackage.C2970
    /* JADX INFO: renamed from: á */
    public final void mo2138a(C0017 c0017, boolean z) {
        C2970 c2970;
        float f;
        int i;
        ArrayList arrayList = this.f17309a;
        super.mo2138a(c0017, z);
        C2970 c29702 = this.f21315a;
        boolean z2 = c29702 != null && ((C2971) c29702).f21342a;
        int i2 = this.f17306a;
        if (i2 != 0) {
            if (i2 == 1) {
                int size = arrayList.size();
                int i3 = 0;
                while (i3 < size) {
                    ((C1813) arrayList.get(i3)).m8229a(i3, z2, i3 == size + (-1));
                    i3++;
                }
            } else if (i2 != 2) {
                if (i2 == 3) {
                    int size2 = arrayList.size();
                    int i4 = 0;
                    while (i4 < size2) {
                        ((C1813) arrayList.get(i4)).m8229a(i4, z2, i4 == size2 + (-1));
                        i4++;
                    }
                }
            } else if (this.f17312a != null && this.f17311a != null && this.f17310a != null) {
                for (int i5 = 0; i5 < this.f17314a; i5++) {
                    this.f17313a[i5].m9897a();
                }
                int[] iArr = this.f17312a;
                int i6 = iArr[0];
                int i7 = iArr[1];
                float f2 = this.f17296a;
                C2970 c29703 = null;
                int i8 = 0;
                while (i8 < i6) {
                    if (z2) {
                        i = (i6 - i8) - 1;
                        f = 1.0f - this.f17296a;
                    } else {
                        f = f2;
                        i = i8;
                    }
                    C2970 c29704 = this.f17311a[i];
                    if (c29704 != null) {
                        C2946 c2946 = c29704.f21303a;
                        if (c29704.f21328a != 8) {
                            if (i8 == 0) {
                                c29704.m9878a(c2946, this.f21303a, this.f11276a);
                                c29704.f21330a = this.f17290a;
                                c29704.f21325a = f;
                            }
                            if (i8 == i6 - 1) {
                                c29704.m9878a(c29704.f21305a, this.f21305a, this.f11277a);
                            }
                            if (i8 > 0 && c29703 != null) {
                                C2946 c29462 = c29703.f21305a;
                                c29704.m9878a(c2946, c29462, this.f17302a);
                                c29703.m9878a(c29462, c2946, 0);
                            }
                            c29703 = c29704;
                        }
                    }
                    i8++;
                    f2 = f;
                }
                for (int i9 = 0; i9 < i7; i9++) {
                    C2970 c29705 = this.f17310a[i9];
                    if (c29705 != null) {
                        C2946 c29463 = c29705.f21304a;
                        if (c29705.f21328a != 8) {
                            if (i9 == 0) {
                                c29705.m9878a(c29463, this.f21304a, this.f11272a);
                                c29705.f21331a = this.f17291a;
                                c29705.f21326a = this.f17297a;
                            }
                            if (i9 == i7 - 1) {
                                c29705.m9878a(c29705.f21306a, this.f21306a, this.f11273a);
                            }
                            if (i9 > 0 && c29703 != null) {
                                C2946 c29464 = c29703.f21306a;
                                c29705.m9878a(c29463, c29464, this.f17303a);
                                c29703.m9878a(c29464, c29463, 0);
                            }
                            c29703 = c29705;
                        }
                    }
                }
                for (int i10 = 0; i10 < i6; i10++) {
                    for (int i11 = 0; i11 < i7; i11++) {
                        int i12 = (i11 * i6) + i10;
                        if (this.f17308a == 1) {
                            i12 = (i10 * i7) + i11;
                        }
                        C2970[] c2970Arr = this.f17313a;
                        if (i12 < c2970Arr.length && (c2970 = c2970Arr[i12]) != null && c2970.f21328a != 8) {
                            C2970 c29706 = this.f17311a[i10];
                            C2970 c29707 = this.f17310a[i11];
                            if (c2970 != c29706) {
                                c2970.m9878a(c2970.f21303a, c29706.f21303a, 0);
                                c2970.m9878a(c2970.f21305a, c29706.f21305a, 0);
                            }
                            if (c2970 != c29707) {
                                c2970.m9878a(c2970.f21304a, c29707.f21304a, 0);
                                c2970.m9878a(c2970.f21306a, c29707.f21306a, 0);
                            }
                        }
                    }
                }
            }
        } else if (arrayList.size() > 0) {
            ((C1813) arrayList.get(0)).m8229a(0, z2, true);
        }
        this.f11278a = false;
    }

    /* JADX INFO: renamed from: a̮, reason: contains not printable characters */
    public final int m8234a(C2970 c2970, int i) {
        C2970 c29702;
        if (c2970 == null) {
            return 0;
        }
        EnumC2969[] enumC2969Arr = c2970.f21314a;
        if (enumC2969Arr[1] == EnumC2969.MATCH_CONSTRAINT) {
            int i2 = c2970.f21287a;
            if (i2 == 0) {
                return 0;
            }
            if (i2 == 2) {
                int i3 = (int) (c2970.f21294a * i);
                if (i3 != c2970.m9882a()) {
                    c2970.f21275a = true;
                    m5522a(c2970, enumC2969Arr[0], c2970.m9886a(), EnumC2969.FIXED, i3);
                }
                return i3;
            }
            c29702 = c2970;
            if (i2 == 1) {
                return c29702.m9882a();
            }
            if (i2 == 3) {
                return (int) ((c29702.m9886a() * c29702.f21318a) + 0.5f);
            }
        } else {
            c29702 = c2970;
        }
        return c29702.m9882a();
    }

    /* JADX INFO: renamed from: a̯, reason: contains not printable characters */
    public final int m8235a(C2970 c2970, int i) {
        C2970 c29702;
        if (c2970 == null) {
            return 0;
        }
        EnumC2969[] enumC2969Arr = c2970.f21314a;
        if (enumC2969Arr[0] == EnumC2969.MATCH_CONSTRAINT) {
            int i2 = c2970.f21286a;
            if (i2 == 0) {
                return 0;
            }
            if (i2 == 2) {
                int i3 = (int) (c2970.f21291a * i);
                if (i3 != c2970.m9886a()) {
                    c2970.f21275a = true;
                    m5522a(c2970, EnumC2969.FIXED, i3, enumC2969Arr[1], c2970.m9882a());
                }
                return i3;
            }
            c29702 = c2970;
            if (i2 == 1) {
                return c29702.m9886a();
            }
            if (i2 == 3) {
                return (int) ((c29702.m9882a() * c29702.f21318a) + 0.5f);
            }
        } else {
            c29702 = c2970;
        }
        return c29702.m9886a();
    }
}
