package defpackage;

import androidx.fragment.app.AbstractComponentCallbacksC3990a;

/* JADX INFO: renamed from: е⃖, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1930 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    default void mo8305a(AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a, boolean z) {
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    default void mo8306a(AbstractComponentCallbacksC3990a abstractComponentCallbacksC3990a, boolean z) {
    }

    void onBackStackChanged();
}
