package defpackage;

import android.os.Bundle;
import com.piyush.music.dialogs.artist.SelectArtistDialog;
import com.piyush.music.dialogs.bottomsheet.grid.SelectGridCountDialog;
import com.piyush.music.dialogs.multiple.genres.SelectGenreDialog;
import com.piyush.music.fragments.list.SongsListFragment;
import com.piyush.music.fragments.search.SearchFragment;
import com.piyush.music.fragments.settings.SettingsMainFragment;
import com.piyush.music.fragments.settings.SubSettingParentFragment;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: ιٔ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0188 extends AbstractC3210 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f12203a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ Object f12204a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0188(int i, Object obj) {
        super(0);
        this.f12203a = i;
        this.f12204a = obj;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        switch (this.f12203a) {
            case 0:
                return (InterfaceC6285p) ((C0185) this.f12204a).invoke();
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return (InterfaceC6285p) ((C5361j) this.f12204a).invoke();
            case 2:
                return (C5534j) this.f12204a;
            case 3:
                return (InterfaceC6285p) ((C0188) this.f12204a).invoke();
            case 4:
                String str = (String) this.f12204a;
                AbstractC3098.m10103a(str, "uriPattern");
                return new C5676j(str, null, null);
            case 5:
                ((C3455) this.f12204a).m10591a();
                return C6174p.f10843a;
            case 6:
                return (InterfaceC6285p) ((C5744o) this.f12204a).invoke();
            case 7:
                return (InterfaceC6285p) ((C5744o) this.f12204a).invoke();
            case 8:
                return (InterfaceC6285p) ((C5780o) this.f12204a).invoke();
            case 9:
                return (C5796o) this.f12204a;
            case 10:
                return (InterfaceC6285p) ((C0188) this.f12204a).invoke();
            case 11:
                return (C2082) this.f12204a;
            case 12:
                return (InterfaceC6285p) ((C0188) this.f12204a).invoke();
            case 13:
                return (InterfaceC6285p) ((C2235) this.f12204a).invoke();
            case 14:
                return (SearchFragment) this.f12204a;
            case 15:
                return (InterfaceC6285p) ((C0188) this.f12204a).invoke();
            case 16:
                SelectArtistDialog selectArtistDialog = (SelectArtistDialog) this.f12204a;
                Bundle arguments = selectArtistDialog.getArguments();
                if (arguments != null) {
                    return arguments;
                }
                throw new IllegalStateException("Fragment " + selectArtistDialog + " has null arguments");
            case 17:
                SelectGenreDialog selectGenreDialog = (SelectGenreDialog) this.f12204a;
                Bundle arguments2 = selectGenreDialog.getArguments();
                if (arguments2 != null) {
                    return arguments2;
                }
                throw new IllegalStateException("Fragment " + selectGenreDialog + " has null arguments");
            case 18:
                SelectGridCountDialog selectGridCountDialog = (SelectGridCountDialog) this.f12204a;
                Bundle arguments3 = selectGridCountDialog.getArguments();
                if (arguments3 != null) {
                    return arguments3;
                }
                throw new IllegalStateException("Fragment " + selectGridCountDialog + " has null arguments");
            case 19:
                return (SettingsMainFragment) this.f12204a;
            case 20:
                return (InterfaceC6285p) ((C0188) this.f12204a).invoke();
            case 21:
                SongsListFragment songsListFragment = (SongsListFragment) this.f12204a;
                Bundle arguments4 = songsListFragment.getArguments();
                if (arguments4 != null) {
                    return arguments4;
                }
                throw new IllegalStateException("Fragment " + songsListFragment + " has null arguments");
            case 22:
                SubSettingParentFragment subSettingParentFragment = (SubSettingParentFragment) this.f12204a;
                Bundle arguments5 = subSettingParentFragment.getArguments();
                if (arguments5 != null) {
                    return arguments5;
                }
                throw new IllegalStateException("Fragment " + subSettingParentFragment + " has null arguments");
            case 23:
                return (InterfaceC6285p) ((C3809) this.f12204a).invoke();
            case 24:
                return (InterfaceC6285p) ((C3921) this.f12204a).invoke();
            default:
                return new AbstractC2978[((InterfaceC1814[]) this.f12204a).length];
        }
    }
}
