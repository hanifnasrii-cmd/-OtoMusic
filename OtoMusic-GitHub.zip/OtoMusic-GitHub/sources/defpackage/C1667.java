package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: е̌, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1667 implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16718a = 0;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ AbstractC0077 f16719a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C5481j f16720a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ AbstractC0077 f16721a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5056i f16722a;

    public /* synthetic */ C1667(AbstractC0077 abstractC0077, AbstractC0077 abstractC00772, C5481j c5481j, InterfaceC5056i interfaceC5056i) {
        this.f16719a = abstractC0077;
        this.f16721a = abstractC00772;
        this.f16720a = c5481j;
        this.f16722a = interfaceC5056i;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        switch (this.f16718a) {
            case 0:
                C5481j c5481j = (C5481j) this.f16721a;
                Object objM5849a = this.f16720a.m5849a();
                Object objM5849a2 = this.f16719a.m5849a();
                if (objM5849a != null && objM5849a2 != null) {
                    c5481j.mo4304a(this.f16722a.mo2172a(obj, objM5849a, objM5849a2));
                }
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C5481j c5481j2 = (C5481j) this.f16721a;
                Object objM5849a3 = this.f16719a.m5849a();
                Object objM5849a4 = this.f16720a.m5849a();
                if (objM5849a3 != null && objM5849a4 != null) {
                    c5481j2.mo4304a(this.f16722a.mo2172a(objM5849a3, objM5849a4, obj));
                }
                break;
            default:
                Object objM5849a5 = this.f16719a.m5849a();
                Object objM5849a6 = this.f16721a.m5849a();
                if (objM5849a5 != null && objM5849a6 != null) {
                    this.f16720a.mo4304a(this.f16722a.mo2172a(objM5849a5, obj, objM5849a6));
                }
                break;
        }
        return C6174p.f10843a;
    }

    public /* synthetic */ C1667(AbstractC0077 abstractC0077, C5481j c5481j, C5481j c5481j2, InterfaceC5056i interfaceC5056i) {
        this.f16719a = abstractC0077;
        this.f16720a = c5481j;
        this.f16721a = c5481j2;
        this.f16722a = interfaceC5056i;
    }

    public /* synthetic */ C1667(C5481j c5481j, AbstractC0077 abstractC0077, C5481j c5481j2, InterfaceC5056i interfaceC5056i) {
        this.f16720a = c5481j;
        this.f16719a = abstractC0077;
        this.f16721a = c5481j2;
        this.f16722a = interfaceC5056i;
    }
}
