package defpackage;

import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: renamed from: ρ⃩, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0949 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C0111 f14319a = new C0111("MediaSessionUtils", null);

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static ArrayList m7023a(C0703 c0703) {
        try {
            Parcel parcelM9093a = c0703.m9093a(c0703.m9092a(), 3);
            ArrayList arrayListCreateTypedArrayList = parcelM9093a.createTypedArrayList(C3385.CREATOR);
            parcelM9093a.recycle();
            return arrayListCreateTypedArrayList;
        } catch (RemoteException e) {
            Object[] objArr = {"getNotificationActions", C0703.class.getSimpleName()};
            C0111 c0111 = f14319a;
            Log.e(c0111.f11965a, c0111.m5889a("Unable to call %s on %s.", objArr), e);
            return null;
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static int[] m7024a(C0703 c0703) {
        try {
            Parcel parcelM9093a = c0703.m9093a(c0703.m9092a(), 4);
            int[] iArrCreateIntArray = parcelM9093a.createIntArray();
            parcelM9093a.recycle();
            return iArrCreateIntArray;
        } catch (RemoteException e) {
            Object[] objArr = {"getCompactViewActionIndices", C0703.class.getSimpleName()};
            C0111 c0111 = f14319a;
            Log.e(c0111.f11965a, c0111.m5889a("Unable to call %s on %s.", objArr), e);
            return null;
        }
    }
}
