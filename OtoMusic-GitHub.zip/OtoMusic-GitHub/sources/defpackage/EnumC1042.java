package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: ϲ̱, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1042 {
    private static final /* synthetic */ InterfaceC4935e $ENTRIES;
    private static final /* synthetic */ EnumC1042[] $VALUES;
    public static final EnumC1042 BLOCKING;
    public static final EnumC1042 CPU_ACQUIRED;
    public static final EnumC1042 DORMANT;
    public static final EnumC1042 PARKING;
    public static final EnumC1042 TERMINATED;

    static {
        EnumC1042 enumC1042 = new EnumC1042("CPU_ACQUIRED", 0);
        CPU_ACQUIRED = enumC1042;
        EnumC1042 enumC10422 = new EnumC1042("BLOCKING", 1);
        BLOCKING = enumC10422;
        EnumC1042 enumC10423 = new EnumC1042("PARKING", 2);
        PARKING = enumC10423;
        EnumC1042 enumC10424 = new EnumC1042("DORMANT", 3);
        DORMANT = enumC10424;
        EnumC1042 enumC10425 = new EnumC1042("TERMINATED", 4);
        TERMINATED = enumC10425;
        EnumC1042[] enumC1042Arr = {enumC1042, enumC10422, enumC10423, enumC10424, enumC10425};
        $VALUES = enumC1042Arr;
        $ENTRIES = AbstractC5120i.m3435a(enumC1042Arr);
    }

    public static EnumC1042 valueOf(String str) {
        return (EnumC1042) Enum.valueOf(EnumC1042.class, str);
    }

    public static EnumC1042[] values() {
        return (EnumC1042[]) $VALUES.clone();
    }
}
