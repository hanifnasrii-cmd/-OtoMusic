package defpackage;

import com.piyush.music.R;

/* JADX INFO: renamed from: οޮ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0587 extends C0584 {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int f13557a;

    public C0587(C3347 c3347, int i) {
        super(c3347, i);
        this.f13557a = R.string.rn;
    }

    @Override // defpackage.C0584, defpackage.AbstractC2503
    /* JADX INFO: renamed from: ã */
    public final Integer mo5937a() {
        return Integer.valueOf(this.f13557a);
    }
}
