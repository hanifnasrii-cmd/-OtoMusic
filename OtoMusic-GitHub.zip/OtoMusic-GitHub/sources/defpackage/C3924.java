package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.piyush.music.R;

/* JADX INFO: renamed from: օ⃥, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3924 extends AbstractC3922 {

    /* JADX INFO: renamed from: ḁ, reason: contains not printable characters */
    public static final C2416 f24055a;

    /* JADX INFO: renamed from: a̦, reason: contains not printable characters */
    public static final SparseIntArray f24056a;

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public boolean f24057a;

    /* JADX INFO: renamed from: a̤, reason: contains not printable characters */
    public long f24058a;

    static {
        C2416 c2416 = new C2416(12);
        f24055a = c2416;
        c2416.m8958a(0, new int[]{4}, new int[]{R.layout.cp}, new String[]{"include_tag_editor_cover"});
        c2416.m8958a(3, new int[]{5}, new int[]{R.layout.cm}, new String[]{"include_edit_tags_list"});
        SparseIntArray sparseIntArray = new SparseIntArray();
        f24056a = sparseIntArray;
        sparseIntArray.put(R.id.divider, 6);
        sparseIntArray.put(R.id.guideline_horizontal, 7);
        sparseIntArray.put(R.id.guideline_vertical, 8);
        sparseIntArray.put(R.id.divider_vertical, 9);
        sparseIntArray.put(R.id.btn_download_tags, 10);
        sparseIntArray.put(R.id.eyebrow, 11);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C3924(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 12, f24055a, f24056a);
        MaterialButton materialButton = (MaterialButton) objArrM5440a[10];
        TextView textView = (TextView) objArrM5440a[11];
        super(null, view, null, materialButton, textView, (AbstractC3059) objArrM5440a[4], (AbstractC3053) objArrM5440a[5], (NestedScrollView) objArrM5440a[2], (ConstraintLayout) objArrM5440a[0], (MaterialToolbar) objArrM5440a[1]);
        this.f24058a = -1L;
        AbstractC3059 abstractC3059 = this.f24046a;
        if (abstractC3059 != null) {
            abstractC3059.f11087a = this;
        }
        AbstractC3053 abstractC3053 = this.f24047a;
        if (abstractC3053 != null) {
            abstractC3053.f11087a = this;
        }
        this.f24048a.setTag(null);
        ((LinearLayout) objArrM5440a[3]).setTag(null);
        this.f24049a.setTag(null);
        this.f24050a.setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        long j;
        synchronized (this) {
            j = this.f24058a;
            this.f24058a = 0L;
        }
        long j2 = j & 4;
        if (j2 != 0) {
            AbstractC2179.m8620a(this.f24048a, false, false, false, this.f24057a, false, false, false, true);
            AbstractC2179.m8620a(this.f24050a, false, this.f24057a, false, false, false, true, false, false);
        }
        if (j2 != 0) {
            this.f24057a = true;
        }
        this.f24046a.m5442a();
        this.f24047a.m5442a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                if (this.f24058a != 0) {
                    return true;
                }
                return this.f24046a.mo666a() || this.f24047a.mo666a();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f24058a = 4L;
        }
        this.f24046a.mo667a();
        this.f24047a.mo667a();
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        if (i != 0) {
            return false;
        }
        synchronized (this) {
            this.f24058a |= 1;
        }
        return true;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
