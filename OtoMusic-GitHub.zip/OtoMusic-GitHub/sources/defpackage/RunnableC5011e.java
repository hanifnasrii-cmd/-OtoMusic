package defpackage;

import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import java.util.ArrayList;

/* JADX INFO: renamed from: eⷵ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class RunnableC5011e implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f6843a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C5014e f6844a;

    public /* synthetic */ RunnableC5011e(C5014e c5014e, int i) {
        this.f6843a = i;
        this.f6844a = c5014e;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f6843a) {
            case 0:
                C5014e c5014e = this.f6844a;
                int i = 0;
                AnimatorSet animatorSetM3341a = c5014e.m3341a(false);
                animatorSetM3341a.addListener(new C4608c(1, c5014e));
                ArrayList arrayList = c5014e.f6855a;
                int size = arrayList.size();
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    animatorSetM3341a.addListener((AnimatorListenerAdapter) obj);
                }
                animatorSetM3341a.start();
                break;
            default:
                C5014e c5014e2 = this.f6844a;
                AnimatorSet animatorSetM3341a2 = c5014e2.m3341a(true);
                animatorSetM3341a2.addListener(new C4112a(5, c5014e2));
                ArrayList arrayList2 = c5014e2.f6855a;
                int size2 = arrayList2.size();
                int i2 = 0;
                while (i2 < size2) {
                    Object obj2 = arrayList2.get(i2);
                    i2++;
                    animatorSetM3341a2.addListener((AnimatorListenerAdapter) obj2);
                }
                animatorSetM3341a2.start();
                break;
        }
    }
}
