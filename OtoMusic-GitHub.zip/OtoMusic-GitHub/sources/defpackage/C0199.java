package defpackage;

import android.view.View;
import androidx.fragment.app.AbstractComponentCallbacksC3990a;
import com.piyush.taglib.AudioProperties;
import java.util.List;
import kotlin.Metadata;

/* JADX INFO: renamed from: ιٟ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0007¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Lιٟ;", "Lc͞;", "Lе⃮;", "Lс̈́;", "<init>", "()V", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public final class C0199 extends AbstractC4455c<AbstractC1947, C2716> {

    /* JADX INFO: renamed from: a̙, reason: contains not printable characters */
    public final C3559 f12251a;

    public C0199() {
        super(0);
        C2826 c2826 = new C2826(0.55f, 0.75f);
        EnumC3557 enumC3557 = EnumC3557.A1;
        C3549 c3549 = new C3549(enumC3557, 200);
        EnumC3557 enumC35572 = EnumC3557.A3;
        this.f12251a = new C3559(c2826, AbstractC2852.m9677a(c3549, new C3549(enumC35572, 300), new C3549(enumC3557, 400), new C3549(enumC35572, 200)), 2);
    }

    @Override // defpackage.AbstractC4452c
    /* JADX INFO: renamed from: a̠ */
    public final AbstractComponentCallbacksC3990a mo2198a() {
        return new C5748o();
    }

    @Override // defpackage.AbstractC4455c
    /* JADX INFO: renamed from: ḁ */
    public final void mo2221a(View view, List list) {
        ((C2716) view).setPalette(list);
    }

    @Override // defpackage.AbstractC4455c
    /* JADX INFO: renamed from: a̦ */
    public final C2716 mo2222a() {
        C2716 c2716 = new C2716(requireContext());
        c2716.setBaseColor(-16777216);
        return c2716;
    }

    @Override // defpackage.AbstractC4455c
    /* JADX INFO: renamed from: ą, reason: from getter */
    public final C3559 getF12251a() {
        return this.f12251a;
    }

    @Override // defpackage.AbstractC4455c
    /* JADX INFO: renamed from: a̩ */
    public final void mo2225a(C0272 c0272) {
        m2200a().f4869a.mo4474a(c0272);
    }
}
