package defpackage;

import com.piyush.music.fragments.player.mainplayer.controls.PlayerControlsMD3Fragment;

/* JADX INFO: renamed from: ò, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5745o extends AbstractC3210 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f9415a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ PlayerControlsMD3Fragment f9416a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ Object f9417a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C5745o(PlayerControlsMD3Fragment playerControlsMD3Fragment, InterfaceC3238 interfaceC3238, int i) {
        super(0);
        this.f9415a = i;
        this.f9416a = playerControlsMD3Fragment;
        this.f9417a = interfaceC3238;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, і߫] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Object, і߫] */
    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        InterfaceC6282p defaultViewModelProviderFactory;
        InterfaceC6282p defaultViewModelProviderFactory2;
        switch (this.f9415a) {
            case 0:
                InterfaceC6285p interfaceC6285p = (InterfaceC6285p) this.f9417a.getValue();
                InterfaceC5200i interfaceC5200i = interfaceC6285p instanceof InterfaceC5200i ? (InterfaceC5200i) interfaceC6285p : null;
                if (interfaceC5200i != null && (defaultViewModelProviderFactory = interfaceC5200i.getDefaultViewModelProviderFactory()) != null) {
                    return defaultViewModelProviderFactory;
                }
                InterfaceC6282p defaultViewModelProviderFactory3 = this.f9416a.getDefaultViewModelProviderFactory();
                AbstractC3098.m10102a(defaultViewModelProviderFactory3, "defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory3;
            default:
                InterfaceC6285p interfaceC6285p2 = (InterfaceC6285p) this.f9417a.getValue();
                InterfaceC5200i interfaceC5200i2 = interfaceC6285p2 instanceof InterfaceC5200i ? (InterfaceC5200i) interfaceC6285p2 : null;
                if (interfaceC5200i2 != null && (defaultViewModelProviderFactory2 = interfaceC5200i2.getDefaultViewModelProviderFactory()) != null) {
                    return defaultViewModelProviderFactory2;
                }
                InterfaceC6282p defaultViewModelProviderFactory4 = this.f9416a.getDefaultViewModelProviderFactory();
                AbstractC3098.m10102a(defaultViewModelProviderFactory4, "defaultViewModelProviderFactory");
                return defaultViewModelProviderFactory4;
        }
    }
}
