package defpackage;

/* JADX INFO: renamed from: eⷯ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5005e implements Comparable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C5756o f6760a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f6761a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public long f6762a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public Object f6763a;

    public C5005e(C5756o c5756o) {
        this.f6760a = c5756o;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        C5005e c5005e = (C5005e) obj;
        Object obj2 = this.f6763a;
        if ((obj2 == null) != (c5005e.f6763a == null)) {
            return obj2 != null ? -1 : 1;
        }
        if (obj2 == null) {
            return 0;
        }
        int i = this.f6761a - c5005e.f6761a;
        return i != 0 ? i : Long.compare(this.f6762a, c5005e.f6762a);
    }
}
