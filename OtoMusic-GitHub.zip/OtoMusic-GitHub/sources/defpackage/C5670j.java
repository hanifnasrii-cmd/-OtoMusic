package defpackage;

import android.os.Bundle;

/* JADX INFO: renamed from: jⷴ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5670j extends AbstractC3210 implements InterfaceC5040i {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C2044 f9114a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ AbstractC5671j f9115a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ AbstractC5679j f9116a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ Bundle f9117a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C5670j(C2044 c2044, AbstractC5671j abstractC5671j, AbstractC5679j abstractC5679j, Bundle bundle) {
        super(1);
        this.f9114a = c2044;
        this.f9115a = abstractC5671j;
        this.f9116a = abstractC5679j;
        this.f9117a = bundle;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        C5662j c5662j = (C5662j) obj;
        AbstractC3098.m10103a(c5662j, "it");
        this.f9114a.f18167a = true;
        this.f9115a.m4528a(this.f9116a, this.f9117a, c5662j, C4891e.f6320a);
        return C6174p.f10843a;
    }
}
