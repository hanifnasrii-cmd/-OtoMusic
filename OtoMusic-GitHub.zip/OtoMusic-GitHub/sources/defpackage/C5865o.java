package defpackage;

/* JADX INFO: renamed from: oِ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5865o extends AbstractC5866o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f9829a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f9830a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Integer f9831a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C5481j f9832a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final boolean f9833a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final AbstractC0077 f9834a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final AbstractC0077 f9835a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final InterfaceC5040i f9836a;

    public C5865o(String str, int i, Integer num, C5481j c5481j, C5631j c5631j, C5481j c5481j2, InterfaceC5040i interfaceC5040i, int i2) {
        num = (i2 & 4) != 0 ? null : num;
        boolean z = (i2 & 16) == 0;
        c5631j = (i2 & 32) != 0 ? null : c5631j;
        c5481j2 = (i2 & 128) != 0 ? null : c5481j2;
        this.f9829a = str;
        this.f9830a = i;
        this.f9831a = num;
        this.f9832a = c5481j;
        this.f9833a = z;
        this.f9834a = c5631j;
        this.f9835a = c5481j2;
        this.f9836a = interfaceC5040i;
    }

    @Override // defpackage.AbstractC5866o
    /* JADX INFO: renamed from: à */
    public final String mo4810a() {
        return this.f9829a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C5865o)) {
            return false;
        }
        C5865o c5865o = (C5865o) obj;
        return this.f9829a.equals(c5865o.f9829a) && this.f9830a == c5865o.f9830a && AbstractC3098.m10094a(this.f9831a, c5865o.f9831a) && this.f9832a.equals(c5865o.f9832a) && this.f9833a == c5865o.f9833a && AbstractC3098.m10094a(this.f9834a, c5865o.f9834a) && AbstractC3098.m10094a(this.f9835a, c5865o.f9835a) && this.f9836a.equals(c5865o.f9836a);
    }

    public final int hashCode() {
        int iM975a = AbstractC4164a.m975a(this.f9830a, this.f9829a.hashCode() * 31, 31);
        Integer num = this.f9831a;
        int iM978a = AbstractC4164a.m978a((this.f9832a.hashCode() + ((iM975a + (num == null ? 0 : num.hashCode())) * 31)) * 31, this.f9833a, 31);
        AbstractC0077 abstractC0077 = this.f9834a;
        int iM978a2 = AbstractC4164a.m978a((iM978a + (abstractC0077 == null ? 0 : abstractC0077.hashCode())) * 31, false, 31);
        AbstractC0077 abstractC00772 = this.f9835a;
        return this.f9836a.hashCode() + ((iM978a2 + (abstractC00772 != null ? abstractC00772.hashCode() : 0)) * 31);
    }

    public final String toString() {
        return "ValueRow(key=" + this.f9829a + ", title=" + this.f9830a + ", supporting=" + this.f9831a + ", valueLive=" + this.f9832a + ", accent=" + this.f9833a + ", enabled=" + this.f9834a + ", betaPill=false, locked=" + this.f9835a + ", onClick=" + this.f9836a + ")";
    }
}
