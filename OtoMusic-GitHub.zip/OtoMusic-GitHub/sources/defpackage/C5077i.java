package defpackage;

import com.piyush.music.models.Album;
import com.piyush.music.models.Artist;
import com.piyush.music.models.Genre;
import com.piyush.music.models.SearchHeader;
import com.piyush.music.models.Song;
import com.piyush.music.models.SuggestionQueryRow;

/* JADX INFO: renamed from: i̸, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5077i extends AbstractC5120i {

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static final C5077i f6934a = new C5077i();

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: â */
    public final boolean mo1112a(Object obj, Object obj2) {
        if ((obj instanceof SearchHeader) && (obj2 instanceof SearchHeader)) {
            return ((SearchHeader) obj2).getCount() == ((SearchHeader) obj).getCount();
        }
        if ((obj instanceof SuggestionQueryRow) && (obj2 instanceof SuggestionQueryRow)) {
            return obj.equals(obj2);
        }
        if ((obj instanceof Album) && (obj2 instanceof Album)) {
            Album album = (Album) obj;
            Album album2 = (Album) obj2;
            return album.equals(album2) && album.getDateModified() == album2.getDateModified();
        }
        if ((obj instanceof Song) && (obj2 instanceof Song)) {
            Song song = (Song) obj;
            Song song2 = (Song) obj2;
            return song.equals(song2) && song.getDateModified() == song2.getDateModified();
        }
        if ((obj instanceof Artist) && (obj2 instanceof Artist)) {
            Artist artist = (Artist) obj;
            Artist artist2 = (Artist) obj2;
            return AbstractC3098.m10094a(artist.getActualName(), artist2.getActualName()) && artist.getAlbumCount() == artist2.getAlbumCount() && artist.getSongCount() == artist2.getSongCount();
        }
        if ((obj instanceof C5767o) && (obj2 instanceof C5767o)) {
            C5767o c5767o = (C5767o) obj;
            C5767o c5767o2 = (C5767o) obj2;
            return AbstractC3098.m10094a(c5767o.f9524a, c5767o2.f9524a) && c5767o.f9527a.size() == c5767o2.f9527a.size() && AbstractC3098.m10094a(c5767o.f9526a, c5767o2.f9526a);
        }
        if (!(obj instanceof Genre) || !(obj2 instanceof Genre)) {
            return false;
        }
        Genre genre = (Genre) obj;
        Genre genre2 = (Genre) obj2;
        return AbstractC3098.m10094a(genre2.getName(), genre.getName()) && genre2.getSongs().size() == genre.getSongs().size();
    }

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: ã */
    public final boolean mo1113a(Object obj, Object obj2) {
        if ((obj instanceof SearchHeader) && (obj2 instanceof SearchHeader)) {
            return ((SearchHeader) obj2).getStringId() == ((SearchHeader) obj).getStringId();
        }
        if ((obj instanceof SuggestionQueryRow) && (obj2 instanceof SuggestionQueryRow)) {
            SuggestionQueryRow suggestionQueryRow = (SuggestionQueryRow) obj;
            SuggestionQueryRow suggestionQueryRow2 = (SuggestionQueryRow) obj2;
            return suggestionQueryRow.getKind() == suggestionQueryRow2.getKind() && AbstractC3098.m10094a(suggestionQueryRow.getQuery(), suggestionQueryRow2.getQuery());
        }
        if ((obj instanceof Album) && (obj2 instanceof Album)) {
            Album album = (Album) obj;
            Album album2 = (Album) obj2;
            return album.getSongCount() == album2.getSongCount() && album.getFirstSong().getId() == album2.getFirstSong().getId();
        }
        if ((obj instanceof Song) && (obj2 instanceof Song)) {
            return ((Song) obj).getId() == ((Song) obj2).getId();
        }
        if ((obj instanceof Artist) && (obj2 instanceof Artist)) {
            return AbstractC3098.m10094a(((Artist) obj).getActualName(), ((Artist) obj2).getActualName());
        }
        if ((obj instanceof C5767o) && (obj2 instanceof C5767o)) {
            return ((C5767o) obj).f9523a == ((C5767o) obj2).f9523a;
        }
        if ((obj instanceof Genre) && (obj2 instanceof Genre)) {
            return AbstractC3098.m10094a(((Genre) obj2).getName(), ((Genre) obj).getName());
        }
        return false;
    }

    @Override // defpackage.AbstractC5120i
    /* JADX INFO: renamed from: a̔ */
    public final Object mo1114a(Object obj, Object obj2) {
        return ((obj instanceof Album) && (obj2 instanceof Album)) ? ((Album) obj).equals((Album) obj2) ? C4240a.f1490a : C4240a.f1489a : ((obj instanceof Song) && (obj2 instanceof Song)) ? ((Song) obj).equals((Song) obj2) ? C5974o.f10108a : C5974o.f10107a : ((obj instanceof Artist) && (obj2 instanceof Artist)) ? C4240a.f1492a : ((obj instanceof C5767o) && (obj2 instanceof C5767o)) ? C4240a.f1496a : ((obj instanceof Genre) && (obj2 instanceof Genre)) ? new Object() : Boolean.FALSE;
    }
}
