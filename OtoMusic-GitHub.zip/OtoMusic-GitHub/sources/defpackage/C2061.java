package defpackage;

import android.os.Bundle;
import java.util.ArrayList;

/* JADX INFO: renamed from: о͋, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2061 extends AbstractC5423j implements InterfaceC2058 {

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final String f18187a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C5425j f18188a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public String f18189a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public String f18190a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public boolean f18191a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public int f18193a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C2057 f18194a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final /* synthetic */ ServiceConnectionC2063 f18196a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public int f18192a = -1;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f18195a = -1;

    public C2061(ServiceConnectionC2063 serviceConnectionC2063, String str, C5425j c5425j) {
        this.f18196a = serviceConnectionC2063;
        this.f18187a = str;
        this.f18188a = c5425j;
    }

    @Override // defpackage.InterfaceC2058
    /* JADX INFO: renamed from: à */
    public final int mo8471a() {
        return this.f18195a;
    }

    @Override // defpackage.InterfaceC2058
    /* JADX INFO: renamed from: á */
    public final void mo8472a(C2057 c2057) {
        C2060 c2060 = new C2060(this);
        this.f18194a = c2057;
        int i = c2057.f18181a;
        c2057.f18181a = i + 1;
        int i2 = c2057.f18180a;
        c2057.f18180a = i2 + 1;
        Bundle bundle = new Bundle();
        bundle.putString("memberRouteId", this.f18187a);
        bundle.putParcelable("routeControllerOptions", this.f18188a.f8345a);
        c2057.m8467a(11, i2, i, null, bundle);
        c2057.f18184a.put(i2, c2060);
        this.f18195a = i;
        if (this.f18191a) {
            c2057.m8466a(i);
            int i3 = this.f18192a;
            if (i3 >= 0) {
                c2057.m8469a(this.f18195a, i3);
                this.f18192a = -1;
            }
            int i4 = this.f18193a;
            if (i4 != 0) {
                c2057.m8470a(this.f18195a, i4);
                this.f18193a = 0;
            }
        }
    }

    @Override // defpackage.InterfaceC2058
    /* JADX INFO: renamed from: â */
    public final void mo8473a() {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            int i = this.f18195a;
            int i2 = c2057.f18180a;
            c2057.f18180a = i2 + 1;
            c2057.m8467a(4, i2, i, null, null);
            this.f18194a = null;
            this.f18195a = 0;
        }
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ã */
    public final void mo4121a() {
        ServiceConnectionC2063 serviceConnectionC2063 = this.f18196a;
        serviceConnectionC2063.f18209a.remove(this);
        mo8473a();
        serviceConnectionC2063.m8479a();
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ā */
    public final void mo4198a() {
        this.f18191a = true;
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            c2057.m8466a(this.f18195a);
        }
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: a̅ */
    public final void mo4122a(int i) {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            c2057.m8469a(this.f18195a, i);
        } else {
            this.f18192a = i;
            this.f18193a = 0;
        }
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ă */
    public final void mo4199a() {
        mo4200a(0);
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ȧ */
    public final void mo4200a(int i) {
        this.f18191a = false;
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            int i2 = this.f18195a;
            Bundle bundle = new Bundle();
            bundle.putInt("unselectReason", i);
            int i3 = c2057.f18180a;
            c2057.f18180a = i3 + 1;
            c2057.m8467a(6, i3, i2, null, bundle);
        }
    }

    @Override // defpackage.AbstractC5424j
    /* JADX INFO: renamed from: ä */
    public final void mo4123a(int i) {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            c2057.m8470a(this.f18195a, i);
        } else {
            this.f18193a += i;
        }
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: ả */
    public final String mo4194a() {
        return this.f18189a;
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: å */
    public final String mo4195a() {
        return this.f18190a;
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: ǎ */
    public final void mo4124a(String str) {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            int i = this.f18195a;
            Bundle bundle = new Bundle();
            bundle.putString("memberRouteId", str);
            int i2 = c2057.f18180a;
            c2057.f18180a = i2 + 1;
            c2057.m8467a(12, i2, i, null, bundle);
        }
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: a̍ */
    public final void mo4125a(String str) {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            int i = this.f18195a;
            Bundle bundle = new Bundle();
            bundle.putString("memberRouteId", str);
            int i2 = c2057.f18180a;
            c2057.f18180a = i2 + 1;
            c2057.m8467a(13, i2, i, null, bundle);
        }
    }

    @Override // defpackage.AbstractC5423j
    /* JADX INFO: renamed from: a̎ */
    public final void mo4126a(ArrayList arrayList) {
        C2057 c2057 = this.f18194a;
        if (c2057 != null) {
            int i = this.f18195a;
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("memberRouteIds", new ArrayList<>(arrayList));
            int i2 = c2057.f18180a;
            c2057.f18180a = i2 + 1;
            c2057.m8467a(14, i2, i, null, bundle);
        }
    }
}
