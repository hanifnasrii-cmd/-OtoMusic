package defpackage;

/* JADX INFO: renamed from: а̀, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1324 implements InterfaceC1325 {
}
