package defpackage;

/* JADX INFO: renamed from: ρ߱, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0927 extends AbstractC6386s {
    private static final C0927 zzf;
    private int zzb;
    private String zzd = "";
    private String zze = "";

    static {
        C0927 c0927 = new C0927();
        zzf = c0927;
        AbstractC6386s.m5619a(C0927.class, c0927);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static C0926 m7010a() {
        return (C0926) zzf.m5621a();
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzf, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဈ\u0001", new Object[]{"zzb", "zzd", "zze"});
        }
        if (i2 == 3) {
            return new C0927();
        }
        if (i2 == 4) {
            return new C0926(zzf);
        }
        if (i2 == 5) {
            return zzf;
        }
        throw null;
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final /* synthetic */ void m7011a(String str) {
        str.getClass();
        this.zzb |= 1;
        this.zzd = str;
    }
}
