package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: і߽, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC3247 {
    private static final /* synthetic */ InterfaceC4935e $ENTRIES;
    private static final /* synthetic */ EnumC3247[] $VALUES;
    public static final EnumC3247 NONE;
    public static final EnumC3247 PUBLICATION;
    public static final EnumC3247 SYNCHRONIZED;

    static {
        EnumC3247 enumC3247 = new EnumC3247("SYNCHRONIZED", 0);
        SYNCHRONIZED = enumC3247;
        EnumC3247 enumC32472 = new EnumC3247("PUBLICATION", 1);
        PUBLICATION = enumC32472;
        EnumC3247 enumC32473 = new EnumC3247("NONE", 2);
        NONE = enumC32473;
        EnumC3247[] enumC3247Arr = {enumC3247, enumC32472, enumC32473};
        $VALUES = enumC3247Arr;
        $ENTRIES = AbstractC5120i.m3435a(enumC3247Arr);
    }

    public static EnumC3247 valueOf(String str) {
        return (EnumC3247) Enum.valueOf(EnumC3247.class, str);
    }

    public static EnumC3247[] values() {
        return (EnumC3247[]) $VALUES.clone();
    }
}
