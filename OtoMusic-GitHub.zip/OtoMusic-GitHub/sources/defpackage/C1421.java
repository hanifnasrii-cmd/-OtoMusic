package defpackage;

/* JADX INFO: renamed from: а͡, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1421 implements InterfaceC1422 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C1426 f15907a;

    public C1421(C1426 c1426) {
        this.f15907a = c1426;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C1421) && AbstractC3098.m10094a(this.f15907a, ((C1421) obj).f15907a);
    }

    public final int hashCode() {
        return this.f15907a.hashCode();
    }

    public final String toString() {
        return "StartFlow(info=" + this.f15907a + ")";
    }
}
