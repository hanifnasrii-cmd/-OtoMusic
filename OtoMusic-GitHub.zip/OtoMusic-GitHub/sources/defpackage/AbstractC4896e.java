package defpackage;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/* JADX INFO: renamed from: eۚ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC4896e extends AbstractC6265p {

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public static final /* synthetic */ int f6325a = 0;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final ImageView f6326a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final TextView f6327a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final TextView f6328a;

    public AbstractC4896e(InterfaceC1126 interfaceC1126, View view, ImageView imageView, TextView textView, TextView textView2) {
        super(interfaceC1126, view, 0);
        this.f6326a = imageView;
        this.f6327a = textView;
        this.f6328a = textView2;
    }
}
