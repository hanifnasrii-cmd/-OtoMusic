package defpackage;

import java.util.Iterator;
import java.util.Set;

/* JADX INFO: renamed from: јⷠ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3609 extends AbstractC4081a implements InterfaceC3048 {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final C3609 f23123a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Object f23124a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Object f23125a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C3598 f23126a;

    static {
        C0966 c0966 = C0966.f14344a;
        C3598 c3598 = C3598.f23101a;
        AbstractC3098.m10101a(c3598, "null cannot be cast to non-null type kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap<K of kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap.Companion.emptyOf, V of kotlinx.collections.immutable.implementations.immutableMap.PersistentHashMap.Companion.emptyOf>");
        f23123a = new C3609(c0966, c0966, c3598);
    }

    public C3609(Object obj, Object obj2, C3598 c3598) {
        AbstractC3098.m10103a(c3598, "hashMap");
        this.f23124a = obj;
        this.f23125a = obj2;
        this.f23126a = c3598;
    }

    @Override // defpackage.AbstractC4033a
    /* JADX INFO: renamed from: ã */
    public final int mo684a() {
        C3598 c3598 = this.f23126a;
        c3598.getClass();
        return c3598.f23103a;
    }

    @Override // defpackage.AbstractC4033a, java.util.Collection
    public final boolean contains(Object obj) {
        return this.f23126a.containsKey(obj);
    }

    @Override // defpackage.AbstractC4081a, java.util.Collection, java.util.Set
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set = (Set) obj;
        if (mo684a() != set.size()) {
            return false;
        }
        boolean z = set instanceof C3609;
        C3598 c3598 = this.f23126a;
        return z ? c3598.f23102a.m5159a(((C3609) obj).f23126a.f23102a, C3597.f23096a) : set instanceof C3610 ? c3598.f23102a.m5159a(((C3610) obj).f23130a.f23109a, C3597.f23097a) : super.equals(obj);
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public final Iterator iterator() {
        return new C3611(this.f23124a, this.f23126a);
    }
}
