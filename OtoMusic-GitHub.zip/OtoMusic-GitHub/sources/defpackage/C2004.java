package defpackage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.piyush.music.R;
import com.piyush.music.models.Song;

/* JADX INFO: renamed from: о̒, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2004 extends AbstractC4431c {

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final InterfaceC3113 f18056a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public C2003 f18057a;

    public C2004(ComponentCallbacks2C2114 componentCallbacks2C2114, InterfaceC3113 interfaceC3113) {
        super(componentCallbacks2C2114);
        this.f18056a = interfaceC3113;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: å */
    public final void mo4571a(RecyclerView recyclerView) {
        C2003 c2003 = new C2003(recyclerView.getResources().getDimensionPixelSize(R.dimen.anj));
        recyclerView.m494a(c2003);
        this.f18057a = c2003;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̍ */
    public final AbstractC2042 mo1039a(ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(viewGroup.getContext());
        int i2 = AbstractC2005.f18058a;
        final C2002 c2002 = new C2002((AbstractC2005) AbstractC1127.m7137a(layoutInflaterFrom, R.layout.ch, viewGroup, false), 0);
        AbstractC2005 abstractC2005 = (AbstractC2005) c2002.f13354a;
        abstractC2005.f18059a.setOnClickListener(new ViewOnClickListenerC4785e(6, c2002));
        abstractC2005.f18059a.setOnLongClickListener(new View.OnLongClickListener() { // from class: о̏
            @Override // android.view.View.OnLongClickListener
            public final boolean onLongClick(View view) {
                Song song = (Song) AbstractC5123i.m3553a(c2002);
                if (song == null) {
                    return false;
                }
                this.f18056a.mo8670a(song);
                return true;
            }
        });
        return c2002;
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̎ */
    public final void mo4572a(RecyclerView recyclerView) {
        C2003 c2003 = this.f18057a;
        if (c2003 != null) {
            recyclerView.m542a(c2003);
        }
        this.f18057a = null;
    }

    @Override // defpackage.AbstractC4431c
    /* JADX INFO: renamed from: a̕ */
    public final /* bridge */ /* synthetic */ AbstractC5120i mo2190a() {
        return C5974o.f10106a;
    }
}
