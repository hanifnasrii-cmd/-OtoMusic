package defpackage;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: j⃡, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5633j implements Map, InterfaceC0211, InterfaceC3190 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Map f8981a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C4221a f8982a;

    public C5633j(Map map, C4221a c4221a) {
        this.f8981a = map;
        this.f8982a = c4221a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Map m4470a() {
        return this.f8981a;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object m4471a(Object obj) {
        Map map = this.f8981a;
        Object obj2 = map.get(obj);
        return (obj2 != null || map.containsKey(obj)) ? obj2 : this.f8982a.invoke(obj);
    }

    @Override // java.util.Map
    public final void clear() {
        this.f8981a.clear();
    }

    @Override // java.util.Map
    public final boolean containsKey(Object obj) {
        return this.f8981a.containsKey(obj);
    }

    @Override // java.util.Map
    public final boolean containsValue(Object obj) {
        return this.f8981a.containsValue(obj);
    }

    @Override // java.util.Map
    public final Set entrySet() {
        return this.f8981a.entrySet();
    }

    @Override // java.util.Map
    public final boolean equals(Object obj) {
        return this.f8981a.equals(obj);
    }

    @Override // java.util.Map
    public final Object get(Object obj) {
        return this.f8981a.get(obj);
    }

    @Override // java.util.Map
    public final int hashCode() {
        return this.f8981a.hashCode();
    }

    @Override // java.util.Map
    public final boolean isEmpty() {
        return this.f8981a.isEmpty();
    }

    @Override // java.util.Map
    public final Set keySet() {
        return this.f8981a.keySet();
    }

    @Override // java.util.Map
    public final Object put(Object obj, Object obj2) {
        return this.f8981a.put(obj, obj2);
    }

    @Override // java.util.Map
    public final void putAll(Map map) {
        AbstractC3098.m10103a(map, "from");
        this.f8981a.putAll(map);
    }

    @Override // java.util.Map
    public final Object remove(Object obj) {
        return this.f8981a.remove(obj);
    }

    @Override // java.util.Map
    public final int size() {
        return this.f8981a.size();
    }

    public final String toString() {
        return this.f8981a.toString();
    }

    @Override // java.util.Map
    public final Collection values() {
        return this.f8981a.values();
    }
}
