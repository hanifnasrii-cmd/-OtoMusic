package defpackage;

/* JADX INFO: renamed from: і̕, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3000 extends AbstractC3002 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f21484a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final InterfaceC4684c f21485a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C3000(C2110 c2110, InterfaceC4681c interfaceC4681c, InterfaceC1014 interfaceC1014, InterfaceC4684c interfaceC4684c, int i) {
        super(c2110, interfaceC4681c, interfaceC1014);
        this.f21484a = i;
        this.f21485a = interfaceC4684c;
    }

    @Override // defpackage.AbstractC3002
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Object mo9969a(C3436 c3436, Object[] objArr) {
        int i = this.f21484a;
        InterfaceC4684c interfaceC4684c = this.f21485a;
        switch (i) {
            case 0:
                return interfaceC4684c.mo2805a(c3436);
            default:
                InterfaceC4682c interfaceC4682c = (InterfaceC4682c) interfaceC4684c.mo2805a(c3436);
                InterfaceC1005 interfaceC1005 = (InterfaceC1005) objArr[objArr.length - 1];
                try {
                    C2665 c2665 = new C2665(1, AbstractC5120i.m3446a(interfaceC1005));
                    c2665.m9364a();
                    c2665.m9366a(new C3204(interfaceC4682c, 2));
                    interfaceC4682c.mo2800a(new C1430(c2665, 4));
                    Object objM9363a = c2665.m9363a();
                    EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                    return objM9363a;
                } catch (Exception e) {
                    return AbstractC3085.m10074a(e, interfaceC1005);
                }
        }
    }
}
