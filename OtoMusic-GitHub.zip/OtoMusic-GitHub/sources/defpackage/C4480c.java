package defpackage;

import android.app.Application;

/* JADX INFO: renamed from: c֓, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public class C4480c extends AbstractC4303a {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C4262a f5039a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C3110 f5040a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C5481j f5041a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final C5481j f5042a;

    public C4480c(Application application) {
        super(application);
        C4262a c4262a = new C4262a(application);
        this.f5039a = c4262a;
        C3110 c3110 = new C3110(2);
        this.f5040a = c3110;
        this.f5041a = AbstractC2179.m8642a((C5482j) c4262a.f14037a, new C4298a(4));
        this.f5042a = AbstractC2179.m8642a((C5482j) c3110.f14037a, new C4298a(5));
    }
}
