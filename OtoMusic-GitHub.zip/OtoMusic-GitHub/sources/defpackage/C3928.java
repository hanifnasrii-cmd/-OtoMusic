package defpackage;

import android.net.Uri;

/* JADX INFO: renamed from: օ⃩, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3928 implements InterfaceC3929 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Uri f24061a;

    public C3928(Uri uri) {
        this.f24061a = uri;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C3928) && AbstractC3098.m10094a(this.f24061a, ((C3928) obj).f24061a);
    }

    public final int hashCode() {
        return this.f24061a.hashCode();
    }

    public final String toString() {
        return "Replace(uri=" + this.f24061a + ")";
    }
}
