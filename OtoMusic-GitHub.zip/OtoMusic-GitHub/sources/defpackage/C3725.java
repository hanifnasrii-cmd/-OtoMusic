package defpackage;

/* JADX INFO: renamed from: օ͔, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3725 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f23535a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C1839 f23536a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f23537a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C3725(C1839 c1839, InterfaceC1005 interfaceC1005) {
        super(interfaceC1005);
        this.f23536a = c1839;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f23535a = obj;
        this.f23537a |= Integer.MIN_VALUE;
        return this.f23536a.m8237a(0, this);
    }
}
