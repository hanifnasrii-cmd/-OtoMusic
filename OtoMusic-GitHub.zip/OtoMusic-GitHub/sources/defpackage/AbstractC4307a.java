package defpackage;

import android.graphics.drawable.Drawable;

/* JADX INFO: renamed from: a⵿, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC4307a {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public C4306a f1707a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public abstract void mo1195a(Drawable drawable);

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public void mo1196a(Drawable drawable) {
    }
}
