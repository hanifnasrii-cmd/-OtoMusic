package defpackage;

import java.io.File;

/* JADX INFO: renamed from: eۣ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC4903e {
    /* JADX INFO: renamed from: ã */
    boolean mo2415a(Object obj, File file, C3515 c3515);
}
