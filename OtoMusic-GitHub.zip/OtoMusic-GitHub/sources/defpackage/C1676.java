package defpackage;

import android.animation.Animator;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/* JADX INFO: renamed from: е̕, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1676 implements Animator.AnimatorListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ LinearLayout f16753a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ LinearLayout f16754a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final /* synthetic */ FrameLayout f16755a;

    public C1676(LinearLayout linearLayout, LinearLayout linearLayout2, FrameLayout frameLayout) {
        this.f16753a = linearLayout;
        this.f16754a = linearLayout2;
        this.f16755a = frameLayout;
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        LinearLayout linearLayout = this.f16753a;
        linearLayout.setVisibility(8);
        linearLayout.setAlpha(1.0f);
        this.f16754a.setAlpha(1.0f);
        FrameLayout frameLayout = this.f16755a;
        ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
        if (layoutParams == null) {
            throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
        }
        layoutParams.height = -2;
        frameLayout.setLayoutParams(layoutParams);
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationRepeat(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
    }
}
