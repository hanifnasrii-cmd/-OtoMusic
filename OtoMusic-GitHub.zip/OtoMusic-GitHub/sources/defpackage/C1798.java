package defpackage;

import android.content.Context;

/* JADX INFO: renamed from: е֫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1798 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f17142a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public InterfaceC1562 f17143a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public boolean f17144a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public boolean f17145a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C4648c f17146a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public C1585 f17147a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public C1339 f17148a;

    public C1798(Context context) {
        this.f17142a = context;
        C1532 c1532 = C1532.f16241a;
    }
}
