package defpackage;

import com.piyush.taglib.AudioProperties;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: ἱ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0020 implements Iterator {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public C0022 f11638a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C0022 f11639a = null;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f11640a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ C0023 f11641a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ int f11642a;

    public C0020(C0023 c0023, int i) {
        this.f11642a = i;
        this.f11641a = c0023;
        this.f11638a = c0023.f11657a.f11648a;
        this.f11640a = c0023.f11659a;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Object m5776a() {
        return m5777a();
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C0022 m5777a() {
        C0022 c0022 = this.f11638a;
        C0023 c0023 = this.f11641a;
        if (c0022 == c0023.f11657a) {
            throw new NoSuchElementException();
        }
        if (c0023.f11659a != this.f11640a) {
            throw new ConcurrentModificationException();
        }
        this.f11638a = c0022.f11648a;
        this.f11639a = c0022;
        return c0022;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f11638a != this.f11641a.f11657a;
    }

    @Override // java.util.Iterator
    public Object next() {
        switch (this.f11642a) {
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return m5777a().f11650a;
            default:
                return m5776a();
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        C0022 c0022 = this.f11639a;
        if (c0022 == null) {
            throw new IllegalStateException();
        }
        C0023 c0023 = this.f11641a;
        c0023.m5780a(c0022, true);
        this.f11639a = null;
        this.f11640a = c0023.f11659a;
    }
}
