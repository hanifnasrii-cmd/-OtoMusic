package defpackage;

import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: renamed from: рⷪ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class RunnableC2626 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f19875a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C2630 f19876a;

    public /* synthetic */ RunnableC2626(C2630 c2630, int i) {
        this.f19875a = i;
        this.f19876a = c2630;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f19875a) {
            case 0:
                C2630 c2630 = this.f19876a;
                c2630.getClass();
                C3097 c3097 = new C3097(c2630);
                C0410 c0410 = c2630.f19888a;
                AbstractC2582.m9223a(c0410);
                c0410.m6266a(c3097);
                break;
            default:
                C0111 c0111 = C2630.f19882a;
                c0111.m5889a("transfer with type = %d has timed out", 0);
                c0111.m5887a("notify failed transfer with type = %d, reason = %d", 0, 101);
                C2630 c26302 = this.f19876a;
                Iterator it = new HashSet(c26302.f19884a).iterator();
                while (it.hasNext()) {
                    ((C0856) it.next()).m6889a();
                }
                c26302.m9325a();
                break;
        }
    }
}
