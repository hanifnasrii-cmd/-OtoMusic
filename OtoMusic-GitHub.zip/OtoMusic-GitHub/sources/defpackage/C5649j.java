package defpackage;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.zip.GZIPOutputStream;

/* JADX INFO: renamed from: j⵿, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5649j implements Closeable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final EnumC5648j f9013a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final String f9014a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final InputStream f9015a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final long f9016a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C5646j f9017a = new C5646j(this);

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final HashMap f9018a = new HashMap();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public EnumC5645j f9019a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f9020a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public boolean f9021a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public boolean f9022a;

    public C5649j(EnumC5648j enumC5648j, String str, InputStream inputStream, long j) {
        this.f9013a = enumC5648j;
        this.f9014a = str;
        this.f9015a = inputStream;
        this.f9016a = j;
        this.f9020a = j < 0;
        this.f9022a = true;
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static void m4499a(PrintWriter printWriter, String str, String str2) {
        printWriter.append((CharSequence) str).append(": ").append((CharSequence) str2).append("\r\n");
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String m4500a(String str) {
        return (String) this.f9018a.get(str.toLowerCase());
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final boolean m4501a() {
        return "close".equals(m4500a("connection"));
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final void m4502a(OutputStream outputStream) {
        String str = this.f9014a;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("E, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        EnumC5648j enumC5648j = this.f9013a;
        try {
            if (enumC5648j == null) {
                throw new Error("sendResponse(): Status can't be null.");
            }
            String str2 = new C5642j(str).f8995a;
            if (str2 == null) {
                str2 = "US-ASCII";
            }
            PrintWriter printWriter = new PrintWriter((Writer) new BufferedWriter(new OutputStreamWriter(outputStream, str2)), false);
            printWriter.append("HTTP/1.1 ").append(enumC5648j.m4498a()).append(" \r\n");
            if (str != null) {
                m4499a(printWriter, "Content-Type", str);
            }
            if (m4500a("date") == null) {
                m4499a(printWriter, "Date", simpleDateFormat.format(new Date()));
            }
            for (Map.Entry entry : this.f9017a.entrySet()) {
                m4499a(printWriter, (String) entry.getKey(), (String) entry.getValue());
            }
            if (m4500a("connection") == null) {
                m4499a(printWriter, "Connection", this.f9022a ? "keep-alive" : "close");
            }
            if (m4500a("content-length") != null) {
                this.f9021a = false;
            }
            if (this.f9021a) {
                m4499a(printWriter, "Content-Encoding", "gzip");
                this.f9020a = true;
            }
            InputStream inputStream = this.f9015a;
            long jM4504a = inputStream != null ? this.f9016a : 0L;
            EnumC5645j enumC5645j = this.f9019a;
            EnumC5645j enumC5645j2 = EnumC5645j.HEAD;
            if (enumC5645j != enumC5645j2 && this.f9020a) {
                m4499a(printWriter, "Transfer-Encoding", "chunked");
            } else if (!this.f9021a) {
                jM4504a = m4504a(printWriter, jM4504a);
            }
            printWriter.append("\r\n");
            printWriter.flush();
            if (this.f9019a != enumC5645j2 && this.f9020a) {
                C5647j c5647j = new C5647j(outputStream);
                if (this.f9021a) {
                    GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(c5647j);
                    m4503a(gZIPOutputStream, -1L);
                    gZIPOutputStream.finish();
                } else {
                    m4503a(c5647j, -1L);
                }
                c5647j.m4497a();
            } else if (this.f9021a) {
                GZIPOutputStream gZIPOutputStream2 = new GZIPOutputStream(outputStream);
                m4503a(gZIPOutputStream2, -1L);
                gZIPOutputStream2.finish();
            } else {
                m4503a(outputStream, jM4504a);
            }
            outputStream.flush();
            C2997.m9957a(inputStream);
        } catch (IOException e) {
            C2997.f21469a.log(Level.SEVERE, "Could not send response to the client", (Throwable) e);
        }
    }

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final void m4503a(OutputStream outputStream, long j) throws IOException {
        byte[] bArr = new byte[(int) 16384];
        boolean z = j == -1;
        while (true) {
            if (j <= 0 && !z) {
                return;
            }
            int i = this.f9015a.read(bArr, 0, (int) (z ? 16384L : Math.min(j, 16384L)));
            if (i <= 0) {
                return;
            }
            outputStream.write(bArr, 0, i);
            if (!z) {
                j -= (long) i;
            }
        }
    }

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public final long m4504a(PrintWriter printWriter, long j) {
        String strM4500a = m4500a("content-length");
        if (strM4500a != null) {
            try {
                j = Long.parseLong(strM4500a);
            } catch (NumberFormatException unused) {
                C2997.f21469a.severe("content-length was no number ".concat(strM4500a));
            }
        }
        printWriter.print("Content-Length: " + j + "\r\n");
        return j;
    }

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public final void m4505a(boolean z) {
        this.f9021a = z;
    }

    /* JADX INFO: renamed from: a̡, reason: contains not printable characters */
    public final void m4506a(boolean z) {
        this.f9022a = z;
    }

    /* JADX INFO: renamed from: a̧, reason: contains not printable characters */
    public final void m4507a(EnumC5645j enumC5645j) {
        this.f9019a = enumC5645j;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        InputStream inputStream = this.f9015a;
        if (inputStream != null) {
            inputStream.close();
        }
    }
}
