package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.common.internal.a;

/* JADX INFO: renamed from: s̫, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6384s extends a {

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public static final C0111 f11400a = new C0111("CastClientImplCxless", null);

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    public final CastDevice f11401a;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final long f11402a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final Bundle f11403a;

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final String f11404a;

    public C6384s(Context context, Looper looper, C1375 c1375, CastDevice castDevice, long j, Bundle bundle, String str, C2457 c2457, C2457 c24572) {
        super(context, looper, 10, c1375, c2457, c24572, 0);
        this.f11401a = castDevice;
        this.f11402a = j;
        this.f11403a = bundle;
        this.f11404a = str;
    }

    @Override // defpackage.InterfaceC1326
    /* JADX INFO: renamed from: à */
    public final int mo5582a() {
        return 19390000;
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: â */
    public final /* synthetic */ IInterface mo1359a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.internal.ICastDeviceController");
        return iInterfaceQueryLocalInterface instanceof C2531 ? (C2531) iInterfaceQueryLocalInterface : new C2531(iBinder);
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: ã */
    public final void mo1360a() {
        try {
            try {
                C2531 c2531 = (C2531) m1366a();
                C1332 c1332M9253a = AbstractC2582.m9253a();
                Parcel parcelM9092a = c2531.m9092a();
                AbstractC2622.m9309a(parcelM9092a, c1332M9253a);
                c2531.m9095a(parcelM9092a, 1);
            } catch (RemoteException | IllegalStateException unused) {
                f11400a.m5888a("Error while disconnecting the controller interface", new Object[0]);
            }
        } finally {
            super.mo1360a();
        }
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: a̅ */
    public final C1725[] mo1362a() {
        return AbstractC1149.f14857a;
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: ȧ */
    public final Bundle mo1364a() {
        Bundle bundle = new Bundle();
        f11400a.m5887a("getRemoteService()", new Object[0]);
        CastDevice castDevice = this.f11401a;
        castDevice.getClass();
        bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", castDevice);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.f11402a);
        bundle.putString("connectionless_client_record_id", this.f11404a);
        Bundle bundle2 = this.f11403a;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        return bundle;
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: å */
    public final String mo1367a() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: a̋ */
    public final String mo1368a() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    @Override // com.google.android.gms.common.internal.a
    /* JADX INFO: renamed from: ȃ */
    public final boolean mo1374a() {
        return true;
    }
}
