package defpackage;

import java.util.Arrays;

/* JADX INFO: renamed from: ρ̫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0705 {
    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C0705);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{0, 1, 0, 0, 0, Boolean.FALSE});
    }
}
