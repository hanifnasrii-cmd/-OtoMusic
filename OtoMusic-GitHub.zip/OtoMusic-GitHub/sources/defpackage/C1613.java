package defpackage;

/* JADX INFO: renamed from: а⃫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1613 implements InterfaceC1816 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16544a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC1816 f16545a;

    public /* synthetic */ C1613(InterfaceC1816 interfaceC1816, int i) {
        this.f16544a = i;
        this.f16545a = interfaceC1816;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object m8024a(defpackage.InterfaceC1814 r5, defpackage.InterfaceC1005 r6) {
        /*
            r4 = this;
            boolean r0 = r6 instanceof defpackage.C1840
            if (r0 == 0) goto L13
            r0 = r6
            еّ r0 = (defpackage.C1840) r0
            int r1 = r0.f17402a
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f17402a = r1
            goto L18
        L13:
            еّ r0 = new еّ
            r0.<init>(r4, r6)
        L18:
            java.lang.Object r6 = r0.f17400a
            ϲ̴ r1 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r2 = r0.f17402a
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 != r3) goto L27
            defpackage.AbstractC1149.m7200a(r6)
            goto L3d
        L27:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L2f:
            defpackage.AbstractC1149.m7200a(r6)
            r0.f17402a = r3
            еֽ r6 = r4.f16545a
            java.lang.Object r5 = defpackage.AbstractC1149.m7171a(r6, r5, r0)
            if (r5 != r1) goto L3d
            return r1
        L3d:
            pׁ r5 = defpackage.C6174p.f10843a
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C1613.m8024a(еֻ, ϲ̌):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x01ba  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x01f6  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x024b  */
    /* JADX WARN: Removed duplicated region for block: B:166:0x02a2  */
    /* JADX WARN: Removed duplicated region for block: B:187:0x02f9  */
    /* JADX WARN: Removed duplicated region for block: B:207:0x033a  */
    /* JADX WARN: Removed duplicated region for block: B:265:0x0521  */
    /* JADX WARN: Removed duplicated region for block: B:301:0x058c  */
    /* JADX WARN: Removed duplicated region for block: B:321:0x05d0  */
    /* JADX WARN: Removed duplicated region for block: B:341:0x0614  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:361:0x0656  */
    /* JADX WARN: Removed duplicated region for block: B:383:0x06a1  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0138  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0179  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x002d  */
    @Override // defpackage.InterfaceC1816
    /* JADX INFO: renamed from: a̅ */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object mo674a(java.lang.Object r23, defpackage.InterfaceC1005 r24) {
        /*
            Method dump skipped, instruction units count: 1784
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C1613.mo674a(java.lang.Object, ϲ̌):java.lang.Object");
    }

    public /* synthetic */ C1613(InterfaceC1816 interfaceC1816, Object obj, int i) {
        this.f16544a = i;
        this.f16545a = interfaceC1816;
    }
}
