package defpackage;

import com.piyush.taglib.AudioProperties;
import kotlin.Metadata;

/* JADX INFO: renamed from: а⃛, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001:\u0001\u0005J\u0010\u0010\u0003\u001a\u00020\u0002H§@¢\u0006\u0004\b\u0003\u0010\u0004ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0006À\u0006\u0001"}, d2 = {"Lа⃛;", "", "Lоֹ;", "à", "(Lϲ̌;)Ljava/lang/Object;", "а⃚", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public interface InterfaceC1604 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C1603 f16530a = C1603.f16527a;

    @InterfaceC5073i("https://github.com/Piyush7890/autoeq-catalog/releases/latest/download/autoeq.json.gz")
    @InterfaceC3773
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    Object m8023a(InterfaceC1005<? super AbstractC2143> interfaceC1005);
}
