package defpackage;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/* JADX INFO: renamed from: ρ֚, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0788 extends AbstractC2516 implements Set {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public transient AbstractC0786 f14012a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public static C0805 m6759a() {
        return C0805.f14053a;
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static int m6760a(int i) {
        int iMax = Math.max(i, 2);
        if (iMax >= 751619276) {
            if (iMax < 1073741824) {
                return 1073741824;
            }
            throw new IllegalArgumentException("collection too large");
        }
        int iHighestOneBit = Integer.highestOneBit(iMax - 1);
        do {
            iHighestOneBit += iHighestOneBit;
        } while (((double) iHighestOneBit) * 0.7d < iMax);
        return iHighestOneBit;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static AbstractC0788 m6761a(LinkedHashSet linkedHashSet) {
        Object[] array = linkedHashSet.toArray();
        return m6762a(array.length, array);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static AbstractC0788 m6762a(int i, Object... objArr) {
        if (i == 0) {
            return C0805.f14053a;
        }
        if (i == 1) {
            Object obj = objArr[0];
            Objects.requireNonNull(obj);
            return new C0806(obj);
        }
        int iM6760a = m6760a(i);
        Object[] objArr2 = new Object[iM6760a];
        int i2 = iM6760a - 1;
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < i; i5++) {
            Object obj2 = objArr[i5];
            AbstractC1149.m7218a(i5, obj2);
            int iHashCode = obj2.hashCode();
            int iM2066a = AbstractC4372c.m2066a(iHashCode);
            while (true) {
                int i6 = iM2066a & i2;
                Object obj3 = objArr2[i6];
                if (obj3 == null) {
                    objArr[i4] = obj2;
                    objArr2[i6] = obj2;
                    i3 += iHashCode;
                    i4++;
                    break;
                }
                if (!obj3.equals(obj2)) {
                    iM2066a++;
                }
            }
        }
        Arrays.fill(objArr, i4, i, (Object) null);
        if (i4 == 1) {
            Object obj4 = objArr[0];
            Objects.requireNonNull(obj4);
            return new C0806(obj4);
        }
        if (m6760a(i4) < iM6760a / 2) {
            return m6762a(i4, objArr);
        }
        int length = objArr.length;
        if (i4 < (length >> 1) + (length >> 2)) {
            objArr = Arrays.copyOf(objArr, i4);
        }
        return new C0805(i3, i2, i4, objArr, objArr2);
    }

    @Override // java.util.Collection, java.util.Set
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if ((obj instanceof AbstractC0788) && (this instanceof C0805) && (((AbstractC0788) obj) instanceof C0805) && hashCode() != obj.hashCode()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            try {
                if (size() == set.size()) {
                    return containsAll(set);
                }
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        Iterator it = iterator();
        int iHashCode = 0;
        while (it.hasNext()) {
            Object next = it.next();
            iHashCode += next != null ? next.hashCode() : 0;
        }
        return iHashCode;
    }
}
