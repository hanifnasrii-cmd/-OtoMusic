package defpackage;

/* JADX INFO: renamed from: cؑ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4530c extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f5183a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C4531c f5184a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f5185a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C4530c(C4531c c4531c, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f5184a = c4531c;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f5183a = obj;
        this.f5185a |= Integer.MIN_VALUE;
        return C4531c.m2393a(this.f5184a, this);
    }
}
