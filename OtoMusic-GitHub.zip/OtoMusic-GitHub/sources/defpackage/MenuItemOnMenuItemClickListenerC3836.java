package defpackage;

import android.view.InflateException;
import android.view.MenuItem;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: օٛ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class MenuItemOnMenuItemClickListenerC3836 implements MenuItem.OnMenuItemClickListener {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final Class[] f23801a = {MenuItem.class};

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f23802a = 0;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Object f23803a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Object f23804a;

    public MenuItemOnMenuItemClickListenerC3836(Object obj, String str) {
        this.f23803a = obj;
        Class<?> cls = obj.getClass();
        try {
            this.f23804a = cls.getMethod(str, f23801a);
        } catch (Exception e) {
            StringBuilder sbM752a = AbstractC4072a.m752a("Couldn't resolve menu item onClick handler ", str, " in class ");
            sbM752a.append(cls.getName());
            InflateException inflateException = new InflateException(sbM752a.toString());
            inflateException.initCause(e);
            throw inflateException;
        }
    }

    @Override // android.view.MenuItem.OnMenuItemClickListener
    public final boolean onMenuItemClick(MenuItem menuItem) {
        switch (this.f23802a) {
            case 0:
                Method method = (Method) this.f23804a;
                try {
                    Class<?> returnType = method.getReturnType();
                    Class<?> cls = Boolean.TYPE;
                    Object obj = this.f23803a;
                    if (returnType == cls) {
                        return ((Boolean) method.invoke(obj, menuItem)).booleanValue();
                    }
                    method.invoke(obj, menuItem);
                    return true;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            default:
                return ((MenuItem.OnMenuItemClickListener) this.f23803a).onMenuItemClick(((MenuItemC5498j) this.f23804a).m7566a(menuItem));
        }
    }

    public MenuItemOnMenuItemClickListenerC3836(MenuItemC5498j menuItemC5498j, MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f23804a = menuItemC5498j;
        this.f23803a = onMenuItemClickListener;
    }
}
