package defpackage;

/* JADX INFO: renamed from: j֓, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5470j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC4453c f8491a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C2908 f8492a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C1211 f8493a;

    public C5470j(AbstractC4453c abstractC4453c, C2908 c2908, C1211 c1211) {
        this.f8491a = abstractC4453c;
        this.f8492a = c2908;
        this.f8493a = c1211;
    }
}
