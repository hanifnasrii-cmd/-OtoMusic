package defpackage;

import android.animation.ValueAnimator;
import android.view.View;

/* JADX INFO: renamed from: jܾ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC5586j {
    /* JADX INFO: renamed from: à */
    void mo3882a(ValueAnimator valueAnimator, View view);
}
