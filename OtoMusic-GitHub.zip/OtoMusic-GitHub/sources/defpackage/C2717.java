package defpackage;

import java.net.URL;

/* JADX INFO: renamed from: сͅ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2717 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final URL f20264a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C1651 f20265a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f20266a;

    public C2717(URL url, C1651 c1651, String str) {
        this.f20264a = url;
        this.f20265a = c1651;
        this.f20266a = str;
    }
}
