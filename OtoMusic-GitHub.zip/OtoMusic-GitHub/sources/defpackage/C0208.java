package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: renamed from: ι۟, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0208 extends AbstractC4069a {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f12282a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C0207 f12283a;

    public /* synthetic */ C0208(C0207 c0207, int i) {
        this.f12282a = i;
        this.f12283a = c0207;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean add(Object obj) {
        switch (this.f12282a) {
            case 0:
                AbstractC3098.m10103a((Map.Entry) obj, "element");
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean addAll(Collection collection) {
        switch (this.f12282a) {
            case 0:
                AbstractC3098.m10103a(collection, "elements");
                throw new UnsupportedOperationException();
            default:
                AbstractC3098.m10103a(collection, "elements");
                throw new UnsupportedOperationException();
        }
    }

    @Override // defpackage.AbstractC4069a
    /* JADX INFO: renamed from: ã */
    public final int mo722a() {
        switch (this.f12282a) {
        }
        return this.f12283a.f12277a;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final void clear() {
        switch (this.f12282a) {
            case 0:
                this.f12283a.clear();
                break;
            default:
                this.f12283a.clear();
                break;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean contains(Object obj) {
        switch (this.f12282a) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                return this.f12283a.m5971a((Map.Entry) obj);
            default:
                return this.f12283a.containsKey(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean containsAll(Collection collection) {
        switch (this.f12282a) {
            case 0:
                AbstractC3098.m10103a(collection, "elements");
                return this.f12283a.m5970a(collection);
            default:
                return super.containsAll(collection);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean isEmpty() {
        switch (this.f12282a) {
        }
        return this.f12283a.isEmpty();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final Iterator iterator() {
        switch (this.f12282a) {
            case 0:
                C0207 c0207 = this.f12283a;
                c0207.getClass();
                return new C0203(c0207, 0);
            default:
                C0207 c02072 = this.f12283a;
                c02072.getClass();
                return new C0206(c02072);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean remove(Object obj) {
        switch (this.f12282a) {
            case 0:
                if (obj instanceof Map.Entry) {
                    Map.Entry entry = (Map.Entry) obj;
                    C0207 c0207 = this.f12283a;
                    c0207.getClass();
                    c0207.m5968a();
                    int iM5973a = c0207.m5973a(entry.getKey());
                    if (iM5973a >= 0) {
                        Object[] objArr = c0207.f12270a;
                        AbstractC3098.m10100a(objArr);
                        if (AbstractC3098.m10094a(objArr[iM5973a], entry.getValue())) {
                            c0207.m5977a(iM5973a);
                            break;
                        }
                    }
                }
                break;
            default:
                C0207 c02072 = this.f12283a;
                c02072.m5968a();
                int iM5973a2 = c02072.m5973a(obj);
                if (iM5973a2 >= 0) {
                    c02072.m5977a(iM5973a2);
                    break;
                }
                break;
        }
        return true;
    }

    @Override // java.util.AbstractSet, java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean removeAll(Collection collection) {
        switch (this.f12282a) {
            case 0:
                AbstractC3098.m10103a(collection, "elements");
                this.f12283a.m5968a();
                break;
            default:
                AbstractC3098.m10103a(collection, "elements");
                this.f12283a.m5968a();
                break;
        }
        return super.removeAll(collection);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean retainAll(Collection collection) {
        switch (this.f12282a) {
            case 0:
                AbstractC3098.m10103a(collection, "elements");
                this.f12283a.m5968a();
                break;
            default:
                AbstractC3098.m10103a(collection, "elements");
                this.f12283a.m5968a();
                break;
        }
        return super.retainAll(collection);
    }
}
