package defpackage;

import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.datatransport.runtime.TransportRuntime;
import com.piyush.music.cast.CastOptionsProvider;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/* JADX INFO: renamed from: с̥, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2685 {

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public static final C0111 f20083a = new C0111("CastContext", null);

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static final Object f20084a = new Object();

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static volatile C2685 f20085a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Context f20086a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final C0410 f20087a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C2510 f20088a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C2693 f20089a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C0863 f20090a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final BinderC2569 f20091a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C2605 f20092a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C2630 f20093a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C2584 f20094a;

    public C2685(Context context, C2693 c2693, List list, BinderC2613 binderC2613, C0863 c0863) throws C5556j {
        C2549 c2549;
        ConnectivityManager connectivityManager;
        LinkProperties linkProperties;
        this.f20086a = context;
        this.f20089a = c2693;
        this.f20090a = c0863;
        this.f20092a = new C2605(context);
        this.f20093a = binderC2613.f19852a;
        C2566 c2566 = null;
        if (TextUtils.isEmpty(c2693.f20118a)) {
            this.f20094a = null;
        } else {
            this.f20094a = new C2584(context, c2693, binderC2613);
        }
        HashMap map = new HashMap();
        C2584 c2584 = this.f20094a;
        if (c2584 != null) {
            map.put(c2584.f19765a, c2584.f19766a);
        }
        if (list != null) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                C2584 c25842 = (C2584) it.next();
                AbstractC2582.m9224a(c25842, "Additional SessionProvider must not be null.");
                String str = c25842.f19765a;
                AbstractC2582.m9222a(str, "Category for SessionProvider must not be null or empty string.");
                AbstractC2582.m9217a("SessionProvider for category " + str + " already added", !map.containsKey(str));
                map.put(str, c25842.f19766a);
            }
        }
        c2693.f20133a = new C0859(1);
        try {
            InterfaceC2536 interfaceC2536M9184a = AbstractC2572.m9184a(context, c2693, binderC2613, map);
            try {
                C2528 c2528 = (C2528) interfaceC2536M9184a;
                Parcel parcelM9093a = c2528.m9093a(c2528.m9092a(), 6);
                IBinder strongBinder = parcelM9093a.readStrongBinder();
                if (strongBinder == null) {
                    c2549 = null;
                } else {
                    IInterface iInterfaceQueryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.cast.framework.IDiscoveryManager");
                    c2549 = iInterfaceQueryLocalInterface instanceof C2549 ? (C2549) iInterfaceQueryLocalInterface : new C2549(strongBinder, "com.google.android.gms.cast.framework.IDiscoveryManager", 0);
                }
                parcelM9093a.recycle();
                this.f20088a = new C2510(c2549);
                try {
                    C2528 c25282 = (C2528) interfaceC2536M9184a;
                    Parcel parcelM9093a2 = c25282.m9093a(c25282.m9092a(), 5);
                    IBinder strongBinder2 = parcelM9093a2.readStrongBinder();
                    if (strongBinder2 != null) {
                        IInterface iInterfaceQueryLocalInterface2 = strongBinder2.queryLocalInterface("com.google.android.gms.cast.framework.ISessionManager");
                        c2566 = iInterfaceQueryLocalInterface2 instanceof C2566 ? (C2566) iInterfaceQueryLocalInterface2 : new C2566(strongBinder2, "com.google.android.gms.cast.framework.ISessionManager", 0);
                    }
                    parcelM9093a2.recycle();
                    C0410 c0410 = new C0410(c2566, context);
                    this.f20087a = c0410;
                    AbstractC2582.m9222a("PrecacheManager", "The log tag cannot be null or empty.");
                    C2630 c2630 = this.f20093a;
                    if (c2630 != null) {
                        c2630.f19888a = c0410;
                        HandlerC2059 handlerC2059 = c2630.f19885a;
                        AbstractC2582.m9223a(handlerC2059);
                        handlerC2059.post(new RunnableC2626(c2630, 0));
                    }
                    ExecutorService executorServiceNewFixedThreadPool = Executors.newFixedThreadPool(3);
                    C0716 c0716 = new C0716(context, executorServiceNewFixedThreadPool instanceof InterfaceExecutorServiceC6362s ? (InterfaceExecutorServiceC6362s) executorServiceNewFixedThreadPool : executorServiceNewFixedThreadPool instanceof ScheduledExecutorService ? new ScheduledExecutorServiceC6366s((ScheduledExecutorService) executorServiceNewFixedThreadPool) : new C6363s(executorServiceNewFixedThreadPool));
                    AbstractC2582.m9222a("BaseNetUtils", "The log tag cannot be null or empty.");
                    C0716.f13887a.m5887a("Start monitoring connectivity changes", new Object[0]);
                    if (!c0716.f13893a && (connectivityManager = c0716.f13890a) != null) {
                        Context context2 = c0716.f13894a;
                        if (AbstractC2411.m8896a(context2, "android.permission.ACCESS_NETWORK_STATE") == 0) {
                            Network activeNetwork = connectivityManager.getActiveNetwork();
                            if (activeNetwork != null && (linkProperties = connectivityManager.getLinkProperties(activeNetwork)) != null) {
                                c0716.m6617a(activeNetwork, linkProperties);
                            }
                            NetworkRequest.Builder builderAddTransportType = new NetworkRequest.Builder().addTransportType(1);
                            if (c0716.f13896a) {
                                builderAddTransportType.setIncludeOtherUidNetworks(true);
                            } else {
                                context2.registerReceiver(c0716.f13897a, new IntentFilter("android.net.wifi.STATE_CHANGE"));
                            }
                            connectivityManager.registerNetworkCallback(builderAddTransportType.build(), c0716.f13889a);
                            c0716.f13893a = true;
                        }
                    }
                    BinderC2569 binderC2569 = new BinderC2569();
                    this.f20091a = binderC2569;
                    try {
                        C2528 c25283 = (C2528) interfaceC2536M9184a;
                        Parcel parcelM9092a = c25283.m9092a();
                        AbstractC2622.m9310a(parcelM9092a, binderC2569);
                        c25283.m9094a(parcelM9092a, 3);
                        binderC2569.f19740a.add(this.f20092a.f19827a);
                        if (!Collections.unmodifiableList(c2693.f20129a).isEmpty()) {
                            f20083a.m5889a("Setting Route Discovery for appIds: ".concat(String.valueOf(Collections.unmodifiableList(this.f20089a.f20129a))), new Object[0]);
                            C2605 c2605 = this.f20092a;
                            List listUnmodifiableList = Collections.unmodifiableList(this.f20089a.f20129a);
                            c2605.getClass();
                            C0111 c0111 = C2605.f19826a;
                            int size = listUnmodifiableList.size();
                            StringBuilder sb = new StringBuilder(String.valueOf(size).length() + 26);
                            sb.append("SetRouteDiscovery for ");
                            sb.append(size);
                            sb.append(" IDs");
                            c0111.m5887a(sb.toString(), new Object[0]);
                            LinkedHashSet<String> linkedHashSet = new LinkedHashSet();
                            Iterator it2 = listUnmodifiableList.iterator();
                            while (it2.hasNext()) {
                                linkedHashSet.add(AbstractC2451.m9042a((String) it2.next()));
                            }
                            Map map2 = c2605.f19829a;
                            c0111.m5887a("resetting routes. appIdToRouteInfo has these appId route keys: ".concat(String.valueOf(map2.keySet())), new Object[0]);
                            HashMap map3 = new HashMap();
                            synchronized (map2) {
                                try {
                                    for (String str2 : linkedHashSet) {
                                        C2602 c2602 = (C2602) map2.get(AbstractC2451.m9042a(str2));
                                        if (c2602 != null) {
                                            map3.put(str2, c2602);
                                        }
                                    }
                                    map2.clear();
                                    map2.putAll(map3);
                                } finally {
                                }
                            }
                            c0111.m5887a("Routes reset. appIdToRouteInfo has these appId route keys: ".concat(String.valueOf(map2.keySet())), new Object[0]);
                            LinkedHashSet linkedHashSet2 = c2605.f19830a;
                            synchronized (linkedHashSet2) {
                                linkedHashSet2.clear();
                                linkedHashSet2.addAll(linkedHashSet);
                            }
                            c2605.m9284a();
                        }
                        final int i = 0;
                        c0863.m6891a(new String[]{"com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED", "com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_MODE", "com.google.android.gms.cast.FLAG_FIRELOG_UPLOAD_MODE", "com.google.android.gms.cast.FLAG_ANALYTICS_LOGGING_BUCKET_SIZE", "com.google.android.gms.cast.FLAG_CLIENT_FEATURE_USAGE_ANALYTICS_ENABLED", "com.google.android.gms.cast.FLAG_CLIENT_ANALYTICS_ENABLED", "com.google.android.gms.cast.FLAG_ANALYTICS_CONSENT_TIMEOUT_SECONDS"}).m5547a(new InterfaceC3471(this) { // from class: ρͭ

                            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
                            public final /* synthetic */ C2685 f13970a;

                            {
                                this.f13970a = this;
                            }

                            @Override // defpackage.InterfaceC3471
                            /* JADX INFO: renamed from: â */
                            public final void mo1090a(Object obj) {
                                C0914 c0914;
                                EnumC0883 enumC0883M7001a;
                                switch (i) {
                                    case 0:
                                        C2685 c2685 = this.f13970a;
                                        Bundle bundle = (Bundle) obj;
                                        if (C0818.f14073a) {
                                            Context context3 = c2685.f20086a;
                                            C0863 c08632 = c2685.f20090a;
                                            C0818 c0818 = new C0818(context3, c08632, c2685.f20087a, c2685.f20093a, c2685.f20091a);
                                            int i2 = bundle.containsKey("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_MODE") ? bundle.getInt("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_MODE", 0) : (bundle.containsKey("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED") && bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED", false)) ? 1 : 0;
                                            boolean z = bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_FEATURE_USAGE_ANALYTICS_ENABLED", false);
                                            boolean z2 = bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_ANALYTICS_ENABLED", false);
                                            C0818.f14073a = z2;
                                            if (i2 == 0) {
                                                if (!z && !z2) {
                                                    return;
                                                } else {
                                                    i2 = 0;
                                                }
                                            }
                                            c0818.f14081a = new C2647(context3, bundle.getLong("com.google.android.gms.cast.FLAG_ANALYTICS_CONSENT_TIMEOUT_SECONDS", 5L));
                                            String packageName = context3.getPackageName();
                                            Locale locale = Locale.ROOT;
                                            String strM746a = AbstractC4072a.m746a(packageName, ".client_cast_analytics_data");
                                            c0818.f14082a = bundle.getLong("com.google.android.gms.cast.FLAG_FIRELOG_UPLOAD_MODE") != 0 ? 2 : 1;
                                            TransportRuntime.initialize(context3);
                                            c0818.f14080a = TransportRuntime.getInstance().newFactory(C4664c.f5604a).getTransport("CAST_SENDER_SDK", C0904.class, new C4907e("proto"), C6316p.f11218a);
                                            if (bundle.containsKey("com.google.android.gms.cast.FLAG_ANALYTICS_LOGGING_BUCKET_SIZE")) {
                                                c0818.f14078a = Long.valueOf(bundle.getLong("com.google.android.gms.cast.FLAG_ANALYTICS_LOGGING_BUCKET_SIZE"));
                                            }
                                            SharedPreferences sharedPreferences = context3.getApplicationContext().getSharedPreferences(strM746a, 0);
                                            if (i2 != 0) {
                                                C4592c c4592cM2483a = C4592c.m2483a();
                                                c4592cM2483a.f5344a = new C5166i(c08632, 27, new String[]{"com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_ERROR", "com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_CHANGE_REASON"});
                                                c4592cM2483a.f5345a = new C1725[]{AbstractC1149.f14855a};
                                                c4592cM2483a.f5342a = false;
                                                c4592cM2483a.f5343a = 8426;
                                                c08632.m3726a(0, c4592cM2483a.m2484a()).m5547a(new C4538c(c0818, packageName, i2, sharedPreferences));
                                            }
                                            if (z) {
                                                AbstractC2582.m9223a(sharedPreferences);
                                                C0111 c01112 = C0914.f14272a;
                                                synchronized (C0914.class) {
                                                    try {
                                                        if (C0914.f14274a == null) {
                                                            C0914.f14274a = new C0914(sharedPreferences, c0818, packageName);
                                                        }
                                                        c0914 = C0914.f14274a;
                                                    } catch (Throwable th) {
                                                        throw th;
                                                    }
                                                }
                                                String str3 = c0914.f14277a;
                                                SharedPreferences sharedPreferences2 = c0914.f14276a;
                                                HashSet hashSet = c0914.f14280a;
                                                String string = sharedPreferences2.getString("feature_usage_sdk_version", null);
                                                String string2 = sharedPreferences2.getString("feature_usage_package_name", null);
                                                hashSet.clear();
                                                HashSet hashSet2 = c0914.f14281a;
                                                hashSet2.clear();
                                                c0914.f14282a = 0L;
                                                String str4 = C0914.f14273a;
                                                if (str4.equals(string) && str3.equals(string2)) {
                                                    c0914.f14282a = sharedPreferences2.getLong("feature_usage_last_report_time", 0L);
                                                    long jM7031a = C0966.f14343a.m7031a();
                                                    HashSet hashSet3 = new HashSet();
                                                    for (String str5 : sharedPreferences2.getAll().keySet()) {
                                                        if (str5.startsWith("feature_usage_timestamp_")) {
                                                            long j = sharedPreferences2.getLong(str5, 0L);
                                                            if (j != 0 && jM7031a - j > 1209600000) {
                                                                hashSet3.add(str5);
                                                            } else if (str5.startsWith("feature_usage_timestamp_reported_feature_")) {
                                                                EnumC0883 enumC0883M7001a2 = C0914.m7001a(str5.substring(41));
                                                                if (enumC0883M7001a2 != null) {
                                                                    hashSet2.add(enumC0883M7001a2);
                                                                    hashSet.add(enumC0883M7001a2);
                                                                }
                                                            } else if (str5.startsWith("feature_usage_timestamp_detected_feature_") && (enumC0883M7001a = C0914.m7001a(str5.substring(41))) != null) {
                                                                hashSet.add(enumC0883M7001a);
                                                            }
                                                        }
                                                    }
                                                    c0914.m7002a(hashSet3);
                                                    AbstractC2582.m9223a(c0914.f14279a);
                                                    AbstractC2582.m9223a(c0914.f14278a);
                                                    c0914.f14279a.post(c0914.f14278a);
                                                } else {
                                                    HashSet hashSet4 = new HashSet();
                                                    for (String str6 : sharedPreferences2.getAll().keySet()) {
                                                        if (str6.startsWith("feature_usage_timestamp_")) {
                                                            hashSet4.add(str6);
                                                        }
                                                    }
                                                    hashSet4.add("feature_usage_last_report_time");
                                                    c0914.m7002a(hashSet4);
                                                    sharedPreferences2.edit().putString("feature_usage_sdk_version", str4).putString("feature_usage_package_name", str3).apply();
                                                }
                                                C0914.m7000a(EnumC0883.CAST_CONTEXT);
                                            }
                                            if (C0818.f14073a) {
                                                C0966.m7029a();
                                                return;
                                            }
                                            return;
                                        }
                                        return;
                                    default:
                                        this.f13970a.getClass();
                                        AbstractC5121i.m3511a("com.google.android.gms.cast.MAP_CAST_STATUS_CODES_TO_CAST_REASON_CODES", (Bundle) obj);
                                        return;
                                }
                            }
                        });
                        C4592c c4592cM2483a = C4592c.m2483a();
                        c4592cM2483a.f5344a = new C1274(c0863, 19, new String[]{"com.google.android.gms.cast.MAP_CAST_STATUS_CODES_TO_CAST_REASON_CODES"});
                        c4592cM2483a.f5345a = new C1725[]{AbstractC1149.f14856a};
                        c4592cM2483a.f5342a = false;
                        c4592cM2483a.f5343a = 8427;
                        final int i2 = 1;
                        c0863.m3726a(0, c4592cM2483a.m2484a()).m5547a(new InterfaceC3471(this) { // from class: ρͭ

                            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
                            public final /* synthetic */ C2685 f13970a;

                            {
                                this.f13970a = this;
                            }

                            @Override // defpackage.InterfaceC3471
                            /* JADX INFO: renamed from: â */
                            public final void mo1090a(Object obj) {
                                C0914 c0914;
                                EnumC0883 enumC0883M7001a;
                                switch (i2) {
                                    case 0:
                                        C2685 c2685 = this.f13970a;
                                        Bundle bundle = (Bundle) obj;
                                        if (C0818.f14073a) {
                                            Context context3 = c2685.f20086a;
                                            C0863 c08632 = c2685.f20090a;
                                            C0818 c0818 = new C0818(context3, c08632, c2685.f20087a, c2685.f20093a, c2685.f20091a);
                                            int i22 = bundle.containsKey("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_MODE") ? bundle.getInt("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_MODE", 0) : (bundle.containsKey("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED") && bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED", false)) ? 1 : 0;
                                            boolean z = bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_FEATURE_USAGE_ANALYTICS_ENABLED", false);
                                            boolean z2 = bundle.getBoolean("com.google.android.gms.cast.FLAG_CLIENT_ANALYTICS_ENABLED", false);
                                            C0818.f14073a = z2;
                                            if (i22 == 0) {
                                                if (!z && !z2) {
                                                    return;
                                                } else {
                                                    i22 = 0;
                                                }
                                            }
                                            c0818.f14081a = new C2647(context3, bundle.getLong("com.google.android.gms.cast.FLAG_ANALYTICS_CONSENT_TIMEOUT_SECONDS", 5L));
                                            String packageName = context3.getPackageName();
                                            Locale locale = Locale.ROOT;
                                            String strM746a = AbstractC4072a.m746a(packageName, ".client_cast_analytics_data");
                                            c0818.f14082a = bundle.getLong("com.google.android.gms.cast.FLAG_FIRELOG_UPLOAD_MODE") != 0 ? 2 : 1;
                                            TransportRuntime.initialize(context3);
                                            c0818.f14080a = TransportRuntime.getInstance().newFactory(C4664c.f5604a).getTransport("CAST_SENDER_SDK", C0904.class, new C4907e("proto"), C6316p.f11218a);
                                            if (bundle.containsKey("com.google.android.gms.cast.FLAG_ANALYTICS_LOGGING_BUCKET_SIZE")) {
                                                c0818.f14078a = Long.valueOf(bundle.getLong("com.google.android.gms.cast.FLAG_ANALYTICS_LOGGING_BUCKET_SIZE"));
                                            }
                                            SharedPreferences sharedPreferences = context3.getApplicationContext().getSharedPreferences(strM746a, 0);
                                            if (i22 != 0) {
                                                C4592c c4592cM2483a2 = C4592c.m2483a();
                                                c4592cM2483a2.f5344a = new C5166i(c08632, 27, new String[]{"com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_ERROR", "com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_CHANGE_REASON"});
                                                c4592cM2483a2.f5345a = new C1725[]{AbstractC1149.f14855a};
                                                c4592cM2483a2.f5342a = false;
                                                c4592cM2483a2.f5343a = 8426;
                                                c08632.m3726a(0, c4592cM2483a2.m2484a()).m5547a(new C4538c(c0818, packageName, i22, sharedPreferences));
                                            }
                                            if (z) {
                                                AbstractC2582.m9223a(sharedPreferences);
                                                C0111 c01112 = C0914.f14272a;
                                                synchronized (C0914.class) {
                                                    try {
                                                        if (C0914.f14274a == null) {
                                                            C0914.f14274a = new C0914(sharedPreferences, c0818, packageName);
                                                        }
                                                        c0914 = C0914.f14274a;
                                                    } catch (Throwable th) {
                                                        throw th;
                                                    }
                                                }
                                                String str3 = c0914.f14277a;
                                                SharedPreferences sharedPreferences2 = c0914.f14276a;
                                                HashSet hashSet = c0914.f14280a;
                                                String string = sharedPreferences2.getString("feature_usage_sdk_version", null);
                                                String string2 = sharedPreferences2.getString("feature_usage_package_name", null);
                                                hashSet.clear();
                                                HashSet hashSet2 = c0914.f14281a;
                                                hashSet2.clear();
                                                c0914.f14282a = 0L;
                                                String str4 = C0914.f14273a;
                                                if (str4.equals(string) && str3.equals(string2)) {
                                                    c0914.f14282a = sharedPreferences2.getLong("feature_usage_last_report_time", 0L);
                                                    long jM7031a = C0966.f14343a.m7031a();
                                                    HashSet hashSet3 = new HashSet();
                                                    for (String str5 : sharedPreferences2.getAll().keySet()) {
                                                        if (str5.startsWith("feature_usage_timestamp_")) {
                                                            long j = sharedPreferences2.getLong(str5, 0L);
                                                            if (j != 0 && jM7031a - j > 1209600000) {
                                                                hashSet3.add(str5);
                                                            } else if (str5.startsWith("feature_usage_timestamp_reported_feature_")) {
                                                                EnumC0883 enumC0883M7001a2 = C0914.m7001a(str5.substring(41));
                                                                if (enumC0883M7001a2 != null) {
                                                                    hashSet2.add(enumC0883M7001a2);
                                                                    hashSet.add(enumC0883M7001a2);
                                                                }
                                                            } else if (str5.startsWith("feature_usage_timestamp_detected_feature_") && (enumC0883M7001a = C0914.m7001a(str5.substring(41))) != null) {
                                                                hashSet.add(enumC0883M7001a);
                                                            }
                                                        }
                                                    }
                                                    c0914.m7002a(hashSet3);
                                                    AbstractC2582.m9223a(c0914.f14279a);
                                                    AbstractC2582.m9223a(c0914.f14278a);
                                                    c0914.f14279a.post(c0914.f14278a);
                                                } else {
                                                    HashSet hashSet4 = new HashSet();
                                                    for (String str6 : sharedPreferences2.getAll().keySet()) {
                                                        if (str6.startsWith("feature_usage_timestamp_")) {
                                                            hashSet4.add(str6);
                                                        }
                                                    }
                                                    hashSet4.add("feature_usage_last_report_time");
                                                    c0914.m7002a(hashSet4);
                                                    sharedPreferences2.edit().putString("feature_usage_sdk_version", str4).putString("feature_usage_package_name", str3).apply();
                                                }
                                                C0914.m7000a(EnumC0883.CAST_CONTEXT);
                                            }
                                            if (C0818.f14073a) {
                                                C0966.m7029a();
                                                return;
                                            }
                                            return;
                                        }
                                        return;
                                    default:
                                        this.f13970a.getClass();
                                        AbstractC5121i.m3511a("com.google.android.gms.cast.MAP_CAST_STATUS_CODES_TO_CAST_REASON_CODES", (Bundle) obj);
                                        return;
                                }
                            }
                        });
                    } catch (RemoteException e) {
                        throw new IllegalStateException("Failed to call addAppVisibilityListener", e);
                    }
                } catch (RemoteException e2) {
                    throw new IllegalStateException("Failed to call getSessionManagerImpl", e2);
                }
            } catch (RemoteException e3) {
                throw new IllegalStateException("Failed to call getDiscoveryManagerImpl", e3);
            }
        } catch (RemoteException e4) {
            throw new IllegalStateException("Failed to call newCastContextImpl", e4);
        }
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static C2685 m9392a(Context context) {
        AbstractC2582.m9219a();
        if (f20085a == null) {
            synchronized (f20084a) {
                if (f20085a == null) {
                    Context applicationContext = context.getApplicationContext();
                    CastOptionsProvider castOptionsProviderM9395a = m9395a(m9394a(applicationContext));
                    C2693 castOptions = castOptionsProviderM9395a.getCastOptions(applicationContext);
                    C0863 c0863 = new C0863(applicationContext);
                    try {
                        f20085a = new C2685(applicationContext, castOptions, castOptionsProviderM9395a.getAdditionalSessionProviders(applicationContext), new BinderC2613(applicationContext, C5435j.m4237a(applicationContext), castOptions, c0863), c0863);
                    } catch (C5556j e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
        return f20085a;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static C6346s m9393a(Context context, Executor executor) {
        AbstractC2582.m9219a();
        if (f20085a != null) {
            C2685 c2685 = f20085a;
            C6346s c6346s = new C6346s();
            c6346s.m5551a(c2685);
            return c6346s;
        }
        Context applicationContext = context.getApplicationContext();
        CastOptionsProvider castOptionsProviderM9395a = m9395a(m9394a(applicationContext));
        C2693 castOptions = castOptionsProviderM9395a.getCastOptions(applicationContext);
        C0863 c0863 = new C0863(applicationContext);
        CallableC0822 callableC0822 = new CallableC0822(applicationContext, castOptions, castOptionsProviderM9395a, new BinderC2613(applicationContext, C5435j.m4237a(applicationContext), castOptions, c0863), c0863);
        AbstractC2582.m9224a(executor, "Executor must not be null");
        C6346s c6346s2 = new C6346s();
        executor.execute(new RunnableC1199(c6346s2, callableC0822, 14, false));
        return c6346s2;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static String m9394a(Context context) {
        Bundle bundle;
        try {
            ApplicationInfo applicationInfo = C2436.m9009a(context).f15944a.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            if (applicationInfo == null || (bundle = applicationInfo.metaData) == null) {
                return null;
            }
            return bundle.getString("com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME");
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static CastOptionsProvider m9395a(String str) {
        try {
            if (str != null) {
                return (CastOptionsProvider) Class.forName(str).asSubclass(CastOptionsProvider.class).getDeclaredConstructor(null).newInstance(null);
            }
            throw new IllegalStateException("The fully qualified name of the implementation of OptionsProvider must be provided as a metadata in the AndroidManifest.xml with key com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME.");
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Failed to initialize CastContext with manifest options.", e);
        }
    }
}
