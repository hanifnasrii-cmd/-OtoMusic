package defpackage;

import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Spliterator;
import java.util.Spliterators;

/* JADX INFO: renamed from: р⃫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2606 extends AbstractCollection implements Serializable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final Object[] f19832a = new Object[0];

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public abstract int mo9286a(Object[] objArr);

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int mo9287a() {
        throw new UnsupportedOperationException();
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int mo9288a() {
        throw new UnsupportedOperationException();
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public abstract AbstractC2611 mo9289a();

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public abstract boolean mo9290a();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public Object[] mo9291a() {
        return null;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final void clear() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean remove(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Collection, java.lang.Iterable
    public final Spliterator spliterator() {
        return Spliterators.spliterator(this, 1296);
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final Object[] toArray() {
        return toArray(f19832a);
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        objArr.getClass();
        int size = size();
        int length = objArr.length;
        if (length < size) {
            Object[] objArrMo9291a = mo9291a();
            if (objArrMo9291a != null) {
                return Arrays.copyOfRange(objArrMo9291a, mo9288a(), mo9287a(), objArr.getClass());
            }
            if (length != 0) {
                objArr = Arrays.copyOf(objArr, 0);
            }
            objArr = Arrays.copyOf(objArr, size);
        } else if (length > size) {
            objArr[size] = null;
        }
        mo9286a(objArr);
        return objArr;
    }
}
