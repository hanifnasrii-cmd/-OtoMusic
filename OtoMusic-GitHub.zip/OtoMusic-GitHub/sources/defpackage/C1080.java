package defpackage;

import java.util.Arrays;

/* JADX INFO: renamed from: ϲ͗, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public class C1080 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float[] f14565a;

    public C1080(float[] fArr) {
        this.f14565a = fArr;
        if (fArr.length != 8) {
            throw new IllegalArgumentException("Points array size should be 8");
        }
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float m7104a() {
        return this.f14565a[6];
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float m7105a() {
        return this.f14565a[7];
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final long m7106a(float f) {
        float f2 = 1 - f;
        float[] fArr = this.f14565a;
        float f3 = f2 * f2 * f2;
        float f4 = 3 * f;
        float f5 = f4 * f2 * f2;
        float f6 = f4 * f * f2;
        float f7 = f * f * f;
        return C1801.m8215a((m7104a() * f7) + (fArr[4] * f6) + (fArr[2] * f5) + (fArr[0] * f3), (m7105a() * f7) + (fArr[5] * f6) + (fArr[3] * f5) + (fArr[1] * f3));
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C3549 m7107a(float f) {
        float f2 = 1 - f;
        long jM7106a = m7106a(f);
        float[] fArr = this.f14565a;
        float f3 = fArr[0];
        float f4 = fArr[1];
        float f5 = fArr[2];
        float f6 = fArr[3];
        float f7 = f2 * f2;
        float f8 = 2 * f2 * f;
        float f9 = f * f;
        return new C3549(AbstractC3098.m10091a(f3, f4, (f5 * f) + (f3 * f2), (f6 * f) + (f4 * f2), (fArr[4] * f9) + (f5 * f8) + (f3 * f7), (fArr[5] * f9) + (f6 * f8) + (f4 * f7), AbstractC2179.m8636a(jM7106a), AbstractC2179.m8637a(jM7106a)), AbstractC3098.m10091a(AbstractC2179.m8636a(jM7106a), AbstractC2179.m8637a(jM7106a), (m7104a() * f9) + (fArr[4] * f8) + (fArr[2] * f7), (m7105a() * f9) + (fArr[5] * f8) + (fArr[3] * f7), (m7104a() * f) + (fArr[4] * f2), (m7105a() * f) + (fArr[5] * f2), m7104a(), m7105a()));
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C5629j m7108a(C5853o c5853o) {
        float[] fArr = new float[8];
        C5629j c5629j = new C5629j(fArr);
        AbstractC1458.m7701a(this.f14565a, fArr);
        c5629j.m4466a(c5853o, 0);
        c5629j.m4466a(c5853o, 2);
        c5629j.m4466a(c5853o, 4);
        c5629j.m4466a(c5853o, 6);
        return c5629j;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1080)) {
            return false;
        }
        return Arrays.equals(this.f14565a, ((C1080) obj).f14565a);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f14565a);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("anchor0: (");
        float[] fArr = this.f14565a;
        sb.append(fArr[0]);
        sb.append(", ");
        sb.append(fArr[1]);
        sb.append(") control0: (");
        sb.append(fArr[2]);
        sb.append(", ");
        sb.append(fArr[3]);
        sb.append("), control1: (");
        sb.append(fArr[4]);
        sb.append(", ");
        sb.append(fArr[5]);
        sb.append("), anchor1: (");
        sb.append(m7104a());
        sb.append(", ");
        sb.append(m7105a());
        sb.append(')');
        return sb.toString();
    }
}
