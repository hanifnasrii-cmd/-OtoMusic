package defpackage;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import com.bumptech.glide.a;
import com.piyush.music.R;
import com.piyush.music.fragments.base.WrappedLinearLayoutManager;
import com.piyush.music.fragments.folders.FoldersOpenMode;
import com.piyush.music.models.Song;
import com.piyush.music.widget.fastscroll.FastScrollRecyclerView;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;

/* JADX INFO: renamed from: е۫, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003B\u0007¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Lе۫;", "Lc̓;", "Lc͂;", "Lcޯ;", "<init>", "()V", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public final class C1872 extends AbstractC5238i<C4427c> implements InterfaceC4618c {

    /* JADX INFO: renamed from: a̘, reason: contains not printable characters */
    public static final /* synthetic */ int f17490a = 0;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final C3865 f17491a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public C1111 f17492a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final C3865 f17493a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public boolean f17494a = true;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public String f17495a;

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final C5404j f17496a;

    /* JADX INFO: renamed from: a̗, reason: contains not printable characters */
    public final C1871 f17497a;

    public C1872() {
        final int i = 0;
        this.f17491a = new C3865(new InterfaceC5038i(this) { // from class: еۧ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17485a;

            {
                this.f17485a = this;
            }

            @Override // defpackage.InterfaceC5038i
            public final Object invoke() {
                int i2 = i;
                C1872 c1872 = this.f17485a;
                switch (i2) {
                    case 0:
                        int i3 = C1872.f17490a;
                        C1872 c18722 = this.f17485a;
                        return new C1868(c18722.requireContext(), a.m1237a(c18722.getContext()).m8566a(c18722), AbstractC6161p.m5214a(c18722), c18722.m2180a(), c18722);
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        int i4 = C1872.f17490a;
                        return new C0560(c1872.requireContext());
                    default:
                        C1111 c1111 = c1872.f17492a;
                        if (c1111 != null) {
                            return AbstractC3573.m10769a(c1111, FoldersOpenMode.NORMAL);
                        }
                        AbstractC3098.m10141a("viewModelFactory");
                        throw null;
                }
            }
        });
        final int i2 = 1;
        this.f17493a = new C3865(new InterfaceC5038i(this) { // from class: еۧ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17485a;

            {
                this.f17485a = this;
            }

            @Override // defpackage.InterfaceC5038i
            public final Object invoke() {
                int i22 = i2;
                C1872 c1872 = this.f17485a;
                switch (i22) {
                    case 0:
                        int i3 = C1872.f17490a;
                        C1872 c18722 = this.f17485a;
                        return new C1868(c18722.requireContext(), a.m1237a(c18722.getContext()).m8566a(c18722), AbstractC6161p.m5214a(c18722), c18722.m2180a(), c18722);
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        int i4 = C1872.f17490a;
                        return new C0560(c1872.requireContext());
                    default:
                        C1111 c1111 = c1872.f17492a;
                        if (c1111 != null) {
                            return AbstractC3573.m10769a(c1111, FoldersOpenMode.NORMAL);
                        }
                        AbstractC3098.m10141a("viewModelFactory");
                        throw null;
                }
            }
        });
        final int i3 = 2;
        InterfaceC5038i interfaceC5038i = new InterfaceC5038i(this) { // from class: еۧ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17485a;

            {
                this.f17485a = this;
            }

            @Override // defpackage.InterfaceC5038i
            public final Object invoke() {
                int i22 = i3;
                C1872 c1872 = this.f17485a;
                switch (i22) {
                    case 0:
                        int i32 = C1872.f17490a;
                        C1872 c18722 = this.f17485a;
                        return new C1868(c18722.requireContext(), a.m1237a(c18722.getContext()).m8566a(c18722), AbstractC6161p.m5214a(c18722), c18722.m2180a(), c18722);
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        int i4 = C1872.f17490a;
                        return new C0560(c1872.requireContext());
                    default:
                        C1111 c1111 = c1872.f17492a;
                        if (c1111 != null) {
                            return AbstractC3573.m10769a(c1111, FoldersOpenMode.NORMAL);
                        }
                        AbstractC3098.m10141a("viewModelFactory");
                        throw null;
                }
            }
        };
        InterfaceC3238 interfaceC3238M4989a = AbstractC6005o.m4989a(EnumC3247.NONE, new C4242a(8, new C4242a(7, this)));
        this.f17496a = AbstractC2582.m9230a(this, AbstractC2051.m8456a(C1760.class), new C4243a(interfaceC3238M4989a, 6), new C4243a(interfaceC3238M4989a, 7), interfaceC5038i);
        this.f17497a = new C1871(0, this);
    }

    @Override // defpackage.InterfaceC0385
    /* JADX INFO: renamed from: à */
    public final void mo1115a(ArrayList arrayList, int i, AbstractC2042 abstractC2042) {
        C4427c c4427c = (C4427c) arrayList.get(i);
        if (!(c4427c instanceof C0618)) {
            C1760 c1760M8241a = m8241a();
            AbstractC6265p abstractC6265p = this.f4707a;
            AbstractC3098.m10100a(abstractC6265p);
            androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p).f22171a.getLayoutManager();
            AbstractC3098.m10100a(layoutManager);
            c1760M8241a.f17038a.m2568a(layoutManager.mo451a(), c4427c.mo2178a());
            ((C0560) this.f17493a.getValue()).m6446a(1);
            return;
        }
        ArrayList arrayListM10126a = AbstractC3098.m10126a(arrayList);
        C5763o c5763o = C5601j.f8884a;
        int size = arrayListM10126a.size();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                i2 = -1;
                break;
            }
            Object obj = arrayListM10126a.get(i3);
            i3++;
            if (((Song) obj).getId() == ((C0618) c4427c).m6511a().getId()) {
                break;
            } else {
                i2++;
            }
        }
        C5601j.m4446a(arrayListM10126a, i2, false, 12);
    }

    @Override // defpackage.InterfaceC4618c
    /* JADX INFO: renamed from: ȃ */
    public final void mo1755a(String str, boolean z) {
        C1760 c1760M8241a = m8241a();
        AbstractC6265p abstractC6265p = this.f4707a;
        AbstractC3098.m10100a(abstractC6265p);
        androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p).f22171a.getLayoutManager();
        AbstractC3098.m10100a(layoutManager);
        c1760M8241a.f17038a.m2568a(layoutManager.mo451a(), str);
        ((C0560) this.f17493a.getValue()).m6446a(z ? 1 : -1);
    }

    @Override // defpackage.C4027a
    /* JADX INFO: renamed from: a̜ */
    public final InterfaceC1083 mo681a() {
        return mo2179a();
    }

    @Override // defpackage.AbstractC4900e
    /* JADX INFO: renamed from: a̠ */
    public final C4899e mo1118a() {
        return new C4899e(R.drawable.nt, Integer.valueOf(R.string.q1), null, 12);
    }

    @Override // defpackage.AbstractC4428c
    /* JADX INFO: renamed from: a̤ */
    public final int mo1119a() {
        return R.menu.e;
    }

    @Override // defpackage.AbstractC4428c
    /* JADX INFO: renamed from: ḁ */
    public final List mo1120a() {
        return AbstractC3098.m10126a(new ArrayList(mo2179a().f14586a));
    }

    @Override // defpackage.AbstractC4428c
    /* JADX INFO: renamed from: a̧ */
    public final boolean getF4743a() {
        return false;
    }

    @Override // defpackage.AbstractC4428c
    /* JADX INFO: renamed from: a̩, reason: contains not printable characters and merged with bridge method [inline-methods] */
    public final C1868 mo2179a() {
        return (C1868) this.f17491a.getValue();
    }

    /* JADX INFO: renamed from: a̪, reason: contains not printable characters */
    public final C1760 m8241a() {
        return (C1760) this.f17496a.getValue();
    }

    /* JADX INFO: renamed from: a̫, reason: contains not printable characters */
    public final void m8242a() {
        this.f17497a.m10585a(m2180a().m6243a() || m8241a().m8149a());
    }

    @Override // defpackage.AbstractC4428c, defpackage.AbstractC4900e, defpackage.C4027a, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        requireActivity().mo8291a().m10590a(getViewLifecycleOwner(), this.f17497a);
        final int i = 0;
        m2180a().m6241a().mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: еۨ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17487a;

            {
                this.f17487a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i2 = i;
                Object obj2 = null;
                C6174p c6174p = C6174p.f10843a;
                C1872 c1872 = this.f17487a;
                switch (i2) {
                    case 0:
                        int i3 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        AbstractC2154 abstractC2154 = (AbstractC2154) obj;
                        int i4 = C1872.f17490a;
                        if (abstractC2154 instanceof C2152) {
                            c1872.m3075a(true);
                        } else if (abstractC2154 instanceof C2150) {
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            ((C2150) abstractC2154).f18531a.printStackTrace();
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else if (abstractC2154 instanceof C2149) {
                            AbstractC6265p abstractC6265p = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p);
                            AbstractC4647c.m2675a(((C3268) abstractC6265p).f22171a, 0L, 0, 7);
                            AbstractC4647c.m2673a(c1872.m3074a(), 0L, 7);
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else {
                            if (!(abstractC2154 instanceof C2153)) {
                                throw new C2895();
                            }
                            List list = (List) ((C2153) abstractC2154).f18534a;
                            if (!c1872.f17494a) {
                                AbstractC6265p abstractC6265p2 = c1872.f4707a;
                                AbstractC3098.m10100a(abstractC6265p2);
                                ((C3268) abstractC6265p2).f22171a.setItemAnimator((C0560) c1872.f17493a.getValue());
                            }
                            c1872.f17494a = false;
                            String str = c1872.f17495a;
                            if (str == null || str.equals(c1872.m8241a().m8150a())) {
                                c1872.mo2179a().mo2145a(list, null);
                            } else {
                                c1872.mo2179a().m8148a(list);
                                Object objM5849a = c1872.m8241a().f17038a.m5849a();
                                AbstractC3098.m10100a(objM5849a);
                                Parcelable parcelableM5093a = ((C6102p) objM5849a).m5093a();
                                if (parcelableM5093a != null) {
                                    AbstractC6265p abstractC6265p3 = c1872.f4707a;
                                    AbstractC3098.m10100a(abstractC6265p3);
                                    androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p3).f22171a.getLayoutManager();
                                    AbstractC3098.m10100a(layoutManager);
                                    layoutManager.mo450a(parcelableM5093a);
                                }
                            }
                            c1872.f17495a = c1872.m8241a().m8150a();
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            AbstractC6265p abstractC6265p4 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p4);
                            AbstractC4647c.m2673a(((C3268) abstractC6265p4).f22171a, 0L, 7);
                            c1872.m3075a(false);
                        }
                        return c6174p;
                    case 2:
                        C4616c c4616c = (C4616c) obj;
                        int i5 = C1872.f17490a;
                        C1868 c1868Mo2179a = c1872.mo2179a();
                        c1868Mo2179a.f17483a = c4616c;
                        Iterator it = c1868Mo2179a.f11158a.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object next = it.next();
                                AbstractC2042 abstractC2042 = (AbstractC2042) next;
                                if ((abstractC2042 instanceof C0516) && (((C0516) abstractC2042).f13354a instanceof C3217)) {
                                    obj2 = next;
                                }
                            }
                        }
                        AbstractC2042 abstractC20422 = (AbstractC2042) obj2;
                        if (abstractC20422 != null) {
                            ((C3217) ((C0516) abstractC20422).f13354a).f22052a.setData(c4616c);
                        }
                        c1872.m8242a();
                        return c6174p;
                    default:
                        int i6 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                }
            }
        }, 15));
        final int i2 = 1;
        m8241a().f17042a.mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: еۨ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17487a;

            {
                this.f17487a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i22 = i2;
                Object obj2 = null;
                C6174p c6174p = C6174p.f10843a;
                C1872 c1872 = this.f17487a;
                switch (i22) {
                    case 0:
                        int i3 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        AbstractC2154 abstractC2154 = (AbstractC2154) obj;
                        int i4 = C1872.f17490a;
                        if (abstractC2154 instanceof C2152) {
                            c1872.m3075a(true);
                        } else if (abstractC2154 instanceof C2150) {
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            ((C2150) abstractC2154).f18531a.printStackTrace();
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else if (abstractC2154 instanceof C2149) {
                            AbstractC6265p abstractC6265p = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p);
                            AbstractC4647c.m2675a(((C3268) abstractC6265p).f22171a, 0L, 0, 7);
                            AbstractC4647c.m2673a(c1872.m3074a(), 0L, 7);
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else {
                            if (!(abstractC2154 instanceof C2153)) {
                                throw new C2895();
                            }
                            List list = (List) ((C2153) abstractC2154).f18534a;
                            if (!c1872.f17494a) {
                                AbstractC6265p abstractC6265p2 = c1872.f4707a;
                                AbstractC3098.m10100a(abstractC6265p2);
                                ((C3268) abstractC6265p2).f22171a.setItemAnimator((C0560) c1872.f17493a.getValue());
                            }
                            c1872.f17494a = false;
                            String str = c1872.f17495a;
                            if (str == null || str.equals(c1872.m8241a().m8150a())) {
                                c1872.mo2179a().mo2145a(list, null);
                            } else {
                                c1872.mo2179a().m8148a(list);
                                Object objM5849a = c1872.m8241a().f17038a.m5849a();
                                AbstractC3098.m10100a(objM5849a);
                                Parcelable parcelableM5093a = ((C6102p) objM5849a).m5093a();
                                if (parcelableM5093a != null) {
                                    AbstractC6265p abstractC6265p3 = c1872.f4707a;
                                    AbstractC3098.m10100a(abstractC6265p3);
                                    androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p3).f22171a.getLayoutManager();
                                    AbstractC3098.m10100a(layoutManager);
                                    layoutManager.mo450a(parcelableM5093a);
                                }
                            }
                            c1872.f17495a = c1872.m8241a().m8150a();
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            AbstractC6265p abstractC6265p4 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p4);
                            AbstractC4647c.m2673a(((C3268) abstractC6265p4).f22171a, 0L, 7);
                            c1872.m3075a(false);
                        }
                        return c6174p;
                    case 2:
                        C4616c c4616c = (C4616c) obj;
                        int i5 = C1872.f17490a;
                        C1868 c1868Mo2179a = c1872.mo2179a();
                        c1868Mo2179a.f17483a = c4616c;
                        Iterator it = c1868Mo2179a.f11158a.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object next = it.next();
                                AbstractC2042 abstractC2042 = (AbstractC2042) next;
                                if ((abstractC2042 instanceof C0516) && (((C0516) abstractC2042).f13354a instanceof C3217)) {
                                    obj2 = next;
                                }
                            }
                        }
                        AbstractC2042 abstractC20422 = (AbstractC2042) obj2;
                        if (abstractC20422 != null) {
                            ((C3217) ((C0516) abstractC20422).f13354a).f22052a.setData(c4616c);
                        }
                        c1872.m8242a();
                        return c6174p;
                    default:
                        int i6 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                }
            }
        }, 15));
        AbstractC6265p abstractC6265p = this.f4707a;
        AbstractC3098.m10100a(abstractC6265p);
        FastScrollRecyclerView fastScrollRecyclerView = ((C3268) abstractC6265p).f22171a;
        requireContext();
        fastScrollRecyclerView.setLayoutManager(new WrappedLinearLayoutManager(1));
        final int i3 = 2;
        m8241a().f17041a.mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: еۨ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17487a;

            {
                this.f17487a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i22 = i3;
                Object obj2 = null;
                C6174p c6174p = C6174p.f10843a;
                C1872 c1872 = this.f17487a;
                switch (i22) {
                    case 0:
                        int i32 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        AbstractC2154 abstractC2154 = (AbstractC2154) obj;
                        int i4 = C1872.f17490a;
                        if (abstractC2154 instanceof C2152) {
                            c1872.m3075a(true);
                        } else if (abstractC2154 instanceof C2150) {
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            ((C2150) abstractC2154).f18531a.printStackTrace();
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else if (abstractC2154 instanceof C2149) {
                            AbstractC6265p abstractC6265p2 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p2);
                            AbstractC4647c.m2675a(((C3268) abstractC6265p2).f22171a, 0L, 0, 7);
                            AbstractC4647c.m2673a(c1872.m3074a(), 0L, 7);
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else {
                            if (!(abstractC2154 instanceof C2153)) {
                                throw new C2895();
                            }
                            List list = (List) ((C2153) abstractC2154).f18534a;
                            if (!c1872.f17494a) {
                                AbstractC6265p abstractC6265p22 = c1872.f4707a;
                                AbstractC3098.m10100a(abstractC6265p22);
                                ((C3268) abstractC6265p22).f22171a.setItemAnimator((C0560) c1872.f17493a.getValue());
                            }
                            c1872.f17494a = false;
                            String str = c1872.f17495a;
                            if (str == null || str.equals(c1872.m8241a().m8150a())) {
                                c1872.mo2179a().mo2145a(list, null);
                            } else {
                                c1872.mo2179a().m8148a(list);
                                Object objM5849a = c1872.m8241a().f17038a.m5849a();
                                AbstractC3098.m10100a(objM5849a);
                                Parcelable parcelableM5093a = ((C6102p) objM5849a).m5093a();
                                if (parcelableM5093a != null) {
                                    AbstractC6265p abstractC6265p3 = c1872.f4707a;
                                    AbstractC3098.m10100a(abstractC6265p3);
                                    androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p3).f22171a.getLayoutManager();
                                    AbstractC3098.m10100a(layoutManager);
                                    layoutManager.mo450a(parcelableM5093a);
                                }
                            }
                            c1872.f17495a = c1872.m8241a().m8150a();
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            AbstractC6265p abstractC6265p4 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p4);
                            AbstractC4647c.m2673a(((C3268) abstractC6265p4).f22171a, 0L, 7);
                            c1872.m3075a(false);
                        }
                        return c6174p;
                    case 2:
                        C4616c c4616c = (C4616c) obj;
                        int i5 = C1872.f17490a;
                        C1868 c1868Mo2179a = c1872.mo2179a();
                        c1868Mo2179a.f17483a = c4616c;
                        Iterator it = c1868Mo2179a.f11158a.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object next = it.next();
                                AbstractC2042 abstractC2042 = (AbstractC2042) next;
                                if ((abstractC2042 instanceof C0516) && (((C0516) abstractC2042).f13354a instanceof C3217)) {
                                    obj2 = next;
                                }
                            }
                        }
                        AbstractC2042 abstractC20422 = (AbstractC2042) obj2;
                        if (abstractC20422 != null) {
                            ((C3217) ((C0516) abstractC20422).f13354a).f22052a.setData(c4616c);
                        }
                        c1872.m8242a();
                        return c6174p;
                    default:
                        int i6 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                }
            }
        }, 15));
        final int i4 = 3;
        m8241a().f17040a.mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: еۨ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C1872 f17487a;

            {
                this.f17487a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i22 = i4;
                Object obj2 = null;
                C6174p c6174p = C6174p.f10843a;
                C1872 c1872 = this.f17487a;
                switch (i22) {
                    case 0:
                        int i32 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                    case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                        AbstractC2154 abstractC2154 = (AbstractC2154) obj;
                        int i42 = C1872.f17490a;
                        if (abstractC2154 instanceof C2152) {
                            c1872.m3075a(true);
                        } else if (abstractC2154 instanceof C2150) {
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            ((C2150) abstractC2154).f18531a.printStackTrace();
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else if (abstractC2154 instanceof C2149) {
                            AbstractC6265p abstractC6265p2 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p2);
                            AbstractC4647c.m2675a(((C3268) abstractC6265p2).f22171a, 0L, 0, 7);
                            AbstractC4647c.m2673a(c1872.m3074a(), 0L, 7);
                            c1872.m3075a(false);
                            c1872.mo2179a().m8147a();
                        } else {
                            if (!(abstractC2154 instanceof C2153)) {
                                throw new C2895();
                            }
                            List list = (List) ((C2153) abstractC2154).f18534a;
                            if (!c1872.f17494a) {
                                AbstractC6265p abstractC6265p22 = c1872.f4707a;
                                AbstractC3098.m10100a(abstractC6265p22);
                                ((C3268) abstractC6265p22).f22171a.setItemAnimator((C0560) c1872.f17493a.getValue());
                            }
                            c1872.f17494a = false;
                            String str = c1872.f17495a;
                            if (str == null || str.equals(c1872.m8241a().m8150a())) {
                                c1872.mo2179a().mo2145a(list, null);
                            } else {
                                c1872.mo2179a().m8148a(list);
                                Object objM5849a = c1872.m8241a().f17038a.m5849a();
                                AbstractC3098.m10100a(objM5849a);
                                Parcelable parcelableM5093a = ((C6102p) objM5849a).m5093a();
                                if (parcelableM5093a != null) {
                                    AbstractC6265p abstractC6265p3 = c1872.f4707a;
                                    AbstractC3098.m10100a(abstractC6265p3);
                                    androidx.recyclerview.widget.a layoutManager = ((C3268) abstractC6265p3).f22171a.getLayoutManager();
                                    AbstractC3098.m10100a(layoutManager);
                                    layoutManager.mo450a(parcelableM5093a);
                                }
                            }
                            c1872.f17495a = c1872.m8241a().m8150a();
                            AbstractC4647c.m2675a(c1872.m3074a(), 0L, 0, 7);
                            AbstractC6265p abstractC6265p4 = c1872.f4707a;
                            AbstractC3098.m10100a(abstractC6265p4);
                            AbstractC4647c.m2673a(((C3268) abstractC6265p4).f22171a, 0L, 7);
                            c1872.m3075a(false);
                        }
                        return c6174p;
                    case 2:
                        C4616c c4616c = (C4616c) obj;
                        int i5 = C1872.f17490a;
                        C1868 c1868Mo2179a = c1872.mo2179a();
                        c1868Mo2179a.f17483a = c4616c;
                        Iterator it = c1868Mo2179a.f11158a.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object next = it.next();
                                AbstractC2042 abstractC2042 = (AbstractC2042) next;
                                if ((abstractC2042 instanceof C0516) && (((C0516) abstractC2042).f13354a instanceof C3217)) {
                                    obj2 = next;
                                }
                            }
                        }
                        AbstractC2042 abstractC20422 = (AbstractC2042) obj2;
                        if (abstractC20422 != null) {
                            ((C3217) ((C0516) abstractC20422).f13354a).f22052a.setData(c4616c);
                        }
                        c1872.m8242a();
                        return c6174p;
                    default:
                        int i6 = C1872.f17490a;
                        c1872.m8242a();
                        return c6174p;
                }
            }
        }, 15));
    }
}
