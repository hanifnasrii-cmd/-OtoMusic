package defpackage;

import android.media.Spatializer;

/* JADX INFO: renamed from: аۘ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract /* synthetic */ class AbstractC1527 {
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static /* bridge */ /* synthetic */ Spatializer m7788a(Object obj) {
        return (Spatializer) obj;
    }
}
