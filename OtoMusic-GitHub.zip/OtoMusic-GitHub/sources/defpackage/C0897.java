package defpackage;

/* JADX INFO: renamed from: ρܾ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0897 extends AbstractC6385s {
}
