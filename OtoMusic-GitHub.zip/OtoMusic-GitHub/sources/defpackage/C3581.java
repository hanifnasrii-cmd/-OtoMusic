package defpackage;

/* JADX INFO: renamed from: ј⃒, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3581 implements InterfaceC6105p, InterfaceC6003o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ C3587 f23054a;

    public C3581(C3587 c3587) {
        this.f23054a = c3587;
    }

    @Override // defpackage.InterfaceC5828o
    /* JADX INFO: renamed from: à */
    public final Object mo4760a(String str, InterfaceC5040i interfaceC5040i, AbstractC1006 abstractC1006) {
        return this.f23054a.mo4760a(str, interfaceC5040i, abstractC1006);
    }

    @Override // defpackage.InterfaceC6003o
    /* JADX INFO: renamed from: á */
    public final InterfaceC2205 mo4768a() {
        return this.f23054a.f23073a;
    }
}
