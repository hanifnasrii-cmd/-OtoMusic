package defpackage;

/* JADX INFO: renamed from: оٔ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2174 extends AbstractC3130 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C1275 f18567a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2174(C1275 c1275, int i) {
        super(i);
        this.f18567a = c1275;
    }

    @Override // defpackage.AbstractC3130
    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final void mo8598a(C5024i c5024i) throws Exception {
        this.f18567a.m7441a(new C3840(c5024i));
    }

    @Override // defpackage.AbstractC3130
    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void mo8599a(C5024i c5024i, int i, int i2) throws Exception {
        mo8601a(c5024i, i, i2);
    }

    @Override // defpackage.AbstractC3130
    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final void mo8600a(C5024i c5024i) throws Exception {
        C3840 c3840 = new C3840(c5024i);
        C1275 c1275 = this.f18567a;
        c1275.m7443a(c3840);
        c1275.f15415a = c5024i;
    }

    @Override // defpackage.AbstractC3130
    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final void mo8601a(C5024i c5024i, int i, int i2) throws Exception {
        this.f18567a.m7442a(new C3840(c5024i), i, i2);
    }
}
