package defpackage;

import android.os.Bundle;
import android.os.IInterface;

/* JADX INFO: renamed from: і̬, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC3023 extends IInterface {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final String f21528a = "android$support$v4$os$IResultReceiver".replace('$', '.');

    /* JADX INFO: renamed from: a͊ */
    void mo8595a(int i, Bundle bundle);
}
