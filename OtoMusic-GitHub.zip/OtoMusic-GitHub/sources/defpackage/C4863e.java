package defpackage;

import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.google.android.material.tabs.TabLayout;

/* JADX INFO: renamed from: eؔ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4863e extends C1211 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f6265a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C4863e(int i) {
        super(29);
        this.f6265a = i;
    }

    @Override // defpackage.C1211
    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final void mo3043a(TabLayout tabLayout, View view, View view2, float f, Drawable drawable) {
        float fSin;
        float fCos;
        switch (this.f6265a) {
            case 0:
                RectF rectFM7338a = C1211.m7338a(tabLayout, view);
                RectF rectFM7338a2 = C1211.m7338a(tabLayout, view2);
                if (rectFM7338a.left < rectFM7338a2.left) {
                    double d = (((double) f) * 3.141592653589793d) / 2.0d;
                    fSin = (float) (1.0d - Math.cos(d));
                    fCos = (float) Math.sin(d);
                } else {
                    double d2 = (((double) f) * 3.141592653589793d) / 2.0d;
                    fSin = (float) Math.sin(d2);
                    fCos = (float) (1.0d - Math.cos(d2));
                }
                drawable.setBounds(AbstractC4336a.m1224a((int) rectFM7338a.left, fSin, (int) rectFM7338a2.left), drawable.getBounds().top, AbstractC4336a.m1224a((int) rectFM7338a.right, fCos, (int) rectFM7338a2.right), drawable.getBounds().bottom);
                break;
            default:
                if (f >= 0.5f) {
                    view = view2;
                }
                RectF rectFM7338a3 = C1211.m7338a(tabLayout, view);
                float fM1223a = f < 0.5f ? AbstractC4336a.m1223a(1.0f, 0.0f, 0.0f, 0.5f, f) : AbstractC4336a.m1223a(0.0f, 1.0f, 0.5f, 1.0f, f);
                drawable.setBounds((int) rectFM7338a3.left, drawable.getBounds().top, (int) rectFM7338a3.right, drawable.getBounds().bottom);
                drawable.setAlpha((int) (fM1223a * 255.0f));
                break;
        }
    }
}
