package defpackage;

import java.lang.reflect.Type;

/* JADX INFO: renamed from: jۤ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5564j extends AbstractC3160 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Type f8810a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f8811a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Object f8812a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public AbstractC3160 f8813a;

    public C5564j(Type type, String str, Object obj) {
        this.f8810a = type;
        this.f8811a = str;
        this.f8812a = obj;
    }

    @Override // defpackage.AbstractC3160
    public final Object fromJson(AbstractC3171 abstractC3171) {
        AbstractC3160 abstractC3160 = this.f8813a;
        if (abstractC3160 != null) {
            return abstractC3160.fromJson(abstractC3171);
        }
        throw new IllegalStateException("JsonAdapter isn't ready");
    }

    @Override // defpackage.AbstractC3160
    public final void toJson(AbstractC3179 abstractC3179, Object obj) {
        AbstractC3160 abstractC3160 = this.f8813a;
        if (abstractC3160 == null) {
            throw new IllegalStateException("JsonAdapter isn't ready");
        }
        abstractC3160.toJson(abstractC3179, obj);
    }

    public final String toString() {
        AbstractC3160 abstractC3160 = this.f8813a;
        return abstractC3160 != null ? abstractC3160.toString() : super.toString();
    }
}
