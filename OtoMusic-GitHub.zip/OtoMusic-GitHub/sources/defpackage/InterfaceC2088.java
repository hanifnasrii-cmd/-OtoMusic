package defpackage;

/* JADX INFO: renamed from: оͦ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC2088 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    static boolean m8527a(int i, boolean z) {
        int i2 = i & 7;
        if (i2 != 4) {
            return z && i2 == 3;
        }
        return true;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    static int m8528a(int i, int i2, int i3, int i4) {
        return i | i2 | i3 | 128 | i4;
    }

    void clearListener();

    String getName();

    int getTrackType();

    void setListener(InterfaceC2087 interfaceC2087);

    int supportsFormat(C1898 c1898);

    int supportsMixedMimeTypeAdaptation();
}
