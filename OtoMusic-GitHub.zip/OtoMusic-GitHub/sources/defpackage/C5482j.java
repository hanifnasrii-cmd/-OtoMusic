package defpackage;

/* JADX INFO: renamed from: j֟, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C5482j extends C5481j {
    /* JADX INFO: renamed from: a͂, reason: contains not printable characters */
    public final void m4308a(AbstractC0077 abstractC0077, InterfaceC3422 interfaceC3422) {
        m4307a(abstractC0077);
        m4306a(abstractC0077, interfaceC3422);
    }
}
