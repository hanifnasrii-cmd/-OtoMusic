package defpackage;

import android.app.Application;
import com.piyush.music.service.MusicService;

/* JADX INFO: renamed from: ο͌, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C0407 implements InterfaceC5080i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final MusicService f12921a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C1115 f12922a;

    public C0407(MusicService musicService) {
        this.f12921a = musicService;
    }

    @Override // defpackage.InterfaceC5080i
    public final Object generatedComponent() {
        if (this.f12922a == null) {
            Application application = this.f12921a.getApplication();
            AbstractC4647c.m2662a(application instanceof InterfaceC5080i, "Hilt service must be attached to an @HiltAndroidApp Application. Found: %s", application.getClass());
            this.f12922a = new C1115(((C1118) ((InterfaceC0406) AbstractC1149.m7180a(application, InterfaceC0406.class))).f14683a);
        }
        return this.f12922a;
    }
}
