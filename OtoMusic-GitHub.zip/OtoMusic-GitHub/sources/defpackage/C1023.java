package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: renamed from: ϲ̞, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1023 extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public AbstractC1020 f14429a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public boolean f14430a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int f14431a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f14432a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f14433a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f14434a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f14435a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f14436a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public int f14437a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public int f14438a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public View f14439a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public View f14440a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public boolean f14441a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public boolean f14442a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public boolean f14443a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public final Rect f14444a;

    public C1023(int i, int i2) {
        super(i, i2);
        this.f14430a = false;
        this.f14431a = 0;
        this.f14432a = 0;
        this.f14433a = -1;
        this.f14434a = -1;
        this.f14435a = 0;
        this.f14436a = 0;
        this.f14444a = new Rect();
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean m7058a(int i) {
        if (i == 0) {
            return this.f14441a;
        }
        if (i != 1) {
            return false;
        }
        return this.f14442a;
    }

    public C1023(Context context, AttributeSet attributeSet) {
        AbstractC1020 abstractC1020;
        super(context, attributeSet);
        this.f14430a = false;
        this.f14431a = 0;
        this.f14432a = 0;
        this.f14433a = -1;
        this.f14434a = -1;
        this.f14435a = 0;
        this.f14436a = 0;
        this.f14444a = new Rect();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC5991o.f10241a);
        this.f14431a = typedArrayObtainStyledAttributes.getInteger(0, 0);
        this.f14434a = typedArrayObtainStyledAttributes.getResourceId(1, -1);
        this.f14432a = typedArrayObtainStyledAttributes.getInteger(2, 0);
        this.f14433a = typedArrayObtainStyledAttributes.getInteger(6, -1);
        this.f14435a = typedArrayObtainStyledAttributes.getInt(5, 0);
        this.f14436a = typedArrayObtainStyledAttributes.getInt(4, 0);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(3);
        this.f14430a = zHasValue;
        if (zHasValue) {
            String string = typedArrayObtainStyledAttributes.getString(3);
            String str = CoordinatorLayout.f278a;
            if (TextUtils.isEmpty(string)) {
                abstractC1020 = null;
            } else {
                if (string.startsWith(".")) {
                    string = context.getPackageName() + string;
                } else if (string.indexOf(46) < 0) {
                    String str2 = CoordinatorLayout.f278a;
                    if (!TextUtils.isEmpty(str2)) {
                        string = str2 + '.' + string;
                    }
                }
                try {
                    ThreadLocal threadLocal = CoordinatorLayout.f280a;
                    Map map = (Map) threadLocal.get();
                    if (map == null) {
                        map = new HashMap();
                        threadLocal.set(map);
                    }
                    Constructor<?> constructor = (Constructor) map.get(string);
                    if (constructor == null) {
                        constructor = Class.forName(string, false, context.getClassLoader()).getConstructor(CoordinatorLayout.f279a);
                        constructor.setAccessible(true);
                        map.put(string, constructor);
                    }
                    abstractC1020 = (AbstractC1020) constructor.newInstance(context, attributeSet);
                } catch (Exception e) {
                    throw new RuntimeException(AbstractC4072a.m759a("Could not inflate Behavior subclass ", string), e);
                }
            }
            this.f14429a = abstractC1020;
        }
        typedArrayObtainStyledAttributes.recycle();
        AbstractC1020 abstractC10202 = this.f14429a;
        if (abstractC10202 != null) {
            abstractC10202.mo1428a(this);
        }
    }

    public C1023(C1023 c1023) {
        super((ViewGroup.MarginLayoutParams) c1023);
        this.f14430a = false;
        this.f14431a = 0;
        this.f14432a = 0;
        this.f14433a = -1;
        this.f14434a = -1;
        this.f14435a = 0;
        this.f14436a = 0;
        this.f14444a = new Rect();
    }

    public C1023(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f14430a = false;
        this.f14431a = 0;
        this.f14432a = 0;
        this.f14433a = -1;
        this.f14434a = -1;
        this.f14435a = 0;
        this.f14436a = 0;
        this.f14444a = new Rect();
    }

    public C1023(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f14430a = false;
        this.f14431a = 0;
        this.f14432a = 0;
        this.f14433a = -1;
        this.f14434a = -1;
        this.f14435a = 0;
        this.f14436a = 0;
        this.f14444a = new Rect();
    }
}
