package defpackage;

import android.content.Context;
import android.graphics.Point;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import java.util.ArrayList;

/* JADX INFO: renamed from: pⷥ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C6315p {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static Integer f11213a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final View f11214a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final ArrayList f11215a = new ArrayList();

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public ViewTreeObserverOnPreDrawListenerC1089 f11216a;

    public C6315p(ImageView imageView) {
        this.f11214a = imageView;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int m5500a(int i, int i2, int i3) {
        int i4 = i2 - i3;
        if (i4 > 0) {
            return i4;
        }
        int i5 = i - i3;
        if (i5 > 0) {
            return i5;
        }
        View view = this.f11214a;
        if (view.isLayoutRequested() || i2 != -2) {
            return 0;
        }
        Log.isLoggable("ViewTarget", 4);
        Context context = view.getContext();
        if (f11213a == null) {
            WindowManager windowManager = (WindowManager) context.getSystemService("window");
            AbstractC2411.m8894a(windowManager, "Argument must not be null");
            Display defaultDisplay = windowManager.getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getSize(point);
            f11213a = Integer.valueOf(Math.max(point.x, point.y));
        }
        return f11213a.intValue();
    }
}
