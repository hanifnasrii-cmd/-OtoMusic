package defpackage;

/* JADX INFO: renamed from: cֱ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4510c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final float f5107a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final boolean f5108a;

    public C4510c(float f, boolean z) {
        this.f5107a = f;
        this.f5108a = z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C4510c)) {
            return false;
        }
        C4510c c4510c = (C4510c) obj;
        return Float.compare(this.f5107a, c4510c.f5107a) == 0 && this.f5108a == c4510c.f5108a;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f5108a) + (Float.hashCode(this.f5107a) * 31);
    }

    public final String toString() {
        return "Tick(value=" + this.f5107a + ", isMajor=" + this.f5108a + ")";
    }
}
