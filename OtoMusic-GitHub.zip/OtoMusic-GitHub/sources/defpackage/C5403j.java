package defpackage;

import android.app.Dialog;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a;
import androidx.mediarouter.app.DialogC4005a;

/* JADX INFO: renamed from: j̴, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public class C5403j extends DialogInterfaceOnCancelListenerC3984a {

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final boolean f8225a = false;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public DialogC1373 f8226a;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public C5427j f8227a;

    public C5403j() {
        this.f451a = true;
        Dialog dialog = this.f456a;
        if (dialog != null) {
            dialog.setCancelable(true);
        }
    }

    @Override // androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a
    /* JADX INFO: renamed from: a̟ */
    public final Dialog mo261a() {
        if (this.f8225a) {
            DialogC5420j dialogC5420j = new DialogC5420j(getContext());
            this.f8226a = dialogC5420j;
            dialogC5420j.m4188a(this.f8227a);
        } else {
            this.f8226a = new DialogC4005a(getContext());
        }
        return this.f8226a;
    }

    /* JADX INFO: renamed from: ạ, reason: contains not printable characters */
    public final void m4160a(C5427j c5427j) {
        if (c5427j == null) {
            throw new IllegalArgumentException("selector must not be null");
        }
        if (this.f8227a == null) {
            Bundle arguments = getArguments();
            if (arguments != null) {
                this.f8227a = C5427j.m4204a(arguments.getBundle("selector"));
            }
            if (this.f8227a == null) {
                this.f8227a = C5427j.f8354a;
            }
        }
        if (this.f8227a.equals(c5427j)) {
            return;
        }
        this.f8227a = c5427j;
        Bundle arguments2 = getArguments();
        if (arguments2 == null) {
            arguments2 = new Bundle();
        }
        arguments2.putBundle("selector", c5427j.f8355a);
        setArguments(arguments2);
        DialogC1373 dialogC1373 = this.f8226a;
        if (dialogC1373 == null || !this.f8225a) {
            return;
        }
        ((DialogC5420j) dialogC1373).m4188a(c5427j);
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        DialogC1373 dialogC1373 = this.f8226a;
        if (dialogC1373 != null) {
            if (this.f8225a) {
                ((DialogC5420j) dialogC1373).m4189a();
            } else {
                ((DialogC4005a) dialogC1373).m384a();
            }
        }
    }

    @Override // androidx.fragment.app.DialogInterfaceOnCancelListenerC3984a, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onStop() {
        super.onStop();
        DialogC1373 dialogC1373 = this.f8226a;
        if (dialogC1373 == null || this.f8225a) {
            return;
        }
        ((DialogC4005a) dialogC1373).m376a(false);
    }
}
