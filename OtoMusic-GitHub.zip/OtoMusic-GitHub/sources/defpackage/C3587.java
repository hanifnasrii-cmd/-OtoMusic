package defpackage;

import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: renamed from: ј⃘, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3587 implements InterfaceC6107p, InterfaceC6003o {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final AbstractC5067i f23072a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final InterfaceC2205 f23073a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final AtomicInteger f23074a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public EnumC6106p f23075a;

    /* JADX WARN: Multi-variable type inference failed */
    public C3587(InterfaceC5054i interfaceC5054i, InterfaceC2205 interfaceC2205) {
        AbstractC3098.m10103a(interfaceC2205, "delegate");
        this.f23072a = (AbstractC5067i) interfaceC5054i;
        this.f23073a = interfaceC2205;
        this.f23074a = new AtomicInteger(0);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r6v3, types: [i̡, i̮] */
    @Override // defpackage.InterfaceC5828o
    /* JADX INFO: renamed from: à */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object mo4760a(java.lang.String r6, defpackage.InterfaceC5040i r7, defpackage.AbstractC1006 r8) throws java.lang.Exception {
        /*
            r5 = this;
            boolean r0 = r8 instanceof defpackage.C3584
            if (r0 == 0) goto L13
            r0 = r8
            ј⃕ r0 = (defpackage.C3584) r0
            int r1 = r0.f23064a
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f23064a = r1
            goto L18
        L13:
            ј⃕ r0 = new ј⃕
            r0.<init>(r5, r8)
        L18:
            java.lang.Object r8 = r0.f23062a
            ϲ̴ r1 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r2 = r0.f23064a
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L3a
            if (r2 == r4) goto L32
            if (r2 != r3) goto L2a
            defpackage.AbstractC1149.m7200a(r8)
            return r8
        L2a:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L32:
            i̓ r7 = r0.f23061a
            java.lang.String r6 = r0.f23060a
            defpackage.AbstractC1149.m7200a(r8)
            goto L4a
        L3a:
            defpackage.AbstractC1149.m7200a(r8)
            r0.f23060a = r6
            r0.f23061a = r7
            r0.f23064a = r4
            java.lang.Boolean r8 = r5.mo4769a(r0)
            if (r8 != r1) goto L4a
            goto L66
        L4a:
            java.lang.Boolean r8 = (java.lang.Boolean) r8
            boolean r8 = r8.booleanValue()
            r2 = 0
            if (r8 == 0) goto L68
            ј⃖ r8 = new ј⃖
            r8.<init>(r5, r6, r7, r2)
            r0.f23060a = r2
            r0.f23061a = r2
            r0.f23064a = r3
            i̮ r6 = r5.f23072a
            java.lang.Object r6 = r6.invoke(r8, r0)
            if (r6 != r1) goto L67
        L66:
            return r1
        L67:
            return r6
        L68:
            оۭ r8 = r5.f23073a
            оܰ r6 = r8.mo8687a(r6)
            java.lang.Object r7 = r7.invoke(r6)     // Catch: java.lang.Throwable -> L76
            defpackage.AbstractC2582.m9226a(r6, r2)
            return r7
        L76:
            r7 = move-exception
            throw r7     // Catch: java.lang.Throwable -> L78
        L78:
            r8 = move-exception
            defpackage.AbstractC2582.m9226a(r6, r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C3587.mo4760a(java.lang.String, i̓, ϲ̍):java.lang.Object");
    }

    @Override // defpackage.InterfaceC6003o
    /* JADX INFO: renamed from: á */
    public final InterfaceC2205 mo4768a() {
        return this.f23073a;
    }

    @Override // defpackage.InterfaceC6107p
    /* JADX INFO: renamed from: â */
    public final Boolean mo4769a(InterfaceC1005 interfaceC1005) {
        return Boolean.valueOf(this.f23075a != null || this.f23073a.mo8686a());
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [i̡, i̮] */
    @Override // defpackage.InterfaceC6107p
    /* JADX INFO: renamed from: ã */
    public final Object mo4770a(EnumC6106p enumC6106p, InterfaceC5054i interfaceC5054i, AbstractC3855 abstractC3855) {
        Object objInvoke = this.f23072a.invoke(new C3586(this, enumC6106p, interfaceC5054i, null), abstractC3855);
        EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
        return objInvoke;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object m10788a(defpackage.EnumC6106p r9, defpackage.InterfaceC5054i r10, defpackage.AbstractC1006 r11) {
        /*
            r8 = this;
            boolean r0 = r11 instanceof defpackage.C3583
            if (r0 == 0) goto L13
            r0 = r11
            ј⃔ r0 = (defpackage.C3583) r0
            int r1 = r0.f23059a
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f23059a = r1
            goto L18
        L13:
            ј⃔ r0 = new ј⃔
            r0.<init>(r8, r11)
        L18:
            java.lang.Object r11 = r0.f23057a
            ϲ̴ r1 = defpackage.EnumC1045.COROUTINE_SUSPENDED
            int r2 = r0.f23059a
            java.lang.String r3 = "ROLLBACK TRANSACTION"
            r4 = 0
            java.util.concurrent.atomic.AtomicInteger r5 = r8.f23074a
            r6 = 1
            оۭ r7 = r8.f23073a
            if (r2 == 0) goto L3a
            if (r2 != r6) goto L32
            int r6 = r0.f23056a
            defpackage.AbstractC1149.m7200a(r11)     // Catch: java.lang.Throwable -> L30
            goto L7d
        L30:
            r9 = move-exception
            goto L91
        L32:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
            r9.<init>(r10)
            throw r9
        L3a:
            defpackage.AbstractC1149.m7200a(r11)
            int[] r11 = defpackage.AbstractC3582.f23055a
            int r2 = r9.ordinal()
            r11 = r11[r2]
            if (r11 == r6) goto L60
            r2 = 2
            if (r11 == r2) goto L5a
            r2 = 3
            if (r11 != r2) goto L53
            java.lang.String r11 = "BEGIN EXCLUSIVE TRANSACTION"
            defpackage.AbstractC6161p.m5209a(r7, r11)
            goto L65
        L53:
            с݊ r9 = new с݊
            r10 = 0
            r9.<init>(r10)
            throw r9
        L5a:
            java.lang.String r11 = "BEGIN IMMEDIATE TRANSACTION"
            defpackage.AbstractC6161p.m5209a(r7, r11)
            goto L65
        L60:
            java.lang.String r11 = "BEGIN DEFERRED TRANSACTION"
            defpackage.AbstractC6161p.m5209a(r7, r11)
        L65:
            int r11 = r5.incrementAndGet()
            if (r11 <= 0) goto L6d
            r8.f23075a = r9
        L6d:
            ј⃒ r9 = new ј⃒     // Catch: java.lang.Throwable -> L30
            r9.<init>(r8)     // Catch: java.lang.Throwable -> L30
            r0.f23056a = r6     // Catch: java.lang.Throwable -> L30
            r0.f23059a = r6     // Catch: java.lang.Throwable -> L30
            java.lang.Object r11 = r10.invoke(r9, r0)     // Catch: java.lang.Throwable -> L30
            if (r11 != r1) goto L7d
            return r1
        L7d:
            int r9 = r5.decrementAndGet()
            if (r9 != 0) goto L85
            r8.f23075a = r4
        L85:
            if (r6 == 0) goto L8d
            java.lang.String r9 = "END TRANSACTION"
            defpackage.AbstractC6161p.m5209a(r7, r9)
            return r11
        L8d:
            defpackage.AbstractC6161p.m5209a(r7, r3)
            return r11
        L91:
            throw r9     // Catch: java.lang.Throwable -> L92
        L92:
            r10 = move-exception
            int r11 = r5.decrementAndGet()     // Catch: android.database.SQLException -> L9c
            if (r11 != 0) goto L9e
            r8.f23075a = r4     // Catch: android.database.SQLException -> L9c
            goto L9e
        L9c:
            r11 = move-exception
            goto La2
        L9e:
            defpackage.AbstractC6161p.m5209a(r7, r3)     // Catch: android.database.SQLException -> L9c
            goto La5
        La2:
            defpackage.AbstractC4611c.m2514a(r9, r11)
        La5:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C3587.m10788a(p͟, i̡, ϲ̍):java.lang.Object");
    }
}
