package defpackage;

import android.text.Editable;
import android.text.TextWatcher;
import com.piyush.music.fragments.equalizer.autoeq.picker.AutoEqPickerViewModel;
import com.piyush.music.fragments.lyrics.EditLyricsFragment;
import com.piyush.music.fragments.search.SearchFragment;
import com.piyush.music.fragments.search.SearchViewModel;
import com.piyush.music.fragments.settings.SettingsMainFragment;
import com.piyush.music.fragments.settings.search.SettingsSearchController;
import com.piyush.music.widget.expandablesearchview.ExpandableSearchView;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: аⷨ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1631 implements TextWatcher {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16583a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f16584a;

    public /* synthetic */ C1631(int i, Object obj) {
        this.f16583a = i;
        this.f16584a = obj;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    private final void m8025a(Editable editable) {
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    private final void m8026a(Editable editable) {
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    private final void m8027a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    private final void m8028a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    private final void m8029a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    private final void m8030a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    private final void m8031a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    private final void m8032a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    private final void m8033a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    private final void m8034a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    private final void m8035a(int i, int i2, int i3, CharSequence charSequence) {
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    private final void m8036a(int i, int i2, int i3, CharSequence charSequence) {
    }

    @Override // android.text.TextWatcher
    public final void afterTextChanged(Editable editable) {
        switch (this.f16583a) {
            case 0:
                AutoEqPickerViewModel autoEqPickerViewModelM8038a = ((C1632) this.f16584a).m8038a();
                String string = editable != null ? editable.toString() : null;
                if (string == null) {
                    string = "";
                }
                C3735 c3735 = autoEqPickerViewModelM8038a.f3174a;
                c3735.getClass();
                c3735.m10932a(null, string);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                EditLyricsFragment editLyricsFragment = (EditLyricsFragment) this.f16584a;
                if (!editLyricsFragment.f3244a) {
                    String string2 = editable != null ? editable.toString() : null;
                    if (string2 == null) {
                        string2 = "";
                    }
                    editLyricsFragment.m1776a().m3038a(string2);
                    editLyricsFragment.m1772a(AbstractC4855e.m3037a(string2), string2);
                    break;
                }
                break;
            case 2:
            case 3:
                break;
            case 4:
                SettingsMainFragment settingsMainFragment = (SettingsMainFragment) this.f16584a;
                String string3 = editable != null ? editable.toString() : null;
                if (string3 == null) {
                    string3 = "";
                }
                C3735 c37352 = ((SettingsSearchController) settingsMainFragment.f3342a.getValue()).f3353a;
                c37352.getClass();
                c37352.m10932a(null, string3);
                AbstractC6265p abstractC6265p = settingsMainFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p);
                ((AbstractC0425) abstractC6265p).f12958a.setVisibility(string3.length() > 0 ? 0 : 8);
                break;
            default:
                String string4 = editable != null ? editable.toString() : null;
                if (string4 == null) {
                    string4 = "";
                }
                if (string4.length() == 1) {
                    C3860 c3860 = (C3860) this.f16584a;
                    C5872o c5872o = c3860.f23872a;
                    c3860.m11034a();
                    if (c5872o != null) {
                        c5872o.invoke(string4);
                    }
                }
                break;
        }
    }

    @Override // android.text.TextWatcher
    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        int i4 = this.f16583a;
    }

    @Override // android.text.TextWatcher
    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        switch (this.f16583a) {
            case 0:
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return;
            case 2:
                ((ExpandableSearchView) this.f16584a).getClearButton().setVisibility(charSequence.length() > 0 ? 0 : 8);
                return;
            case 3:
                SearchFragment searchFragment = (SearchFragment) this.f16584a;
                C0560 c0560 = searchFragment.f3315a;
                if (c0560 == null) {
                    AbstractC3098.m10141a("slideItemAnimator");
                    throw null;
                }
                c0560.m6447a(0.0f);
                searchFragment.f3317a = false;
                SearchViewModel searchViewModelM1802a = searchFragment.m1802a();
                String strValueOf = String.valueOf(charSequence);
                C3735 c3735 = searchViewModelM1802a.f3333a;
                c3735.getClass();
                c3735.m10932a(null, strValueOf);
                C2270 c2270 = searchFragment.f3316a;
                if (c2270 == null) {
                    AbstractC3098.m10141a("adapter");
                    throw null;
                }
                for (AbstractC2042 abstractC2042 : c2270.f11158a) {
                    int iM8440a = abstractC2042.m8440a();
                    if (iM8440a != -1 && iM8440a < c2270.m8722a().size()) {
                        c2270.m8721a(abstractC2042, c2270.m8722a().get(iM8440a));
                    }
                }
                return;
            case 4:
            default:
                return;
        }
    }
}
