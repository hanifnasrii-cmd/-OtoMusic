package defpackage;

/* JADX INFO: renamed from: e߽, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractRunnableC4959e implements Runnable, Comparable, InterfaceC4739e {
    private volatile Object _heap;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public long f6542a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f6543a = -1;

    public AbstractRunnableC4959e(long j) {
        this.f6542a = j;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int m3147a(long j, C4960e c4960e, AbstractC4961e abstractC4961e) {
        synchronized (this) {
            if (this._heap == AbstractC5120i.f7072a) {
                return 2;
            }
            synchronized (c4960e) {
                try {
                    AbstractRunnableC4959e[] abstractRunnableC4959eArr = c4960e.f10335a;
                    AbstractRunnableC4959e abstractRunnableC4959e = abstractRunnableC4959eArr != null ? abstractRunnableC4959eArr[0] : null;
                    if (AbstractC4961e.f6547a.get(abstractC4961e) != 0) {
                        return 1;
                    }
                    if (abstractRunnableC4959e == null) {
                        c4960e.f6544a = j;
                    } else {
                        long j2 = abstractRunnableC4959e.f6542a;
                        if (j2 - j < 0) {
                            j = j2;
                        }
                        if (j - c4960e.f6544a > 0) {
                            c4960e.f6544a = j;
                        }
                    }
                    long j3 = this.f6542a;
                    long j4 = c4960e.f6544a;
                    if (j3 - j4 < 0) {
                        this.f6542a = j4;
                    }
                    c4960e.m5016a(this);
                    return 0;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    @Override // defpackage.InterfaceC4739e
    /* JADX INFO: renamed from: á */
    public final void mo2889a() {
        synchronized (this) {
            try {
                Object obj = this._heap;
                C5948o c5948o = AbstractC5120i.f7072a;
                if (obj == c5948o) {
                    return;
                }
                C4960e c4960e = obj instanceof C4960e ? (C4960e) obj : null;
                if (c4960e != null) {
                    synchronized (c4960e) {
                        Object obj2 = this._heap;
                        if ((obj2 instanceof C6020p ? (C6020p) obj2 : null) != null) {
                            c4960e.m5017a(this.f6543a);
                        }
                    }
                }
                this._heap = c5948o;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m3148a(C4960e c4960e) {
        if (this._heap == AbstractC5120i.f7072a) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        this._heap = c4960e;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        long j = this.f6542a - ((AbstractRunnableC4959e) obj).f6542a;
        if (j > 0) {
            return 1;
        }
        return j < 0 ? -1 : 0;
    }

    public String toString() {
        return "Delayed[nanos=" + this.f6542a + ']';
    }
}
