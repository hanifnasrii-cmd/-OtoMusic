package defpackage;

/* JADX INFO: renamed from: ρⷻ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0988 extends AbstractC6386s {
    private static final C0988 zzh;
    private int zzb;
    private int zzd;
    private InterfaceC6391s zze;
    private InterfaceC6391s zzf;
    private int zzg;

    static {
        C0988 c0988 = new C0988();
        zzh = c0988;
        AbstractC6386s.m5619a(C0988.class, c0988);
    }

    public C0988() {
        C6406s c6406s = C6406s.f11436a;
        this.zze = c6406s;
        this.zzf = c6406s;
    }

    @Override // defpackage.AbstractC6386s
    /* JADX INFO: renamed from: ä */
    public final Object mo5529a(int i, AbstractC6386s abstractC6386s) {
        int i2 = i - 1;
        if (i2 == 0) {
            return (byte) 1;
        }
        if (i2 == 2) {
            return new C6407s(zzh, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001᠌\u0000\u0002\u001b\u0003\u001b\u0004င\u0001", new Object[]{"zzb", "zzd", C0869.f14196a, "zze", C0960.class, "zzf", C0960.class, "zzg"});
        }
        if (i2 == 3) {
            return new C0988();
        }
        if (i2 == 4) {
            return new C0981(zzh);
        }
        if (i2 == 5) {
            return zzh;
        }
        throw null;
    }
}
