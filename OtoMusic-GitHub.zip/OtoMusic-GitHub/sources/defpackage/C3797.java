package defpackage;

import com.piyush.music.R;

/* JADX INFO: renamed from: օָ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3797 extends AbstractC2503 {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f23734a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f23735a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C0585 f23736a;

    public C3797(C3798 c3798) {
        super(2);
        this.f23734a = R.string.hv;
        this.f23735a = R.string.qt;
        this.f23736a = new C0585(1, c3798);
    }

    @Override // defpackage.AbstractC2503
    /* JADX INFO: renamed from: à */
    public final Integer mo5935a() {
        return Integer.valueOf(this.f23735a);
    }

    @Override // defpackage.AbstractC2503
    /* JADX INFO: renamed from: á */
    public final InterfaceC0583 mo5936a() {
        return this.f23736a;
    }

    @Override // defpackage.AbstractC2503
    /* JADX INFO: renamed from: ã */
    public final Integer mo5937a() {
        return Integer.valueOf(this.f23734a);
    }

    @Override // defpackage.AbstractC2503
    /* JADX INFO: renamed from: ā */
    public final int mo5938a() {
        return 0;
    }
}
