package defpackage;

import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import android.widget.Toast;
import androidx.fragment.app.AbstractActivityC3991a;
import com.bumptech.glide.a;
import com.piyush.music.R;
import com.piyush.music.activities.main.MainActivity;
import com.piyush.music.dialogs.splitsymbols.MultipleGenresSymbolsSheetDialog;
import com.piyush.music.fragments.base.WrappedGridLayoutManager;
import com.piyush.music.models.NowPlayingTheme;
import com.piyush.music.models.Song;
import com.piyush.music.service.MusicService;
import com.piyush.taglib.AudioProperties;
import com.piyush.taglib.Metadata;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: i͓, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C5104i implements InterfaceC5040i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f7003a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f7004a;

    public /* synthetic */ C5104i(int i, Object obj) {
        this.f7003a = i;
        this.f7004a = obj;
    }

    @Override // defpackage.InterfaceC5040i
    public final Object invoke(Object obj) {
        String str;
        int i = this.f7003a;
        int i2 = 17;
        int i3 = 4;
        C2152 c2152 = C2152.f18533a;
        int i4 = 2;
        int i5 = 0;
        InterfaceC1005 interfaceC1005 = null;
        C6174p c6174p = C6174p.f10843a;
        Object obj2 = this.f7004a;
        switch (i) {
            case 0:
                String[] strArr = ((Metadata) obj2).getPropertyMap().get((String) obj);
                if (strArr == null || (str = (String) AbstractC1458.m7708a(strArr)) == null || AbstractC3778.m10973a(str)) {
                    return null;
                }
                return str;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                AbstractC5172i abstractC5172i = (AbstractC5172i) obj2;
                int i6 = AbstractC5172i.f7343a;
                int iM3799a = abstractC5172i.m3806a().m3799a(abstractC5172i.getF16074a());
                AbstractC6265p abstractC6265p = abstractC5172i.f4707a;
                AbstractC3098.m10100a(abstractC6265p);
                int itemDecorationCount = ((C3268) abstractC6265p).f22171a.getItemDecorationCount();
                while (true) {
                    if (i5 < itemDecorationCount) {
                        AbstractC6265p abstractC6265p2 = abstractC5172i.f4707a;
                        AbstractC3098.m10100a(abstractC6265p2);
                        if (((C3268) abstractC6265p2).f22171a.m525a(i5) instanceof C3707) {
                            AbstractC6265p abstractC6265p3 = abstractC5172i.f4707a;
                            AbstractC3098.m10100a(abstractC6265p3);
                            AbstractC2022 abstractC2022M525a = ((C3268) abstractC6265p3).f22171a.m525a(i5);
                            if (abstractC2022M525a == null) {
                                throw new NullPointerException("null cannot be cast to non-null type com.piyush.music.itemdecoration.StaggeredGridItemDecoration");
                            }
                        } else {
                            i5++;
                        }
                    }
                }
                WrappedGridLayoutManager wrappedGridLayoutManager = abstractC5172i.f7344a;
                if (wrappedGridLayoutManager == null) {
                    AbstractC3098.m10141a("layoutManager");
                    throw null;
                }
                wrappedGridLayoutManager.m435a(iM3799a);
                AbstractC0650 abstractC0650Mo1122a = abstractC5172i.mo1122a();
                abstractC0650Mo1122a.getClass();
                ArrayList arrayList = abstractC0650Mo1122a.f14584a;
                ArrayList arrayList2 = new ArrayList(arrayList);
                int size = arrayList.size();
                arrayList.clear();
                abstractC0650Mo1122a.m7116a(size);
                arrayList.addAll(arrayList2);
                abstractC0650Mo1122a.m7115a(arrayList.size());
                abstractC0650Mo1122a.m6561a();
                return c6174p;
            case 2:
                C5267i c5267i = (C5267i) obj2;
                AbstractC1149.m7188a(c5267i.f7719a, null, null, new C1475(i4, interfaceC1005, c5267i, (Map) obj), 3);
                return c6174p;
            case 3:
                C3109 c3109 = (C3109) obj2;
                C0485 c0485 = ((C0492) c3109.f21757a).f13237a;
                InterfaceC3192 interfaceC3192 = C0492.f13161a[40];
                c3109.mo4305a(Boolean.valueOf(AbstractC3098.m10094a((String) obj, (String) c0485.m6329a())));
                return c6174p;
            case 4:
                C1222.f15216a.m7365a(new C4173a((C3213) obj2, 16, (List) obj));
                return c6174p;
            case 5:
                C0627 c0627 = (C0627) obj;
                Song song = (Song) ((Map) obj2).get(c0627.f13673a);
                if (song != null) {
                    return new C3549(song, Integer.valueOf(c0627.f13674a));
                }
                return null;
            case 6:
                NowPlayingTheme nowPlayingTheme = (NowPlayingTheme) obj;
                int i7 = C0172.f12167a;
                AbstractC6265p abstractC6265p4 = ((C0172) obj2).f4707a;
                AbstractC3098.m10100a(abstractC6265p4);
                C3877 c3877 = ((AbstractC1947) abstractC6265p4).f17841a;
                i = nowPlayingTheme != NowPlayingTheme.GRADIENT_BLUR ? 0 : 1;
                if (c3877.m11067a()) {
                    ((View) c3877.f23923a).setVisibility(i != 0 ? 0 : 8);
                } else if (i != 0) {
                    ViewStub viewStub = (ViewStub) c3877.f23921a;
                    AbstractC3098.m10100a(viewStub);
                    viewStub.inflate();
                }
                return c6174p;
            case 7:
                C0174 c0174 = (C0174) obj2;
                int i8 = C0174.f12172a;
                C5084i c5084i = C5133i.f7171a;
                C2104 c2104 = (C2104) ((C2104) C5133i.m3653a(a.m1237a(c0174.getContext()).m8566a(c0174), (Song) obj, null, 8).mo2264a(AbstractC2943.f21027a)).mo2253a(1000, 1000);
                c2104.m8548a(c0174.f12176a, null, c2104, AbstractC5121i.f7085a);
                return c6174p;
            case 8:
                NowPlayingTheme nowPlayingTheme2 = (NowPlayingTheme) obj;
                int i9 = C0194.f12236a;
                AbstractC6265p abstractC6265p5 = ((C0194) obj2).f4707a;
                AbstractC3098.m10100a(abstractC6265p5);
                C3877 c38772 = ((AbstractC1947) abstractC6265p5).f17841a;
                i = nowPlayingTheme2 != NowPlayingTheme.GRADIENT ? 0 : 1;
                if (c38772.m11067a()) {
                    ((View) c38772.f23923a).setVisibility(i != 0 ? 0 : 8);
                } else if (i != 0) {
                    ViewStub viewStub2 = (ViewStub) c38772.f23921a;
                    AbstractC3098.m10100a(viewStub2);
                    viewStub2.inflate();
                }
                return c6174p;
            case 9:
                MusicService musicService = ((C5447j) obj2).f8428a;
                int i10 = MusicService.f3779a;
                musicService.m1898a((List) obj, 0, true, null);
                return c6174p;
            case 10:
                ((C5534j) obj2).m4375a().f3056a.m10931a(((C2669) obj).f20004a);
                return c6174p;
            case 11:
                C1494 c1494 = (C1494) obj2;
                AbstractC1149.m7188a((C1003) c1494.f16104a, null, null, new C4197a(i2, interfaceC1005, c1494, (Map) obj), 3);
                return c6174p;
            case 12:
                ArrayList arrayList3 = (ArrayList) obj2;
                String str2 = (String) obj;
                int size2 = arrayList3.size();
                int i11 = 0;
                int i12 = 0;
                int i13 = 0;
                while (i13 < size2) {
                    Object obj3 = arrayList3.get(i13);
                    i13++;
                    String str3 = (String) obj3;
                    if (str3.length() != 0) {
                        int i14 = 0;
                        for (int iM10971a = AbstractC3778.m10971a(str2, str3, 0, true, 2); iM10971a >= 0; iM10971a = AbstractC3778.m10968a(str2, str3, str3.length() + iM10971a, true)) {
                            i14++;
                        }
                        if (i14 > 0) {
                            i11++;
                            i12 += i14;
                        }
                    }
                }
                return new C3549(str2, new C3549(Integer.valueOf(i11), Integer.valueOf(i12)));
            case 13:
                C0286 c0286 = (C0286) obj2;
                int i15 = MusicService.f3779a;
                List<Song> list = (List) obj;
                ArrayList arrayList4 = new ArrayList(AbstractC2853.m9682a(list, 10));
                for (Song song2 : list) {
                    int i16 = C4290a.f1671a;
                    arrayList4.add(AbstractC2582.m9251a("", song2));
                }
                c0286.m6122a(arrayList4);
                return c6174p;
            case 14:
                ((C5639j) obj2).mo4475a(null);
                return c6174p;
            case 15:
                C5655j c5655j = (C5655j) obj2;
                c5655j.m2214a(new C0527(((Long) obj).longValue(), c5655j.f9058a));
                return c6174p;
            case 16:
                C5777o c5777o = (C5777o) obj2;
                Song song3 = (Song) obj;
                if (c5777o.f14586a.isEmpty()) {
                    ((MainActivity) c5777o.f9552a).m1616a(song3);
                }
                return c6174p;
            case 17:
                C5784o c5784o = (C5784o) obj2;
                ((Integer) obj).intValue();
                c5784o.f9567a.m3392a(new C5100i(c5784o.f9571a, c5784o.f9572a));
                return (C5482j) c5784o.f9567a.f14037a;
            case 18:
                C5785o c5785o = (C5785o) obj2;
                int i17 = C5785o.f9579a;
                int i18 = ((C3669) obj).f23282a;
                if (i18 == R.id.create_playlist) {
                    AbstractActivityC3991a abstractActivityC3991aRequireActivity = c5785o.requireActivity();
                    ArrayList arrayList5 = new ArrayList();
                    C1064 c1064 = new C1064();
                    Bundle bundle = new Bundle();
                    bundle.putString("songsKey", AbstractC0635.m6527a(arrayList5));
                    bundle.putString("name", null);
                    c1064.setArguments(bundle);
                    c1064.m264a(abstractActivityC3991aRequireActivity.m275a(), "create_playlist");
                } else if (i18 == R.id.import_playlist) {
                    Toast.makeText(c5785o.requireContext(), "Please choose a folder containing your playlists.", 0).show();
                    AbstractC4149a abstractC4149a = c5785o.f9581a;
                    if (abstractC4149a == null) {
                        AbstractC3098.m10141a("launcher");
                        throw null;
                    }
                    abstractC4149a.mo946a(null);
                } else if (i18 == R.id.external_playlist) {
                    new C1681().m264a(c5785o.requireActivity().m275a(), "EXTERNAL PLAYLIST");
                }
                return c6174p;
            case 19:
                C5796o c5796o = (C5796o) obj2;
                AbstractC2154 abstractC2154 = (AbstractC2154) obj;
                if (abstractC2154 instanceof C2152) {
                    AbstractC3050 abstractC3050 = c5796o.f9603a;
                    if (abstractC3050 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    abstractC3050.f21566a.setVisibility(0);
                    AbstractC3050 abstractC30502 = c5796o.f9603a;
                    if (abstractC30502 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    AbstractC5120i.m3457a(abstractC30502.f21565a);
                } else if (abstractC2154 instanceof C2153) {
                    AbstractC3050 abstractC30503 = c5796o.f9603a;
                    if (abstractC30503 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    abstractC30503.f21566a.setVisibility(8);
                    AbstractC3050 abstractC30504 = c5796o.f9603a;
                    if (abstractC30504 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    abstractC30504.f21565a.setVisibility(0);
                    Toast.makeText(c5796o.getContext(), "Playlists imported successfully", 0).show();
                    c5796o.m259a(false, false);
                } else if (abstractC2154 instanceof C2150) {
                    AbstractC3050 abstractC30505 = c5796o.f9603a;
                    if (abstractC30505 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    abstractC30505.f21566a.setVisibility(8);
                    AbstractC3050 abstractC30506 = c5796o.f9603a;
                    if (abstractC30506 == null) {
                        AbstractC3098.m10141a("binding");
                        throw null;
                    }
                    abstractC30506.f21565a.setVisibility(0);
                    Toast.makeText(c5796o.getContext(), ((C2150) abstractC2154).f18531a.toString(), 0).show();
                }
                return c6174p;
            case 20:
                C1487 c1487 = (C1487) obj2;
                C5482j c5482j = (C5482j) c1487.f14037a;
                C5631j c5631j = c1487.f16092a.f8935a;
                C5774o c5774o = new C5774o(c1487, i, (String) obj);
                c5482j.getClass();
                c5482j.m4308a(c5631j, new C4235a(new C4754e(c5482j, c5631j, c5774o, i), 26));
                return c5482j;
            case 21:
                C1121 c1121 = (C1121) obj2;
                C1120 c1120 = new C1120(((Integer) obj).intValue());
                C5482j c5482j2 = (C5482j) c1121.f14037a;
                c5482j2.mo4304a(c2152);
                c5482j2.m4308a(c1121.f14773a.f8937a, new C4235a(new C4221a(c1121, 11, c1120), 9));
                return c5482j2;
            case 22:
                C1494 c14942 = (C1494) obj2;
                C5482j c5482j3 = (C5482j) c14942.f14037a;
                c5482j3.m4308a(((C5611j) c14942.f16102a).f8935a, new C1999(new C5774o(c14942, 13, (String) obj), 12));
                return c5482j3;
            case 23:
                C1487 c14872 = (C1487) obj2;
                C5482j c5482j4 = (C5482j) c14872.f14037a;
                c5482j4.m4308a(c14872.f16092a.f8935a, new C4235a(new C4221a(c14872, i3, (String) obj), i4));
                return c5482j4;
            case 24:
                C1487 c14873 = (C1487) obj2;
                C5482j c5482j5 = (C5482j) c14873.f14037a;
                c5482j5.m4308a(c14873.f16092a.f8935a, new C4235a(new C4221a(c14873, 21, (String) obj), i2));
                return c5482j5;
            case 25:
                C5562j c5562j = (C5562j) obj2;
                C5482j c5482j6 = (C5482j) c5562j.f14037a;
                c5482j6.mo4305a(c2152);
                c5482j6.m4308a(c5562j.f8808a.f8935a, new C4235a(new C4221a((C4263a) obj, 24, c5562j), 27));
                return c5482j6;
            case 26:
                C1494 c14943 = (C1494) obj2;
                C5482j c5482j7 = (C5482j) c14943.f14037a;
                c5482j7.mo4304a(c2152);
                c5482j7.m4308a(((C5611j) c14943.f16102a).f8937a, new C1999(new C5774o(c14943, 5, (AbstractC5312i) obj), i4));
                return c5482j7;
            case 27:
                C1494 c14944 = (C1494) obj2;
                ((C5482j) c14944.f14037a).m4308a((C2181) c14944.f16104a, new C4181a(new C5774o((Map) obj, i3, c14944), 22));
                return c6174p;
            case 28:
                C5821o c5821o = (C5821o) obj2;
                int iIntValue = ((Integer) obj).intValue();
                return c5821o.f9678a[iIntValue] + ": " + c5821o.mo4752a(iIntValue).mo4747a();
            default:
                C5823o c5823o = (C5823o) obj2;
                C2808 c2808 = (C2808) obj;
                AbstractC3098.m10103a(c2808, "$this$buildSerialDescriptor");
                C2808.m9581a(c2808, "type", C3777.f23693a);
                String str4 = "kotlinx.serialization.Polymorphic<" + c5823o.f9689a.m9579a() + '>';
                C5822o c5822o = C5822o.f9687a;
                InterfaceC0402[] interfaceC0402Arr = new InterfaceC0402[0];
                AbstractC3098.m10103a(str4, "serialName");
                if (AbstractC3778.m10973a(str4)) {
                    throw new IllegalArgumentException("Blank serial names are prohibited");
                }
                if (c5822o.equals(C5822o.f9688a)) {
                    throw new IllegalArgumentException("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
                }
                C2808 c28082 = new C2808(str4);
                C2808.m9581a(c2808, "value", new C0404(str4, c5822o, c28082.f20607a.size(), AbstractC1458.m7720a(interfaceC0402Arr), c28082));
                AbstractC3098.m10103a(c5823o.f9690a, "<set-?>");
                return c6174p;
        }
    }

    public /* synthetic */ C5104i(C5639j c5639j, C5638j c5638j) {
        this.f7003a = 14;
        this.f7004a = c5639j;
    }

    public /* synthetic */ C5104i(MultipleGenresSymbolsSheetDialog multipleGenresSymbolsSheetDialog, ArrayList arrayList) {
        this.f7003a = 12;
        this.f7004a = arrayList;
    }
}
