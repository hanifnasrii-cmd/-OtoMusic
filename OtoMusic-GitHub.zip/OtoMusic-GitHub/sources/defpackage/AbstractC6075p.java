package defpackage;

import android.view.View;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.Objects;

/* JADX INFO: renamed from: p̀, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC6075p {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static OnBackInvokedDispatcher m5072a(View view) {
        return view.findOnBackInvokedDispatcher();
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static OnBackInvokedCallback m5073a(Runnable runnable) {
        Objects.requireNonNull(runnable);
        return new C1363(3, runnable);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static void m5074a(Object obj, Object obj2) {
        ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback) obj2);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static void m5075a(Object obj, Object obj2) {
        ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
    }
}
