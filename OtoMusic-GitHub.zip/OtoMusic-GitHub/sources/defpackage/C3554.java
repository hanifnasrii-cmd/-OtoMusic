package defpackage;

import android.graphics.Color;
import java.util.Arrays;

/* JADX INFO: renamed from: ј݇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3554 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f22958a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f22959a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f22960a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f22961a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f22962a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public boolean f22963a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public int f22964a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public int f22965a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public float[] f22966a;

    public C3554(int i, int i2) {
        this.f22958a = Color.red(i);
        this.f22959a = Color.green(i);
        this.f22960a = Color.blue(i);
        this.f22961a = i;
        this.f22962a = i2;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m10702a() {
        if (this.f22963a) {
            return;
        }
        int i = this.f22961a;
        int iM9753a = AbstractC2872.m9753a(-1, 4.5f, i);
        int iM9753a2 = AbstractC2872.m9753a(-1, 3.0f, i);
        if (iM9753a != -1 && iM9753a2 != -1) {
            this.f22965a = AbstractC2872.m9760a(-1, iM9753a);
            this.f22964a = AbstractC2872.m9760a(-1, iM9753a2);
            this.f22963a = true;
            return;
        }
        int iM9753a3 = AbstractC2872.m9753a(-16777216, 4.5f, i);
        int iM9753a4 = AbstractC2872.m9753a(-16777216, 3.0f, i);
        if (iM9753a3 == -1 || iM9753a4 == -1) {
            this.f22965a = iM9753a != -1 ? AbstractC2872.m9760a(-1, iM9753a) : AbstractC2872.m9760a(-16777216, iM9753a3);
            this.f22964a = iM9753a2 != -1 ? AbstractC2872.m9760a(-1, iM9753a2) : AbstractC2872.m9760a(-16777216, iM9753a4);
            this.f22963a = true;
        } else {
            this.f22965a = AbstractC2872.m9760a(-16777216, iM9753a3);
            this.f22964a = AbstractC2872.m9760a(-16777216, iM9753a4);
            this.f22963a = true;
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float[] m10703a() {
        if (this.f22966a == null) {
            this.f22966a = new float[3];
        }
        AbstractC2872.m9747a(this.f22958a, this.f22959a, this.f22960a, this.f22966a);
        return this.f22966a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C3554.class == obj.getClass()) {
            C3554 c3554 = (C3554) obj;
            if (this.f22962a == c3554.f22962a && this.f22961a == c3554.f22961a) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (this.f22961a * 31) + this.f22962a;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(C3554.class.getSimpleName());
        sb.append(" [RGB: #");
        sb.append(Integer.toHexString(this.f22961a));
        sb.append("] [HSL: ");
        sb.append(Arrays.toString(m10703a()));
        sb.append("] [Population: ");
        sb.append(this.f22962a);
        sb.append("] [Title Text: #");
        m10702a();
        sb.append(Integer.toHexString(this.f22964a));
        sb.append("] [Body Text: #");
        m10702a();
        sb.append(Integer.toHexString(this.f22965a));
        sb.append(']');
        return sb.toString();
    }
}
