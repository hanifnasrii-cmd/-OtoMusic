package defpackage;

/* JADX INFO: renamed from: рּ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2477 extends AbstractC2454 {
}
