package defpackage;

import java.util.HashSet;

/* JADX INFO: renamed from: оؙ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2163 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final HashSet f18545a = new HashSet();
}
