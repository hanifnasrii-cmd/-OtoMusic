package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

/* JADX INFO: renamed from: і͂, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC3045 extends AbstractC3038 implements List, RandomAccess {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final C3041 f21557a = new C3041(C2068.f18238a, 0);

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public static C2068 m10012a(int i, Object[] objArr) {
        return i == 0 ? C2068.f18238a : new C2068(i, objArr);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public static AbstractC3045 m10013a(Collection collection) {
        if (!(collection instanceof AbstractC3038)) {
            Object[] array = collection.toArray();
            AbstractC5122i.m3516a(array.length, array);
            return m10012a(array.length, array);
        }
        AbstractC3045 abstractC3045Mo6400a = ((AbstractC3038) collection).mo6400a();
        if (!abstractC3045Mo6400a.mo6402a()) {
            return abstractC3045Mo6400a;
        }
        Object[] array2 = abstractC3045Mo6400a.toArray(AbstractC3038.f21545a);
        return m10012a(array2.length, array2);
    }

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public static C2068 m10014a(Long l, Long l2, Long l3, Long l4, Long l5) {
        Object[] objArr = {l, l2, l3, l4, l5};
        AbstractC5122i.m3516a(5, objArr);
        return m10012a(5, objArr);
    }

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public static C2068 m10015a(Object obj) {
        Object[] objArr = {obj};
        AbstractC5122i.m3516a(1, objArr);
        return m10012a(1, objArr);
    }

    @Override // java.util.List
    public final void add(int i, Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.List
    public final boolean addAll(int i, Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // defpackage.AbstractC3038
    /* JADX INFO: renamed from: ã */
    public final AbstractC3045 mo6400a() {
        return this;
    }

    @Override // defpackage.AbstractC3038
    /* JADX INFO: renamed from: ā */
    public int mo6401a(int i, Object[] objArr) {
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            objArr[i + i2] = get(i2);
        }
        return i + size;
    }

    @Override // java.util.List
    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters and merged with bridge method [inline-methods] */
    public final C3041 listIterator(int i) {
        AbstractC1545.m7846a(i, size());
        return isEmpty() ? f21557a : new C3041(this, i);
    }

    @Override // java.util.List
    /* JADX INFO: renamed from: ȁ, reason: merged with bridge method [inline-methods] */
    public AbstractC3045 subList(int i, int i2) {
        AbstractC1545.m7847a(i, i2, size());
        int i3 = i2 - i;
        return i3 == size() ? this : i3 == 0 ? C2068.f18238a : new C3043(this, i, i3);
    }

    @Override // defpackage.AbstractC3038, java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof List) {
                List list = (List) obj;
                int size = size();
                if (size == list.size()) {
                    if (!(list instanceof RandomAccess)) {
                        Iterator it = iterator();
                        Iterator it2 = list.iterator();
                        while (it.hasNext()) {
                            if (it2.hasNext() && AbstractC5123i.m3558a(it.next(), it2.next())) {
                            }
                        }
                        return !it2.hasNext();
                    }
                    for (int i = 0; i < size; i++) {
                        if (AbstractC5123i.m3558a(get(i), list.get(i))) {
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    @Override // java.util.Collection, java.util.List
    public final int hashCode() {
        int size = size();
        int i = 1;
        for (int i2 = 0; i2 < size; i2++) {
            i = ~(~(get(i2).hashCode() + (i * 31)));
        }
        return i;
    }

    @Override // java.util.List
    public final int indexOf(Object obj) {
        if (obj == null) {
            return -1;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            if (obj.equals(get(i))) {
                return i;
            }
        }
        return -1;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public Iterator iterator() {
        return listIterator(0);
    }

    @Override // java.util.List
    public final int lastIndexOf(Object obj) {
        if (obj == null) {
            return -1;
        }
        for (int size = size() - 1; size >= 0; size--) {
            if (obj.equals(get(size))) {
                return size;
            }
        }
        return -1;
    }

    @Override // java.util.List
    public final Object remove(int i) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.List
    public final Object set(int i, Object obj) {
        throw new UnsupportedOperationException();
    }

    public ListIterator listIterator() {
        return listIterator(0);
    }
}
