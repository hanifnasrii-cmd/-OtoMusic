package defpackage;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: renamed from: a֣, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4144a implements Parcelable {
    public static final Parcelable.Creator<C4144a> CREATOR = new C4124a(1);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f1186a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Intent f1187a;

    public C4144a(Intent intent, int i) {
        this.f1186a = i;
        this.f1187a = intent;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("ActivityResult{resultCode=");
        int i = this.f1186a;
        sb.append(i != -1 ? i != 0 ? String.valueOf(i) : "RESULT_CANCELED" : "RESULT_OK");
        sb.append(", data=");
        sb.append(this.f1187a);
        sb.append('}');
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f1186a);
        Intent intent = this.f1187a;
        parcel.writeInt(intent == null ? 0 : 1);
        if (intent != null) {
            intent.writeToParcel(parcel, i);
        }
    }

    public C4144a(Parcel parcel) {
        this.f1186a = parcel.readInt();
        this.f1187a = parcel.readInt() == 0 ? null : (Intent) Intent.CREATOR.createFromParcel(parcel);
    }
}
