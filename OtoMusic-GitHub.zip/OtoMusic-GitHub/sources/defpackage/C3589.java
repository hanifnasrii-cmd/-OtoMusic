package defpackage;

/* JADX INFO: renamed from: ј⃚, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3589 implements InterfaceC2923 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final InterfaceC2206 f23078a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final String f23079a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final AbstractC5067i f23080a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C3865 f23081a = new C3865(new C4241a(22, this));

    /* JADX WARN: Multi-variable type inference failed */
    public C3589(InterfaceC2206 interfaceC2206, String str, InterfaceC5054i interfaceC5054i) {
        this.f23078a = interfaceC2206;
        this.f23079a = str;
        this.f23080a = (AbstractC5067i) interfaceC5054i;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [i̡, i̮] */
    @Override // defpackage.InterfaceC2923
    /* JADX INFO: renamed from: a̜ */
    public final Object mo9803a(boolean z, InterfaceC5054i interfaceC5054i, AbstractC1006 abstractC1006) {
        C3588 c3588 = (C3588) abstractC1006.getContext().get(C3588.f23076a);
        C3587 c3587 = c3588 != null ? c3588.f23077a : null;
        if (c3587 != null) {
            return interfaceC5054i.invoke(c3587, abstractC1006);
        }
        C3587 c35872 = new C3587(this.f23080a, (InterfaceC2205) this.f23081a.getValue());
        return AbstractC1149.m7203a(new C3588(c35872), new C4568c(interfaceC5054i, c35872, (InterfaceC1005) null), abstractC1006);
    }

    @Override // java.lang.AutoCloseable
    public final void close() throws Exception {
        C3865 c3865 = this.f23081a;
        if (c3865.f23885a != C5165i.f7308a) {
            ((InterfaceC2205) c3865.getValue()).close();
        }
    }
}
