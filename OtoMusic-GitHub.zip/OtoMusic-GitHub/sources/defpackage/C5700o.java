package defpackage;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/* JADX INFO: renamed from: o̓, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5700o extends AbstractC4071a {
    @Override // defpackage.AbstractC6000o
    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int mo4589a(int i) {
        return ThreadLocalRandom.current().nextInt(0, i);
    }

    @Override // defpackage.AbstractC6000o
    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final long mo4590a() {
        return ThreadLocalRandom.current().nextLong(0L, 300000000000L);
    }

    @Override // defpackage.AbstractC4071a
    /* JADX INFO: renamed from: ä */
    public final Random mo729a() {
        ThreadLocalRandom threadLocalRandomCurrent = ThreadLocalRandom.current();
        AbstractC3098.m10102a(threadLocalRandomCurrent, "current(...)");
        return threadLocalRandomCurrent;
    }
}
