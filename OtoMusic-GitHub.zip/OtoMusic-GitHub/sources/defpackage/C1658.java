package defpackage;

import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.TextView;
import com.piyush.music.widget.ExpandableTextView;

/* JADX INFO: renamed from: е̃, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1658 extends Animation {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final ExpandableTextView f16694a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f16695a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int f16696a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ ExpandableTextView f16697a;

    public C1658(ExpandableTextView expandableTextView, ExpandableTextView expandableTextView2, int i, int i2) {
        this.f16697a = expandableTextView;
        this.f16694a = expandableTextView2;
        this.f16695a = i;
        this.f16696a = i2;
        setDuration(expandableTextView.f3960a);
    }

    @Override // android.view.animation.Animation
    public final void applyTransformation(float f, Transformation transformation) {
        int i = this.f16696a;
        int i2 = (int) (((i - r0) * f) + this.f16695a);
        ExpandableTextView expandableTextView = this.f16697a;
        float f2 = expandableTextView.f3961a;
        TextView textView = expandableTextView.f3951a;
        if (textView == null) {
            AbstractC3098.m10141a("mTv");
            throw null;
        }
        textView.setMaxHeight(i2 - expandableTextView.f3958a);
        if (Float.compare(f2, 1.0f) != 0) {
            int i3 = ExpandableTextView.f3950a;
            TextView textView2 = expandableTextView.f3951a;
            if (textView2 == null) {
                AbstractC3098.m10141a("mTv");
                throw null;
            }
            textView2.setAlpha(((1.0f - f2) * f) + f2);
        }
        ExpandableTextView expandableTextView2 = this.f16694a;
        expandableTextView2.getLayoutParams().height = i2;
        expandableTextView2.requestLayout();
    }
}
