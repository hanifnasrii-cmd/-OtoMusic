package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: c̔, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC4381c {
    private static final /* synthetic */ EnumC4381c[] $VALUES;
    public static final EnumC4381c EXPONENTIAL;
    public static final EnumC4381c LINEAR;

    static {
        EnumC4381c enumC4381c = new EnumC4381c("EXPONENTIAL", 0);
        EXPONENTIAL = enumC4381c;
        EnumC4381c enumC4381c2 = new EnumC4381c("LINEAR", 1);
        LINEAR = enumC4381c2;
        $VALUES = new EnumC4381c[]{enumC4381c, enumC4381c2};
    }

    public static EnumC4381c valueOf(String str) {
        return (EnumC4381c) Enum.valueOf(EnumC4381c.class, str);
    }

    public static EnumC4381c[] values() {
        return (EnumC4381c[]) $VALUES.clone();
    }
}
