package defpackage;

import android.util.Log;
import com.piyush.audiokit.PcmDecodeSession;
import java.io.InputStream;
import java.util.Arrays;

/* JADX INFO: renamed from: р̗, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2340 extends InputStream {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final PcmDecodeSession f19081a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final byte[] f19082a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final long f19083a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f19084a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final long f19085a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public long f19086a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f19088a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public boolean f19089a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final byte[] f19092a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public int f19093a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public int f19094a;

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public long f19095a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final long f19096a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public long f19087a = -1;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final float[] f19090a = new float[16384];

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final byte[] f19091a = new byte[32768];

    public C2340(PcmDecodeSession pcmDecodeSession, byte[] bArr, long j, int i) {
        this.f19081a = pcmDecodeSession;
        this.f19082a = bArr;
        this.f19083a = j;
        this.f19084a = i;
        this.f19085a = j + 44;
        this.f19092a = new byte[i];
        this.f19096a = ((long) pcmDecodeSession.getSampleRate()) * ((long) i);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int m8751a(byte[] bArr, int i, int i2) {
        int i3 = i / this.f19084a;
        if (i3 <= 0) {
            return 0;
        }
        PcmDecodeSession pcmDecodeSession = this.f19081a;
        int channelCount = pcmDecodeSession.getChannelCount() * i3;
        float[] fArr = this.f19090a;
        int length = fArr.length;
        if (channelCount > length) {
            channelCount = length;
        }
        if (channelCount <= 0) {
            return 0;
        }
        int floats = pcmDecodeSession.readFloats(fArr, channelCount);
        if (floats < 0) {
            return -1;
        }
        if (floats == 0) {
            return 0;
        }
        for (int i4 = 0; i4 < floats; i4++) {
            int iM5205a = (int) AbstractC6161p.m5205a(fArr[i4] * 32767.0f, -32768.0f, 32767.0f);
            int i5 = i2 + 1;
            bArr[i2] = (byte) (iM5205a & 255);
            i2 += 2;
            bArr[i5] = (byte) ((iM5205a >> 8) & 255);
        }
        return floats * 2;
    }

    @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.f19089a) {
            return;
        }
        this.f19089a = true;
        this.f19081a.release();
    }

    @Override // java.io.InputStream
    public final int read() {
        byte[] bArr = new byte[1];
        if (read(bArr, 0, 1) <= 0) {
            return -1;
        }
        return bArr[0] & 255;
    }

    @Override // java.io.InputStream
    public final int read(byte[] bArr, int i, int i2) {
        int iMin;
        int i3;
        long j;
        int i4 = i;
        int i5 = i2;
        if (i5 == 0) {
            return 0;
        }
        if (this.f19088a || this.f19089a) {
            return -1;
        }
        long j2 = this.f19086a;
        if (j2 < 44) {
            iMin = (int) Math.min(i5, 44 - j2);
            System.arraycopy(this.f19082a, (int) this.f19086a, bArr, i4, iMin);
            this.f19086a += (long) iMin;
            i4 += iMin;
            i5 -= iMin;
            if (i5 == 0) {
                return iMin;
            }
        } else {
            iMin = 0;
        }
        long j3 = this.f19086a - 44;
        long j4 = this.f19083a;
        if (j3 >= j4) {
            this.f19088a = true;
            if (iMin > 0) {
                return iMin;
            }
            return -1;
        }
        int i6 = this.f19094a - this.f19093a;
        byte[] bArr2 = this.f19092a;
        if (i6 != 0 || this.f19087a == j3) {
            i3 = iMin;
            j = j4;
        } else {
            int i7 = this.f19084a;
            long j5 = i7;
            i3 = iMin;
            long j6 = j3 - (j3 % j5);
            PcmDecodeSession pcmDecodeSession = this.f19081a;
            j = j4;
            if (!pcmDecodeSession.seekTo(((j6 / j5) * 1000000) / ((long) pcmDecodeSession.getSampleRate()))) {
                this.f19088a = true;
                if (i3 > 0) {
                    return i3;
                }
                return -1;
            }
            this.f19087a = j6;
            this.f19093a = 0;
            this.f19094a = 0;
            int i8 = (int) (j3 - j6);
            if (i8 > 0) {
                int iM8751a = m8751a(bArr2, i7, 0);
                if (iM8751a <= 0) {
                    this.f19088a = true;
                    if (i3 > 0) {
                        return i3;
                    }
                    return -1;
                }
                this.f19087a += (long) iM8751a;
                this.f19094a = iM8751a;
                this.f19093a = i8;
            }
        }
        int i9 = this.f19094a - this.f19093a;
        if (i9 > 0) {
            int iMin2 = Math.min(i5, i9);
            System.arraycopy(bArr2, this.f19093a, bArr, i4, iMin2);
            this.f19093a += iMin2;
            this.f19086a += (long) iMin2;
            return i3 + iMin2;
        }
        long j7 = j - j3;
        int iMin3 = (int) Math.min(Math.min(i5, j7), this.f19091a.length);
        int iM8751a2 = m8751a(bArr, iMin3, i4);
        if (iM8751a2 < 0) {
            Log.e("CastWavTranscoder", "decode failed " + j3 + " bytes into the stream");
            this.f19088a = true;
            if (i3 > 0) {
                return i3;
            }
            return -1;
        }
        if (iM8751a2 == 0) {
            long j8 = iMin3;
            long j9 = this.f19095a + j8;
            if (j9 > this.f19096a) {
                Log.e("CastWavTranscoder", "decode ran dry " + j7 + " bytes short; refusing to pad");
                this.f19088a = true;
                if (i3 > 0) {
                    return i3;
                }
                return -1;
            }
            this.f19095a = j9;
            AbstractC3098.m10103a(bArr, "<this>");
            Arrays.fill(bArr, i4, i4 + iMin3, (byte) 0);
            this.f19086a += j8;
            this.f19087a += j8;
            return i3 + iMin3;
        }
        long j10 = iM8751a2;
        this.f19086a += j10;
        this.f19087a += j10;
        return i3 + iM8751a2;
    }
}
