package defpackage;

/* JADX INFO: renamed from: aֹ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC4166a {
}
