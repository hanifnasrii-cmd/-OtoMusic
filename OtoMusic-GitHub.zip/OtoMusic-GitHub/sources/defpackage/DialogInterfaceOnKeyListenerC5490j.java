package defpackage;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

/* JADX INFO: renamed from: j֧, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class DialogInterfaceOnKeyListenerC5490j implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, InterfaceC5510j {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public SubMenuC3793 f8602a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public DialogInterfaceC4273a f8603a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public C0034 f8604a;

    @Override // defpackage.InterfaceC5510j
    /* JADX INFO: renamed from: à */
    public final void mo3748a(MenuC5487j menuC5487j, boolean z) {
        DialogInterfaceC4273a dialogInterfaceC4273a;
        if ((z || menuC5487j == this.f8602a) && (dialogInterfaceC4273a = this.f8603a) != null) {
            dialogInterfaceC4273a.dismiss();
        }
    }

    @Override // defpackage.InterfaceC5510j
    /* JADX INFO: renamed from: a̖ */
    public final boolean mo3757a(MenuC5487j menuC5487j) {
        return false;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f8602a.m4329a(this.f8604a.m5805a().getItem(i), null, 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        this.f8604a.mo891a(this.f8602a, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public final boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        SubMenuC3793 subMenuC3793 = this.f8602a;
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f8603a.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f8603a.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                subMenuC3793.m4315a(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return subMenuC3793.performShortcut(i, keyEvent, 0);
    }
}
