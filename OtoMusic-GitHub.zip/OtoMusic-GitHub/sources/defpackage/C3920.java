package defpackage;

import com.piyush.music.fragments.tageditor.TagEditorFragment;

/* JADX INFO: renamed from: օ⃚, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3920 extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f24038a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f24039a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ TagEditorFragment f24040a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C3920(TagEditorFragment tagEditorFragment, InterfaceC1005 interfaceC1005, int i) {
        super(2, interfaceC1005);
        this.f24038a = i;
        this.f24040a = tagEditorFragment;
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        switch (this.f24038a) {
            case 0:
                return new C3920(this.f24040a, interfaceC1005, 0);
            default:
                return new C3920(this.f24040a, interfaceC1005, 1);
        }
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        InterfaceC1044 interfaceC1044 = (InterfaceC1044) obj;
        InterfaceC1005 interfaceC1005 = (InterfaceC1005) obj2;
        switch (this.f24038a) {
        }
        return ((C3920) create(interfaceC1044, interfaceC1005)).invokeSuspend(C6174p.f10843a);
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        switch (this.f24038a) {
            case 0:
                EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
                int i = this.f24039a;
                if (i == 0) {
                    AbstractC1149.m7200a(obj);
                    TagEditorFragment tagEditorFragment = this.f24040a;
                    C6007o c6007o = tagEditorFragment.m1824a().f3404a;
                    C3917 c3917 = new C3917(tagEditorFragment, 1);
                    this.f24039a = 1;
                    if (c6007o.f10306a.mo2389a(c3917, this) == enumC1045) {
                        return enumC1045;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC1149.m7200a(obj);
                }
                throw new C2895();
            default:
                EnumC1045 enumC10452 = EnumC1045.COROUTINE_SUSPENDED;
                int i2 = this.f24039a;
                if (i2 == 0) {
                    AbstractC1149.m7200a(obj);
                    TagEditorFragment tagEditorFragment2 = this.f24040a;
                    C2743 c2743 = tagEditorFragment2.m1824a().f3406a;
                    C3917 c39172 = new C3917(tagEditorFragment2, 2);
                    this.f24039a = 1;
                    if (c2743.mo2389a(c39172, this) == enumC10452) {
                        return enumC10452;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC1149.m7200a(obj);
                }
                return C6174p.f10843a;
        }
    }
}
