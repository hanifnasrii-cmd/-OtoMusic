package defpackage;

import java.util.Arrays;
import java.util.Random;

/* JADX INFO: renamed from: οؗ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0506 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Random f13319a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int[] f13320a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int[] f13321a;

    public C0506() {
        this(new Random());
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C0506 m6370a(int i, int i2) {
        int[] iArr;
        Random random;
        int[] iArr2 = new int[i2];
        int[] iArr3 = new int[i2];
        int i3 = 0;
        while (true) {
            iArr = this.f13320a;
            random = this.f13319a;
            if (i3 >= i2) {
                break;
            }
            iArr2[i3] = random.nextInt(iArr.length + 1);
            int i4 = i3 + 1;
            int iNextInt = random.nextInt(i4);
            iArr3[i3] = iArr3[iNextInt];
            iArr3[iNextInt] = i3 + i;
            i3 = i4;
        }
        Arrays.sort(iArr2);
        int[] iArr4 = new int[iArr.length + i2];
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < iArr.length + i2; i7++) {
            if (i5 >= i2 || i6 != iArr2[i5]) {
                int i8 = i6 + 1;
                int i9 = iArr[i6];
                iArr4[i7] = i9;
                if (i9 >= i) {
                    iArr4[i7] = i9 + i2;
                }
                i6 = i8;
            } else {
                iArr4[i7] = iArr3[i5];
                i5++;
            }
        }
        return new C0506(iArr4, new Random(random.nextLong()));
    }

    public C0506(int[] iArr, Random random) {
        this.f13320a = iArr;
        this.f13319a = random;
        this.f13321a = new int[iArr.length];
        for (int i = 0; i < iArr.length; i++) {
            this.f13321a[iArr[i]] = i;
        }
    }

    public C0506(Random random) {
        this(new int[0], random);
    }
}
