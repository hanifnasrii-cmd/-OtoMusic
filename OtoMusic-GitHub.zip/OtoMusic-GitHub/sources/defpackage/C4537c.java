package defpackage;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* JADX INFO: renamed from: cؘ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4537c extends AbstractC2029 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ RecyclerView f5215a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ View f5216a;

    public C4537c(RecyclerView recyclerView, View view) {
        this.f5215a = recyclerView;
        this.f5216a = view;
    }

    @Override // defpackage.AbstractC2029
    /* JADX INFO: renamed from: á */
    public final void mo1201a(RecyclerView recyclerView, int i, int i2) {
        boolean zCanScrollVertically = this.f5215a.canScrollVertically(-1);
        View view = this.f5216a;
        if (zCanScrollVertically) {
            view.setVisibility(0);
        } else {
            view.setVisibility(4);
        }
    }
}
