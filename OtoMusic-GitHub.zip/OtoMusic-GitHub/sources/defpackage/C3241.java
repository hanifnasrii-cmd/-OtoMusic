package defpackage;

/* JADX INFO: renamed from: і߮, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3241 extends C1246 {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final InterfaceC1005 f22136a;

    /* JADX WARN: Multi-variable type inference failed */
    public C3241(InterfaceC1031 interfaceC1031, InterfaceC5054i interfaceC5054i) {
        super(interfaceC1031, false);
        this.f22136a = ((AbstractC4415c) interfaceC5054i).create(this, this);
    }

    @Override // defpackage.C3156
    /* JADX INFO: renamed from: a̫ */
    public final void mo10223a() {
        try {
            AbstractC1149.m7194a(AbstractC5120i.m3446a(this.f22136a), C6174p.f10843a);
        } catch (Throwable th) {
            resumeWith(AbstractC1149.m7168a(th));
            throw th;
        }
    }
}
