package defpackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.piyush.music.R;
import com.piyush.music.models.NowPlayingTheme;
import com.piyush.music.models.QueueSong;
import com.piyush.music.widget.player.SquareImageView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: renamed from: aۖ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4210a extends AbstractC6275p {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final ComponentCallbacks2C2114 f1383a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Context f1384a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final NowPlayingTheme f1385a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C0456 f1386a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final int f1387a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final ArrayList f1388a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f1389a;

    public C4210a(ComponentCallbacks2C2114 componentCallbacks2C2114, Context context, NowPlayingTheme nowPlayingTheme) {
        this.f1383a = componentCallbacks2C2114;
        this.f1384a = context;
        this.f1385a = nowPlayingTheme;
        C4842e c4842e = new C4842e(0);
        C4842e c4842e2 = new C4842e(0);
        C4842e c4842e3 = new C4842e(0);
        C4842e c4842e4 = new C4842e(0);
        float dimension = context.getResources().getDimension(nowPlayingTheme.getPlayerCoverRadiusRes());
        AbstractC4647c abstractC4647cM8624a = AbstractC2179.m8624a(0);
        C4031a c4031a = new C4031a(dimension);
        C4031a c4031a2 = new C4031a(dimension);
        C4031a c4031a3 = new C4031a(dimension);
        C4031a c4031a4 = new C4031a(dimension);
        C0456 c0456 = new C0456();
        c0456.f13058a = abstractC4647cM8624a;
        c0456.f13059a = abstractC4647cM8624a;
        c0456.f13060a = abstractC4647cM8624a;
        c0456.f13061a = abstractC4647cM8624a;
        c0456.f13062a = c4031a;
        c0456.f13063a = c4031a2;
        c0456.f13064a = c4031a3;
        c0456.f13065a = c4031a4;
        c0456.f13066a = c4842e;
        c0456.f13067a = c4842e2;
        c0456.f13068a = c4842e3;
        c0456.f13069a = c4842e4;
        this.f1386a = c0456;
        this.f1387a = nowPlayingTheme.isEditorial() ? 0 : context.getResources().getDimensionPixelSize(R.dimen.wt);
        m8398a();
        this.f1388a = new ArrayList();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int mo1074a() {
        return this.f1388a.size();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final long mo1075a(int i) {
        return ((QueueSong) this.f1388a.get(i)).getUniqueId();
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̋ */
    public final /* bridge */ /* synthetic */ void mo1037a(AbstractC2042 abstractC2042, int i) {
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: ǎ */
    public final void mo1038a(AbstractC2042 abstractC2042, int i, List list) {
        C0516 c0516 = (C0516) abstractC2042;
        InterfaceC6244p interfaceC6244p = c0516.f13354a;
        this.f11158a.add(c0516);
        ArrayList arrayList = this.f1388a;
        if (i >= arrayList.size()) {
            return;
        }
        QueueSong queueSong = (QueueSong) arrayList.get(i);
        ((AbstractC4211a) interfaceC6244p).f1390a.setVisibility(!this.f1389a ? 0 : 8);
        C5084i c5084i = C5133i.f7171a;
        C2104 c2104Mo3661a = ((C2104) ((C2104) C5133i.m3653a(this.f1383a, queueSong.getSong(), null, 12).mo2264a(AbstractC2943.f21027a)).mo2253a(1000, 1000)).mo3661a(C5133i.f7171a);
        c2104Mo3661a.m8548a(new C3030(((AbstractC4211a) interfaceC6244p).f1390a), null, c2104Mo3661a, AbstractC5121i.f7085a);
    }

    @Override // defpackage.AbstractC2015
    /* JADX INFO: renamed from: a̍ */
    public final AbstractC2042 mo1039a(ViewGroup viewGroup, int i) {
        C0516 c0516 = new C0516(AbstractC4211a.m1077a(LayoutInflater.from(viewGroup.getContext()), viewGroup));
        AbstractC4211a abstractC4211a = (AbstractC4211a) c0516.f13354a;
        abstractC4211a.f1390a.setShapeAppearanceModel(this.f1386a);
        SquareImageView squareImageView = abstractC4211a.f1390a;
        squareImageView.setElevation(this.f1384a.getResources().getDimension(this.f1385a.getPlayerCoverElevationRes()));
        int i2 = this.f1387a;
        squareImageView.setPadding(i2, i2, i2, i2);
        return c0516;
    }

    @Override // defpackage.AbstractC6275p, defpackage.AbstractC2015
    /* JADX INFO: renamed from: ȃ */
    public final void mo1059a(AbstractC2042 abstractC2042) {
        C0516 c0516 = (C0516) abstractC2042;
        super.mo1059a(c0516);
        this.f1383a.m8559a(((AbstractC4211a) c0516.f13354a).f1390a);
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final void m1076a(boolean z) {
        if (this.f1389a == z) {
            return;
        }
        this.f1389a = z;
        Iterator it = this.f11158a.iterator();
        while (it.hasNext()) {
            ((AbstractC4211a) ((C0516) it.next()).f13354a).f1390a.setVisibility(z ? 8 : 0);
        }
    }
}
