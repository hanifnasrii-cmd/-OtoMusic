package defpackage;

import java.lang.ref.Reference;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: о̅, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1991 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f18021a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final long f18022a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C3946 f18023a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C4725e f18024a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final ConcurrentLinkedQueue f18025a;

    public C1991(C3947 c3947, int i, long j, TimeUnit timeUnit) {
        AbstractC3098.m10103a(c3947, "taskRunner");
        AbstractC3098.m10103a(timeUnit, "timeUnit");
        this.f18021a = i;
        this.f18022a = timeUnit.toNanos(j);
        this.f18023a = c3947.m11108a();
        this.f18024a = new C4725e(1, this, AbstractC4072a.m749a(new StringBuilder(), AbstractC6204p.f10910a, " ConnectionPool"));
        this.f18025a = new ConcurrentLinkedQueue();
        if (j > 0) {
            return;
        }
        throw new IllegalArgumentException(("keepAliveDuration <= 0: " + j).toString());
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0029 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x002f A[SYNTHETIC] */
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean m8377a(defpackage.C4195a r4, defpackage.C1987 r5, java.util.ArrayList r6, boolean r7) {
        /*
            r3 = this;
            java.util.concurrent.ConcurrentLinkedQueue r0 = r3.f18025a
            java.util.Iterator r0 = r0.iterator()
        L6:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L33
            java.lang.Object r1 = r0.next()
            о̄ r1 = (defpackage.C1990) r1
            java.lang.String r2 = "connection"
            defpackage.AbstractC3098.m10102a(r1, r2)
            monitor-enter(r1)
            if (r7 == 0) goto L23
            boolean r2 = r1.m8369a()     // Catch: java.lang.Throwable -> L21
            if (r2 == 0) goto L2f
            goto L23
        L21:
            r4 = move-exception
            goto L31
        L23:
            boolean r2 = r1.m8367a(r4, r6)     // Catch: java.lang.Throwable -> L21
            if (r2 == 0) goto L2f
            r5.m8352a(r1)     // Catch: java.lang.Throwable -> L21
            monitor-exit(r1)
            r4 = 1
            return r4
        L2f:
            monitor-exit(r1)
            goto L6
        L31:
            monitor-exit(r1)
            throw r4
        L33:
            r4 = 0
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C1991.m8377a(aْ, о́, java.util.ArrayList, boolean):boolean");
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int m8378a(C1990 c1990, long j) {
        byte[] bArr = AbstractC6204p.f10905a;
        ArrayList arrayListM8365a = c1990.m8365a();
        int i = 0;
        while (i < arrayListM8365a.size()) {
            Reference reference = (Reference) arrayListM8365a.get(i);
            if (reference.get() != null) {
                i++;
            } else {
                String str = "A connection to " + c1990.m8372a().m8680a().m1045a() + " was leaked. Did you forget to close a response body?";
                C5693o c5693o = C5693o.f9228a;
                C5693o.f9228a.mo1191a(((C6011o) reference).m5008a(), str);
                arrayListM8365a.remove(i);
                c1990.m8374a();
                if (arrayListM8365a.isEmpty()) {
                    c1990.m8373a(j - this.f18022a);
                    return 0;
                }
            }
        }
        return arrayListM8365a.size();
    }
}
