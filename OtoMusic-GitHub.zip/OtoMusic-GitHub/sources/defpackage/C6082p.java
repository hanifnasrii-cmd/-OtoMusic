package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import com.piyush.music.R;

/* JADX INFO: renamed from: p͇, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C6082p implements InterfaceC1169 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Toolbar f10481a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f10482a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final View f10483a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public Drawable f10484a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Drawable f10485a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Drawable f10486a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final boolean f10487a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public CharSequence f10488a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final CharSequence f10489a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final CharSequence f10490a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public Window.Callback f10491a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public boolean f10492a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public C4126a f10493a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public final int f10494a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final Drawable f10495a;

    public C6082p(Toolbar toolbar) {
        Drawable drawable;
        this.f10494a = 0;
        this.f10481a = toolbar;
        this.f10488a = toolbar.getTitle();
        this.f10489a = toolbar.getSubtitle();
        this.f10487a = this.f10488a != null;
        this.f10486a = toolbar.getNavigationIcon();
        C2426 c2426M8985a = C2426.m8985a(toolbar.getContext(), null, AbstractC5998o.f10260a, R.attr.i);
        TypedArray typedArray = (TypedArray) c2426M8985a.f19388a;
        this.f10495a = c2426M8985a.m8987a(15);
        CharSequence text = typedArray.getText(27);
        if (!TextUtils.isEmpty(text)) {
            this.f10487a = true;
            this.f10488a = text;
            if ((this.f10482a & 8) != 0) {
                toolbar.setTitle(text);
                if (this.f10487a) {
                    AbstractC6260p.m5434a(toolbar.getRootView(), text);
                }
            }
        }
        CharSequence text2 = typedArray.getText(25);
        if (!TextUtils.isEmpty(text2)) {
            this.f10489a = text2;
            if ((this.f10482a & 8) != 0) {
                toolbar.setSubtitle(text2);
            }
        }
        Drawable drawableM8987a = c2426M8985a.m8987a(20);
        if (drawableM8987a != null) {
            this.f10485a = drawableM8987a;
            m5079a();
        }
        Drawable drawableM8987a2 = c2426M8985a.m8987a(17);
        if (drawableM8987a2 != null) {
            this.f10484a = drawableM8987a2;
            m5079a();
        }
        if (this.f10486a == null && (drawable = this.f10495a) != null) {
            this.f10486a = drawable;
            if ((this.f10482a & 4) != 0) {
                toolbar.setNavigationIcon(drawable);
            } else {
                toolbar.setNavigationIcon((Drawable) null);
            }
        }
        m5077a(typedArray.getInt(10, 0));
        int resourceId = typedArray.getResourceId(9, 0);
        if (resourceId != 0) {
            View viewInflate = LayoutInflater.from(toolbar.getContext()).inflate(resourceId, (ViewGroup) toolbar, false);
            View view = this.f10483a;
            if (view != null && (this.f10482a & 16) != 0) {
                toolbar.removeView(view);
            }
            this.f10483a = viewInflate;
            if (viewInflate != null && (this.f10482a & 16) != 0) {
                toolbar.addView(viewInflate);
            }
            m5077a(this.f10482a | 16);
        }
        int layoutDimension = typedArray.getLayoutDimension(13, 0);
        if (layoutDimension > 0) {
            ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
            layoutParams.height = layoutDimension;
            toolbar.setLayoutParams(layoutParams);
        }
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
        if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
            int iMax = Math.max(dimensionPixelOffset, 0);
            int iMax2 = Math.max(dimensionPixelOffset2, 0);
            toolbar.m131a();
            toolbar.f221a.m8681a(iMax, iMax2);
        }
        int resourceId2 = typedArray.getResourceId(28, 0);
        if (resourceId2 != 0) {
            Context context = toolbar.getContext();
            toolbar.f213a = resourceId2;
            AppCompatTextView appCompatTextView = toolbar.f203a;
            if (appCompatTextView != null) {
                appCompatTextView.setTextAppearance(context, resourceId2);
            }
        }
        int resourceId3 = typedArray.getResourceId(26, 0);
        if (resourceId3 != 0) {
            Context context2 = toolbar.getContext();
            toolbar.f214a = resourceId3;
            TextView textView = toolbar.f204a;
            if (textView != null) {
                textView.setTextAppearance(context2, resourceId3);
            }
        }
        int resourceId4 = typedArray.getResourceId(22, 0);
        if (resourceId4 != 0) {
            toolbar.setPopupTheme(resourceId4);
        }
        c2426M8985a.m8992a();
        if (R.string.c != this.f10494a) {
            this.f10494a = R.string.c;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                int i = this.f10494a;
                this.f10490a = i != 0 ? toolbar.getContext().getString(i) : null;
                m5078a();
            }
        }
        this.f10490a = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new ViewOnClickListenerC0237(this));
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m5077a(int i) {
        View view;
        int i2 = this.f10482a ^ i;
        this.f10482a = i;
        if (i2 != 0) {
            int i3 = i2 & 4;
            Toolbar toolbar = this.f10481a;
            if (i3 != 0) {
                if ((i & 4) != 0) {
                    m5078a();
                }
                if ((this.f10482a & 4) != 0) {
                    Drawable drawable = this.f10486a;
                    if (drawable == null) {
                        drawable = this.f10495a;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i2 & 3) != 0) {
                m5079a();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    toolbar.setTitle(this.f10488a);
                    toolbar.setSubtitle(this.f10489a);
                } else {
                    toolbar.setTitle((CharSequence) null);
                    toolbar.setSubtitle((CharSequence) null);
                }
            }
            if ((i2 & 16) == 0 || (view = this.f10483a) == null) {
                return;
            }
            if ((i & 16) != 0) {
                toolbar.addView(view);
            } else {
                toolbar.removeView(view);
            }
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m5078a() {
        if ((this.f10482a & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f10490a);
            Toolbar toolbar = this.f10481a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f10494a);
            } else {
                toolbar.setNavigationContentDescription(this.f10490a);
            }
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m5079a() {
        Drawable drawable;
        int i = this.f10482a;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f10485a) == null) {
            drawable = this.f10484a;
        }
        this.f10481a.setLogo(drawable);
    }
}
