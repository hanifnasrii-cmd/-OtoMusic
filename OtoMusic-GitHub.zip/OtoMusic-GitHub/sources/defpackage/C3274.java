package defpackage;

/* JADX INFO: renamed from: і⳯, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3274 {
    public final InterfaceC3193 serializer() {
        return C3273.f22179a;
    }
}
