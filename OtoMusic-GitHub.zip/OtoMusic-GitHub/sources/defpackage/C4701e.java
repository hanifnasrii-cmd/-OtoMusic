package defpackage;

/* JADX INFO: renamed from: e̊, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4701e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public int f5774a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f5775a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int f5776a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f5777a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f5778a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int m2814a() {
        return Math.min(this.f5776a - this.f5774a, this.f5777a - this.f5775a);
    }
}
