package defpackage;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;

/* JADX INFO: renamed from: cⷫ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4671c implements Closeable, Flushable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C4726e f5635a;

    public C4671c(File file) {
        this.f5635a = new C4726e(file, C3947.f24119a);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m2783a(C1176 c1176) {
        AbstractC3098.m10103a(c1176, "request");
        C4726e c4726e = this.f5635a;
        C3005 c3005M7262a = c1176.m7262a();
        AbstractC3098.m10103a(c3005M7262a, "url");
        C4663c c4663c = C4663c.f5598a;
        String strMo2762a = C5165i.m3744a(c3005M7262a.f21509a).mo2760a("MD5").mo2762a();
        synchronized (c4726e) {
            AbstractC3098.m10103a(strMo2762a, "key");
            c4726e.m2851a();
            c4726e.m2847a();
            C4726e.m2846a(strMo2762a);
            C4722e c4722e = (C4722e) c4726e.f5852a.get(strMo2762a);
            if (c4722e == null) {
                return;
            }
            c4726e.m2858a(c4722e);
            if (c4726e.f5850a <= 10485760) {
                c4726e.f5858a = false;
            }
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.f5635a.close();
    }

    @Override // java.io.Flushable
    public final void flush() {
        this.f5635a.flush();
    }
}
