package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import com.google.android.material.card.MaterialCardView;
import com.piyush.music.R;

/* JADX INFO: renamed from: ι⃗, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0276 extends AbstractC0275 {

    /* JADX INFO: renamed from: a̟, reason: contains not printable characters */
    public static final SparseIntArray f12559a;

    /* JADX INFO: renamed from: a̞, reason: contains not printable characters */
    public long f12560a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f12559a = sparseIntArray;
        sparseIntArray.put(R.id.color_tile, 1);
        sparseIntArray.put(R.id.lock_chip, 2);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C0276(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 3, null, f12559a);
        MaterialCardView materialCardView = (MaterialCardView) objArrM5440a[0];
        super(null, view, materialCardView, (ImageView) objArrM5440a[2]);
        this.f12560a = -1L;
        this.f12557a.setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f12560a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f12560a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f12560a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
