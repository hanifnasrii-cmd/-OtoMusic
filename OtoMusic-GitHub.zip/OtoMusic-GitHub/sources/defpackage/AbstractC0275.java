package defpackage;

import android.view.View;
import android.widget.ImageView;
import com.google.android.material.card.MaterialCardView;

/* JADX INFO: renamed from: ι⃖, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0275 extends AbstractC6265p {

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public static final /* synthetic */ int f12556a = 0;

    /* JADX INFO: renamed from: a̛, reason: contains not printable characters */
    public final MaterialCardView f12557a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public final ImageView f12558a;

    public AbstractC0275(InterfaceC1126 interfaceC1126, View view, MaterialCardView materialCardView, ImageView imageView) {
        super(interfaceC1126, view, 0);
        this.f12557a = materialCardView;
        this.f12558a = imageView;
    }
}
