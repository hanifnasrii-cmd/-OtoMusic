package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: р֗, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class EnumC2440 {
    private static final /* synthetic */ EnumC2440[] $VALUES;
    public static final EnumC2440 BLUE;
    public static final EnumC2440 GREEN;
    public static final EnumC2440 RED;

    static {
        EnumC2440 enumC2440 = new EnumC2440("RED", 0);
        RED = enumC2440;
        EnumC2440 enumC24402 = new EnumC2440("GREEN", 1);
        GREEN = enumC24402;
        EnumC2440 enumC24403 = new EnumC2440("BLUE", 2);
        BLUE = enumC24403;
        $VALUES = new EnumC2440[]{enumC2440, enumC24402, enumC24403};
    }

    public static EnumC2440 valueOf(String str) {
        return (EnumC2440) Enum.valueOf(EnumC2440.class, str);
    }

    public static EnumC2440[] values() {
        return (EnumC2440[]) $VALUES.clone();
    }
}
