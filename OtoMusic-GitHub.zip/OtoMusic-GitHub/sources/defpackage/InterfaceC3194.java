package defpackage;

/* JADX INFO: renamed from: іۨ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC3194 extends InterfaceC3181 {
}
