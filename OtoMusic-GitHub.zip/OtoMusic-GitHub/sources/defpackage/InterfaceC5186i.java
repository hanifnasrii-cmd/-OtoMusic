package defpackage;

import java.util.Iterator;

/* JADX INFO: renamed from: iׄ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC5186i {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    Object mo3829a(Object obj);

    /* JADX INFO: renamed from: a̚, reason: contains not printable characters */
    Iterator mo3830a();
}
