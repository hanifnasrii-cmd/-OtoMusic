package defpackage;

import android.os.Parcelable;
import com.piyush.music.models.DetailSection;
import com.piyush.music.models.Song;
import com.piyush.music.sort.Sort;
import java.util.ArrayList;

/* JADX INFO: renamed from: οⷬ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC0642 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static ArrayList m6531a(ArrayList arrayList, AbstractC3646 abstractC3646, boolean z) {
        Object songSection;
        ArrayList arrayListM6532a = m6532a(arrayList, abstractC3646, z);
        ArrayList arrayList2 = new ArrayList(AbstractC2853.m9682a(arrayListM6532a, 10));
        int size = arrayListM6532a.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListM6532a.get(i);
            i++;
            Object obj2 = (Parcelable) obj;
            if (obj2 instanceof Song) {
                songSection = new DetailSection.SongSection((Song) obj2);
            } else {
                AbstractC3098.m10101a(obj2, "null cannot be cast to non-null type com.piyush.music.models.DetailSection");
                songSection = (DetailSection) obj2;
            }
            arrayList2.add(songSection);
        }
        return arrayList2;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static ArrayList m6532a(ArrayList arrayList, AbstractC3646 abstractC3646, boolean z) {
        if (arrayList.isEmpty()) {
            return arrayList;
        }
        abstractC3646.m10854a(arrayList, Sort.TRACK_NUMBER, z);
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        DetailSection.DiscSeparator discSeparator = null;
        int i = 0;
        int discNumber = 0;
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            Song song = (Song) obj;
            i++;
            if (discNumber != song.getDiscNumber()) {
                if (discSeparator != null) {
                    discSeparator.setCount(i);
                }
                discSeparator = new DetailSection.DiscSeparator(song.getDiscNumber(), i);
                arrayList2.add(discSeparator);
                discNumber = song.getDiscNumber();
                i = 0;
            }
            arrayList2.add(song);
        }
        if (discSeparator != null) {
            discSeparator.setCount(i + 1);
        }
        return arrayList2;
    }
}
