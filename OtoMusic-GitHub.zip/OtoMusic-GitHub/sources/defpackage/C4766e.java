package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: e͋, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4766e {

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static final C4766e f5959a = new C4766e(2);

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final C4766e f5960a = new C4766e(0);

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C4766e f5961a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public static final C4766e f5962a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public static final C4766e f5963a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public static final C3511 f5964a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public static final boolean f5965a;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f5966a;

    static {
        C4766e c4766e = new C4766e(1);
        f5961a = c4766e;
        f5962a = new C4766e(3);
        f5963a = c4766e;
        f5964a = C3511.m10663a(c4766e, "com.bumptech.glide.load.resource.bitmap.Downsampler.DownsampleStrategy");
        f5965a = true;
    }

    public /* synthetic */ C4766e(int i) {
        this.f5966a = i;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final EnumC4767e m2906a(int i, int i2, int i3, int i4) {
        switch (this.f5966a) {
            case 0:
                return m2907a(i, i2, i3, i4) == 1.0f ? EnumC4767e.QUALITY : f5959a.m2906a(i, i2, i3, i4);
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return EnumC4767e.QUALITY;
            case 2:
                return f5965a ? EnumC4767e.QUALITY : EnumC4767e.MEMORY;
            default:
                return EnumC4767e.QUALITY;
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float m2907a(int i, int i2, int i3, int i4) {
        switch (this.f5966a) {
            case 0:
                return Math.min(1.0f, f5959a.m2907a(i, i2, i3, i4));
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                return Math.max(i3 / i, i4 / i2);
            case 2:
                if (f5965a) {
                    return Math.min(i3 / i, i4 / i2);
                }
                if (Math.max(i2 / i4, i / i3) == 0) {
                    return 1.0f;
                }
                return 1.0f / Integer.highestOneBit(r2);
            default:
                return 1.0f;
        }
    }
}
