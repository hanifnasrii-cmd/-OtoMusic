package defpackage;

/* JADX INFO: renamed from: eⷴ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C5010e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C6091p f6841a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int[] f6842a;

    public C5010e(int i, C6091p c6091p, int[] iArr) {
        if (iArr.length == 0) {
            AbstractC3573.m10740a("ETSDefinition", "Empty tracks are not allowed", new IllegalArgumentException());
        }
        this.f6841a = c6091p;
        this.f6842a = iArr;
    }
}
