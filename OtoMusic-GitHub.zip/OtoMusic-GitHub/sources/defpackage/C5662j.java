package defpackage;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

/* JADX INFO: renamed from: jⷬ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5662j implements InterfaceC3292, InterfaceC6285p, InterfaceC5200i, InterfaceC2232 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final Context f9074a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public AbstractC5679j f9075a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Bundle f9076a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public EnumC3282 f9077a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C5672j f9078a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final String f9079a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final Bundle f9080a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final C3294 f9081a = new C3294(this);

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final C2231 f9082a = new C2231(this);

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public boolean f9083a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public EnumC3282 f9084a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public final C2233 f9085a;

    public C5662j(Context context, AbstractC5679j abstractC5679j, Bundle bundle, EnumC3282 enumC3282, C5672j c5672j, String str, Bundle bundle2) {
        this.f9074a = context;
        this.f9075a = abstractC5679j;
        this.f9076a = bundle;
        this.f9077a = enumC3282;
        this.f9078a = c5672j;
        this.f9079a = str;
        this.f9080a = bundle2;
        C3865 c3865 = new C3865(new C4242a(14, this));
        this.f9084a = EnumC3282.INITIALIZED;
        this.f9085a = (C2233) c3865.getValue();
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final Bundle m4512a() {
        Bundle bundle = this.f9076a;
        if (bundle == null) {
            return null;
        }
        return new Bundle(bundle);
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m4513a(EnumC3282 enumC3282) {
        AbstractC3098.m10103a(enumC3282, "maxState");
        this.f9084a = enumC3282;
        m4514a();
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m4514a() {
        if (!this.f9083a) {
            C2231 c2231 = this.f9082a;
            c2231.m8703a();
            this.f9083a = true;
            if (this.f9078a != null) {
                AbstractC2582.m9233a(this);
            }
            c2231.m8704a(this.f9080a);
        }
        int iOrdinal = this.f9077a.ordinal();
        int iOrdinal2 = this.f9084a.ordinal();
        C3294 c3294 = this.f9081a;
        if (iOrdinal < iOrdinal2) {
            c3294.m10364a(this.f9077a);
        } else {
            c3294.m10364a(this.f9084a);
        }
    }

    public final boolean equals(Object obj) {
        Set<String> setKeySet;
        if (obj != null && (obj instanceof C5662j)) {
            C5662j c5662j = (C5662j) obj;
            Bundle bundle = c5662j.f9076a;
            if (AbstractC3098.m10094a(this.f9079a, c5662j.f9079a) && AbstractC3098.m10094a(this.f9075a, c5662j.f9075a) && AbstractC3098.m10094a(this.f9081a, c5662j.f9081a) && AbstractC3098.m10094a(this.f9082a.f18752a, c5662j.f9082a.f18752a)) {
                Bundle bundle2 = this.f9076a;
                if (AbstractC3098.m10094a(bundle2, bundle)) {
                    return true;
                }
                if (bundle2 != null && (setKeySet = bundle2.keySet()) != null) {
                    if (setKeySet.isEmpty()) {
                        return true;
                    }
                    for (String str : setKeySet) {
                        if (!AbstractC3098.m10094a(bundle2.get(str), bundle != null ? bundle.get(str) : null)) {
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }

    @Override // defpackage.InterfaceC5200i
    public final AbstractC1070 getDefaultViewModelCreationExtras() {
        C5628j c5628j = new C5628j(0);
        Context applicationContext = this.f9074a.getApplicationContext();
        Application application = applicationContext instanceof Application ? (Application) applicationContext : null;
        LinkedHashMap linkedHashMap = c5628j.f14538a;
        if (application != null) {
            linkedHashMap.put(C6281p.f11173a, application);
        }
        linkedHashMap.put(AbstractC2582.f19756a, this);
        linkedHashMap.put(AbstractC2582.f19757a, this);
        Bundle bundleM4512a = m4512a();
        if (bundleM4512a != null) {
            linkedHashMap.put(AbstractC2582.f19758a, bundleM4512a);
        }
        return c5628j;
    }

    @Override // defpackage.InterfaceC5200i
    public final InterfaceC6282p getDefaultViewModelProviderFactory() {
        return this.f9085a;
    }

    @Override // defpackage.InterfaceC3292
    public final AbstractC3284 getLifecycle() {
        return this.f9081a;
    }

    @Override // defpackage.InterfaceC2232
    public final C2230 getSavedStateRegistry() {
        return this.f9082a.f18752a;
    }

    @Override // defpackage.InterfaceC6285p
    public final C6284p getViewModelStore() {
        if (!this.f9083a) {
            throw new IllegalStateException("You cannot access the NavBackStackEntry's ViewModels until it is added to the NavController's back stack (i.e., the Lifecycle of the NavBackStackEntry reaches the CREATED state).");
        }
        if (this.f9081a.f22205a == EnumC3282.DESTROYED) {
            throw new IllegalStateException("You cannot access the NavBackStackEntry's ViewModels after the NavBackStackEntry is destroyed.");
        }
        C5672j c5672j = this.f9078a;
        if (c5672j == null) {
            throw new IllegalStateException("You must call setViewModelStore() on your NavHostController before accessing the ViewModelStore of a navigation graph.");
        }
        String str = this.f9079a;
        AbstractC3098.m10103a(str, "backStackEntryId");
        LinkedHashMap linkedHashMap = c5672j.f9149a;
        C6284p c6284p = (C6284p) linkedHashMap.get(str);
        if (c6284p != null) {
            return c6284p;
        }
        C6284p c6284p2 = new C6284p();
        linkedHashMap.put(str, c6284p2);
        return c6284p2;
    }

    public final int hashCode() {
        Set<String> setKeySet;
        int iHashCode = this.f9075a.hashCode() + (this.f9079a.hashCode() * 31);
        Bundle bundle = this.f9076a;
        if (bundle != null && (setKeySet = bundle.keySet()) != null) {
            Iterator<T> it = setKeySet.iterator();
            while (it.hasNext()) {
                int i = iHashCode * 31;
                Object obj = bundle.get((String) it.next());
                iHashCode = i + (obj != null ? obj.hashCode() : 0);
            }
        }
        return this.f9082a.f18752a.hashCode() + ((this.f9081a.hashCode() + (iHashCode * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(C5662j.class.getSimpleName());
        sb.append("(" + this.f9079a + ')');
        sb.append(" destination=");
        sb.append(this.f9075a);
        String string = sb.toString();
        AbstractC3098.m10102a(string, "sb.toString()");
        return string;
    }
}
