package defpackage;

import android.view.View;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.recyclerview.widget.a;
import java.util.ArrayList;

/* JADX INFO: renamed from: օ͇, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3712 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final ArrayList f23456a = new ArrayList();

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f23457a = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public int f23458a = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f23459a = 0;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f23460a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ StaggeredGridLayoutManager f23461a;

    public C3712(StaggeredGridLayoutManager staggeredGridLayoutManager, int i) {
        this.f23461a = staggeredGridLayoutManager;
        this.f23460a = i;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m10909a() {
        View view = (View) this.f23456a.get(r0.size() - 1);
        C3709 c3709 = (C3709) view.getLayoutParams();
        this.f23458a = this.f23461a.f818a.mo10666a(view);
        c3709.getClass();
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m10910a() {
        this.f23456a.clear();
        this.f23457a = Integer.MIN_VALUE;
        this.f23458a = Integer.MIN_VALUE;
        this.f23459a = 0;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int m10911a() {
        return this.f23461a.f823a ? m10913a(r1.size() - 1, -1) : m10913a(0, this.f23456a.size());
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int m10912a() {
        return this.f23461a.f823a ? m10913a(0, this.f23456a.size()) : m10913a(r1.size() - 1, -1);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int m10913a(int i, int i2) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f23461a;
        int iMo10675a = staggeredGridLayoutManager.f818a.mo10675a();
        int iMo10671a = staggeredGridLayoutManager.f818a.mo10671a();
        int i3 = i2 > i ? 1 : -1;
        while (i != i2) {
            View view = (View) this.f23456a.get(i);
            int iMo10669a = staggeredGridLayoutManager.f818a.mo10669a(view);
            int iMo10666a = staggeredGridLayoutManager.f818a.mo10666a(view);
            boolean z = iMo10669a <= iMo10671a;
            boolean z2 = iMo10666a >= iMo10675a;
            if (z && z2 && (iMo10669a < iMo10675a || iMo10666a > iMo10671a)) {
                return a.m598a(view);
            }
            i += i3;
        }
        return -1;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final int m10914a(int i) {
        int i2 = this.f23458a;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        if (this.f23456a.size() == 0) {
            return i;
        }
        m10909a();
        return this.f23458a;
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final View m10915a(int i, int i2) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f23461a;
        ArrayList arrayList = this.f23456a;
        View view = null;
        if (i2 != -1) {
            int size = arrayList.size() - 1;
            while (size >= 0) {
                View view2 = (View) arrayList.get(size);
                if ((staggeredGridLayoutManager.f823a && a.m598a(view2) >= i) || ((!staggeredGridLayoutManager.f823a && a.m598a(view2) <= i) || !view2.hasFocusable())) {
                    break;
                }
                size--;
                view = view2;
            }
            return view;
        }
        int size2 = arrayList.size();
        int i3 = 0;
        while (i3 < size2) {
            View view3 = (View) arrayList.get(i3);
            if ((staggeredGridLayoutManager.f823a && a.m598a(view3) <= i) || ((!staggeredGridLayoutManager.f823a && a.m598a(view3) >= i) || !view3.hasFocusable())) {
                break;
            }
            i3++;
            view = view3;
        }
        return view;
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final int m10916a(int i) {
        int i2 = this.f23457a;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        ArrayList arrayList = this.f23456a;
        if (arrayList.size() == 0) {
            return i;
        }
        View view = (View) arrayList.get(0);
        C3709 c3709 = (C3709) view.getLayoutParams();
        this.f23457a = this.f23461a.f818a.mo10669a(view);
        c3709.getClass();
        return this.f23457a;
    }
}
