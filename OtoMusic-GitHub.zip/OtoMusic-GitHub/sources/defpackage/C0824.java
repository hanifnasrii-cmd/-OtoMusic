package defpackage;

/* JADX INFO: renamed from: ρֿ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0824 extends AbstractC0736 {
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void m6821a(String str) {
        m6654a();
        C0826.m6830a((C0826) this.f13930a, str);
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final void m6822a(String str) {
        m6654a();
        C0826.m6831a((C0826) this.f13930a, str);
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final void m6823a() {
        m6654a();
        C0826.m6832a((C0826) this.f13930a);
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void m6824a(EnumC0825 enumC0825) {
        m6654a();
        C0826.m6834a((C0826) this.f13930a, enumC0825);
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m6825a(int i) {
        m6654a();
        C0826.m6828a((C0826) this.f13930a, i);
    }
}
