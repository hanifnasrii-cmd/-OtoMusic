package defpackage;

import android.net.Uri;
import java.util.List;

/* JADX INFO: renamed from: оܾ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C2221 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final List f18728a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final Uri f18729a;

    public C2221(List list, Uri uri) {
        this.f18728a = list;
        this.f18729a = uri;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C2221)) {
            return false;
        }
        C2221 c2221 = (C2221) obj;
        return AbstractC3098.m10094a(this.f18728a, c2221.f18728a) && AbstractC3098.m10094a(this.f18729a, c2221.f18729a);
    }

    public final int hashCode() {
        return this.f18729a.hashCode() + (this.f18728a.hashCode() * 31);
    }

    public final String toString() {
        return "SavePlaylistParams(playlists=" + this.f18728a + ", uri=" + this.f18729a + ")";
    }
}
