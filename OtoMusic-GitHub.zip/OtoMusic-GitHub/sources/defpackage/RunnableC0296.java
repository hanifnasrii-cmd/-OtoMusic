package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Messenger;
import com.piyush.music.service.MusicService;
import com.piyush.taglib.AudioProperties;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/* JADX INFO: renamed from: ι⳰, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class RunnableC0296 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f12617a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Object f12618a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ Object f12619a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ Object f12620a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ Object f12621a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ Object f12622a;

    public /* synthetic */ RunnableC0296(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, int i) {
        this.f12617a = i;
        this.f12621a = obj;
        this.f12618a = obj2;
        this.f12619a = obj3;
        this.f12622a = obj4;
        this.f12620a = obj5;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f12617a) {
            case 0:
                IBinder binder = ((Messenger) ((C5141i) this.f12618a).f7193a).getBinder();
                C3097 c3097 = (C3097) this.f12621a;
                C0287 c0287 = (C0287) ((AbstractServiceC0299) c3097.f21718a).f12634a.get(binder);
                if (c0287 == null) {
                    return;
                }
                HashMap map = c0287.f12590a;
                AbstractServiceC0299 abstractServiceC0299 = (AbstractServiceC0299) c3097.f21718a;
                String str = (String) this.f12619a;
                IBinder iBinder = (IBinder) this.f12622a;
                Bundle bundle = (Bundle) this.f12620a;
                List<C3550> arrayList = (List) map.get(str);
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                for (C3550 c3550 : arrayList) {
                    if (iBinder == c3550.f22956a) {
                        Bundle bundle2 = (Bundle) c3550.f22957a;
                        if (bundle == bundle2) {
                            return;
                        }
                        if (bundle == null) {
                            if (bundle2.getInt("android.media.browse.extra.PAGE", -1) == -1 && bundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1) {
                                return;
                            }
                        } else if (bundle2 == null) {
                            if (bundle.getInt("android.media.browse.extra.PAGE", -1) == -1 && bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1) {
                                return;
                            }
                        } else if (bundle.getInt("android.media.browse.extra.PAGE", -1) == bundle2.getInt("android.media.browse.extra.PAGE", -1) && bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1) == bundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1)) {
                            return;
                        }
                    }
                }
                arrayList.add(new C3550(iBinder, bundle));
                map.put(str, arrayList);
                C0285 c0285 = new C0285(abstractServiceC0299, str, c0287, str, bundle);
                if (bundle == null) {
                    abstractServiceC0299.mo1873a(str, c0285);
                } else {
                    c0285.f12607a = 1;
                    abstractServiceC0299.mo1873a(str, c0285);
                }
                if (!c0285.m6121a()) {
                    throw new IllegalStateException(AbstractC4072a.m750a(new StringBuilder("onLoadChildren must call detach() or sendResult() before returning for package="), c0287.f12586a, " id=", str));
                }
                return;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                IBinder binder2 = ((Messenger) ((C5141i) this.f12618a).f7193a).getBinder();
                C3097 c30972 = (C3097) this.f12621a;
                if (((C0287) ((AbstractServiceC0299) c30972.f21718a).f12634a.get(binder2)) == null) {
                    return;
                }
                AbstractServiceC0299 abstractServiceC02992 = (AbstractServiceC0299) c30972.f21718a;
                String str2 = (String) this.f12619a;
                Bundle bundle3 = (Bundle) this.f12620a;
                C0286 c0286 = new C0286(str2, (C2161) this.f12622a, 1);
                c0286.mo6119a();
                C4290a c4290a = ((MusicService) abstractServiceC02992).f3826a;
                if (c4290a == null) {
                    AbstractC3098.m10141a("androidAutoHelper");
                    throw null;
                }
                if (bundle3 == null) {
                    bundle3 = Bundle.EMPTY;
                }
                C5104i c5104i = new C5104i(13, c0286);
                C5631j c5631j = c4290a.f1673a.f8935a;
                c5631j.mo4301a(c4290a.f1672a, new C4281a(c5631j, c5104i, c4290a, str2, bundle3));
                if (!c0286.m6121a()) {
                    throw new IllegalStateException(AbstractC4072a.m759a("onSearch must call detach() or sendResult() before returning for query=", str2));
                }
                return;
            default:
                try {
                    if (!(((C0420) this.f12618a).f998a instanceof C4037a)) {
                        String string = ((UUID) this.f12619a).toString();
                        C2422 c2422M8977a = ((C2405) this.f12621a).f19289a.m8977a(string);
                        if (c2422M8977a == null || c2422M8977a.f19348a.m8880a()) {
                            throw new IllegalStateException("Calls to setForegroundAsync() must complete before a ListenableWorker signals completion of work by returning an instance of Result.");
                        }
                        ((C5901o) ((C2405) this.f12621a).f19288a).m4840a(string, (C1889) this.f12622a);
                        ((Context) this.f12620a).startService(C3869.m11045a((Context) this.f12620a, AbstractC4647c.m2677a(c2422M8977a), (C1889) this.f12622a));
                    }
                    ((C0420) this.f12618a).m6277a(null);
                    return;
                } catch (Throwable th) {
                    ((C0420) this.f12618a).m6278a(th);
                    return;
                }
        }
    }

    public RunnableC0296(C3097 c3097, C5141i c5141i, String str, Bundle bundle, C2161 c2161) {
        this.f12617a = 1;
        this.f12621a = c3097;
        this.f12618a = c5141i;
        this.f12619a = str;
        this.f12620a = bundle;
        this.f12622a = c2161;
    }
}
