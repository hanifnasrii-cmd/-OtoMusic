package defpackage;

/* JADX INFO: renamed from: ο͠, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0427 {
}
