package defpackage;

import com.piyush.taglib.AudioProperties;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: јⷢ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public class C3611 implements Iterator, InterfaceC3186 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f23131a = 2;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public int f23132a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public Object f23133a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final Object f23134a;

    public C3611(Object obj, Map map) {
        AbstractC3098.m10103a(map, "map");
        this.f23133a = obj;
        this.f23134a = map;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f23131a) {
            case 0:
                return this.f23132a < ((Map) this.f23134a).size();
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C3794 c3794 = (C3794) this.f23134a;
                Iterator it = (Iterator) this.f23133a;
                while (this.f23132a < c3794.f23729a && it.hasNext()) {
                    it.next();
                    this.f23132a++;
                }
                return this.f23132a < c3794.f23730a && it.hasNext();
            default:
                return ((Iterator) this.f23133a).hasNext();
        }
    }

    @Override // java.util.Iterator
    public Object next() {
        switch (this.f23131a) {
            case 0:
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                Object obj = this.f23133a;
                this.f23132a++;
                Object obj2 = ((Map) this.f23134a).get(obj);
                if (obj2 != null) {
                    this.f23133a = ((C0024) obj2).f11664a;
                    return obj;
                }
                throw new ConcurrentModificationException("Hash code of an element (" + obj + ") has changed after it was added to the persistent set.");
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                C3794 c3794 = (C3794) this.f23134a;
                Iterator it = (Iterator) this.f23133a;
                while (this.f23132a < c3794.f23729a && it.hasNext()) {
                    it.next();
                    this.f23132a++;
                }
                int i = this.f23132a;
                if (i >= c3794.f23730a) {
                    throw new NoSuchElementException();
                }
                this.f23132a = i + 1;
                return it.next();
            default:
                C4251a c4251a = (C4251a) ((C4751e) this.f23134a).f5934a;
                int i2 = this.f23132a;
                this.f23132a = i2 + 1;
                if (i2 >= 0) {
                    return c4251a.invoke(Integer.valueOf(i2), ((Iterator) this.f23133a).next());
                }
                AbstractC2852.m9681a();
                throw null;
        }
    }

    @Override // java.util.Iterator
    public void remove() {
        switch (this.f23131a) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public C3611(C4751e c4751e) {
        this.f23134a = c4751e;
        this.f23133a = c4751e.f5933a.iterator();
    }

    public C3611(C3794 c3794) {
        this.f23134a = c3794;
        this.f23133a = c3794.f23728a.iterator();
    }
}
