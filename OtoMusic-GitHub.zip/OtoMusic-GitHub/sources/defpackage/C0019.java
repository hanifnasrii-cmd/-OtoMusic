package defpackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: ἰ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0019 implements Iterator, InterfaceC3186 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public String f11635a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f11636a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ C1460 f11637a;

    public C0019(C1460 c1460) {
        this.f11637a = c1460;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() throws IOException {
        if (this.f11635a == null && !this.f11636a) {
            String line = ((BufferedReader) this.f11637a.f16021a).readLine();
            this.f11635a = line;
            if (line == null) {
                this.f11636a = true;
            }
        }
        return this.f11635a != null;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        String str = this.f11635a;
        this.f11635a = null;
        AbstractC3098.m10100a(str);
        return str;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
