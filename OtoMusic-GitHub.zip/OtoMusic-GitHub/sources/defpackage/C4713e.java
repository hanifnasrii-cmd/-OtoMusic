package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.RelativeLayout;
import com.piyush.music.R;

/* JADX INFO: renamed from: e̖, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4713e extends AbstractC4712e {

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public static final SparseIntArray f5802a;

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public long f5803a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f5802a = sparseIntArray;
        sparseIntArray.put(R.id.frame, 1);
        sparseIntArray.put(R.id.disc_number, 2);
        sparseIntArray.put(R.id.count, 3);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C4713e(View view) {
        super(null, view, 0);
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 4, null, f5802a);
        this.f5803a = -1L;
        ((RelativeLayout) objArrM5440a[0]).setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f5803a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f5803a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f5803a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
