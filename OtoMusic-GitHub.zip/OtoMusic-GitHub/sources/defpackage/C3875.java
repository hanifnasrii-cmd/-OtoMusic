package defpackage;

/* JADX INFO: renamed from: օܽ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C3875 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final String f23917a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f23918a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f23919a;

    public C3875(String str, int i, int i2) {
        AbstractC3098.m10103a(str, "workSpecId");
        this.f23917a = str;
        this.f23918a = i;
        this.f23919a = i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3875)) {
            return false;
        }
        C3875 c3875 = (C3875) obj;
        return AbstractC3098.m10094a(this.f23917a, c3875.f23917a) && this.f23918a == c3875.f23918a && this.f23919a == c3875.f23919a;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f23919a) + AbstractC4164a.m975a(this.f23918a, this.f23917a.hashCode() * 31, 31);
    }

    public final String toString() {
        return "SystemIdInfo(workSpecId=" + this.f23917a + ", generation=" + this.f23918a + ", systemId=" + this.f23919a + ')';
    }
}
