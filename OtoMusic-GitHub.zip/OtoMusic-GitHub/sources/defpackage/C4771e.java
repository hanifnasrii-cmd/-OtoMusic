package defpackage;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/* JADX INFO: renamed from: e͐, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4771e extends AbstractC3036 {
    public C4771e(ImageView imageView) {
        super(imageView);
    }

    @Override // defpackage.AbstractC3036
    /* JADX INFO: renamed from: ȧ */
    public final void mo2417a(Object obj) {
        this.f21539a.setImageDrawable((Drawable) obj);
    }
}
