package defpackage;

/* JADX INFO: renamed from: ј̈, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3318 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C3316 f22289a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public boolean f22290a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public boolean f22291a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f22292a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public boolean f22293a;

    public C3318() {
        C3316 c3316 = new C3316();
        c3316.f22278a = -1;
        c3316.f22279a = -1;
        this.f22289a = c3316;
        this.f22292a = -1;
    }
}
