package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewStub;
import com.bumptech.glide.a;
import com.piyush.music.R;
import com.piyush.music.models.Song;
import com.piyush.music.widget.dynamic.GlowingBackgroundView;
import com.piyush.taglib.AudioProperties;
import kotlin.Metadata;

/* JADX INFO: renamed from: ιۗ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"Lιۗ;", "Lc͛;", "Lе⃮;", "<init>", "()V", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public final class C0202 extends AbstractC4452c {

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public C5150i f12259a;

    public C0202() {
        super(R.layout.c3);
    }

    @Override // defpackage.AbstractC4452c, defpackage.AbstractC4416c, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onDestroyView() {
        this.f12259a = null;
        super.onDestroyView();
    }

    @Override // defpackage.AbstractC4452c, defpackage.C4027a, androidx.fragment.app.AbstractComponentCallbacksC3990a
    public final void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        AbstractC6265p abstractC6265p = this.f4707a;
        AbstractC3098.m10100a(abstractC6265p);
        ((AbstractC1947) abstractC6265p).f11082a.setBackgroundColor(-16777216);
        AbstractC6265p abstractC6265p2 = this.f4707a;
        AbstractC3098.m10100a(abstractC6265p2);
        ViewStub viewStub = (ViewStub) ((AbstractC1947) abstractC6265p2).f17843a.f23921a;
        if (viewStub != null) {
            viewStub.inflate();
        }
        ComponentCallbacks2C2114 componentCallbacks2C2114M8566a = a.m1237a(getContext()).m8566a(this);
        Context contextRequireContext = requireContext();
        AbstractC3284 lifecycle = getLifecycle();
        AbstractC6265p abstractC6265p3 = this.f4707a;
        AbstractC3098.m10100a(abstractC6265p3);
        View view2 = (View) ((AbstractC1947) abstractC6265p3).f17843a.f23923a;
        AbstractC3098.m10101a(view2, "null cannot be cast to non-null type com.piyush.music.widget.dynamic.GlowingBackgroundView");
        this.f12259a = new C5150i(componentCallbacks2C2114M8566a, contextRequireContext, lifecycle, (GlowingBackgroundView) view2);
        final int i = 0;
        m682a().f2663a.mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: ιۖ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C0202 f12258a;

            {
                this.f12258a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                switch (i) {
                    case 0:
                        Boolean bool = (Boolean) obj;
                        C5150i c5150i = this.f12258a.f12259a;
                        if (c5150i != null) {
                            boolean zBooleanValue = bool.booleanValue();
                            C5149i c5149i = c5150i.f7248a;
                            if (c5149i.f7242a != zBooleanValue) {
                                c5149i.f7242a = zBooleanValue;
                                if (c5149i.f7243a) {
                                    C5148i c5148i = c5149i.f7245a;
                                    if (zBooleanValue) {
                                        c5149i.m3721a().removeUpdateListener(c5148i);
                                        c5149i.m3721a().resume();
                                    } else {
                                        c5149i.m3721a().addUpdateListener(c5148i);
                                    }
                                }
                            }
                        }
                        return C6174p.f10843a;
                    default:
                        Song song = (Song) obj;
                        C5150i c5150i2 = this.f12258a.f12259a;
                        if (c5150i2 != null && song.getId() != -1) {
                            C1228 c1228 = C6049p.f10434a;
                            C6049p c6049p = C6049p.f10435a;
                            if (c6049p == null) {
                                synchronized (c1228) {
                                    c6049p = C6049p.f10435a;
                                    if (c6049p == null) {
                                        c6049p = new C6049p();
                                        C6049p.f10435a = c6049p;
                                    }
                                }
                            }
                            C6049p c6049p2 = c6049p;
                            ComponentCallbacks2C2114 componentCallbacks2C2114 = c5150i2.f7246a;
                            C5141i c5141i = new C5141i(c5150i2);
                            long albumId = song.getAlbumId();
                            C2048 c2048 = new C2048();
                            Object obj2 = c6049p2.f10436a.get(Long.valueOf(albumId));
                            c2048.f18171a = obj2;
                            if (obj2 != null) {
                                c5141i.m3695a((C6047p) obj2);
                            } else {
                                C5084i c5084i = C5133i.f7171a;
                                C2104 c2104 = (C2104) C5133i.m3652a(AbstractC3098.m10095a(componentCallbacks2C2114), song).mo2237a(new C2118().mo2253a(192, 192)).mo2239a();
                                c2104.m8548a(new C6048p(c2048, c6049p2, albumId, c5141i, song), null, c2104, AbstractC5121i.f7085a);
                            }
                            break;
                        }
                        return C6174p.f10843a;
                }
            }
        }, 19));
        final int i2 = 1;
        m682a().f2660a.mo4301a(getViewLifecycleOwner(), new C4181a(new InterfaceC5040i(this) { // from class: ιۖ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C0202 f12258a;

            {
                this.f12258a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                switch (i2) {
                    case 0:
                        Boolean bool = (Boolean) obj;
                        C5150i c5150i = this.f12258a.f12259a;
                        if (c5150i != null) {
                            boolean zBooleanValue = bool.booleanValue();
                            C5149i c5149i = c5150i.f7248a;
                            if (c5149i.f7242a != zBooleanValue) {
                                c5149i.f7242a = zBooleanValue;
                                if (c5149i.f7243a) {
                                    C5148i c5148i = c5149i.f7245a;
                                    if (zBooleanValue) {
                                        c5149i.m3721a().removeUpdateListener(c5148i);
                                        c5149i.m3721a().resume();
                                    } else {
                                        c5149i.m3721a().addUpdateListener(c5148i);
                                    }
                                }
                            }
                        }
                        return C6174p.f10843a;
                    default:
                        Song song = (Song) obj;
                        C5150i c5150i2 = this.f12258a.f12259a;
                        if (c5150i2 != null && song.getId() != -1) {
                            C1228 c1228 = C6049p.f10434a;
                            C6049p c6049p = C6049p.f10435a;
                            if (c6049p == null) {
                                synchronized (c1228) {
                                    c6049p = C6049p.f10435a;
                                    if (c6049p == null) {
                                        c6049p = new C6049p();
                                        C6049p.f10435a = c6049p;
                                    }
                                }
                            }
                            C6049p c6049p2 = c6049p;
                            ComponentCallbacks2C2114 componentCallbacks2C2114 = c5150i2.f7246a;
                            C5141i c5141i = new C5141i(c5150i2);
                            long albumId = song.getAlbumId();
                            C2048 c2048 = new C2048();
                            Object obj2 = c6049p2.f10436a.get(Long.valueOf(albumId));
                            c2048.f18171a = obj2;
                            if (obj2 != null) {
                                c5141i.m3695a((C6047p) obj2);
                            } else {
                                C5084i c5084i = C5133i.f7171a;
                                C2104 c2104 = (C2104) C5133i.m3652a(AbstractC3098.m10095a(componentCallbacks2C2114), song).mo2237a(new C2118().mo2253a(192, 192)).mo2239a();
                                c2104.m8548a(new C6048p(c2048, c6049p2, albumId, c5141i, song), null, c2104, AbstractC5121i.f7085a);
                            }
                            break;
                        }
                        return C6174p.f10843a;
                }
            }
        }, 19));
    }
}
