package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.piyush.music.R;
import com.piyush.music.bottomsheet.BottomSheetBehavior;
import com.piyush.music.widget.expandablesearchview.ClippableRoundedCornerLayout;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: cܼ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4594c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final ClippableRoundedCornerLayout f5347a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float f5348a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final float[] f5349a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f5350a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public View f5351a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final BottomSheetBehavior f5352a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final int f5353a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final RectF f5354a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final boolean f5355a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public boolean f5356a;

    public C4594c(AttributeSet attributeSet, ClippableRoundedCornerLayout clippableRoundedCornerLayout) {
        this.f5347a = clippableRoundedCornerLayout;
        C4593c c4593c = new C4593c(this);
        this.f5349a = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        BottomSheetBehavior bottomSheetBehavior = new BottomSheetBehavior(clippableRoundedCornerLayout.getContext(), attributeSet);
        this.f5352a = bottomSheetBehavior;
        this.f5354a = new RectF();
        this.f5355a = true;
        this.f5356a = true;
        this.f5348a = clippableRoundedCornerLayout.getContext().getResources().getDimension(R.dimen.wc);
        TypedArray typedArrayObtainStyledAttributes = clippableRoundedCornerLayout.getContext().obtainStyledAttributes(attributeSet, AbstractC5987o.f10221a);
        this.f5348a = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        this.f5353a = typedArrayObtainStyledAttributes.getDimensionPixelSize(3, 0);
        this.f5350a = typedArrayObtainStyledAttributes.getColor(5, clippableRoundedCornerLayout.getContext().getColor(R.color.d_));
        this.f5355a = typedArrayObtainStyledAttributes.getBoolean(6, true);
        Context context = clippableRoundedCornerLayout.getContext();
        int color = -16777216;
        try {
            color = context.getTheme().obtainStyledAttributes(new int[]{R.attr.a3t}).getColor(0, -16777216);
        } catch (Exception unused) {
        }
        int iM3044a = new C4864e(clippableRoundedCornerLayout.getContext()).m3044a(typedArrayObtainStyledAttributes.getColor(2, new C4864e(context).m3044a(color, context.getResources().getDimension(R.dimen.ad6))), clippableRoundedCornerLayout.getElevation());
        clippableRoundedCornerLayout.setElevation(0.0f);
        clippableRoundedCornerLayout.setBackgroundColor(iM3044a);
        typedArrayObtainStyledAttributes.recycle();
        bottomSheetBehavior.m1645a(0);
        bottomSheetBehavior.f2930a = false;
        bottomSheetBehavior.m1644a(true);
        bottomSheetBehavior.m1647a(5);
        bottomSheetBehavior.m1639a(c4593c);
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m2486a() {
        if (this.f5355a) {
            if (this.f5351a == null) {
                ClippableRoundedCornerLayout clippableRoundedCornerLayout = this.f5347a;
                View view = new View(clippableRoundedCornerLayout.getContext());
                view.setId(R.id.og_botom_drawer_scrim);
                view.setContentDescription(null);
                view.setBackgroundColor(this.f5350a);
                view.setFitsSystemWindows(true);
                WeakHashMap weakHashMap = AbstractC6260p.f11065a;
                view.setElevation(clippableRoundedCornerLayout.getElevation());
                this.f5351a = view;
                ViewParent parent = clippableRoundedCornerLayout.getParent();
                AbstractC3098.m10101a(parent, "null cannot be cast to non-null type android.view.ViewGroup");
                View view2 = this.f5351a;
                ViewParent parent2 = clippableRoundedCornerLayout.getParent();
                AbstractC3098.m10101a(parent2, "null cannot be cast to non-null type android.view.ViewGroup");
                ((ViewGroup) parent).addView(view2, ((ViewGroup) parent2).indexOfChild(clippableRoundedCornerLayout), new C1023(-1, -1));
            }
            int i = this.f5352a.f2925a;
            View view3 = this.f5351a;
            if (view3 != null) {
                if (i != 4 && i != 5) {
                    view3.setVisibility(0);
                } else {
                    view3.setVisibility(8);
                    view3.setAlpha(0.0f);
                }
            }
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m2487a(int i, int i2, int i3, int i4) {
        this.f5354a.set(0.0f, 0.0f, i3 - i, i4 - i2);
        if (!this.f5356a) {
            m2488a(0.0f);
            return;
        }
        int i5 = this.f5352a.f2925a;
        if (i5 == 3) {
            m2488a(1.0f);
        } else if (i5 == 4 || i5 == 5) {
            m2488a(0.0f);
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m2488a(float f) {
        float fM2687a = AbstractC4647c.m2687a(this.f5348a, 0.0f, f);
        float[] fArr = this.f5349a;
        fArr[3] = fM2687a;
        fArr[2] = fM2687a;
        fArr[1] = fM2687a;
        fArr[0] = fM2687a;
        ClippableRoundedCornerLayout clippableRoundedCornerLayout = this.f5347a;
        Path path = clippableRoundedCornerLayout.f4271a;
        if (path == null) {
            path = new Path();
        }
        clippableRoundedCornerLayout.f4271a = path;
        path.reset();
        path.addRoundRect(this.f5354a, fArr, Path.Direction.CW);
        path.close();
        clippableRoundedCornerLayout.invalidate();
    }
}
