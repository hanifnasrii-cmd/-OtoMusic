package defpackage;

import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import java.lang.annotation.Annotation;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/* JADX INFO: renamed from: j̵, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5404j implements InterfaceC3238 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public Object f8228a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Object f8229a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Object f8230a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final Object f8231a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final Object f8232a;

    /* JADX WARN: Multi-variable type inference failed */
    public C5404j(C2807 c2807, InterfaceC5038i interfaceC5038i, InterfaceC5038i interfaceC5038i2, InterfaceC5038i interfaceC5038i3) {
        this.f8229a = c2807;
        this.f8230a = (AbstractC3210) interfaceC5038i;
        this.f8231a = interfaceC5038i2;
        this.f8232a = (AbstractC3210) interfaceC5038i3;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public void m4161a(ArrayList arrayList) {
        if (arrayList == null) {
            throw new IllegalArgumentException("filters must not be null");
        }
        if (arrayList.isEmpty()) {
            return;
        }
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            IntentFilter intentFilter = (IntentFilter) obj;
            if (intentFilter != null) {
                ArrayList arrayList2 = (ArrayList) this.f8231a;
                if (!arrayList2.contains(intentFilter)) {
                    arrayList2.add(intentFilter);
                }
            }
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public void m4162a(ArrayList arrayList) {
        if (arrayList.isEmpty()) {
            return;
        }
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            String str = (String) obj;
            ArrayList arrayList2 = (ArrayList) this.f8230a;
            if (TextUtils.isEmpty(str)) {
                throw new IllegalArgumentException("groupMemberId must not be empty");
            }
            if (!arrayList2.contains(str)) {
                arrayList2.add(str);
            }
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public C5405j m4163a() {
        Bundle bundle = (Bundle) this.f8229a;
        bundle.putParcelableArrayList("controlFilters", new ArrayList<>((ArrayList) this.f8231a));
        bundle.putStringArrayList("groupMemberIds", new ArrayList<>((ArrayList) this.f8230a));
        bundle.putStringArrayList("allowedPackages", new ArrayList<>((HashSet) this.f8232a));
        return new C5405j(bundle, (List) this.f8228a);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public InterfaceC4684c m4164a(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "returnType == null");
        Objects.requireNonNull(annotationArr, "annotations == null");
        List list = (List) this.f8232a;
        int iIndexOf = list.indexOf(null) + 1;
        int size = list.size();
        for (int i = iIndexOf; i < size; i++) {
            InterfaceC4684c interfaceC4684cMo2803a = ((AbstractC4683c) list.get(i)).mo2803a(type, annotationArr);
            if (interfaceC4684cMo2803a != null) {
                return interfaceC4684cMo2803a;
            }
        }
        StringBuilder sb = new StringBuilder("Could not locate call adapter for ");
        sb.append(type);
        sb.append(".\n  Tried:");
        int size2 = list.size();
        while (iIndexOf < size2) {
            sb.append("\n   * ");
            sb.append(((AbstractC4683c) list.get(iIndexOf)).getClass().getName());
            iIndexOf++;
        }
        throw new IllegalArgumentException(sb.toString());
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public Object m4165a(Class cls) {
        if (!cls.isInterface()) {
            throw new IllegalArgumentException("API declarations must be interfaces.");
        }
        ArrayDeque arrayDeque = new ArrayDeque(1);
        arrayDeque.add(cls);
        while (!arrayDeque.isEmpty()) {
            Class cls2 = (Class) arrayDeque.removeFirst();
            if (cls2.getTypeParameters().length != 0) {
                StringBuilder sb = new StringBuilder("Type parameters are unsupported on ");
                sb.append(cls2.getName());
                if (cls2 != cls) {
                    sb.append(" which is an interface of ");
                    sb.append(cls.getName());
                }
                throw new IllegalArgumentException(sb.toString());
            }
            Collections.addAll(arrayDeque, cls2.getInterfaces());
        }
        return Proxy.newProxyInstance(cls.getClassLoader(), new Class[]{cls}, new C2164(this, cls));
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public InterfaceC1014 m4166a(Type type, Annotation[] annotationArr, Annotation[] annotationArr2) {
        Objects.requireNonNull(type, "type == null");
        Objects.requireNonNull(annotationArr2, "methodAnnotations == null");
        List list = (List) this.f8228a;
        int iIndexOf = list.indexOf(null) + 1;
        int size = list.size();
        for (int i = iIndexOf; i < size; i++) {
            InterfaceC1014 interfaceC1014Mo2732a = ((AbstractC1013) list.get(i)).mo2732a(type, annotationArr);
            if (interfaceC1014Mo2732a != null) {
                return interfaceC1014Mo2732a;
            }
        }
        StringBuilder sb = new StringBuilder("Could not locate RequestBody converter for ");
        sb.append(type);
        sb.append(".\n  Tried:");
        int size2 = list.size();
        while (iIndexOf < size2) {
            sb.append("\n   * ");
            sb.append(((AbstractC1013) list.get(iIndexOf)).getClass().getName());
            iIndexOf++;
        }
        throw new IllegalArgumentException(sb.toString());
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public InterfaceC1014 m4167a(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "type == null");
        Objects.requireNonNull(annotationArr, "annotations == null");
        List list = (List) this.f8228a;
        int iIndexOf = list.indexOf(null) + 1;
        int size = list.size();
        for (int i = iIndexOf; i < size; i++) {
            InterfaceC1014 interfaceC1014Mo2733a = ((AbstractC1013) list.get(i)).mo2733a(type, annotationArr, this);
            if (interfaceC1014Mo2733a != null) {
                return interfaceC1014Mo2733a;
            }
        }
        StringBuilder sb = new StringBuilder("Could not locate ResponseBody converter for ");
        sb.append(type);
        sb.append(".\n  Tried:");
        int size2 = list.size();
        while (iIndexOf < size2) {
            sb.append("\n   * ");
            sb.append(((AbstractC1013) list.get(iIndexOf)).getClass().getName());
            iIndexOf++;
        }
        throw new IllegalArgumentException(sb.toString());
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public void m4168a(Type type, Annotation[] annotationArr) {
        Objects.requireNonNull(type, "type == null");
        List list = (List) this.f8228a;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ((AbstractC1013) list.get(i)).getClass();
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [ȋ, іܺ] */
    /* JADX WARN: Type inference failed for: r2v1, types: [ȋ, іܺ] */
    @Override // defpackage.InterfaceC3238
    public Object getValue() {
        AbstractC6278p abstractC6278p = (AbstractC6278p) this.f8228a;
        if (abstractC6278p != null) {
            return abstractC6278p;
        }
        C6284p c6284p = (C6284p) ((AbstractC3210) this.f8230a).invoke();
        InterfaceC6282p interfaceC6282p = (InterfaceC6282p) ((InterfaceC5038i) this.f8231a).invoke();
        AbstractC1070 abstractC1070 = (AbstractC1070) ((AbstractC3210) this.f8232a).invoke();
        AbstractC3098.m10103a(c6284p, "store");
        AbstractC3098.m10103a(interfaceC6282p, "factory");
        AbstractC3098.m10103a(abstractC1070, "extras");
        C5454j c5454j = new C5454j(c6284p, interfaceC6282p, abstractC1070);
        C2807 c2807 = (C2807) this.f8229a;
        String strM9578a = c2807.m9578a();
        if (strM9578a == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        AbstractC6278p abstractC6278pM4272a = c5454j.m4272a(c2807, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strM9578a));
        this.f8228a = abstractC6278pM4272a;
        return abstractC6278pM4272a;
    }

    public C5404j(InterfaceC4681c interfaceC4681c, C3005 c3005, List list, List list2, Executor executor) {
        this.f8229a = new ConcurrentHashMap();
        this.f8230a = interfaceC4681c;
        this.f8231a = c3005;
        this.f8228a = list;
        this.f8232a = list2;
    }

    public C5404j(String str, String str2) {
        this.f8230a = new ArrayList();
        this.f8231a = new ArrayList();
        this.f8232a = new HashSet();
        this.f8228a = new ArrayList();
        Bundle bundle = new Bundle();
        this.f8229a = bundle;
        if (str != null) {
            bundle.putString("id", str);
            if (str2 != null) {
                bundle.putString("name", str2);
                return;
            }
            throw new NullPointerException("name must not be null");
        }
        throw new NullPointerException("id must not be null");
    }

    public C5404j(C5405j c5405j) {
        this.f8230a = new ArrayList();
        this.f8231a = new ArrayList();
        this.f8232a = new HashSet();
        this.f8228a = new ArrayList();
        this.f8229a = new Bundle(c5405j.f8233a);
        this.f8230a = c5405j.m4171a();
        this.f8231a = c5405j.m4170a();
        this.f8232a = c5405j.m4169a();
        this.f8228a = c5405j.f8234a;
    }
}
