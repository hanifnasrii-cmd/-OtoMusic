package defpackage;

/* JADX INFO: renamed from: аͬ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1432 {
}
