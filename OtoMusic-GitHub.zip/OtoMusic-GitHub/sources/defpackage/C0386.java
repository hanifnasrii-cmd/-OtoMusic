package defpackage;

import java.util.ArrayList;
import java.util.LinkedHashSet;

/* JADX INFO: renamed from: ο̷, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0386 implements InterfaceC5584j {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final AbstractC4416c f12876a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f12877a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public AbstractC4414c f12878a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public AbstractC1082 f12879a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final C0388 f12880a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final C5481j f12881a;

    /* JADX WARN: Multi-variable type inference failed */
    public C0386(AbstractC4416c abstractC4416c, InterfaceC3292 interfaceC3292, InterfaceC0385 interfaceC0385, int i, AbstractC4414c abstractC4414c) {
        this.f12876a = (AbstractC4416c) interfaceC0385;
        this.f12877a = i;
        this.f12878a = abstractC4414c;
        C0084 c0084 = new C0084(1);
        C6284p viewModelStore = abstractC4416c.getViewModelStore();
        AbstractC1070 defaultViewModelCreationExtras = abstractC4416c.getDefaultViewModelCreationExtras();
        AbstractC3098.m10103a(viewModelStore, "store");
        AbstractC3098.m10103a(defaultViewModelCreationExtras, "defaultCreationExtras");
        C5454j c5454j = new C5454j(viewModelStore, (InterfaceC6282p) c0084, defaultViewModelCreationExtras);
        C2807 c2807M8456a = AbstractC2051.m8456a(C0388.class);
        String strM9578a = c2807M8456a.m9578a();
        if (strM9578a == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        C0388 c0388 = (C0388) c5454j.m4272a(c2807M8456a, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strM9578a));
        this.f12880a = c0388;
        C5631j c5631j = c0388.f12882a;
        this.f12881a = AbstractC2179.m8642a(c5631j, new C2298(5));
        c5631j.mo4301a(interfaceC3292, new C1999(new C5872o(14, this), 6));
        interfaceC3292.getLifecycle().mo10357a(new C0384(this));
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [c̷, ο̶] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // defpackage.InterfaceC5584j
    /* JADX INFO: renamed from: à */
    public final void mo4415a(ArrayList arrayList, int i, AbstractC2042 abstractC2042) {
        this.f12876a.mo1115a(arrayList, i, abstractC2042);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [c̷, ο̶] */
    @Override // defpackage.InterfaceC5584j
    /* JADX INFO: renamed from: á */
    public final boolean mo4416a(AbstractC2042 abstractC2042, Object obj) {
        return this.f12876a.mo1754a(abstractC2042, obj);
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m6240a() {
        C0388 c0388 = this.f12880a;
        Object objM5849a = c0388.f12882a.m5849a();
        AbstractC3098.m10100a(objM5849a);
        LinkedHashSet linkedHashSet = (LinkedHashSet) objM5849a;
        if (linkedHashSet.isEmpty()) {
            return;
        }
        linkedHashSet.clear();
        c0388.f12882a.mo4305a(linkedHashSet);
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final C5481j m6241a() {
        return this.f12881a;
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final boolean m6242a() {
        AbstractC4414c abstractC4414c = this.f12878a;
        if (abstractC4414c == null || !abstractC4414c.f4705a) {
            return false;
        }
        m6240a();
        return true;
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final boolean m6243a() {
        AbstractC4414c abstractC4414c = this.f12878a;
        return abstractC4414c != null && abstractC4414c.f4705a;
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final void m6244a() {
        m6240a();
        AbstractC1082 abstractC1082 = this.f12879a;
        if (abstractC1082 != null) {
            abstractC1082.m7114a(abstractC1082.f14584a.size(), AbstractC1082.f14569a);
        }
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m6245a() {
        AbstractC1082 abstractC1082 = this.f12879a;
        if (abstractC1082 != null) {
            abstractC1082.m7114a(abstractC1082.f14584a.size(), AbstractC1082.f14568a);
        }
    }

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final void m6246a(AbstractC1082 abstractC1082) {
        this.f12879a = abstractC1082;
    }

    @Override // defpackage.InterfaceC5584j
    /* JADX INFO: renamed from: å */
    public final void mo4417a(Object obj, boolean z) {
        C0388 c0388 = this.f12880a;
        c0388.getClass();
        LinkedHashSet linkedHashSet = new LinkedHashSet(AbstractC5120i.m3448a(obj));
        C5631j c5631j = c0388.f12882a;
        Object objM5849a = c5631j.m5849a();
        AbstractC3098.m10100a(objM5849a);
        LinkedHashSet linkedHashSet2 = (LinkedHashSet) objM5849a;
        if (z ? linkedHashSet2.addAll(linkedHashSet) : linkedHashSet2.removeAll(linkedHashSet)) {
            c5631j.mo4305a(linkedHashSet2);
        }
    }

    @Override // defpackage.InterfaceC5584j
    /* JADX INFO: renamed from: ȁ */
    public final void mo4418a(LinkedHashSet linkedHashSet) {
        C5631j c5631j = this.f12880a.f12882a;
        Object objM5849a = c5631j.m5849a();
        AbstractC3098.m10100a(objM5849a);
        LinkedHashSet linkedHashSet2 = (LinkedHashSet) objM5849a;
        if (linkedHashSet2.addAll(linkedHashSet)) {
            c5631j.mo4305a(linkedHashSet2);
        }
    }
}
