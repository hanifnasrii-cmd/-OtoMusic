package defpackage;

/* JADX INFO: renamed from: օ⃬, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3931 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C3931 f24066a = new C3931();
}
