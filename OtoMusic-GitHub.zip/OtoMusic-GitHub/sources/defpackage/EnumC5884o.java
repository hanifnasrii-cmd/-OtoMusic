package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: oۘ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC5884o {
    private static final /* synthetic */ EnumC5884o[] $VALUES;
    public static final EnumC5884o DISPLAY_P3;
    public static final EnumC5884o SRGB;

    static {
        EnumC5884o enumC5884o = new EnumC5884o("SRGB", 0);
        SRGB = enumC5884o;
        EnumC5884o enumC5884o2 = new EnumC5884o("DISPLAY_P3", 1);
        DISPLAY_P3 = enumC5884o2;
        $VALUES = new EnumC5884o[]{enumC5884o, enumC5884o2};
    }

    public static EnumC5884o valueOf(String str) {
        return (EnumC5884o) Enum.valueOf(EnumC5884o.class, str);
    }

    public static EnumC5884o[] values() {
        return (EnumC5884o[]) $VALUES.clone();
    }
}
