package defpackage;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.LinearLayout;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.piyush.music.R;

/* JADX INFO: renamed from: і͋, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C3054 extends AbstractC3053 {

    /* JADX INFO: renamed from: a̮, reason: contains not printable characters */
    public static final SparseIntArray f21588a;

    /* JADX INFO: renamed from: a̭, reason: contains not printable characters */
    public long f21589a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f21588a = sparseIntArray;
        sparseIntArray.put(R.id.til_title, 1);
        sparseIntArray.put(R.id.et_title, 2);
        sparseIntArray.put(R.id.til_album, 3);
        sparseIntArray.put(R.id.et_album, 4);
        sparseIntArray.put(R.id.til_artist, 5);
        sparseIntArray.put(R.id.et_artist, 6);
        sparseIntArray.put(R.id.til_album_artist, 7);
        sparseIntArray.put(R.id.et_album_artist, 8);
        sparseIntArray.put(R.id.til_composer, 9);
        sparseIntArray.put(R.id.et_composer, 10);
        sparseIntArray.put(R.id.til_genre, 11);
        sparseIntArray.put(R.id.et_genre, 12);
        sparseIntArray.put(R.id.til_release_type, 13);
        sparseIntArray.put(R.id.et_release_type, 14);
        sparseIntArray.put(R.id.til_year, 15);
        sparseIntArray.put(R.id.et_year, 16);
        sparseIntArray.put(R.id.til_track_number, 17);
        sparseIntArray.put(R.id.et_track_number, 18);
        sparseIntArray.put(R.id.til_track_total, 19);
        sparseIntArray.put(R.id.et_track_total, 20);
        sparseIntArray.put(R.id.til_disc_number, 21);
        sparseIntArray.put(R.id.et_disc_number, 22);
        sparseIntArray.put(R.id.til_disc_total, 23);
        sparseIntArray.put(R.id.et_disc_total, 24);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public C3054(View view) {
        Object[] objArrM5440a = AbstractC6265p.m5440a(view, 25, null, f21588a);
        TextInputEditText textInputEditText = (TextInputEditText) objArrM5440a[4];
        TextInputEditText textInputEditText2 = (TextInputEditText) objArrM5440a[8];
        TextInputEditText textInputEditText3 = (TextInputEditText) objArrM5440a[6];
        TextInputEditText textInputEditText4 = (TextInputEditText) objArrM5440a[10];
        TextInputEditText textInputEditText5 = (TextInputEditText) objArrM5440a[22];
        TextInputEditText textInputEditText6 = (TextInputEditText) objArrM5440a[24];
        TextInputEditText textInputEditText7 = (TextInputEditText) objArrM5440a[12];
        MaterialAutoCompleteTextView materialAutoCompleteTextView = (MaterialAutoCompleteTextView) objArrM5440a[14];
        TextInputEditText textInputEditText8 = (TextInputEditText) objArrM5440a[2];
        TextInputEditText textInputEditText9 = (TextInputEditText) objArrM5440a[18];
        TextInputEditText textInputEditText10 = (TextInputEditText) objArrM5440a[20];
        TextInputEditText textInputEditText11 = (TextInputEditText) objArrM5440a[16];
        TextInputLayout textInputLayout = (TextInputLayout) objArrM5440a[5];
        TextInputLayout textInputLayout2 = (TextInputLayout) objArrM5440a[9];
        TextInputLayout textInputLayout3 = (TextInputLayout) objArrM5440a[21];
        TextInputLayout textInputLayout4 = (TextInputLayout) objArrM5440a[13];
        TextInputLayout textInputLayout5 = (TextInputLayout) objArrM5440a[1];
        TextInputLayout textInputLayout6 = (TextInputLayout) objArrM5440a[17];
        super(null, view, textInputEditText, textInputEditText2, textInputEditText3, textInputEditText4, textInputEditText5, textInputEditText6, textInputEditText7, materialAutoCompleteTextView, textInputEditText8, textInputEditText9, textInputEditText10, textInputEditText11, textInputLayout, textInputLayout2, textInputLayout3, textInputLayout4, textInputLayout5, textInputLayout6);
        this.f21589a = -1L;
        ((LinearLayout) objArrM5440a[0]).setTag(null);
        m5447a(view);
        mo667a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̱ */
    public final void mo665a() {
        synchronized (this) {
            this.f21589a = 0L;
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̴ */
    public final boolean mo666a() {
        synchronized (this) {
            try {
                return this.f21589a != 0;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̶ */
    public final void mo667a() {
        synchronized (this) {
            this.f21589a = 1L;
        }
        m5445a();
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: a̺ */
    public final boolean mo668a(int i, Object obj) {
        return false;
    }

    @Override // defpackage.AbstractC6265p
    /* JADX INFO: renamed from: à */
    public final boolean mo669a(int i, Object obj) {
        return true;
    }
}
