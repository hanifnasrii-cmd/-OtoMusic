package defpackage;

/* JADX INFO: renamed from: еܲ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1878 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public static final C1228 f17518a = new C1228(11);

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final InterfaceC4869e f17519a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public int f17520a = 0;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final C1193 f17521a = new C1193();

    public C1878(InterfaceC4869e interfaceC4869e) {
        this.f17519a = interfaceC4869e;
    }
}
