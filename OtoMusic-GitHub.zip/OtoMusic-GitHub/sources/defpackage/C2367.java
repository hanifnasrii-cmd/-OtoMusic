package defpackage;

import android.view.WindowInsetsAnimation;

/* JADX INFO: renamed from: р̲, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2367 extends AbstractC2368 {

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final WindowInsetsAnimation f19203a;

    public C2367(WindowInsetsAnimation windowInsetsAnimation) {
        super(0, null, 0L);
        this.f19203a = windowInsetsAnimation;
    }

    @Override // defpackage.AbstractC2368
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final long mo8807a() {
        return this.f19203a.getDurationMillis();
    }

    @Override // defpackage.AbstractC2368
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final float mo8808a() {
        return this.f19203a.getInterpolatedFraction();
    }

    @Override // defpackage.AbstractC2368
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int mo8809a() {
        return this.f19203a.getTypeMask();
    }

    @Override // defpackage.AbstractC2368
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final void mo8810a(float f) {
        this.f19203a.setFraction(f);
    }
}
