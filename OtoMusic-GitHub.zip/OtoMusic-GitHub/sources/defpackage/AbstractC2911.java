package defpackage;

import android.os.Handler;
import android.os.Looper;

/* JADX INFO: renamed from: с߯, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public abstract class AbstractC2911 {
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static Handler m9795a(Looper looper) {
        return Handler.createAsync(looper);
    }
}
