package defpackage;

import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: renamed from: c̬, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4405c {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final CopyOnWriteArrayList f4679a;

    public C4405c() {
        this.f4679a = new CopyOnWriteArrayList();
    }
}
