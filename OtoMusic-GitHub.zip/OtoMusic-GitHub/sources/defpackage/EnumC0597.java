package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: ο߲, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0597 {
    private static final /* synthetic */ EnumC0597[] $VALUES;
    public static final EnumC0597 CONSTANT;
    public static final EnumC0597 ERROR;
    public static final EnumC0597 SLACK;
    public static final EnumC0597 UNKNOWN;
    public static final EnumC0597 UNRESTRICTED;

    static {
        EnumC0597 enumC0597 = new EnumC0597("UNRESTRICTED", 0);
        UNRESTRICTED = enumC0597;
        EnumC0597 enumC05972 = new EnumC0597("CONSTANT", 1);
        CONSTANT = enumC05972;
        EnumC0597 enumC05973 = new EnumC0597("SLACK", 2);
        SLACK = enumC05973;
        EnumC0597 enumC05974 = new EnumC0597("ERROR", 3);
        ERROR = enumC05974;
        EnumC0597 enumC05975 = new EnumC0597("UNKNOWN", 4);
        UNKNOWN = enumC05975;
        $VALUES = new EnumC0597[]{enumC0597, enumC05972, enumC05973, enumC05974, enumC05975};
    }

    public static EnumC0597 valueOf(String str) {
        return (EnumC0597) Enum.valueOf(EnumC0597.class, str);
    }

    public static EnumC0597[] values() {
        return (EnumC0597[]) $VALUES.clone();
    }
}
