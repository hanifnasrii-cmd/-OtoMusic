package defpackage;

import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: аْ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class RunnableC1510 implements Runnable {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16142a = 1;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ int f16143a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final /* synthetic */ List f16144a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final /* synthetic */ List f16145a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final /* synthetic */ Object f16146a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final /* synthetic */ Object f16147a;

    public RunnableC1510(int i, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4) {
        this.f16143a = i;
        this.f16144a = arrayList;
        this.f16145a = arrayList2;
        this.f16146a = arrayList3;
        this.f16147a = arrayList4;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.Runnable
    public final void run() {
        int i = this.f16142a;
        Object obj = this.f16147a;
        Object[] objArr = 0;
        switch (i) {
            case 0:
                ((C1513) obj).f16161a.execute(new RunnableC0673((Object) this, (Object) AbstractC2582.m9216a(new C1508(this)), 2, (boolean) (objArr == true ? 1 : 0)));
                return;
        }
        for (int i2 = 0; i2 < this.f16143a; i2++) {
            View view = (View) ((ArrayList) this.f16144a).get(i2);
            String str = (String) ((ArrayList) this.f16145a).get(i2);
            WeakHashMap weakHashMap = AbstractC6260p.f11065a;
            view.setTransitionName(str);
            ((View) ((ArrayList) this.f16146a).get(i2)).setTransitionName((String) ((ArrayList) obj).get(i2));
        }
    }

    public RunnableC1510(C1513 c1513, List list, List list2, int i, Runnable runnable) {
        this.f16147a = c1513;
        this.f16144a = list;
        this.f16145a = list2;
        this.f16143a = i;
        this.f16146a = runnable;
    }
}
