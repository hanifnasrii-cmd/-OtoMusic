package defpackage;

import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: aؔ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C4181a implements InterfaceC3422, InterfaceC5064i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f1303a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ InterfaceC5040i f1304a;

    public /* synthetic */ C4181a(InterfaceC5040i interfaceC5040i, int i) {
        this.f1303a = i;
        this.f1304a = interfaceC5040i;
    }

    @Override // defpackage.InterfaceC5064i
    /* JADX INFO: renamed from: à */
    public final InterfaceC5055i mo675a() {
        switch (this.f1303a) {
        }
        return this.f1304a;
    }

    @Override // defpackage.InterfaceC3422
    /* JADX INFO: renamed from: á */
    public final /* synthetic */ void mo676a(Object obj) {
        switch (this.f1303a) {
            case 0:
                this.f1304a.invoke(obj);
                break;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                this.f1304a.invoke(obj);
                break;
            case 2:
                this.f1304a.invoke(obj);
                break;
            case 3:
                this.f1304a.invoke(obj);
                break;
            case 4:
                this.f1304a.invoke(obj);
                break;
            case 5:
                this.f1304a.invoke(obj);
                break;
            case 6:
                this.f1304a.invoke(obj);
                break;
            case 7:
                this.f1304a.invoke(obj);
                break;
            case 8:
                this.f1304a.invoke(obj);
                break;
            case 9:
                this.f1304a.invoke(obj);
                break;
            case 10:
                this.f1304a.invoke(obj);
                break;
            case 11:
                this.f1304a.invoke(obj);
                break;
            case 12:
                this.f1304a.invoke(obj);
                break;
            case 13:
                this.f1304a.invoke(obj);
                break;
            case 14:
                this.f1304a.invoke(obj);
                break;
            case 15:
                this.f1304a.invoke(obj);
                break;
            case 16:
                this.f1304a.invoke(obj);
                break;
            case 17:
                this.f1304a.invoke(obj);
                break;
            case 18:
                this.f1304a.invoke(obj);
                break;
            case 19:
                this.f1304a.invoke(obj);
                break;
            case 20:
                this.f1304a.invoke(obj);
                break;
            case 21:
                this.f1304a.invoke(obj);
                break;
            case 22:
                this.f1304a.invoke(obj);
                break;
            case 23:
                this.f1304a.invoke(obj);
                break;
            case 24:
                this.f1304a.invoke(obj);
                break;
            case 25:
                this.f1304a.invoke(obj);
                break;
            case 26:
                this.f1304a.invoke(obj);
                break;
            case 27:
                this.f1304a.invoke(obj);
                break;
            case 28:
                this.f1304a.invoke(obj);
                break;
            default:
                this.f1304a.invoke(obj);
                break;
        }
    }

    public final boolean equals(Object obj) {
        switch (this.f1303a) {
            case 0:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 2:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 3:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 4:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 5:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 6:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 7:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 8:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 9:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 10:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 11:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 12:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 13:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 14:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 15:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 16:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 17:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 18:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 19:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 20:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 21:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 22:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 23:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 24:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 25:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 26:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 27:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            case 28:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
            default:
                if (!(obj instanceof InterfaceC3422) || !(obj instanceof InterfaceC5064i)) {
                    return false;
                }
                return this.f1304a.equals(((InterfaceC5064i) obj).mo675a());
        }
    }

    public final int hashCode() {
        switch (this.f1303a) {
        }
        return this.f1304a.hashCode();
    }
}
