package defpackage;

import android.os.Build;
import android.view.animation.Interpolator;

/* JADX INFO: renamed from: р̴, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C2369 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public AbstractC2368 f19208a;

    public C2369(int i, Interpolator interpolator, long j) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.f19208a = new C2367(AbstractC2365.m8795a(i, interpolator, j));
        } else {
            this.f19208a = new C2364(i, interpolator, j);
        }
    }
}
