package defpackage;

import android.content.Context;
import com.piyush.music.sort.Sort;

/* JADX INFO: renamed from: aّ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4194a extends C4255a {

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final String f1342a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final String f1343a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final Sort f1344a;

    public C4194a(Context context) {
        super(context, 3);
        this.f1342a = "key_add_to_playlist_sort_order_0";
        this.f1343a = "key_add_to_playlist_sort_order_asc_0";
        this.f1344a = Sort.DATE_MODIFIED;
    }

    @Override // defpackage.AbstractC3646
    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final boolean mo1040a() {
        return false;
    }

    @Override // defpackage.C4255a, defpackage.AbstractC3646
    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String mo1041a() {
        return this.f1343a;
    }

    @Override // defpackage.C4255a, defpackage.AbstractC3646
    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final Sort mo1042a() {
        return this.f1344a;
    }

    @Override // defpackage.C4255a, defpackage.AbstractC3646
    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final String mo1043a() {
        return this.f1342a;
    }
}
