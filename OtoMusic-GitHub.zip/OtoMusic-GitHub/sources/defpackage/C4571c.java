package defpackage;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import java.security.MessageDigest;

/* JADX INFO: renamed from: cۡ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4571c extends AbstractC4548c {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final int f5284a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final int f5285a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final Paint f5286a;

    public C4571c(int i, int i2) {
        this.f5284a = i;
        this.f5285a = i2;
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(3.0f);
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.f5286a = paint;
        int i3 = this.f5285a;
        if (i3 < 1) {
            throw new IllegalArgumentException("Scale factor must be >= 1");
        }
        this.f5285a = i3;
    }

    @Override // defpackage.AbstractC4548c
    /* JADX INFO: renamed from: à */
    public final Bitmap mo2425a(InterfaceC4546c interfaceC4546c, Bitmap bitmap, int i, int i2) {
        try {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            Bitmap.Config config = bitmap.getConfig();
            if (config == null) {
                config = Bitmap.Config.ARGB_8888;
            }
            Bitmap bitmapMo2419a = interfaceC4546c.mo2419a(width, height, config);
            Canvas canvas = new Canvas(bitmapMo2419a);
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, this.f5286a);
            canvas.drawColor(855638016, PorterDuff.Mode.OVERLAY);
            canvas.drawColor(1073741824);
            new C3704().m10906a(bitmapMo2419a);
            return bitmapMo2419a;
        } catch (Exception unused) {
            return bitmap;
        }
    }

    @Override // defpackage.InterfaceC3196
    public final void updateDiskCacheKey(MessageDigest messageDigest) {
        byte[] bytes = AbstractC4072a.m744a("com.piyush.music.BlurTransform(blurRadius = ", this.f5284a, ", scaleFactor = ", this.f5285a, ")").getBytes(InterfaceC3196.f21998a);
        AbstractC3098.m10102a(bytes, "getBytes(...)");
        messageDigest.update(bytes);
    }
}
