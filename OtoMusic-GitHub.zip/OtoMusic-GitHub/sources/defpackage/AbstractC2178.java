package defpackage;

import android.os.Looper;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: renamed from: о٘, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC2178 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public C1003 f18587a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public InterfaceC1031 f18588a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public Executor f18589a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public ExecutorC0405 f18590a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public C1275 f18591a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public C3106 f18592a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public boolean f18594a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final C1274 f18593a = new C1274(new C3454(0, this, AbstractC2178.class, "onClosed", "onClosed()V", 0, 2));

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public final ThreadLocal f18595a = new ThreadLocal();

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final LinkedHashMap f18596a = new LinkedHashMap();

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public boolean f18597a = true;

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final void m8604a() {
        if (this.f18594a) {
            return;
        }
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
        }
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final void m8605a() {
        if (!m8611a() || m8612a()) {
            return;
        }
        InterfaceC1031 interfaceC1031 = (InterfaceC1031) this.f18595a.get();
        if ((interfaceC1031 != null ? (C6104p) interfaceC1031.get(C6104p.f10628a) : null) != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final void m8606a() {
        m8604a();
        m8604a();
        InterfaceC3841 interfaceC3841Mo3366a = m8609a().mo3366a();
        if (!interfaceC3841Mo3366a.mo3346a()) {
            int i = 2;
            AbstractC2179.m8651a(new C1335(i, null, m8608a()));
        }
        if (interfaceC3841Mo3366a.mo3355a()) {
            interfaceC3841Mo3366a.mo3359a();
        } else {
            interfaceC3841Mo3366a.mo3348a();
        }
    }

    /* JADX INFO: renamed from: ã */
    public List mo1666a(LinkedHashMap linkedHashMap) {
        LinkedHashMap linkedHashMap2 = new LinkedHashMap(AbstractC0214.m5979a(linkedHashMap.size()));
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            linkedHashMap2.put(AbstractC3098.m10124a((InterfaceC3183) entry.getKey()), entry.getValue());
        }
        return mo651a(linkedHashMap2);
    }

    /* JADX INFO: renamed from: ā */
    public abstract C3106 mo649a();

    /* JADX INFO: renamed from: a̅ */
    public AbstractC3521 mo1667a() {
        throw new C3384(0);
    }

    /* JADX INFO: renamed from: ă */
    public InterfaceC3844 mo650a(C1141 c1141) {
        AbstractC3098.m10103a(c1141, "config");
        throw new C3384(0);
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final void m8607a() {
        m8609a().mo3366a().mo3347a();
        if (m8612a()) {
            return;
        }
        C3106 c3106M8608a = m8608a();
        c3106M8608a.f21743a.m5178a(c3106M8608a.f21746a, c3106M8608a.f21747a);
    }

    /* JADX INFO: renamed from: ä */
    public List mo651a(LinkedHashMap linkedHashMap) {
        return C4891e.f6320a;
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final C3106 m8608a() {
        C3106 c3106 = this.f18592a;
        if (c3106 != null) {
            return c3106;
        }
        AbstractC3098.m10141a("internalTracker");
        throw null;
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final InterfaceC3844 m8609a() {
        C1275 c1275 = this.f18591a;
        if (c1275 == null) {
            AbstractC3098.m10141a("connectionManager");
            throw null;
        }
        InterfaceC3844 interfaceC3844 = (InterfaceC3844) c1275.f15414a;
        if (interfaceC3844 != null) {
            return interfaceC3844;
        }
        throw new IllegalStateException("Cannot return a SupportSQLiteOpenHelper since no SupportSQLiteOpenHelper.Factory was configured with Room.");
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final InterfaceC1031 m8610a() {
        C1003 c1003 = this.f18587a;
        if (c1003 != null) {
            return c1003.f14387a;
        }
        AbstractC3098.m10141a("coroutineScope");
        throw null;
    }

    /* JADX INFO: renamed from: ǎ */
    public Set mo1668a() {
        Set<Class> setMo652a = mo652a();
        ArrayList arrayList = new ArrayList(AbstractC2853.m9682a(setMo652a, 10));
        for (Class cls : setMo652a) {
            AbstractC3098.m10103a(cls, "<this>");
            arrayList.add(AbstractC2051.m8456a(cls));
        }
        return AbstractC2851.m9673a(arrayList);
    }

    /* JADX INFO: renamed from: a̍ */
    public Set mo652a() {
        return C4894e.f6323a;
    }

    /* JADX INFO: renamed from: a̎ */
    public LinkedHashMap mo1669a() {
        Set<Map.Entry> setEntrySet = mo653a().entrySet();
        int iM5979a = AbstractC0214.m5979a(AbstractC2853.m9682a(setEntrySet, 10));
        if (iM5979a < 16) {
            iM5979a = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(iM5979a);
        for (Map.Entry entry : setEntrySet) {
            Class cls = (Class) entry.getKey();
            List list = (List) entry.getValue();
            AbstractC3098.m10103a(cls, "<this>");
            C2807 c2807M8456a = AbstractC2051.m8456a(cls);
            List<Class> list2 = list;
            ArrayList arrayList = new ArrayList(AbstractC2853.m9682a(list2, 10));
            for (Class cls2 : list2) {
                AbstractC3098.m10103a(cls2, "<this>");
                arrayList.add(AbstractC2051.m8456a(cls2));
            }
            linkedHashMap.put(c2807M8456a, arrayList);
        }
        return linkedHashMap;
    }

    /* JADX INFO: renamed from: ȁ */
    public Map mo653a() {
        return C4892e.f6321a;
    }

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public final boolean m8611a() {
        C1275 c1275 = this.f18591a;
        if (c1275 != null) {
            return ((InterfaceC3844) c1275.f15414a) != null;
        }
        AbstractC3098.m10141a("connectionManager");
        throw null;
    }

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public final boolean m8612a() {
        return m8614a() && m8609a().mo3366a().mo3346a();
    }

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public final void m8613a(InterfaceC2205 interfaceC2205) throws Exception {
        AbstractC3098.m10103a(interfaceC2205, "connection");
        C3106 c3106M8608a = m8608a();
        C6150p c6150p = c3106M8608a.f21743a;
        c6150p.getClass();
        InterfaceC2207 interfaceC2207Mo8687a = interfaceC2205.mo8687a("PRAGMA query_only");
        try {
            interfaceC2207Mo8687a.mo4767a();
            boolean zMo8688a = interfaceC2207Mo8687a.mo8688a();
            AbstractC2582.m9226a(interfaceC2207Mo8687a, null);
            if (!zMo8688a) {
                AbstractC6161p.m5209a(interfaceC2205, "PRAGMA temp_store = MEMORY");
                AbstractC6161p.m5209a(interfaceC2205, "PRAGMA recursive_triggers = 1");
                AbstractC6161p.m5209a(interfaceC2205, "DROP TABLE IF EXISTS room_table_modification_log");
                if (c6150p.f10761a) {
                    AbstractC6161p.m5209a(interfaceC2205, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
                } else {
                    AbstractC6161p.m5209a(interfaceC2205, AbstractC3786.m11006a("CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)", "TEMP", "", false));
                }
                C3420 c3420 = c6150p.f10765a;
                ReentrantLock reentrantLock = c3420.f22626a;
                reentrantLock.lock();
                try {
                    c3420.f22629a = true;
                } finally {
                    reentrantLock.unlock();
                }
            }
            synchronized (c3106M8608a.f21749a) {
            }
        } finally {
        }
    }

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public final boolean m8614a() {
        C1275 c1275 = this.f18591a;
        if (c1275 == null) {
            AbstractC3098.m10141a("connectionManager");
            throw null;
        }
        InterfaceC3841 interfaceC3841 = (InterfaceC3841) c1275.f15415a;
        if (interfaceC3841 != null) {
            return interfaceC3841.isOpen();
        }
        return false;
    }

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public final Object m8615a(InterfaceC5038i interfaceC5038i) {
        if (!m8611a()) {
            return AbstractC6161p.m5222a(this, false, true, new C4018a(14, interfaceC5038i));
        }
        m8606a();
        try {
            Object objInvoke = interfaceC5038i.invoke();
            m8616a();
            return objInvoke;
        } finally {
            m8607a();
        }
    }

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public final void m8616a() {
        m8609a().mo3366a().mo3357a();
    }

    /* JADX INFO: renamed from: a̖, reason: contains not printable characters */
    public final Object m8617a(boolean z, InterfaceC5054i interfaceC5054i, AbstractC1006 abstractC1006) {
        C1275 c1275 = this.f18591a;
        if (c1275 != null) {
            return ((InterfaceC2923) c1275.f15413a).mo9803a(z, interfaceC5054i, abstractC1006);
        }
        AbstractC3098.m10141a("connectionManager");
        throw null;
    }
}
