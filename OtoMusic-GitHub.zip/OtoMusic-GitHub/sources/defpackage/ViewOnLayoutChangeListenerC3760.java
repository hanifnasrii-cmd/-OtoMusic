package defpackage;

import android.graphics.drawable.Drawable;
import android.view.View;

/* JADX INFO: renamed from: օ֓, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class ViewOnLayoutChangeListenerC3760 implements View.OnLayoutChangeListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ View f23640a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ int f23641a;

    public ViewOnLayoutChangeListenerC3760(View view, int i) {
        this.f23640a = view;
        this.f23641a = i;
    }

    @Override // android.view.View.OnLayoutChangeListener
    public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        view.removeOnLayoutChangeListener(this);
        Drawable background = this.f23640a.getBackground();
        C0262 c0262 = background instanceof C0262 ? (C0262) background : null;
        if (c0262 != null) {
            c0262.setTint(this.f23641a);
        }
    }
}
