package defpackage;

import android.content.ComponentName;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: renamed from: j͒, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C5433j {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C5432j f8379a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final String f8380a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final String f8381a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public String f8382a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public String f8383a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public Uri f8384a;

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public boolean f8385a;

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final boolean f8386a;

    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    public int f8387a;

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public boolean f8388a;

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public int f8390a;

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public int f8391a;

    /* JADX INFO: renamed from: a̍, reason: contains not printable characters */
    public int f8392a;

    /* JADX INFO: renamed from: a̎, reason: contains not printable characters */
    public int f8393a;

    /* JADX INFO: renamed from: ȁ, reason: contains not printable characters */
    public int f8394a;

    /* JADX INFO: renamed from: a̐, reason: contains not printable characters */
    public int f8395a;

    /* JADX INFO: renamed from: a̒, reason: contains not printable characters */
    public Bundle f8397a;

    /* JADX INFO: renamed from: a̓, reason: contains not printable characters */
    public IntentSender f8398a;

    /* JADX INFO: renamed from: a̔, reason: contains not printable characters */
    public C5405j f8399a;

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final ArrayList f8389a = new ArrayList();

    /* JADX INFO: renamed from: ȃ, reason: contains not printable characters */
    public int f8396a = -1;

    /* JADX INFO: renamed from: a̕, reason: contains not printable characters */
    public ArrayList f8400a = new ArrayList();

    public C5433j(C5432j c5432j, String str, String str2, boolean z) {
        this.f8379a = c5432j;
        this.f8380a = str;
        this.f8381a = str2;
        this.f8386a = z;
    }

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public static AbstractC5423j m4221a() {
        C5435j.m4235a();
        AbstractC5424j abstractC5424j = C5435j.m4236a().f7202a;
        if (abstractC5424j instanceof AbstractC5423j) {
            return (AbstractC5423j) abstractC5424j;
        }
        return null;
    }

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final C5430j m4222a() {
        if (this instanceof C5430j) {
            return (C5430j) this;
        }
        return null;
    }

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final AbstractC5426j m4223a() {
        C5432j c5432j = this.f8379a;
        c5432j.getClass();
        C5435j.m4235a();
        return c5432j.f8374a;
    }

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final boolean m4224a() {
        C5435j.m4235a();
        C5433j c5433j = C5435j.m4236a().f7219a;
        if (c5433j != null) {
            return c5433j == this || this.f8392a == 3 || (TextUtils.equals(((ComponentName) m4223a().f8347a.f21718a).getPackageName(), "android") && m4233a("android.media.intent.category.LIVE_AUDIO") && !m4233a("android.media.intent.category.LIVE_VIDEO"));
        }
        throw new IllegalStateException("There is no default route.  The media router has not yet been fully initialized.");
    }

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final boolean m4225a() {
        return !this.f8400a.isEmpty();
    }

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public final boolean m4226a() {
        return this.f8399a != null && this.f8385a;
    }

    /* JADX INFO: renamed from: ă, reason: contains not printable characters */
    public final boolean m4227a() {
        C5435j.m4235a();
        return C5435j.m4236a().m3711a() == this;
    }

    /* JADX INFO: renamed from: ȧ, reason: contains not printable characters */
    public final boolean m4228a(C5427j c5427j) {
        if (c5427j == null) {
            throw new IllegalArgumentException("selector must not be null");
        }
        C5435j.m4235a();
        ArrayList arrayList = this.f8389a;
        if (arrayList != null) {
            c5427j.m4205a();
            if (!c5427j.f8356a.isEmpty()) {
                int size = arrayList.size();
                int i = 0;
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    IntentFilter intentFilter = (IntentFilter) obj;
                    if (intentFilter != null) {
                        Iterator it = c5427j.f8356a.iterator();
                        while (it.hasNext()) {
                            if (intentFilter.hasCategory((String) it.next())) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:68:0x0105 A[EDGE_INSN: B:131:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098], EDGE_INSN: B:132:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098], EDGE_INSN: B:133:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098], EDGE_INSN: B:134:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098, LOOP_LABEL: LOOP:0: B:35:0x0098->B:137:0x0098], EDGE_INSN: B:135:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098], EDGE_INSN: B:136:0x0105->B:68:0x0105 BREAK  A[LOOP:0: B:35:0x0098->B:137:0x0098, LOOP_LABEL: LOOP:0: B:35:0x0098->B:137:0x0098]] */
    /* JADX INFO: renamed from: ä, reason: contains not printable characters */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int m4229a(defpackage.C5405j r18) {
        /*
            Method dump skipped, instruction units count: 602
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C5433j.m4229a(j̶):int");
    }

    /* JADX INFO: renamed from: ả, reason: contains not printable characters */
    public final void m4230a(int i) {
        C5435j.m4235a();
        C5143i c5143iM4236a = C5435j.m4236a();
        int iMin = Math.min(this.f8395a, Math.max(0, i));
        AbstractC5424j abstractC5424jM3710a = c5143iM4236a.m3710a(this);
        if (abstractC5424jM3710a != null) {
            abstractC5424jM3710a.mo4122a(iMin);
        }
    }

    /* JADX INFO: renamed from: å, reason: contains not printable characters */
    public final void m4231a(int i) {
        AbstractC5424j abstractC5424jM3710a;
        C5435j.m4235a();
        if (i == 0 || (abstractC5424jM3710a = C5435j.m4236a().m3710a(this)) == null) {
            return;
        }
        abstractC5424jM3710a.mo4123a(i);
    }

    /* JADX INFO: renamed from: a̋, reason: contains not printable characters */
    public final void m4232a(boolean z) {
        C5435j.m4235a();
        C5435j.m4236a().m3714a(this, 3, z);
    }

    /* JADX INFO: renamed from: ǎ, reason: contains not printable characters */
    public final boolean m4233a(String str) {
        C5435j.m4235a();
        ArrayList arrayList = this.f8389a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            if (((IntentFilter) obj).hasCategory(str)) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("MediaRouter.RouteInfo{ uniqueId=");
        sb.append(this.f8381a);
        sb.append(", name=");
        sb.append(this.f8382a);
        sb.append(", description=");
        sb.append(this.f8383a);
        sb.append(", iconUri=");
        sb.append(this.f8384a);
        sb.append(", enabled=");
        sb.append(this.f8385a);
        sb.append(", isSystemRoute=");
        sb.append(this.f8386a);
        sb.append(", connectionState=");
        sb.append(this.f8387a);
        sb.append(", canDisconnect=");
        sb.append(this.f8388a);
        sb.append(", playbackType=");
        sb.append(this.f8390a);
        sb.append(", playbackStream=");
        sb.append(this.f8391a);
        sb.append(", deviceType=");
        sb.append(this.f8392a);
        sb.append(", volumeHandling=");
        sb.append(this.f8393a);
        sb.append(", volume=");
        sb.append(this.f8394a);
        sb.append(", volumeMax=");
        sb.append(this.f8395a);
        sb.append(", presentationDisplayId=");
        sb.append(this.f8396a);
        sb.append(", extras=");
        sb.append(this.f8397a);
        sb.append(", settingsIntent=");
        sb.append(this.f8398a);
        sb.append(", providerPackageName=");
        sb.append(((ComponentName) this.f8379a.f8377a.f21718a).getPackageName());
        if (m4225a()) {
            sb.append(", members=[");
            int size = this.f8400a.size();
            for (int i = 0; i < size; i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                if (this.f8400a.get(i) != this) {
                    sb.append(((C5433j) this.f8400a.get(i)).f8381a);
                }
            }
            sb.append(']');
        }
        sb.append(" }");
        return sb.toString();
    }
}
