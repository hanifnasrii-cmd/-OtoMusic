package defpackage;

import com.piyush.music.models.HomeItems;
import java.util.Map;

/* JADX INFO: renamed from: i⃮, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC5313i {
    /* JADX INFO: renamed from: à */
    AbstractC5316i mo3877a(Map map, long j, int i);

    /* JADX INFO: renamed from: á */
    int mo3878a();

    /* JADX INFO: renamed from: â */
    HomeItems mo3879a();

    AbstractC5312i getKey();
}
