package defpackage;

/* JADX INFO: renamed from: аܸ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C1553 extends Exception {
}
