package defpackage;

import android.graphics.RectF;
import java.util.Arrays;

/* JADX INFO: renamed from: aٓ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C4196a implements InterfaceC1027 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final InterfaceC1027 f1355a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final float f1356a;

    public C4196a(float f, InterfaceC1027 interfaceC1027) {
        while (interfaceC1027 instanceof C4196a) {
            interfaceC1027 = ((C4196a) interfaceC1027).f1355a;
            f += ((C4196a) interfaceC1027).f1356a;
        }
        this.f1355a = interfaceC1027;
        this.f1356a = f;
    }

    @Override // defpackage.InterfaceC1027
    /* JADX INFO: renamed from: à */
    public final float mo683a(RectF rectF) {
        return Math.max(0.0f, this.f1355a.mo683a(rectF) + this.f1356a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C4196a)) {
            return false;
        }
        C4196a c4196a = (C4196a) obj;
        return this.f1355a.equals(c4196a.f1355a) && this.f1356a == c4196a.f1356a;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f1355a, Float.valueOf(this.f1356a)});
    }
}
