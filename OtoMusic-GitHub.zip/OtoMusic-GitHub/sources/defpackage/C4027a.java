package defpackage;

import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.AbstractComponentCallbacksC3990a;
import com.piyush.music.R;
import com.piyush.music.activities.base.MusicServiceViewModel;
import com.piyush.taglib.AudioProperties;
import kotlin.Metadata;

/* JADX INFO: renamed from: a̒, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"La̒;", "Landroidx/fragment/app/ǎ;", "<init>", "()V", "app_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {2, 0, 0}, xi = 48)
public class C4027a extends AbstractComponentCallbacksC3990a {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public boolean f961a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C5404j f962a = AbstractC2582.m9230a(this, AbstractC2051.m8456a(MusicServiceViewModel.class), new C4026a(this, 0), new C4026a(this, 1), new C4026a(this, 2));

    /* JADX INFO: renamed from: a̜, reason: contains not printable characters */
    public InterfaceC1083 mo681a() {
        return null;
    }

    /* JADX INFO: renamed from: a̝, reason: contains not printable characters */
    public final MusicServiceViewModel m682a() {
        return (MusicServiceViewModel) this.f962a.getValue();
    }

    @Override // androidx.fragment.app.AbstractComponentCallbacksC3990a
    public void onViewCreated(View view, Bundle bundle) {
        boolean z = false;
        try {
            z = requireContext().getTheme().obtainStyledAttributes(new int[]{R.attr.te}).getBoolean(0, false);
        } catch (Exception unused) {
        }
        this.f961a = z;
        final int i = 0;
        m682a().f2660a.mo4301a(getViewLifecycleOwner(), new C4025a(new InterfaceC5040i(this) { // from class: ȁ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C4027a f956a;

            {
                this.f956a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i2 = i;
                C6174p c6174p = C6174p.f10843a;
                C4027a c4027a = this.f956a;
                switch (i2) {
                    case 0:
                        C5763o c5763o = C5601j.f8884a;
                        Boolean boolValueOf = Boolean.valueOf(C5601j.m4441a());
                        InterfaceC1083 interfaceC1083Mo681a = c4027a.mo681a();
                        if (interfaceC1083Mo681a != null) {
                            interfaceC1083Mo681a.mo7110a(C5601j.m4435a().getId(), boolValueOf);
                        }
                        break;
                    default:
                        Boolean bool = (Boolean) obj;
                        InterfaceC1083 interfaceC1083Mo681a2 = c4027a.mo681a();
                        if (interfaceC1083Mo681a2 != null) {
                            interfaceC1083Mo681a2.mo7110a(C5601j.m4435a().getId(), bool);
                        }
                        break;
                }
                return c6174p;
            }
        }, 0));
        final int i2 = 1;
        m682a().f2663a.mo4301a(getViewLifecycleOwner(), new C4025a(new InterfaceC5040i(this) { // from class: ȁ

            /* JADX INFO: renamed from: ā, reason: contains not printable characters */
            public final /* synthetic */ C4027a f956a;

            {
                this.f956a = this;
            }

            @Override // defpackage.InterfaceC5040i
            public final Object invoke(Object obj) {
                int i22 = i2;
                C6174p c6174p = C6174p.f10843a;
                C4027a c4027a = this.f956a;
                switch (i22) {
                    case 0:
                        C5763o c5763o = C5601j.f8884a;
                        Boolean boolValueOf = Boolean.valueOf(C5601j.m4441a());
                        InterfaceC1083 interfaceC1083Mo681a = c4027a.mo681a();
                        if (interfaceC1083Mo681a != null) {
                            interfaceC1083Mo681a.mo7110a(C5601j.m4435a().getId(), boolValueOf);
                        }
                        break;
                    default:
                        Boolean bool = (Boolean) obj;
                        InterfaceC1083 interfaceC1083Mo681a2 = c4027a.mo681a();
                        if (interfaceC1083Mo681a2 != null) {
                            interfaceC1083Mo681a2.mo7110a(C5601j.m4435a().getId(), bool);
                        }
                        break;
                }
                return c6174p;
            }
        }, 0));
    }
}
