package defpackage;

/* JADX INFO: renamed from: i⃧, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C5306i extends AbstractC5312i {

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public static final C5306i f7868a;

    static {
        EnumC5300i enumC5300i = EnumC5300i.SONG;
        EnumC5305i enumC5305i = EnumC5305i.ON_REPEAT;
        f7868a = new C5306i("row:forgotten_songs", enumC5300i);
    }
}
