package defpackage;

import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.ArrayDeque;
import java.util.TimerTask;

/* JADX INFO: renamed from: ρֵ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0815 extends TimerTask {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ C5378j f14066a;

    public C0815(C5378j c5378j) {
        this.f14066a = c5378j;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        BasePendingResult basePendingResultM8500a;
        C5378j c5378j = this.f14066a;
        ArrayDeque arrayDeque = c5378j.f8111a;
        if (arrayDeque.isEmpty() || c5378j.f8114a != null || c5378j.f8105a == 0) {
            return;
        }
        C2079 c2079 = c5378j.f8106a;
        int[] iArrM9453a = AbstractC2711.m9453a(arrayDeque);
        c2079.getClass();
        AbstractC2582.m9219a();
        if (c2079.m8526a()) {
            C2544 c2544 = new C2544(c2079, iArrM9453a);
            C2079.m8501a(c2544);
            basePendingResultM8500a = c2544;
        } else {
            basePendingResultM8500a = C2079.m8500a();
        }
        c5378j.f8114a = basePendingResultM8500a;
        basePendingResultM8500a.m1355a(new C0851(c5378j, 0));
        arrayDeque.clear();
    }
}
