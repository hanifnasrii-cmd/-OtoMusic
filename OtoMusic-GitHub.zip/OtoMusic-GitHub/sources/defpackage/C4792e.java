package defpackage;

import android.view.ViewGroup;

/* JADX INFO: renamed from: eͥ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4792e extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public int f6045a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public float f6046a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public boolean f6047a;

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public int f6048a;
}
