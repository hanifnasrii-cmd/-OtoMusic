package defpackage;

/* JADX INFO: renamed from: а͛, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1415 extends AbstractC1006 {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f15895a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ C1417 f15896a;

    /* JADX INFO: renamed from: a̅, reason: contains not printable characters */
    public int f15897a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1415(C1417 c1417, AbstractC1006 abstractC1006) {
        super(abstractC1006);
        this.f15896a = c1417;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        this.f15895a = obj;
        this.f15897a |= Integer.MIN_VALUE;
        return this.f15896a.m7656a(null, this);
    }
}
