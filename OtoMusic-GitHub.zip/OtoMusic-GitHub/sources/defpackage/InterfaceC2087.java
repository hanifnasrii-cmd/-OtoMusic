package defpackage;

/* JADX INFO: renamed from: оͥ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public interface InterfaceC2087 {
}
