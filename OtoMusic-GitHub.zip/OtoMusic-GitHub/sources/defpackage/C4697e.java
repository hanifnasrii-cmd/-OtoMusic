package defpackage;

/* JADX INFO: renamed from: ĕ, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C4697e {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final int f5757a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final int f5758a;

    /* JADX INFO: renamed from: â, reason: contains not printable characters */
    public final int f5759a;

    public C4697e(int i, int i2, int i3) {
        this.f5757a = i;
        this.f5758a = i2;
        this.f5759a = i3;
    }
}
