package defpackage;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import com.piyush.music.R;
import com.piyush.music.glide.artist.ArtistSignatureUtil;
import com.piyush.music.recommendation.ui.SmartPlaylistTileView;
import com.piyush.music.widget.fastscroll.FastScrollRecyclerView;
import com.piyush.taglib.AudioProperties;

/* JADX INFO: renamed from: аֽ, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1485 implements InterfaceC5038i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f16083a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ Context f16084a;

    public /* synthetic */ C1485(Context context, int i) {
        this.f16083a = i;
        this.f16084a = context;
    }

    @Override // defpackage.InterfaceC5038i
    public final Object invoke() {
        PackageInfo packageInfo;
        int i = this.f16083a;
        Context context = this.f16084a;
        switch (i) {
            case 0:
                return ArtistSignatureUtil.mPreferences_delegate$lambda$0(context);
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                PathInterpolator pathInterpolator = FastScrollRecyclerView.f4299a;
                Drawable drawableM3494a = AbstractC5121i.m3494a(context, R.drawable.ma);
                AbstractC3098.m10100a(drawableM3494a);
                return drawableM3494a;
            case 2:
                PathInterpolator pathInterpolator2 = FastScrollRecyclerView.f4299a;
                C1711 c1711 = new C1711(context);
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
                layoutParams.gravity = 49;
                layoutParams.setMarginEnd(AbstractC2411.m8929a(AbstractC5120i.m3432a(8.0f, context)));
                c1711.setLayoutParams(layoutParams);
                return c1711;
            case 3:
                return AbstractC5121i.m3492a(context.getApplicationContext());
            case 4:
                return context.getApplicationContext().getSharedPreferences("changelog_state", 0);
            case 5:
                try {
                    packageInfo = context.getApplicationContext().getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0);
                } catch (Exception unused) {
                }
                boolean z = packageInfo.firstInstallTime != packageInfo.lastUpdateTime;
                return Boolean.valueOf(z);
            case 6:
                EnumC0571 enumC0571 = SmartPlaylistTileView.f3501a;
                Typeface typefaceM8584a = AbstractC2137.m8584a(context, R.font.product_sans_medium);
                if (typefaceM8584a == null) {
                    typefaceM8584a = Typeface.SANS_SERIF;
                }
                return Typeface.create(typefaceM8584a, 0);
            case 7:
                EnumC0571 enumC05712 = SmartPlaylistTileView.f3501a;
                Typeface typefaceM8584a2 = AbstractC2137.m8584a(context, R.font.product_sans_regular);
                if (typefaceM8584a2 == null) {
                    typefaceM8584a2 = Typeface.SANS_SERIF;
                }
                return Typeface.create(typefaceM8584a2, 0);
            default:
                return AbstractC5121i.m3492a(context);
        }
    }
}
