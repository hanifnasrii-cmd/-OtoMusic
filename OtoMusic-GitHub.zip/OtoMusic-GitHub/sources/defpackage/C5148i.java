package defpackage;

import android.animation.ValueAnimator;

/* JADX INFO: renamed from: i֛, reason: invalid class name and case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class C5148i implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public final /* synthetic */ int f7234a;

    /* JADX INFO: renamed from: á, reason: contains not printable characters */
    public final /* synthetic */ C5149i f7235a;

    public /* synthetic */ C5148i(C5149i c5149i, int i) {
        this.f7234a = i;
        this.f7235a = c5149i;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        switch (this.f7234a) {
            case 0:
                Object animatedValue = valueAnimator.getAnimatedValue();
                if (animatedValue instanceof Float) {
                    Number number = (Number) animatedValue;
                    if (number.floatValue() > 0.26f && number.floatValue() < 0.28f) {
                        this.f7235a.m3721a().pause();
                        break;
                    }
                }
                break;
            default:
                Object animatedValue2 = valueAnimator.getAnimatedValue();
                if (animatedValue2 instanceof Float) {
                    C5149i c5149i = this.f7235a;
                    if (c5149i.f7237a.m7781a(((Number) animatedValue2).floatValue(), c5149i.f7240a, (C5153i) c5149i.f7238a.getValue())) {
                        c5149i.f7236a.invalidate();
                    }
                }
                break;
        }
    }
}
