package defpackage;

import android.graphics.Canvas;
import android.graphics.Paint;

/* JADX INFO: renamed from: ο֕, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class C0452 implements InterfaceC0453 {

    /* JADX INFO: renamed from: à, reason: contains not printable characters */
    public static final C0452 f13044a = new C0452();

    @Override // defpackage.InterfaceC0453
    /* JADX INFO: renamed from: à */
    public final void mo6285a(Canvas canvas, Paint paint, float f) {
        AbstractC3098.m10103a(paint, "paint");
        canvas.drawRect(0.0f, 0.0f, f, f, paint);
    }
}
