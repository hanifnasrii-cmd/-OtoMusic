package defpackage;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Space;
import com.google.android.material.imageview.ShapeableImageView;
import com.piyush.music.fragments.detail.album.AlbumDetailFragment;
import com.piyush.taglib.AudioProperties;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* JADX INFO: renamed from: ϲ͠, reason: contains not printable characters */
/* JADX INFO: loaded from: classes2.dex */
public final class ViewTreeObserverOnPreDrawListenerC1089 implements ViewTreeObserver.OnPreDrawListener {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final /* synthetic */ int f14597a = 2;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final Object f14598a;

    public ViewTreeObserverOnPreDrawListenerC1089(AlbumDetailFragment albumDetailFragment) {
        this.f14598a = albumDetailFragment;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        ViewTreeObserver viewTreeObserver;
        switch (this.f14597a) {
            case 0:
                Log.isLoggable("CustomViewTarget", 2);
                C1090 c1090 = (C1090) ((WeakReference) this.f14598a).get();
                if (c1090 == null) {
                    return true;
                }
                ArrayList arrayList = c1090.f14601a;
                View view = c1090.f14600a;
                if (arrayList.isEmpty()) {
                    return true;
                }
                int paddingRight = view.getPaddingRight() + view.getPaddingLeft();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                int i = 0;
                int iM7122a = c1090.m7122a(view.getWidth(), layoutParams != null ? layoutParams.width : 0, paddingRight);
                int paddingBottom = view.getPaddingBottom() + view.getPaddingTop();
                ViewGroup.LayoutParams layoutParams2 = view.getLayoutParams();
                int iM7122a2 = c1090.m7122a(view.getHeight(), layoutParams2 != null ? layoutParams2.height : 0, paddingBottom);
                if (iM7122a <= 0 && iM7122a != Integer.MIN_VALUE) {
                    return true;
                }
                if (iM7122a2 <= 0 && iM7122a2 != Integer.MIN_VALUE) {
                    return true;
                }
                ArrayList arrayList2 = new ArrayList(arrayList);
                int size = arrayList2.size();
                while (i < size) {
                    Object obj = arrayList2.get(i);
                    i++;
                    ((C0529) ((InterfaceC0540) obj)).m6393a(iM7122a, iM7122a2);
                }
                ViewTreeObserver viewTreeObserver2 = view.getViewTreeObserver();
                if (viewTreeObserver2.isAlive()) {
                    viewTreeObserver2.removeOnPreDrawListener(c1090.f14602a);
                }
                c1090.f14602a = null;
                arrayList.clear();
                return true;
            case AudioProperties.ChannelMode.JOINT_STEREO /* 1 */:
                Log.isLoggable("ViewTarget", 2);
                C6315p c6315p = (C6315p) ((WeakReference) this.f14598a).get();
                if (c6315p == null) {
                    return true;
                }
                ArrayList arrayList3 = c6315p.f11215a;
                View view2 = c6315p.f11214a;
                if (arrayList3.isEmpty()) {
                    return true;
                }
                int paddingRight2 = view2.getPaddingRight() + view2.getPaddingLeft();
                ViewGroup.LayoutParams layoutParams3 = view2.getLayoutParams();
                int i2 = 0;
                int iM5500a = c6315p.m5500a(view2.getWidth(), layoutParams3 != null ? layoutParams3.width : 0, paddingRight2);
                int paddingBottom2 = view2.getPaddingBottom() + view2.getPaddingTop();
                ViewGroup.LayoutParams layoutParams4 = view2.getLayoutParams();
                int iM5500a2 = c6315p.m5500a(view2.getHeight(), layoutParams4 != null ? layoutParams4.height : 0, paddingBottom2);
                if (iM5500a <= 0 && iM5500a != Integer.MIN_VALUE) {
                    return true;
                }
                if (iM5500a2 <= 0 && iM5500a2 != Integer.MIN_VALUE) {
                    return true;
                }
                ArrayList arrayList4 = new ArrayList(arrayList3);
                int size2 = arrayList4.size();
                while (i2 < size2) {
                    Object obj2 = arrayList4.get(i2);
                    i2++;
                    ((C0529) ((InterfaceC0540) obj2)).m6393a(iM5500a, iM5500a2);
                }
                ViewTreeObserver viewTreeObserver3 = view2.getViewTreeObserver();
                if (viewTreeObserver3.isAlive()) {
                    viewTreeObserver3.removeOnPreDrawListener(c6315p.f11216a);
                }
                c6315p.f11216a = null;
                arrayList3.clear();
                return true;
            default:
                AlbumDetailFragment albumDetailFragment = (AlbumDetailFragment) this.f14598a;
                AbstractC6265p abstractC6265p = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p);
                Space space = ((AbstractC4230a) abstractC6265p).f1448a;
                if (space != null && (viewTreeObserver = space.getViewTreeObserver()) != null) {
                    viewTreeObserver.removeOnPreDrawListener(this);
                }
                AbstractC6265p abstractC6265p2 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p2);
                ShapeableImageView shapeableImageView = ((AbstractC4230a) abstractC6265p2).f1442a;
                AbstractC6265p abstractC6265p3 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p3);
                Space space2 = ((AbstractC4230a) abstractC6265p3).f1448a;
                AbstractC3098.m10100a(space2);
                shapeableImageView.setLeft(space2.getLeft());
                AbstractC6265p abstractC6265p4 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p4);
                ShapeableImageView shapeableImageView2 = ((AbstractC4230a) abstractC6265p4).f1442a;
                AbstractC6265p abstractC6265p5 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p5);
                Space space3 = ((AbstractC4230a) abstractC6265p5).f1448a;
                AbstractC3098.m10100a(space3);
                shapeableImageView2.setTop(space3.getTop());
                AbstractC6265p abstractC6265p6 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p6);
                ShapeableImageView shapeableImageView3 = ((AbstractC4230a) abstractC6265p6).f1442a;
                AbstractC6265p abstractC6265p7 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p7);
                Space space4 = ((AbstractC4230a) abstractC6265p7).f1448a;
                AbstractC3098.m10100a(space4);
                int width = space4.getWidth();
                AbstractC6265p abstractC6265p8 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p8);
                Space space5 = ((AbstractC4230a) abstractC6265p8).f1448a;
                AbstractC3098.m10100a(space5);
                C2845 c2845 = new C2845(width, space5.getHeight());
                AbstractC6265p abstractC6265p9 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p9);
                Space space6 = ((AbstractC4230a) abstractC6265p9).f1448a;
                AbstractC3098.m10100a(space6);
                int left = space6.getLeft();
                AbstractC6265p abstractC6265p10 = albumDetailFragment.f4707a;
                AbstractC3098.m10100a(abstractC6265p10);
                Space space7 = ((AbstractC4230a) abstractC6265p10).f1448a;
                AbstractC3098.m10100a(space7);
                c2845.setMargins(left, space7.getTop(), 0, 0);
                shapeableImageView3.setLayoutParams(c2845);
                return false;
        }
    }

    public ViewTreeObserverOnPreDrawListenerC1089(C1090 c1090) {
        this.f14598a = new WeakReference(c1090);
    }

    public ViewTreeObserverOnPreDrawListenerC1089(C6315p c6315p) {
        this.f14598a = new WeakReference(c6315p);
    }
}
