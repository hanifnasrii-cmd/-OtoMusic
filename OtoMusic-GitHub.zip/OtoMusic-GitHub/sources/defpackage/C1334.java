package defpackage;

import android.content.SharedPreferences;
import com.piyush.audiokit.AudioKitLibrary;
import com.piyush.music.App;
import com.piyush.music.glide.artist.ArtistSignatureUtil;
import com.piyush.music.models.PlaybackEngine;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: renamed from: а̊, reason: contains not printable characters */
/* JADX INFO: loaded from: classes.dex */
public final class C1334 extends AbstractC3855 implements InterfaceC5054i {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public /* synthetic */ Object f15633a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final /* synthetic */ App f15634a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1334(App app, InterfaceC1005 interfaceC1005) {
        super(2, interfaceC1005);
        this.f15634a = app;
    }

    @Override // defpackage.AbstractC4415c
    public final InterfaceC1005 create(Object obj, InterfaceC1005 interfaceC1005) {
        C1334 c1334 = new C1334(this.f15634a, interfaceC1005);
        c1334.f15633a = obj;
        return c1334;
    }

    @Override // defpackage.InterfaceC5054i
    public final Object invoke(Object obj, Object obj2) {
        C1334 c1334 = (C1334) create((InterfaceC1044) obj, (InterfaceC1005) obj2);
        C6174p c6174p = C6174p.f10843a;
        c1334.invokeSuspend(c6174p);
        return c6174p;
    }

    @Override // defpackage.AbstractC4415c
    public final Object invokeSuspend(Object obj) {
        EnumC1045 enumC1045 = EnumC1045.COROUTINE_SUSPENDED;
        AbstractC1149.m7200a(obj);
        C1058 c1058 = this.f15634a.f2648a;
        if (c1058 == null) {
            AbstractC3098.m10141a("crashHandler");
            throw null;
        }
        ((SharedPreferences) c1058.f14504a.getValue()).getString("test", "");
        ArtistSignatureUtil.INSTANCE.getInstance(this.f15634a).getArtistSignature("test");
        C4842e c4842e = AbstractC1502.f16117a;
        App app = this.f15634a;
        if (!AbstractC1502.f16120a) {
            for (Map.Entry<String, ?> entry : app.getApplicationContext().getSharedPreferences("custom_artist_image", 0).getAll().entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (value instanceof Boolean) {
                    AbstractC1502.f16119a.put(key, value);
                }
            }
            AbstractC1502.f16120a = true;
        }
        C2054 c2054 = C1465.f16024a;
        AbstractC3386.m10482a(this.f15634a);
        C5220i c5220i = C0492.f13160a;
        C0492 c0492 = (C0492) c5220i.m3891a(this.f15634a);
        c0492.m6346a();
        c0492.m6350a();
        C2054 c20542 = AbstractC3685.f23327a;
        App app2 = this.f15634a;
        SharedPreferences sharedPreferencesM3492a = AbstractC5121i.m3492a(app2.getApplicationContext());
        if (!sharedPreferencesM3492a.getBoolean("pref_split_words_migration_done", false)) {
            C0492 c04922 = (C0492) c5220i.m3891a(app2);
            String[] strArrM6342a = c04922.m6342a();
            ArrayList arrayList = new ArrayList(strArrM6342a.length);
            for (String str : strArrM6342a) {
                arrayList.add(AbstractC3778.m10991a(str).toString());
            }
            ArrayList arrayList2 = new ArrayList();
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj2 = arrayList.get(i);
                i++;
                if (((String) obj2).length() > 0) {
                    arrayList2.add(obj2);
                }
            }
            List listM9642a = AbstractC2851.m9642a(arrayList2);
            ArrayList arrayList3 = new ArrayList();
            ArrayList arrayList4 = new ArrayList();
            for (Object obj3 : listM9642a) {
                String str2 = (String) obj3;
                if (str2.length() <= 1 || !AbstractC3685.f23327a.m8460a(str2)) {
                    arrayList4.add(obj3);
                } else {
                    arrayList3.add(obj3);
                }
            }
            if (!arrayList3.isEmpty()) {
                ArrayList arrayList5 = new ArrayList(AbstractC2853.m9682a(arrayList3, 10));
                int size2 = arrayList3.size();
                int i2 = 0;
                while (i2 < size2) {
                    Object obj4 = arrayList3.get(i2);
                    i2++;
                    String lowerCase = ((String) obj4).toLowerCase(Locale.ROOT);
                    AbstractC3098.m10102a(lowerCase, "toLowerCase(...)");
                    arrayList5.add(lowerCase);
                }
                String[] strArr = (String[]) AbstractC2851.m9642a(arrayList5).toArray(new String[0]);
                C0490 c0490 = c04922.f13173a;
                InterfaceC3192[] interfaceC3192Arr = C0492.f13161a;
                InterfaceC3192 interfaceC3192 = interfaceC3192Arr[2];
                c0490.mo6324a(strArr);
                String[] strArr2 = (String[]) arrayList4.toArray(new String[0]);
                C0490 c04902 = c04922.f13172a;
                InterfaceC3192 interfaceC31922 = interfaceC3192Arr[1];
                c04902.mo6324a(strArr2);
            }
            SharedPreferences.Editor editorEdit = sharedPreferencesM3492a.edit();
            editorEdit.putBoolean("pref_split_words_migration_done", true);
            editorEdit.apply();
        }
        try {
            C3093.f21710a.m10079a(this.f15634a);
        } catch (Throwable th) {
            AbstractC1149.m7168a(th);
        }
        if (c0492.m6353a() == PlaybackEngine.FFMPEG) {
            try {
                AudioKitLibrary.ensureLoaded();
            } catch (Throwable th2) {
                AbstractC1149.m7168a(th2);
            }
        }
        C4517c c4517c = this.f15634a.f2651a;
        if (c4517c == null) {
            AbstractC3098.m10141a("billingConfig");
            throw null;
        }
        c4517c.m2387a();
        App app3 = this.f15634a;
        C4517c c4517c2 = app3.f2651a;
        if (c4517c2 == null) {
            AbstractC3098.m10141a("billingConfig");
            throw null;
        }
        C1003 c1003 = app3.f2656a;
        Object obj5 = ((C4531c) c4517c2.m2387a()).f5196a.get(c4517c2.m2388a());
        AbstractC3098.m10100a(obj5);
        AbstractC1149.m7189a(new C1830(AbstractC1149.m7169a(new C4521c(1, (InterfaceC5636j) obj5), 1000L), new C4516c()), c1003);
        return C6174p.f10843a;
    }
}
