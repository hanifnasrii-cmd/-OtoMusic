package nl.dionsegijn.konfetti;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import com.piyush.taglib.AudioProperties;
import defpackage.AbstractC2857;
import defpackage.AbstractC3086;
import defpackage.AbstractC3098;
import defpackage.C1945;
import defpackage.C2086;
import defpackage.C2914;
import defpackage.C3089;
import defpackage.C3090;
import defpackage.C3203;
import defpackage.C3580;
import defpackage.C3769;
import defpackage.C4325a;
import defpackage.C6214p;
import defpackage.InterfaceC3467;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;

/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\b\u0016\u0018\u00002\u00020\u0001:\u0001\u0013B\u001d\b\u0016\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0013\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\b¢\u0006\u0004\b\n\u0010\u000bR$\u0010\r\u001a\u0004\u0018\u00010\f8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\r\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012¨\u0006\u0014"}, d2 = {"Lnl/dionsegijn/konfetti/KonfettiView;", "Landroid/view/View;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "", "Lј⃑;", "getActiveSystems", "()Ljava/util/List;", "Lјֹ;", "onParticleSystemUpdateListener", "Lјֹ;", "getOnParticleSystemUpdateListener", "()Lјֹ;", "setOnParticleSystemUpdateListener", "(Lјֹ;)V", "іܳ", "konfetti_release"}, k = AudioProperties.ChannelMode.JOINT_STEREO, mv = {AudioProperties.ChannelMode.JOINT_STEREO, 4, AudioProperties.ChannelMode.JOINT_STEREO})
public class KonfettiView extends View {

    /* JADX INFO: renamed from: ã, reason: contains not printable characters */
    public final ArrayList f9195a;

    /* JADX INFO: renamed from: ā, reason: contains not printable characters */
    public final C3203 f9196a;

    public KonfettiView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f9195a = new ArrayList();
        C3203 c3203 = new C3203();
        c3203.f22030a = -1L;
        this.f9196a = c3203;
    }

    public final List<C3580> getActiveSystems() {
        return this.f9195a;
    }

    public final InterfaceC3467 getOnParticleSystemUpdateListener() {
        return null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        float f;
        boolean z;
        Canvas canvas2;
        long j;
        float f2;
        Canvas canvas3;
        int i;
        Canvas canvas4 = canvas;
        AbstractC3098.m10103a(canvas4, "canvas");
        super.onDraw(canvas);
        C3203 c3203 = this.f9196a;
        if (c3203.f22030a == -1) {
            c3203.f22030a = System.nanoTime();
        }
        float f3 = (r3 - c3203.f22030a) / 1000000.0f;
        c3203.f22030a = System.nanoTime();
        float f4 = 1000;
        float f5 = f3 / f4;
        ArrayList arrayList = this.f9195a;
        boolean z2 = true;
        int size = arrayList.size() - 1;
        while (size >= 0) {
            C3580 c3580 = (C3580) arrayList.get(size);
            C2086 c2086 = c3580.f23052a;
            if (c2086 == null) {
                AbstractC3098.m10141a("renderSystem");
                throw null;
            }
            long jCurrentTimeMillis = System.currentTimeMillis() - c2086.f18309a;
            c3580.f23050a.getClass();
            if (jCurrentTimeMillis >= 0) {
                C2086 c20862 = c3580.f23052a;
                if (c20862 == null) {
                    AbstractC3098.m10141a("renderSystem");
                    throw null;
                }
                ArrayList arrayList2 = c20862.f18300a;
                if (c20862.f18298a) {
                    C3769 c3769 = c20862.f18308a;
                    j = 0;
                    float f6 = c3769.f23678a + f5;
                    c3769.f23678a = f6;
                    float f7 = c3769.f23677a;
                    if (f6 >= f7 && c3769.f23676a < 4000) {
                        int i2 = (int) (f6 / f7);
                        int i3 = 1;
                        Iterator it = new C3090(1, i2, 1).iterator();
                        while (((C3089) it).f21705a) {
                            ((AbstractC3086) it).nextInt();
                            c3769.f23675a += i3;
                            C4325a c4325a = c3769.f23674a;
                            if (c4325a != null) {
                                c4325a.invoke();
                            }
                            i3 = 1;
                        }
                        c3769.f23678a %= c3769.f23677a;
                    }
                    c3769.f23676a = (f5 * f4) + c3769.f23676a;
                } else {
                    j = 0;
                }
                z = true;
                int size2 = arrayList2.size() - 1;
                while (size2 >= 0) {
                    C2914 c2914 = (C2914) arrayList2.get(size2);
                    C6214p c6214p = c20862.f18303a;
                    c2914.getClass();
                    C6214p c6214p2 = c2914.f20952a;
                    AbstractC3098.m10103a(c6214p, "force");
                    float f8 = (c6214p.f10929a * 0.2f) + c6214p2.f10929a;
                    c6214p2.f10929a = f8;
                    float f9 = (c6214p.f10930a * 0.2f) + c6214p2.f10930a;
                    c6214p2.f10930a = f9;
                    float f10 = c2914.f20940a;
                    C6214p c6214p3 = c2914.f20947a;
                    C6214p c6214p4 = c2914.f20953a;
                    int i4 = size2;
                    float f11 = c2914.f20945a;
                    c6214p4.f10929a += f8;
                    c6214p4.f10930a += f9;
                    float f12 = f5 * f11;
                    c6214p3.f10929a = (c6214p4.f10929a * f12) + c6214p3.f10929a;
                    float f13 = (c6214p4.f10930a * f12) + c6214p3.f10930a;
                    c6214p3.f10930a = f13;
                    C2086 c20863 = c20862;
                    long j2 = c2914.f20950a;
                    if (j2 <= j) {
                        if (!c2914.f20951a || (i = c2914.f20946a - ((int) ((5 * f5) * f11))) < 0) {
                            i = 0;
                        }
                        c2914.f20946a = i;
                    } else {
                        c2914.f20950a = j2 - ((long) (f5 * f4));
                    }
                    float f14 = c2914.f20942a * f5 * f11;
                    float f15 = c2914.f20943a + f14;
                    c2914.f20943a = f15;
                    if (f15 >= 360) {
                        c2914.f20943a = 0.0f;
                    }
                    float f16 = c2914.f20944a - f14;
                    c2914.f20944a = f16;
                    float f17 = 0;
                    if (f16 < f17) {
                        c2914.f20944a = f10;
                    }
                    Paint paint = c2914.f20941a;
                    if (f13 > canvas.getHeight()) {
                        c2914.f20950a = j;
                    } else {
                        if (c6214p3.f10929a <= canvas.getWidth() && c6214p3.f10929a + f10 >= f17 && c6214p3.f10930a + f10 >= f17) {
                            paint.setColor((c2914.f20946a << 24) | (c2914.f20948a & 16777215));
                            float f18 = 2;
                            float fAbs = Math.abs((c2914.f20944a / f10) - 0.5f) * f18;
                            float f19 = (fAbs * f10) / f18;
                            int iSave = canvas.save();
                            f2 = f4;
                            canvas3 = canvas;
                            canvas3.translate(c6214p3.f10929a - f19, c6214p3.f10930a);
                            canvas3.rotate(c2914.f20943a, f19, f10 / f18);
                            canvas3.scale(fAbs, 1.0f);
                            c2914.f20949a.mo6285a(canvas3, paint, f10);
                            canvas3.restoreToCount(iSave);
                        }
                        size2 = i4 - 1;
                        canvas4 = canvas3;
                        f4 = f2;
                        c20862 = c20863;
                        j = 0;
                    }
                    f2 = f4;
                    canvas3 = canvas;
                    size2 = i4 - 1;
                    canvas4 = canvas3;
                    f4 = f2;
                    c20862 = c20863;
                    j = 0;
                }
                f = f4;
                canvas2 = canvas4;
                AbstractC2857.m9686a(arrayList2, C1945.f17832a);
            } else {
                f = f4;
                z = z2;
                canvas2 = canvas4;
            }
            C2086 c20864 = c3580.f23052a;
            if (c20864 == null) {
                AbstractC3098.m10141a("renderSystem");
                throw null;
            }
            ArrayList arrayList3 = c20864.f18300a;
            C3769 c37692 = c20864.f18308a;
            c37692.getClass();
            if ((c37692.f23676a >= 4000 && arrayList3.size() == 0) || (!c20864.f18298a && arrayList3.size() == 0)) {
                arrayList.remove(size);
            }
            size--;
            canvas4 = canvas2;
            z2 = z;
            f4 = f;
        }
        if (arrayList.size() != 0) {
            invalidate();
        } else {
            c3203.f22030a = -1L;
        }
    }

    public final void setOnParticleSystemUpdateListener(InterfaceC3467 interfaceC3467) {
    }
}
